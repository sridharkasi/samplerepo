package app.wmAweb.testcases.Disbursements;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.HCCExpressAdd;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.Disbursements.FullSurrender;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.Disbursements.RMDQuote;
import pageobjects.wmA.Disbursements.RMDSubmenu;
import pageobjects.wmA.Disbursements.SystematicWithdrawal;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Value.Value;


public class GW_StateFedralWithholdingTest {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	

	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_Statewithholding_TKM(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate_sys"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln,"ClickOnriderbox");
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Rider information
			 * .
			 *//*	
		    HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);					
		    Web.clickOnElement(rider,"HCC_ClickOn_Add");
		    Web.waitForElement(rider, "HCC_Select_RiderPlan");
		    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);					
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			
			
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			
			g.ClickRMDSubmenu();
			
		    RMDSubmenu RM= new RMDSubmenu(g);
		    RM.get();
		    RM.enterEffectivedate(Stock.GetParameterValue("RMD_ED"));
		    RM.enterStartdate(Stock.GetParameterValue("Startdate"));
		    Thread.sleep(5000);
		    RM.enterEnddate(Stock.GetParameterValue("Enddate"));
		    
		    RM.enterNextpayoutdate(Stock.GetParameterValue("NextPayoutDate"));
		    RM.enteroverrideamount(Stock.GetParameterValue("Overrideamount"));
		    RM.SelectRMDType(Stock.GetParameterValue("RMDType"));
		    RM.SelectSourcecode(Stock.GetParameterValue("SourceCode"));
		    
		    Realtime_update RTU = new Realtime_update(RM);
		    RTU.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			g.clickhistorysubmenu();
			Transaction trs = new Transaction(RTU);
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			//Want to verify whether ZMDItransaction is trigger after doing the real time update
			trs.verifyZMDI_RMDtransaction();
		    Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the ZMDI_RMD transaction", true);
	         g.ClickonmaintenanceSubmenu();
			
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("Startdate"));
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

		    g.clickhistorysubmenu();
			
			
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the TKM transaction happen on the effective date which we have given
			trs.verifyTKMtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TKM tranasaction", true);
			trs.doubleclickTBTransaction();
			Thread.sleep(5000);
			trs.FedralWithhodlingCalc();
			Reporter.logEvent(Status.INFO, "TKM detailed page", "page is Loaded and verifiyed the Federeal amount successfully", true);
			trs.StateWithholdingCalc();
			Reporter.logEvent(Status.INFO, "TKM detailed page", "page is Loaded and verifiyed the AmtWithheldState amount successfully", true);
			SelectPartner sp = new SelectPartner(trs);
			Summary su = new Summary(sp);
		    Web.clickOnElement(su,"Summary_Homebtn");
			Web.waitForElement(sp,"accumulationlink");
		
			
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_StateWithholdoing_FedralWithholding_TB(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnriderbox");
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 15 - Enter Rider information .
			 *//*
			HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);
			Web.clickOnElement(rider, "HCC_ClickOn_Add");
			Web.waitForElement(rider, "HCC_Select_RiderPlan");
			Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.clickpartialsurrender();

			PartialSurrender psurrender = new PartialSurrender(g);
			psurrender.get();
			psurrender.seteffectivedate(Stock.GetParameterValue("PartialEffectiveDate"));
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			psurrender.EnterPartialSurrenderFund();
			// psurrender.clickwithholdingoverride();
			// psurrender.EnterStateoverideamt(Stock.GetParameterValue("StateOverideAmt"));
			psurrender.clickoverirde();
			Summary su = new Summary(psurrender);
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Partial Surrender Page", "page is Loaded ", true);

			g.clickhistorysubmenu();

			Transaction trs = new Transaction(psurrender);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the TB transaction happen on the effective date which
			// we have given
			trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
			trs.doubleclickTBTransaction();
			trs.FedralWithhodlingCalc();
			trs.StateWithholdingCalc();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TB tranasaction", true);

			g.ClickonValueSubmenu();
			Value val = new Value(trs);
			val.get();
			Thread.sleep(1500);
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
			Web.clickOnElement(val, "Value_updateButton");
			// Want to verify the value
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for each fund", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner (val);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_Statewithholding_Fullsurrender(int itr, Map<String, String> testdata) {
try {
			
			
			
	Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
			+ "_" + Stock.getConfigParam("BROWSER"));
	Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

	
	/*SelectPartner sp = new SelectPartner(landing);
	sp.get();
	Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
	Web.clickOnElement(sp, "accumulationlink");

	*//**
	 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
	 * product and click Next. Partner is successfully selected and Select Criteria
	 * Page is loaded
	 * 
	 *//*
	sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
	Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 3 - Enter an effective date which should match the current system date
	 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
	 * Select a non-NY state from the Issue State drop-down box and click next .
	 *//*
	SelectCriteria sc = new SelectCriteria(sp);
	sc.get();
	sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
	 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
	 * column
	 * 
	 * .
	 *//*
	SelectPlan pln = new SelectPlan(sc);
	pln.get();
	pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
			Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
	Web.clickOnElement(pln, "ClickOnriderbox");
	Web.clickOnElement(pln, "ClickOnCashCheckbox");
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 9 - Click on Party Search and search for an advisor to add onto the
	 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
	 * Enter First Year % and Renewal % and click Next .
	 *//*

	ProducerInfo pi = new ProducerInfo(pln);
	pi.get();
	pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
	Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
	Common.switchto_newwindow();
	Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
	Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
	Common.switchto_mainwindow();
	pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
			Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
	Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 12 - Add a new client by filling out the Annuitant Information and
	 * Address fields and click next. .
	 *//*
	AnnuitantInfo ai = new AnnuitantInfo(pi);
	ai.get();
	ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
			Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
	Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 13 - Enter contract information .
	 *//*
	ContractInfo ci = new ContractInfo(ai);
	ci.get();
	ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
	Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 14 - Enter Billing information .
	 *//*
	BillingInfo bi = new BillingInfo(ci);
	bi.get();
	bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
	bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
	Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 15 - Enter Rider information .
	 *//*
	HCCExpressAdd rider = new HCCExpressAdd(bi);
	Web.waitForElement(rider, "HCC_Select_RiderType");
	Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);
	Web.clickOnElement(rider, "HCC_ClickOn_Add");
	Web.waitForElement(rider, "HCC_Select_RiderPlan");
	Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);
	Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 16 - Enter Fund information .
	 *//*
	FundInfo fi = new FundInfo(rider);
	fi.get();
	fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
	Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");
	*//**
	 * Step 17 - Click submit real time processing summary Finish button verify the
	 * Transaction message .
	 *//*

	PaymentAdd pa = new PaymentAdd(fi);
	pa.get();
	pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
	pa.MemoCode(Stock.GetParameterValue("MemoCode"));
	Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
	Web.clickOnElement(sp, "Next_Button");

	Summary su = new Summary(pa);
	su.get();
	Web.waitForElement(su, "Summary_Realtimewait");
	Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
	Web.clickOnElement(su, "Summary_Finishbtn");
	su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
	su.getpolicynumber();
	Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
	Web.clickOnElement(su, "Summary_NavigateButton");
	Web.waitForElement(su, "Summary_Fund");*/

	Common.CreateContractAdd();
	LandingPage landing = new LandingPage();
		General g = new General(landing);
	
     	g.clickFullsurrender();
     	FullSurrender fsurrender = new FullSurrender(g);
        fsurrender.seteffectivedatefullsurrender(Stock.GetParameterValue("EffectiveDate_full"));
		fsurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
		fsurrender.RealtimeDrpDwn(Stock.GetParameterValue("Full_realtime"));
		fsurrender.clickoverirde();
		fsurrender.clicksumbmit();
		fsurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

	g.clickhistorysubmenu();

	Transaction trs = new Transaction(fsurrender);
	trs.get();
	Web.waitForElement(trs, "Transaction_updateBT");
	Web.clickOnElement(trs, "Transaction_updateBT");
	// want to verify whether the TAtransaction happen on the effective date which
	// we have given
	trs.verifyTAtransaction(Stock.GetParameterValue("EffectiveDate_full"));
	Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TA tranasaction", true);
	trs.doubleclickTBTransaction();
	trs.FedralWithhodlingCalc();
	trs.StateWithholdingCalc();
	Reporter.logEvent(Status.INFO, "TA transaction page", "page is Loaded and verifiyed the federal and state withholding amount", true);

	g.ClickonValueSubmenu();
	Value val = new Value(trs);
	val.get();
	Thread.sleep(1500);
	val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("EffectiveDate_full"));
	Web.clickOnElement(val, "Value_updateButton");
	// Want to verify the value
	Common.VerifyFundAllocationChange();
	Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for each fund", true);
	Summary su = new Summary(val);
	SelectPartner sp = new SelectPartner(su);
	Web.clickOnElement(su, "Summary_Homebtn");
	Web.waitForElement(sp, "accumulationlink");
			
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_Statewithholding_DeathClaim1(int itr, Map<String, String> testdata) {

		try {
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			/*LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			Summary su = new Summary(g);
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Clicked on DeathClaim Submenu", true);
			
			DeathClaim dc = new DeathClaim(g);			
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
		//	Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("ctradd_realtime"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			trs.doubleclickTBTransaction();
			trs.FedralWithhodlingCalc();
			trs.StateWithholdingCalc();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TA tranasaction", true);
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
		    SelectPartner sp = new SelectPartner(trs);
		    Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_Statewithholding_SystematicWithdrawal(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		
			LandingPage landing = new LandingPage();
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		   
		    
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");
			su.clicksystematicwithdrawal();*/
			Common.CreateContractAdd();
			General g = new General(landing);
			g.get();
			g.clicksystematicwithdrawal();
			
			SystematicWithdrawal swd = new SystematicWithdrawal(g);
			swd.get();
			/*swd.clickhomebutton();
			swd.entercontractid(Stock.GetParameterValue("ContractID"));
			swd.clicksearchbutton();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded and entered the contratc id", true);*/
			
			swd.clickaddbutton();
			swd.setsyseffectivedate(Stock.GetParameterValue("EffectiveDate_sys"));			
			swd.setstartdate(Stock.GetParameterValue("Startdate"));
			swd.setenddate(Stock.GetParameterValue("Enddate"));
			swd.transactionlevel(Stock.GetParameterValue("TransactionLevel"));
			swd.paymentmode(Stock.GetParameterValue("Paymentmode"));			
			swd.EnterFundAmount(Stock.GetParameterValue("PayoutAmount"));
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));
			swd.clicksumbmit();
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//*******************
			swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			//********************/
			Reporter.logEvent(Status.INFO, "Systematic withdrawal page", "page is Loaded after and entered the data", true);
			swd.clickhistorysubmenu();
			
			Transaction trs = new Transaction(swd);
			trs.get();
			
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the GK transaction happen on the effective date which we have given
			trs.verifyGKtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GK tranasaction", true);
			trs.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(trs);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("Startdate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			//Want to verify whether TK transaction is trigger after doing the real time update
			trs.verifyTKtransaction();
			trs.doubleclickTBTransaction();
			trs.FedralWithhodlingCalc();
			trs.StateWithholdingCalc();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the TK transaction", true);
			trs.ClickonValueSubmenu();
			
			Value val = new Value(RTU);
			val.get();
			val.EnterEffectivedatevalue(Stock.GetParameterValue("Startdate"));
			
			Web.clickOnElement(val, "Value_updateButton");
			//Web.waitForElement(val, "WaitforValuetable");
/*
			Web.isWebEementEnabled(val, "Value_updateButton");
			Web.waitForElement(val, "Value_updateButton");*/
			// want to verify the amount is reduced in the value page for the amount which we have given in the 
			
			Common.ValuesTableDisbursement();			
			
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verifyed the fund amount", true);
			swd.clicksystematicwithdrawal();
			
			// Want to verify the next payout date in the systematic information page.
			swd.VerifyNextpayoutDate();
			Reporter.logEvent(Status.INFO, "Systematic withdrawal Page", "page is Loaded and verifiyed next payout date", true);
			trs.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("NextPayoutDate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and updated the date", true);
			Thread.sleep(5000);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			trs.verifyNextpayoutTKtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the next TK transcation", true);
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
}
