package app.wmAweb.testcases.Fund;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.HCCExpressAdd;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.DataCollect.DataCollect;
import pageobjects.wmA.Fund.FundTransfer;
import pageobjects.wmA.General.General;
import pageobjects.wmA.Value.Value;

public class GW_FundTransfer {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	

	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_FundTransferNonCFDollarType(int itr, Map<String, String> testdata) {

		try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			/**
			 * Step 1 -PreRequisite: 1.Login wmA Application
			 * Login Successful to UAT-Support home page
			 * verify the wmA home page user successfully and navigate to the 
			 * Hover mouse over menu item Accumulation and select Contract Add
			 */
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		   
		    
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			    pa.get();
			    pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			    pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			    Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			    Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			su.getpolicynumber();			   
	//		Web.clickOnElement(su,"Summary_Homebtn");
	//		Web.waitForElement(sp,"accumulationlink");
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			
			FundTransfer ft = new FundTransfer(su);
			ft.get();
			ft.TC1FundtransferNonCFDollartype(Stock.GetParameterValue("FTEffectivedate"), Stock.GetParameterValue("Fttransfertype"), Stock.GetParameterValue("Ftmemocode"));
			Common.TransferfundNewContract();
			Web.waitForElement(su, "Summary_Realtime");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Submitbtn");	
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		    Reporter.logEvent(Status.INFO, "Fund Transfer", "page is displayed", true);
		    Web.waitForElement(ft, "WaitforValuepage");
		    
		    General g = new General(ft);
		    g.ClickonValueSubmenu();
		    
		    Value val = new Value(g);
		    val.get();
		    val.EnterEffectivedatevalue(Stock.GetParameterValue("FTEffectivedate"));		   
		    Web.clickOnElement(val, "Value_updateButton");
		    Web.waitForElement(val, "WaitforValuetable");
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Common.ValuesTable();
		    
		  //  val.VerifyFundTransfer1(Stock.GetParameterValue("FTtransferTO1"));		
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.clickOnElement(su,"Summary_Homebtn");
		    
		    
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	

	@Test(dataProvider = "setData")
	public void TC2_wmA_Fund_FundTransferCFPercentTypetoCF(int itr, Map<String, String> testdata) {

		try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			/**
			 * Step 1 -PreRequisite: 1.Login wmA Application
			 * Login Successful to UAT-Support home page
			 * verify the wmA home page user successfully and navigate to the 
			 * Hover mouse over menu item Accumulation and select Contract Add
			 */
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(pln,"ClickOnriderbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		    HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);				
		    Web.clickOnElement(rider,"HCC_ClickOn_Add");		
		    Web.waitForElement(rider, "HCC_Select_RiderPlan");
		    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);			
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
		   
		    
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			su.getpolicynumber();			   
	//		Web.clickOnElement(su,"Summary_Homebtn");
	//		Web.waitForElement(sp,"accumulationlink");
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			
			FundTransfer ft = new FundTransfer(su);
			ft.get();
			ft.TC2FundTransferCFPercentTypeToCF(Stock.GetParameterValue("FTEffectivedate"),Stock.GetParameterValue("Fundtypr2"),Stock.GetParameterValue("Fttransfertype"), Stock.GetParameterValue("Ftmemocode"));
			Thread.sleep(2000);
			Common.TransferfundNewContract();
			
		//	ft.entercoveredfund(Stock.GetParameterValue("FTtransferTO1"));
			
			Web.waitForElement(su, "Summary_Realtime");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Submitbtn");	
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		    Reporter.logEvent(Status.INFO, "Fund Transfer", "page is displayed", true);
		    Web.waitForElement(ft, "WaitforValuepage");
		    
		    General g = new General(ft);
		    g.ClickonValueSubmenu();
		    
		    Value val = new Value(g);
		    val.get();
		    val.EnterEffectivedatevalue(Stock.GetParameterValue("FTEffectivedate"));		  
		    Web.clickOnElement(val, "Value_updateButton");
		    Web.waitForElement(val, "WaitforValuetable");
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.waitForElement(val, "WaitforValuetable");
		    Common.ValuesTable();
		//    val.calculatebasevaluepercentage_CovFund();
		    //calculatebasevaluepercentage_NonCovFund()
	//	    val.VerifyFundtransferCFBasebenefit(Stock.GetParameterValue("PaymentAmount"));
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.clickOnElement(su,"Summary_Homebtn");
		    
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	
	@Test(dataProvider = "setData")
	public void TC3_wmA_Fund_FundTransferCFPercentTypetoNonCF(int itr, Map<String, String> testdata) {

		try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			/**
			 * Step 1 -PreRequisite: 1.Login wmA Application
			 * Login Successful to UAT-Support home page
			 * verify the wmA home page user successfully and navigate to the 
			 * Hover mouse over menu item Accumulation and select Contract Add
			 */
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(pln,"ClickOnriderbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		    HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);				
		    Web.clickOnElement(rider,"HCC_ClickOn_Add");		
		    Web.waitForElement(rider, "HCC_Select_RiderPlan");
		    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);			
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
		   
		    
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			su.getpolicynumber();			   
	//		Web.clickOnElement(su,"Summary_Homebtn");
	//		Web.waitForElement(sp,"accumulationlink");
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			FundTransfer ft = new FundTransfer(su);
			ft.get();
			ft.TC3FundTransferCFPercentTypeToNonCF(Stock.GetParameterValue("FTEffectivedate"),Stock.GetParameterValue("Fundtypr2"),Stock.GetParameterValue("Fttransfertype"), Stock.GetParameterValue("Ftmemocode"));
			Thread.sleep(2000);
			Common.TransferfundNewContract();
			Web.waitForElement(ft, "FundTransfer_Overridebtn");
			Web.clickOnElement(ft, "FundTransfer_Overridebtn");
			Web.waitForElement(ft, "Summary_Realtime");
		    Web.selectDropDownOption(ft, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(ft,"Summary_Submitbtn");	
		 //   ft.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		    Reporter.logEvent(Status.INFO, "Fund Transfer", "page is displayed", true);
		    Web.waitForElement(ft, "WaitforValuepage");
		    
		    General g = new General(ft);
		    g.ClickonValueSubmenu();
		    
		    Value val = new Value(g);
		    val.get();
		    val.EnterEffectivedatevalue(Stock.GetParameterValue("FTEffectivedate"));		  
		    Web.clickOnElement(val, "Value_updateButton");
		    Web.waitForElement(val, "WaitforValuetable");
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.waitForElement(val, "WaitforValuetable");
		    Common.ValuesTable();
		//    val.calculatebasevaluepercentage_NonCovFund();
		//    val.VerifyFundtransferNonCFBasebenefit(Stock.GetParameterValue("PaymentAmount"));
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.clickOnElement(ft,"Summary_Homebtn");
		    
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	
	
	@Test(dataProvider = "setData")
	public void TC4_wmA_Fund_FundTransferNonMaxRiderCFDollarTypetoCF(int itr, Map<String, String> testdata) {
		
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Web.clickOnElement(sp,"Submenu_contractAdd");
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));				
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));						
			Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();						
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(pln,"ClickOnriderbox");
			Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*							
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));						 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");						 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*						    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();					    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));					    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");					    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*						    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");					    
		    *//**
			 * Step 15 - Enter HCC Express Add information
			 * .
			 *//*						    
			HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);					
		    Web.clickOnElement(rider,"HCC_ClickOn_Add");
		    Web.waitForElement(rider, "HCC_Select_RiderPlan");
		    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);					
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");					
		    *//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*						
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*		
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			Summary su = new Summary(pa);
			su.get();						
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);					
		    Web.clickOnElement(su,"Summary_Finishbtn");					
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			
			FundTransfer ft = new FundTransfer(su);
			ft.get();
		//	ft.clickhomebutton();
		//	ft.entercontractid(Stock.GetParameterValue("ContractId"));
		//	ft.clicksearchbutton();
			ft.TC4FundtransferFromCFDollartypeToCF(Stock.GetParameterValue("FTEffectivedate"),Stock.GetParameterValue("Fttransfertype"), Stock.GetParameterValue("Ftmemocode"));
			Thread.sleep(2000);
			Common.TransferfundNewContract();
			
			Web.waitForElement(ft, "FundTransfer_Overridebtn");
			Web.clickOnElement(ft, "FundTransfer_Overridebtn");
			Web.waitForElement(ft, "Summary_Realtime");
		    Web.selectDropDownOption(ft, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(ft,"Summary_Submitbtn");	
		 //   ft.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		    Reporter.logEvent(Status.INFO, "Fund Transfer", "page is displayed", true);
		    Web.waitForElement(ft, "WaitforValuepage");
		    
		    General g = new General(ft);
		    g.ClickonValueSubmenu();
		    
		    Value val = new Value(g);
		    val.get();
		    val.EnterEffectivedatevalue(Stock.GetParameterValue("FTEffectivedate"));		  
		    Web.clickOnElement(val, "Value_updateButton");
		    Web.waitForElement(val, "WaitforValuetable");
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.waitForElement(val, "WaitforValuetable");
		    Common.ValuesTable();
		    val.calculatebasevaluepercentage_CovFund();
	//	    val.VerifyFundtransferCFBasebenefit(Stock.GetParameterValue("PaymentAmount"));
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.clickOnElement(ft,"Summary_Homebtn");
		    
				} catch (Exception e) {
					e.printStackTrace();
					Globals.exception = e;
					Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
							.getCause().getMessage(), true);
				} catch (Error ae) {
					ae.printStackTrace();
					Globals.error = ae;
					Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
							"Assertion Failed!!", true);

				} finally {
					try {
						Reporter.finalizeTCReport();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}

	@Test(dataProvider = "setData")
	public void TC5_wmA_Fund_FundTransferNonMaxRiderCFPercentTypetoNonCF(int itr, Map<String, String> testdata) {
		
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			/*LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Web.clickOnElement(sp,"Submenu_contractAdd");
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));				
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));						
			Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();						
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(pln,"ClickOnriderbox");
			Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*							
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));						 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");						 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*						    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();					    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));					    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");					    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*						    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");					    
		    *//**
			 * Step 15 - Enter HCC Express Add information
			 * .
			 *//*						    
			HCCExpressAdd rider = new HCCExpressAdd(bi);
			Web.waitForElement(rider, "HCC_Select_RiderType");
			Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);					
		    Web.clickOnElement(rider,"HCC_ClickOn_Add");
		    Web.waitForElement(rider, "HCC_Select_RiderPlan");
		    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);					
			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");					
		    *//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*						
			FundInfo fi = new FundInfo(rider);
			fi.get();
			fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*		
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			Summary su = new Summary(pa);
			su.get();						
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);					
		    Web.clickOnElement(su,"Summary_Finishbtn");					
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			FundTransfer ft = new FundTransfer(su);
			ft.get();
		//	ft.clickhomebutton();
		//	ft.entercontractid(Stock.GetParameterValue("ContractId"));
		//	ft.clicksearchbutton();
			ft.TC3FundTransferCFPercentTypeToNonCF(Stock.GetParameterValue("FTEffectivedate"),Stock.GetParameterValue("Fundtypr2"),Stock.GetParameterValue("Fttransfertype"), Stock.GetParameterValue("Ftmemocode"));
			Thread.sleep(2000);
			Common.TransferfundNewContract();
		//	ft.entercoveredfund(Stock.GetParameterValue("FTtransferTO1"));
			Web.waitForElement(ft, "FundTransfer_Overridebtn");
			Web.clickOnElement(ft, "FundTransfer_Overridebtn");
			Web.waitForElement(ft, "Summary_Realtime");
		    Web.selectDropDownOption(ft, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(ft,"Summary_Submitbtn");	
		 //   ft.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		    Reporter.logEvent(Status.INFO, "Fund Transfer", "page is displayed", true);
		    Web.waitForElement(ft, "WaitforValuepage");
		    
		    General g = new General(ft);
		    g.ClickonValueSubmenu();
		    
		    Value val = new Value(g);
		    val.get();
		    val.EnterEffectivedatevalue(Stock.GetParameterValue("FTEffectivedate"));		  
		    Web.clickOnElement(val, "Value_updateButton");
		    Web.waitForElement(val, "WaitforValuetable");
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.waitForElement(val, "WaitforValuetable");
		    Common.ValuesTable();
		//    val.calculatebasevaluepercentage_NonCovFund();
		 // val.VerifyFundtransferCFBasebenefit(Stock.GetParameterValue("PaymentAmount"));
		    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
		    Web.clickOnElement(ft,"Summary_Homebtn");
		    
				} catch (Exception e) {
					e.printStackTrace();
					Globals.exception = e;
					Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
							.getCause().getMessage(), true);
				} catch (Error ae) {
					ae.printStackTrace();
					Globals.error = ae;
					Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
							"Assertion Failed!!", true);

				} finally {
					try {
						Reporter.finalizeTCReport();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}

	
}
