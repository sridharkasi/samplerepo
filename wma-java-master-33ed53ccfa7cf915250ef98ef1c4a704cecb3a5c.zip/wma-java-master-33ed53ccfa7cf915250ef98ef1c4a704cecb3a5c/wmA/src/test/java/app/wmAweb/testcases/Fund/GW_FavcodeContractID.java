package app.wmAweb.testcases.Fund;

import java.lang.reflect.Method;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.LandingPage;
import pageobjects.wmA.Fund.Fav;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Premiums_Billing.PremiumDeposit;
import pageobjects.wmA.Value.Value;

public class GW_FavcodeContractID {

private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	

	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_Fav_CodeChange(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			
		    g.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(g);
			RTU.get();
			
			RTU.setRealTimedateFavchange(Stock.GetParameterValue("FavEffectiveDate"));
			Summary su = new Summary(RTU);
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			
			g.ClickonValueSubmenu();
			Value val = new Value(g);
			val.get();
			
			if(System.getProperty("FavEffectDate")==null)
			{
				
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("FavEffectiveDate"));
			}
			else if( System.getProperty("FavEffectDate").trim().length() > 0)
			{
				val.EnterEffectivedatevalueGAW(System.getProperty("FavEffectDate"));
									
			}else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("FavEffectiveDate"));
			}
			
			Web.clickOnElement(val, "Value_updateButton");
			// Want to store value and excepted amount
			Common.CAvaluesTableInitial();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and stored the value for calculation", true);
			
			
			g.ClickonFavSubmenu();
			
			Fav f = new Fav(g);
			f.get();
			f.seteffectivedateFavcode(Stock.GetParameterValue("FavEffectiveDate"));
			Web.waitForElement(su,"Summary_Submitbtn");
		    Web.clickOnElement(su,"Summary_Submitbtn");
			//Thread.sleep(15000);
		    Web.waitForElement(su, "Summary_Realtime");
			
			if(System.getProperty("Favcdechange")==null)
			{
				
				f.SelectFAVCode(Stock.GetParameterValue("FavCodeChange"));
			}
			else if( System.getProperty("Favcdechange").trim().length() > 0)
			{
				f.SelectFAVCode(System.getProperty("Favcdechange"));
									
			}else {
				f.SelectFAVCode(Stock.GetParameterValue("FavCodeChange"));
			}
			
			
			
			Web.waitForElement(su, "Summary_Realtime");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
		    Web.waitForElement(su,"Summary_Submitbtn");
		    Web.clickOnElement(su,"Summary_Submitbtn");
		    
		   
		    
		    
		    Reporter.logEvent(Status.INFO, "Fav Page", "page is Loaded and Changed the Fav Code", true);
		    
		    g.clickhistorysubmenu();
		    
		    Transaction trs = new Transaction(f);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the GK transaction happen on the effective date which we have given
			if(System.getProperty("FavEffectDate")==null)
			{
				trs.verifyFavCodeChangeStransaction(Stock.GetParameterValue("FavEffectiveDate"));
			}
			else if( System.getProperty("FavEffectDate").trim().length() > 0)
			{
				trs.verifyFavCodeChangeStransaction(System.getProperty("FavEffectDate"));
									
			}else {
				trs.verifyFavCodeChangeStransaction(Stock.GetParameterValue("FavEffectiveDate"));
			}
			
		 Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the Fav Code tranasaction", true);
			
		 
		 
		    g.ClickFundSilderBar();
			g.getFundINFO();
			g.ClickFundSilderBar();
		 
			g.ClickonValueSubmenu();
		
			
			
			val.get();
			
	       if(System.getProperty("FavEffectDate")==null)
			{
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));
			}
			else if( System.getProperty("FavEffectDate").trim().length() > 0)
			{
				val.EnterEffectivedatevalueGAW(System.getProperty("FavEffectDate"));
									
			}else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));
			}
	
	
			Web.clickOnElement(val, "Value_updateButton");
			// Want to store value and excepted amount
			
			Common.valuesTableInitial_AllocationChange_CFandNCF_EContract();
			
			g.ClickPremiumBillingSM();
			
			PremiumDeposit pd = new PremiumDeposit(trs);
			
			if(System.getProperty("FavPremiundepoDate")==null)
			{
				pd.EnterEffectiveDate(Stock.GetParameterValue("ACEffectivedate"));
			}
			else if( System.getProperty("FavPremiundepoDate").trim().length() > 0)
			{
				pd.EnterEffectiveDate(System.getProperty("FavPremiundepoDate"));
									
			}else {
				pd.EnterEffectiveDate(Stock.GetParameterValue("ACEffectivedate"));
			}
	

			
			

			if(System.getProperty("PaymentAmount")==null)
			{
				pd.EnterPaymentAmount(Stock.GetParameterValue("PremiumAdditonal"));
			}
			else if( System.getProperty("PaymentAmount").trim().length() > 0)
			{
				pd.EnterPaymentAmount(System.getProperty("PaymentAmount"));
									
			}else {
				pd.EnterPaymentAmount(Stock.GetParameterValue("PremiumAdditonal"));
			}

			
			
			pd.SelectMemoCode(Stock.GetParameterValue("MemoCode"));
			Web.waitForElement(pd, "Summary_Realtime");
			Web.selectDropDownOption(pd, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(pd,"Summary_Finishbtn");	
			pd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Premium Deposit Page", "page is Loaded and Enter the Premium Amount", true);
			
			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the NA transaction happen on the effective date which we have given
			trs.verifyNAtransactionFAV();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the NA tranasaction", true);
			
			g.ClickonValueSubmenu();
			
			
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));		
			
			if(System.getProperty("FavPremiundepoDate")==null)
			{
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));
			}
			else if( System.getProperty("FavPremiundepoDate").trim().length() > 0)
			{
				val.EnterEffectivedatevalueGAW(System.getProperty("FavPremiundepoDate"));
									
			}else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));
			}

			Web.clickOnElement(val, "Value_updateButton");
			//Want to verify the fund value after the premium add
			Common.VerifyFundAllocationChange();
			val.VerifyFavCodeChangeExisting();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and Verifyied the fund value after the premium add", true);
			Web.clickOnElement(su,"Summary_Homebtn");
			
			//Web.waitForElement(su,"accumulationlink");
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
	
}
