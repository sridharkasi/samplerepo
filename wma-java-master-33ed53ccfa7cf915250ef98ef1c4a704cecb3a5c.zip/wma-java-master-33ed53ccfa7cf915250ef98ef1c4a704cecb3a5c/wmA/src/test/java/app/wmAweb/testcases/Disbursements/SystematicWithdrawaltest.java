package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Disbursements.SystematicWithdrawal;

public class SystematicWithdrawaltest {
	
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.wmA.Disbursements.SystematicWithdrawal swithdraw;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_SystematicWithdrawal(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			SystematicWithdrawal swd = new SystematicWithdrawal(landing);
			swd.clickhomebutton();
			swd.entercontractid(Stock.GetParameterValue("ContractID"));
			swd.clicksearchbutton();
			swd.clicksystematicwithdrawal();
			swd.clickaddbutton();
			swd.setsyseffectivedate(Stock.GetParameterValue("EffectiveDate_sys"));
			swd.setstartdate(Stock.GetParameterValue("Startdate"));
			swd.setenddate(Stock.GetParameterValue("Enddate"));
			swd.paymentmode(Stock.GetParameterValue("Paymentmode"));
			swd.transactionlevel(Stock.GetParameterValue("TransactionLevel"));
			swd.payoutamount(Stock.GetParameterValue("PayoutAmount"));
			swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			
			
			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}
