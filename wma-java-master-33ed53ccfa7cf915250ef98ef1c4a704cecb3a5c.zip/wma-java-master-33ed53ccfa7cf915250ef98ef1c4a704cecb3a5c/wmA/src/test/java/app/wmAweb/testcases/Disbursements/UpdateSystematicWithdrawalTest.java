package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Disbursements.UpdateSystematicWithdrawal;

public class UpdateSystematicWithdrawalTest {

private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.wmA.Disbursements.UpdateSystematicWithdrawal changesyswithdraw;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_ChangeSystematicWithdrawal(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			UpdateSystematicWithdrawal Changesys =new UpdateSystematicWithdrawal(landing);
			Changesys.clickhomebutton();
			Changesys.entercontractid(Stock.GetParameterValue("ContractID"));
			Changesys.clicksearchbutton();
			Changesys.clicksystematicwithdrawal();
			Changesys.selectrow1();
			Changesys.clickupdatebutton();
			Changesys.updateeffectivedate(Stock.GetParameterValue("UpdateEffectivedate"));
			Changesys.UpdateStartDate(Stock.GetParameterValue("UpdateStartdate"));
			Changesys.updatemodeoption(Stock.GetParameterValue("UpdateModeoption"));
			Changesys.RealtimeDrpDwn(Stock.GetParameterValue("UpdateSys_realtime"));
			Changesys.clicksumbmit();
			Changesys.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			
			
			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
}
