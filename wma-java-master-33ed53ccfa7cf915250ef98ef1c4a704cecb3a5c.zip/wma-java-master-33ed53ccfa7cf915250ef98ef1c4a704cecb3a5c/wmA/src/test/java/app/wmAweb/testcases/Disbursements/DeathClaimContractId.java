package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Party.DeathPending;
import pageobjects.wmA.Party.DemographicChange;
import pageojects.wmA.Search.DetailsSearch;

public class DeathClaimContractId {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}
	
	
			
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim_Multiplebeneficary(int itr, Map<String, String> testdata) {
				try {

					Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
							+ "_" + Stock.getConfigParam("BROWSER"));
					Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

				
					
					Common.contractsearchandFundINFO(System.getProperty("ContractID"));
					LandingPage landing = new LandingPage();				
					
					General g = new General(landing);
					g.get();
					
					if(System.getProperty("DeathPendingEffectiveDate")==null)
					{
						System.out.println("Death pending is not availabe for this test case");
					}
					else if( System.getProperty("EffectiveDate").trim().length() > 0)
					{
						g.ClickRoleSilderBar();
						g.GetDirectorID();
						g.ClickRoleSilderBar();
						Summary su = new Summary(g);
						SelectPartner sp = new SelectPartner(g);
						Web.clickOnElement(su, "Summary_Homebtn");
						Web.waitForElement(sp, "accumulationlink");
						Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
						
						Home om = new Home(sp);
						om.get();
						om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
						Web.waitForElement(om, "Serach_Button");
						Web.clickOnElement(om, "Serach_Button");
						Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
						
						DetailsSearch ds = new DetailsSearch(om);
						ds.get();
						ds.Selectcontractrow();
						Web.waitForElement(ds, "PartyProfile_Button");
						Web.clickOnElement(ds, "PartyProfile_Button");
						Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
						
						DemographicChange Demo = new DemographicChange(ds);
						Demo.get();
						Demo.ClickonDeathpending();
						Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
						
						DeathPending dp = new DeathPending(Demo);
						dp.get();
						dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));
						Web.selectDropDownOption(dp, "Life_Status", Stock.GetParameterValue("LifeStatus"), false);
						dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
						Web.clickOnElement(dp, "DeathPending_CheckBox");
						Web.waitForElement(su, "Summary_Realtime");
						Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
						Web.clickOnElement(su, "Summary_Submitbtn");
						su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
						Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
						Web.clickOnElement(su, "Summary_Homebtn");
						Web.waitForElement(sp, "accumulationlink");
						
						om.get();
						om.entercontractid(System.getProperty("ContractID"));
						Web.waitForElement(om, "Serach_Button");
						Web.clickOnElement(om, "Serach_Button");
						Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
						
						g.get();
						g.VerifyDeathStatus();
						Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
											
					}else {
						System.out.println("Death pending is not availabe for this test case1");
					}
					
					
					g.CLickonDeathClaimSubmenu();
				
					
					DeathClaim dc = new DeathClaim(g);
					dc.get();
					dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
					dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
					dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
					//1st beneficary for death contiuation
					if(System.getProperty("Disbursement")==null)
					{
						
					}
					else if(System.getProperty("Disbursement").trim().length() > 0)
					{
						dc.ClickOnAddbutton();
						dc.EnterPayeePercentage(System.getProperty("PercentOfBenefit"));
						dc.SelectPayeeResState(Stock.GetParameterValue("State"));
						Web.waitForElement(dc,"Disbursement");
						dc.SelectDisbursement(System.getProperty("Disbursement"));							
						dc.ClickonPayeePartyadd();
						Common.switchto_newwindow();
						dc.EnterbeneficiaryDetails(Stock.GetParameterValue("DCEffectivedate"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
						
						Thread.sleep(1500);
						Common.switchto_mainwindow();
						Thread.sleep(1500);
						
						
						if(System.getProperty("CreatePolicy_Payment")==null)
						{
							
						}
						else if(System.getProperty("CreatePolicy_Payment").equalsIgnoreCase("Yes"))
						{
							Web.waitForElement(dc,"Create_Policy");
							dc.CreatePolicy(Stock.GetParameterValue("CreatePolicy"));
							Web.waitForElement(dc,"Create_Payment");
							dc.CreatePayemnt(Stock.GetParameterValue("CreatePolicy"));
							Web.waitForElement(dc,"Spousal_Type");
							Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
											
						}else {
							
						}
						
						dc.ClickUpdatePayee();
										
					}else {
						
					}
					
				
					Summary su = new Summary(dc);
					Web.waitForElement(su, "Overide_Button");
					Web.clickOnElement(su, "Overide_Button");
					Web.waitForElement(su, "Summary_Realtime");
					Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
					Web.clickOnElement(su, "Summary_Submitbtn");
					su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
					Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
					
					g.clickhistorysubmenu();
					
					Transaction trs = new Transaction(dc);
					trs.get();
					Web.waitForElement(trs, "Transaction_updateBT");
					Web.clickOnElement(trs, "Transaction_updateBT");
					// want to verify whether the PA-Deathclaim transaction happen on the effective date which
					// we have given
					trs.verifyPA_DEAThCLAIMtransaction(System.getProperty("TrxEffectiveDate"));
					Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
					
					
					if(System.getProperty("CreatePolicy_Payment")==null)
					{
						
					}
					else if(System.getProperty("CreatePolicy_Payment").equalsIgnoreCase("Yes"))
					{
						trs.doubleclickTBTransaction();
						trs.VerifynewContractIDforExistingContract(Stock.GetParameterValue("SpousalType"));
										
					}else {
						
					}
				
					
					// want to verify whether the status check change to D-death 
					trs.verifystatusD_Death();
					Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
				    Web.clickOnElement(su, "Summary_Homebtn");
				    SelectPartner sp = new SelectPartner(trs);
					Web.waitForElement(sp, "accumulationlink");
	
	
	
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
}
