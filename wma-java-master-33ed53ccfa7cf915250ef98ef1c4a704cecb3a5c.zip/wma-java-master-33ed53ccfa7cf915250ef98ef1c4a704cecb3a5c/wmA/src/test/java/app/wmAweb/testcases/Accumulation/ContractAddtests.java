package app.wmAweb.testcases.Accumulation;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.LoginPagewmA;
import pageobjects.wmA.Accumulation.ContractAdd;

public class ContractAddtests {

	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	private static HashMap<String, String> testDataFromDB = null;
	
	String tcName;
	static String printTestData="";
	static String url = null;
	static String accuCode = null;
	String[] sqlQuery=null;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}


	@Test(dataProvider = "setData")
	public void TC1_wmA_Accumulation_ContractAddd(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			Web.getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			ContractAdd ctradd = new ContractAdd();
		
			//ctradd.clickcontractADD(lib.Stock.GetParameterValue("menu"), lib.Stock.GetParameterValue("submenu"));
			ctradd.clickcontractADD();
			lib.Reporter
			.logEvent(
					Status.PASS,
					"Contract Add is clicked",
					"No error message is displayed after submiting login credentials\nExpected error message on clicking on Sign In button",
					true);
			
			ctradd.selectpartner(Stock.GetParameterValue("SelectPartner"));
			ctradd.ClickNext();
			ctradd.setEffectiveDate(Stock.GetParameterValue("EffectiveDate"));
			ctradd.selectIssuestate(Stock.GetParameterValue("IssueState"));
			ctradd.ClickNext();
			ctradd.selectbaseplan(Stock.GetParameterValue("BasePlan"));
			
			ctradd.StatutoryCompany(Stock.GetParameterValue("StatutoryCompany"));
			ctradd.LineofBusiness(Stock.GetParameterValue("LineofBusiness"));
			ctradd.Residentstate(Stock.GetParameterValue("IssueState"));
			ctradd.cashcheckbox();
			ctradd.ClickNext();
			ctradd.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			ctradd.AdvisorSearch();
			//ctradd.switchtowindow("click");
			Common.switchto_newwindow();
			ctradd.selectpartysearch();
			ctradd.selectpartyOKButton();
			Common.switchto_mainwindow();
			ctradd.selectRoleType(Stock.GetParameterValue("Roletype"));
			ctradd.setProfile(Stock.GetParameterValue("profile"));
			ctradd.FirstYrPercentage(Stock.GetParameterValue("Firstyear"));
			ctradd.RnwalPercentage(Stock.GetParameterValue("Renewal"));
			ctradd.CommisionAgncy(Stock.GetParameterValue("CommissionAgent"));
			ctradd.ClickNext();
			ctradd.AnnuityFirstName(Stock.GetParameterValue("FirstName"));
			ctradd.AnnuityLastName(Stock.GetParameterValue("LastName"));
			ctradd.AnnuityDOB(Stock.GetParameterValue("Dateofbirth"));
			ctradd.AnnuityGender(Stock.GetParameterValue("Gender"));
			ctradd.AnnuitySSN(Stock.GetParameterValue("SocialSecurityNumber"));
			ctradd.AnnuityState(Stock.GetParameterValue("IssueState"));
			ctradd.AnnuityCity(Stock.GetParameterValue("City"));
			ctradd.AnuityAddress(Stock.GetParameterValue("ResidentAddress"));
			ctradd.AnnuityZip(Stock.GetParameterValue("ZIP"));
			
			
			
			
			ctradd.ClickNext();
			//===============================================================
			
			ctradd.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			ctradd.ClickNext();
			ctradd.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			ctradd.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			ctradd.ClickNext();
			ctradd.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			ctradd.ClickNext();
			ctradd.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			ctradd.MemoCode(Stock.GetParameterValue("MemoCode"));
			ctradd.ClickNext();
			ctradd.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			ctradd.FinishButton();
			ctradd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
		Thread.sleep(2000);
		ctradd.getpolicynumber();
			
			ctradd.ClickOnNavigateprofile();
			
			
			//===============================================================
			String errMsg = "";
			//errMsg = login.isValidCredentials();

/*			if (errMsg.trim().isEmpty()) {
				lib.Reporter
						.logEvent(
								Status.FAIL,
								"Check error message displayed on submiting invalid credentials",
								"No error message is displayed after submiting login credentials\nExpected error message on clicking on Sign In button",
								true);

				return;
			} else {
				lib.Reporter
						.logEvent(
								Status.INFO,
								"Check error message displayed on submiting invalid credentials",
								"An error message is displayed as expected",
								true);
			}

			Web.VerifyText(lib.Stock.GetParameterValue("ExpectedErrorMessage"),
					errMsg, true);*/

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC10_wmA_Accumulation_ContractAddd(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			Web.getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			ContractAdd ctradd = new ContractAdd();
		
			//ctradd.clickcontractADD(lib.Stock.GetParameterValue("menu"), lib.Stock.GetParameterValue("submenu"));
			ctradd.clickcontractADD();
			lib.Reporter
			.logEvent(
					Status.PASS,
					"Contract Add is clicked",
					"No error message is displayed after submiting login credentials\nExpected error message on clicking on Sign In button",
					true);
			
			ctradd.selectpartner(Stock.GetParameterValue("SelectPartner"));
			ctradd.ClickNext();
			ctradd.setEffectiveDate(Stock.GetParameterValue("EffectiveDate"));
			ctradd.selectIssuestate(Stock.GetParameterValue("IssueState"));
			ctradd.ClickNext();
			ctradd.selectbaseplan(Stock.GetParameterValue("BasePlan"));
			
			ctradd.StatutoryCompany(Stock.GetParameterValue("StatutoryCompany"));
			ctradd.LineofBusiness(Stock.GetParameterValue("LineofBusiness"));
			ctradd.Residentstate(Stock.GetParameterValue("IssueState"));
			ctradd.cashcheckbox();
			ctradd.addraidercheckbox();
			ctradd.ClickNext();
			ctradd.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			ctradd.AdvisorSearch();
			//ctradd.switchtowindow("click");
			Common.switchto_newwindow();
			ctradd.selectpartysearch();
			ctradd.selectpartyOKButton();
			Common.switchto_mainwindow();
			ctradd.selectRoleType(Stock.GetParameterValue("Roletype"));
			ctradd.setProfile(Stock.GetParameterValue("profile"));
			ctradd.FirstYrPercentage(Stock.GetParameterValue("Firstyear"));
			ctradd.RnwalPercentage(Stock.GetParameterValue("Renewal"));
			ctradd.CommisionAgncy(Stock.GetParameterValue("CommissionAgent"));
			ctradd.ClickNext();
			ctradd.AnnuityFirstName(Stock.GetParameterValue("FirstName"));
			ctradd.AnnuityLastName(Stock.GetParameterValue("LastName"));
			ctradd.AnnuityDOB(Stock.GetParameterValue("Dateofbirth"));
			ctradd.AnnuityGender(Stock.GetParameterValue("Gender"));
			ctradd.AnnuitySSN(Stock.GetParameterValue("SocialSecurityNumber"));
			ctradd.AnnuityState(Stock.GetParameterValue("IssueState"));
			ctradd.AnnuityCity(Stock.GetParameterValue("City"));
			ctradd.AnuityAddress(Stock.GetParameterValue("ResidentAddress"));
			ctradd.AnnuityZip(Stock.GetParameterValue("ZIP"));
			
			
			
			
			ctradd.ClickNext();
			//===============================================================
			
			ctradd.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			ctradd.ClickNext();
			ctradd.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			ctradd.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			ctradd.ClickNext();
			ctradd.addraiderbutton();
			ctradd.HCC_Raiderplanselect("SSAAVF");
			ctradd.ClickNext();
			//ctradd.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			ContractAdd.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
			Thread.sleep(20000);
			ctradd.ClickNext();
			
			ctradd.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			ctradd.MemoCode(Stock.GetParameterValue("MemoCode"));
			ctradd.ClickNext();
			ctradd.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			ctradd.FinishButton();
			ctradd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
		Thread.sleep(2000);
		ctradd.getpolicynumber();
		}
	catch(Exception e) {
		
	}
	}
}
