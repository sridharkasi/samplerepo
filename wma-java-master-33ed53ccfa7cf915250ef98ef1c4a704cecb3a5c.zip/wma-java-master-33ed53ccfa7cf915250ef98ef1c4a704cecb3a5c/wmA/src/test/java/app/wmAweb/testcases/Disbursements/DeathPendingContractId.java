package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.General.General;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Party.DeathPending;
import pageobjects.wmA.Party.DemographicChange;
import pageojects.wmA.Search.DetailsSearch;

public class DeathPendingContractId {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}
	
	
			
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim_Multiplebeneficary(int itr, Map<String, String> testdata) {
				try {

					Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
							+ "_" + Stock.getConfigParam("BROWSER"));
					Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

				
					
					Common.contractsearchandFundINFO(System.getProperty("ContractID"));
					LandingPage landing = new LandingPage();				
					
					General g = new General(landing);
					g.get();
					
					if(System.getProperty("DeathPendingEffectiveDate")==null)
					{
						System.out.println("Death pending is not availabe for this test case");
					}
					else if( System.getProperty("DeathPendingEffectiveDate").trim().length() > 0)
					{
						g.ClickRoleSilderBar();
						g.GetDirectorID();
						g.ClickRoleSilderBar();
						Summary su = new Summary(g);
						SelectPartner sp = new SelectPartner(g);
						Web.clickOnElement(su, "Summary_Homebtn");
						Web.waitForElement(sp, "accumulationlink");
						Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
						
						Home om = new Home(sp);
						om.get();
						om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
						Web.waitForElement(om, "Serach_Button");
						Web.clickOnElement(om, "Serach_Button");
						Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
						
						DetailsSearch ds = new DetailsSearch(om);
						ds.get();
						ds.Selectcontractrow();
						Web.waitForElement(ds, "PartyProfile_Button");
						Web.clickOnElement(ds, "PartyProfile_Button");
						Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
						
						DemographicChange Demo = new DemographicChange(ds);
						Demo.get();
						Demo.ClickonDeathpending();
						Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
						
						DeathPending dp = new DeathPending(Demo);
						dp.get();
						dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));					
						dp.SelectLifeStatus(Stock.GetParameterValue("LifeStatus"));
						dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
						Web.clickOnElement(dp, "DeathPending_CheckBox");
						Web.waitForElement(su, "Summary_Realtime");
						Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
						Web.clickOnElement(su, "Summary_Submitbtn");
						su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
						Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
						Web.clickOnElement(su, "Summary_Homebtn");
						Web.waitForElement(sp, "accumulationlink");
						
						om.get();
						om.entercontractid(System.getProperty("ContractID"));
						Web.waitForElement(om, "Serach_Button");
						Web.clickOnElement(om, "Serach_Button");
						Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
						
						g.get();
						g.VerifyDeathStatus();
						Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
						Web.clickOnElement(su, "Summary_Homebtn");						    
						Web.waitForElement(sp, "accumulationlink");					
					}else {
						System.out.println("Death pending is not availabe for this test case1");
					}
					
					
					
				   
	
	
	
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
}
