package app.wmAweb.testcases.Fund;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Fund.AllocationChange;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Premiums_Billing.PremiumDeposit;
import pageobjects.wmA.Value.Value;

public class AllocationChangeContracttId {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	

	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_AllocationChang_Deposit_ContractID(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		
			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
		
			
			g.ClickAllocationchangeSM();
			
			AllocationChange AC = new AllocationChange(g);
			AC.entereffectivedate(Stock.GetParameterValue("ACEffectivedate"));
	//		AC.Clearfund();
	//		AC.enterfundMultipleExistingContract();
			AC.EnterRandomFundAllocation();
			Web.waitForElement(AC, "Summary_Realtime");
			Web.selectDropDownOption(AC, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(AC,"Summary_Finishbtn");	
			AC.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Allocation Change Page", "page is Loaded and enter the data for the tranasaction", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(AC);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the GK transaction happen on the effective date which we have given
			trs.verifyZEtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GK tranasaction", true);
			
			
		
			g.ClickFundSilderBar();
			g.getFundINFO();
			g.ClickFundSilderBar();
			
			g.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(g);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));			
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			
			g.ClickonValueSubmenu();
			Value val = new Value(trs);
			val.get();
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));			
			Web.clickOnElement(val, "Value_updateButton");
			// Want to store value and excepted amount
			Common.valuesTableInitial_AllocationChange_CFandNCF_EContract();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and stored the value for calculation", true);
			
			g.ClickPremiumBillingSM();
			
			PremiumDeposit pd = new PremiumDeposit(val);
			pd.EnterEffectiveDate(Stock.GetParameterValue("ACEffectivedate"));
			pd.EnterPaymentAmount(Stock.GetParameterValue("PremiumAdditonal"));
			pd.SelectMemoCode(Stock.GetParameterValue("MemoCode"));
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(pd, "Summary_Realtime");
			Web.selectDropDownOption(pd, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(pd,"Summary_Finishbtn");	
			pd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			g.clickhistorysubmenu();
			
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the NA transaction happen on the effective date which we have given
			trs.verifyNAtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the NA tranasaction", true);
			
			g.ClickonValueSubmenu();
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));			
			Web.clickOnElement(val, "Value_updateButton");
			//Want to verify the fund value after the premium add
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and Verifyied the fund value after the premium add", true);
			Web.clickOnElement(su,"Summary_Homebtn");
			SelectPartner sp = new SelectPartner(val);
			Web.waitForElement(sp,"accumulationlink");
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_PremiumAdd_ContractID(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		
			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
		
			
		
			
			g.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(g);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));			
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			
			g.ClickonValueSubmenu();
			Value val = new Value(RTU);
			val.get();
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));			
			Web.clickOnElement(val, "Value_updateButton");
			// Want to store value and excepted amount
			Common.valuesTableInitial_AllocationChange_CFandNCF_EContract();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and stored the value for calculation", true);
			
			g.ClickPremiumBillingSM();
			
			PremiumDeposit pd = new PremiumDeposit(val);
			pd.EnterEffectiveDate(Stock.GetParameterValue("ACEffectivedate"));
			pd.EnterPaymentAmount(Stock.GetParameterValue("PremiumAdditonal"));
			pd.SelectMemoCode(Stock.GetParameterValue("MemoCode"));
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(pd, "Summary_Realtime");
			Web.selectDropDownOption(pd, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(pd,"Summary_Finishbtn");	
			pd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(pd);
			trs.get();
			
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the NA transaction happen on the effective date which we have given
			trs.verifyNAtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the NA tranasaction", true);
			
			g.ClickonValueSubmenu();
			val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("ACEffectivedate"));			
			Web.clickOnElement(val, "Value_updateButton");
			//Want to verify the fund value after the premium add
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and Verifyied the fund value after the premium add", true);
			Web.clickOnElement(su,"Summary_Homebtn");
			SelectPartner sp = new SelectPartner(val);
			Web.waitForElement(sp,"accumulationlink");
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}	
	
}
