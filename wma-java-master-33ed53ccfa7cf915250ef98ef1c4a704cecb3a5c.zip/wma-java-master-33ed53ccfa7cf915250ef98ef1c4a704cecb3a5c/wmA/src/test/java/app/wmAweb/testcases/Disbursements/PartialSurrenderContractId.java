package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Party.DeathPending;
import pageobjects.wmA.Party.DemographicChange;
import pageobjects.wmA.Value.Value;
import pageojects.wmA.Search.DetailsSearch;

public class PartialSurrenderContractId {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PartialSurrender_FundSpecific_Dollar(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);
			
			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
		
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			
			g.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(g);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));
			Summary su = new Summary(RTU); //Overide_Button
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			
			g.clickpartialsurrender();
			
			if(System.getProperty("TrxLevel").equalsIgnoreCase("FundSpecific")) {
				
			
			PartialSurrender psurrender = new PartialSurrender(g);
			psurrender.get();
			psurrender.seteffectivedate(Stock.GetParameterValue("PartialEffectiveDate"));
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			Web.clickOnElement(su, "Summary_Submitbtn");
			// psurrender.EnterPartialSurrenderFund();
			Thread.sleep(8000);
			psurrender.EnterPartialSurrenderFundForExtingContract();
			// psurrender.clickwithholdingoverride();
			// psurrender.EnterStateoverideamt(Stock.GetParameterValue("StateOverideAmt"));
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Partial Surrender Page", "page is Loaded ", true);

			g.clickhistorysubmenu();

			Transaction trs = new Transaction(psurrender);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the TB transaction happen on the effective date which
			// we have given
			if(System.getProperty("TrxEffectiveDate")==null)
			{
				trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
			}
			else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
			{
				trs.verifyTBtransaction(System.getProperty("TrxEffectiveDate"));
									
			}else {
				trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
			}
			
		
			// trs.doubleclickTBTransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TB tranasaction", true);

			g.ClickonValueSubmenu();
			Value val = new Value(trs);
			val.get();
			Thread.sleep(1500);
			if(System.getProperty("TrxEffectiveDate")==null)
			{
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
			}
			else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
			{
				val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
									
			}else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
			}
		
			Web.clickOnElement(val, "Value_updateButton");
			// Want to verify the value
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for each fund", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(val);
			Web.waitForElement(sp, "accumulationlink");
			}
			else if (System.getProperty("TrxLevel").equalsIgnoreCase("ProRataBasis")) {
				g.ClickonValueSubmenu();
				Value val = new Value(g);
				val.get();
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
										
				}else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				Web.clickOnElement(val, "Value_updateButton");
				// Want to fetch the expected value in the value page after removal of Pro RATA
				// Basis
				
				Common.valuesTableInitial_Values_ProRateBasis_CFandNCF_ContractID(System.getProperty("TrxType"));
										
				
				Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for  each fund", true);

				g.clickpartialsurrender();

				PartialSurrender psurrender = new PartialSurrender(val);
				psurrender.get();
				psurrender.seteffectivedate(Stock.GetParameterValue("PartialEffectiveDate"));
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
				psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
				
				Web.clickOnElement(su, "Summary_Submitbtn");
				// psurrender.EnterPartialSurrenderFund();
				Thread.sleep(5000);
				
				psurrender.EnterFundForContractID();				
				psurrender.clickoverirde();
				
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.clickOnElement(su, "Summary_Submitbtn");
				Thread.sleep(2000);
				su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

				g.clickhistorysubmenu();
				Transaction trs = new Transaction(psurrender);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the TB transaction happen on the effective date which
				// we have given
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					trs.verifyTBtransaction(System.getProperty("TrxEffectiveDate"));
										
				}else {
					trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TB tranasaction", true);

				
				Reporter.logEvent(Status.INFO, "TB Transaction detailed page",
						"page is Loaded and verifiyed the withholdamount", true);

				g.ClickonValueSubmenu();
				val.get();
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
										
				}else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
			
				Web.clickOnElement(val, "Value_updateButton");
				// Want to verify the value
				Common.VerifyFundAllocationChange();
				Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for  each fund", true);
				Web.clickOnElement(su, "Summary_Homebtn");
				SelectPartner sp = new SelectPartner(val);
				Web.waitForElement(sp, "accumulationlink");
			}else if (System.getProperty("TrxLevel").equalsIgnoreCase("ProRataInvestment")) {
				g.ClickonValueSubmenu();

				Value val = new Value(g);
				val.get();
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
										
				}else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				Web.clickOnElement(val, "Value_updateButton");
				// Want to store the value
				Common.valuesTableInitialValues_PROratainvestmentonly_ContractId();
				Reporter.logEvent(Status.INFO, "Value Page",
						"page is Loaded and Store the value for each fund before transcation", true);

				g.clickpartialsurrender();

				PartialSurrender psurrender = new PartialSurrender(val);
				psurrender.get();
				psurrender.seteffectivedate(Stock.GetParameterValue("PartialEffectiveDate"));
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
				psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
				// Web.clickOnElement(su, "Summary_Submitbtn");
				Thread.sleep(5000);			
				Web.clickOnElement(su, "Summary_Submitbtn");
				Thread.sleep(5000);	
				psurrender.EnterFundForContractID();				
				psurrender.clickoverirde();
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.clickOnElement(su, "Summary_Submitbtn");
				Thread.sleep(2500);
				su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Partial Surrender Page", "page is Loaded and Entered data", true);

				g.clickhistorysubmenu();

				Transaction trs = new Transaction(psurrender);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the TB transaction happen on the effective date which
				// we have given
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					trs.verifyTBtransaction(System.getProperty("TrxEffectiveDate"));
										
				}else {
					trs.verifyTBtransaction(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the TB tranasaction", true);

				g.ClickonValueSubmenu();
				val.get();
				if(System.getProperty("TrxEffectiveDate")==null)
				{
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
				{
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
										
				}else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("PartialEffectiveDate"));
				}
				Web.clickOnElement(val, "Value_updateButton");
				// Want to verify the value

				Common.VerifyFundAllocationChange();
				Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verify the value for each fund", true);
				Web.clickOnElement(su, "Summary_Homebtn");
				SelectPartner sp = new SelectPartner(val);
				Web.waitForElement(sp, "accumulationlink");
			}
			else {
				System.out.println("No option selected in arugments");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	
}
