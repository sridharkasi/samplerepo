package app.wmAweb.testcases.Fund;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Fund.AssetRebalance;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Value.Value;

public class AssetRebalanceContractId {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_NewRecurringBalance(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			g.ClickAssetRebalanceSM();

			AssetRebalance ar = new AssetRebalance(g);
			ar.EnterEffectivedate(Stock.GetParameterValue("AREffectivedate"));
			ar.SelectTransferFrequency(Stock.GetParameterValue("TransferFrequency"));
			ar.EnterRebalanceStartDate(Stock.GetParameterValue("ARstartdate"));
			ar.EnterFinalRebalanceDate(Stock.GetParameterValue("Arfinaldate"));
			ar.EnterRandomFundAllocation();
		//	ar.EnterAllocationrebalance(Stock.GetParameterValue("Assetrebalance_percent"));
			ar.clickoverirde();
			Web.selectDropDownOption(ar, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(ar, "Summary_Finishbtn");
			ar.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Asset rebalance Page", "page is Loaded and Entered the data", true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(ar);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyRBtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the RB tranasaction", true);

			g.ClickonmaintenanceSubmenu();
			Realtime_update RTU = new Realtime_update(trs);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("ARstartdate"));
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyOEStransaction(Stock.GetParameterValue("AREffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction", true);

			g.ClickonValueSubmenu();
			Thread.sleep(1500);
			Value val = new Value(RTU);
			val.get();
			if(System.getProperty("TrxEffectiveDate")==null)
			{
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("AREffectivedate"));
			}
			else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
			{
				val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
									
			}else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("AREffectivedate"));
				}
		
			Web.clickOnElement(val, "Value_updateButton");
			Common.valuesTableInitial_Assetrebalance_CFandNCF_EContract();
		//	Common.valuesTableInitial_AssetRebalance_CFandNCF();
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value page", "page is displayed", true);

		

			
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(val);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_ChangeExistingAssetrebalance_EContract(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			
			g.ClickAssetRebalanceSM();
			AssetRebalance ar = new AssetRebalance(g);
			ar.EnterChangeEffectivedate(Stock.GetParameterValue("ChangeAREffectivedate"));
			ar.EnterNextpayoutdate(Stock.GetParameterValue("NextRebalancedate"));
			ar.SelectAction(Stock.GetParameterValue("SelectAction"));
			ar.EnterRandomAllocationrebalance_Econtract();
			ar.clickoverirde();
			Web.selectDropDownOption(ar, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(ar, "Summary_Finishbtn");
			ar.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Asset rebalance Page", "page is Loaded and Entered the data", true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(ar);
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyLRBItransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the RB tranasaction", true);

			g.ClickonmaintenanceSubmenu();
			Realtime_update RTU = new Realtime_update(trs);
			RTU.enterrealtimeupdateEffectivedateAssetrebal(System.getProperty("NextPayoutDate"));
			RTU.clickoverirde();
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyOEStransactionAssetrebalanceChange(System.getProperty("NextPayoutDate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction", true);

			g.ClickonValueSubmenu();
			Value val = new Value(RTU);
			val.EnterEffectivedatevalueAssetrebalance(Stock.GetParameterValue("ChangeAREffectivedate"));
			Web.clickOnElement(val, "Value_updateButton");
			Common.valuesTableInitial_AssetRebalance_CFandNCF();
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value page", "page is displayed", true);

			g.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedateAssetrebal(System.getProperty("SubsequentDate"));
			RTU.clickoverirde();
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			// Subsquent OES verification
			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyOEStransactionAssetrebalanceChange(System.getProperty("SubsequentDate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(val);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_TerminateRecurringRebalance(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			
			g.ClickAssetRebalanceSM();
			AssetRebalance ar = new AssetRebalance(g);
			ar.EnterChangeEffectivedate(Stock.GetParameterValue("ChangeAREffectivedate"));
			ar.SelectAction(Stock.GetParameterValue("SelectAction"));
			ar.GetNextRebalanceDate();
			ar.clickoverirde();
			Web.selectDropDownOption(ar, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(ar, "Summary_Finishbtn");
			ar.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Asset rebalance Page", "page is Loaded and Entered the data", true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(ar);
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyLRBItransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LRBI tranasaction", true);

			g.ClickAssetRebalanceSM();
			ar.verifyRebalanceStatus();
			Reporter.logEvent(Status.INFO, "Asset rebalance Page",
					"page is Loaded and Veriyed the Status of Asset rebalance", true);
			Realtime_update RTU = new Realtime_update(trs);
			g.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedateAssetrebal(Common.Contractinfo.get("NextPayoutDate"));
			ar.clickoverirde();
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Next rebalance date is entered",
					true);

			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyNoOEStransaction(Common.Contractinfo.get("NextPayoutDate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the RB tranasaction", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			
			SelectPartner sp = new SelectPartner(RTU);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_OneTimeRecurringBalance(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			g.ClickAssetRebalanceSM();

			AssetRebalance ar = new AssetRebalance(g);
			ar.EnterEffectivedate(Stock.GetParameterValue("AREffectivedate"));
			ar.EnterOneTimeEffectivedate(System.getProperty("TrxEffectiveDate"));
			ar.EnterRandomonetimerebalance_Econtract();
			ar.clickoverirde();
			Web.selectDropDownOption(ar, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(ar, "Summary_Finishbtn");
			ar.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Asset rebalance Page", "page is Loaded and Entered the data", true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(ar);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyRBtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the RB tranasaction", true);

			g.ClickonmaintenanceSubmenu();
			Realtime_update RTU = new Realtime_update(trs);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));
			RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
			RTU.clicksumbmit();
			RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			g.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the RB transaction happen on the effective date which
			// we have given
			trs.verifyOEStransaction(System.getProperty("TrxEffectiveDate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction", true);

			g.ClickonValueSubmenu();
			Thread.sleep(1500);
			Value val = new Value(RTU);
			val.get();
			val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));
			Web.clickOnElement(val, "Value_updateButton");
			Common.valuesTableInitial_AssetRebalance_CFandNCF();
			Common.VerifyFundAllocationChange();
			Reporter.logEvent(Status.INFO, "Value page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(RTU);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
}
