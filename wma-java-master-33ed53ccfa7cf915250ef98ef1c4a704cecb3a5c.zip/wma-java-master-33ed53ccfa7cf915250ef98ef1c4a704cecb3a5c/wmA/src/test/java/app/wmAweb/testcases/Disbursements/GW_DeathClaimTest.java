package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Party.DeathPending;
import pageobjects.wmA.Party.DemographicChange;
import pageojects.wmA.Search.DetailsSearch;

public class GW_DeathClaimTest {

	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.ClickRoleSilderBar();
			g.GetDirectorID();
			g.ClickRoleSilderBar();
			Summary su = new Summary(g);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(su);
			Web.waitForElement(sp, "accumulationlink");
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
			
			Home om = new Home(sp);
			om.get();
			om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
			
			DetailsSearch ds = new DetailsSearch(om);
			ds.get();
			ds.Selectcontractrow();
			Web.waitForElement(ds, "PartyProfile_Button");
			Web.clickOnElement(ds, "PartyProfile_Button");
			Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
			
			DemographicChange Demo = new DemographicChange(ds);
			Demo.get();
			Demo.ClickonDeathpending();
			Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
			
			DeathPending dp = new DeathPending(Demo);
			dp.get();
			dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));
			Web.selectDropDownOption(dp, "Life_Status", Stock.GetParameterValue("LifeStatus"), false);
			dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
			Web.clickOnElement(dp, "DeathPending_CheckBox");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			om.get();
			om.entercontractid(Common.Contractinfo.get("Contractid"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
			
			g.get();
			g.VerifyDeathStatus();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
			
			DeathClaim dc = new DeathClaim(dp);
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));			
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim1(int itr, Map<String, String> testdata) {

		try {
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Clicked on DeathClaim Submenu", true);
			
			DeathClaim dc = new DeathClaim(g);			
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
		//	Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("ctradd_realtime"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			Summary su = new Summary(dc);
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
		    SelectPartner sp = new SelectPartner(trs);
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim_LifeExpectancyPayoutContinuation(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			
		/*	SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.ClickRoleSilderBar();
			g.GetDirectorID();
			g.ClickRoleSilderBar();
			Summary su = new Summary(g);
			SelectPartner sp = new SelectPartner(su);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
			
			Home om = new Home(g);
			om.get();
			om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
			
			DetailsSearch ds = new DetailsSearch(om);
			ds.get();
			ds.Selectcontractrow();
			Web.waitForElement(ds, "PartyProfile_Button");
			Web.clickOnElement(ds, "PartyProfile_Button");
			Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
			
			DemographicChange Demo = new DemographicChange(ds);
			Demo.get();
			Demo.ClickonDeathpending();
			Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
			
			DeathPending dp = new DeathPending(Demo);
			dp.get();
			dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));
			Web.selectDropDownOption(dp, "Life_Status", Stock.GetParameterValue("LifeStatus"), false);
			dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
			Web.clickOnElement(dp, "DeathPending_CheckBox");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			om.get();
			om.entercontractid(Common.Contractinfo.get("Contractid"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
			
			g.get();
			g.VerifyDeathStatus();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
			
			DeathClaim dc = new DeathClaim(dp);
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));	
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			trs.doubleclickTBTransaction();
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse"));
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim_Bene5yrContinuation(int itr, Map<String, String> testdata) {

		try {
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			
		/*	SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Clicked on DeathClaim Submenu", true);
			
			DeathClaim dc = new DeathClaim(g);
			dc.get();			
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			Summary su = new Summary(dc);
			SelectPartner sp = new SelectPartner(su);
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(sp);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			trs.doubleclickTBTransaction();
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse"));
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim_DeathContinuation_3beneficiary(int itr, Map<String, String> testdata) {

		try {
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			
			/*SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Clicked on DeathClaim Submenu", true);
			
			DeathClaim dc = new DeathClaim(g);
			dc.get();			
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			//1st beneficary for death contiuation
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit1"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse1"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			//2nd benificary for death continuation
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit2"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State2"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse2"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City2"));
			dc.SelectPayeeState(Stock.GetParameterValue("State2"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			// 3rd Beneficary for death contiuation
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit3"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State3"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse3"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City3"));
			dc.SelectPayeeState(Stock.GetParameterValue("State3"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			Summary su = new Summary(dc);
			SelectPartner sp = new SelectPartner(su);
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			trs.doubleclickTBTransaction();
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse1"));
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse2"));
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse3"));
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim_DeathContinuation_3beneficiary(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.ClickRoleSilderBar();
			g.GetDirectorID();
			g.ClickRoleSilderBar();
			Summary su = new Summary(g);
			SelectPartner sp = new SelectPartner(g);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
			
			Home om = new Home(sp);
			om.get();
			om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
			
			DetailsSearch ds = new DetailsSearch(om);
			ds.get();
			ds.Selectcontractrow();
			Web.waitForElement(ds, "PartyProfile_Button");
			Web.clickOnElement(ds, "PartyProfile_Button");
			Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
			
			DemographicChange Demo = new DemographicChange(ds);
			Demo.get();
			Demo.ClickonDeathpending();
			Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
			
			DeathPending dp = new DeathPending(Demo);
			dp.get();
			dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));
			Web.selectDropDownOption(dp, "Life_Status", Stock.GetParameterValue("LifeStatus"), false);
			dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
			Web.clickOnElement(dp, "DeathPending_CheckBox");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			om.get();
			om.entercontractid(Common.Contractinfo.get("Contractid"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
			
			g.get();
			g.VerifyDeathStatus();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
			
			DeathClaim dc = new DeathClaim(dp);
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			//1st beneficary for death contiuation
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit1"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse1"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			//2nd benificary for death continuation
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit2"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State2"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse2"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City2"));
			dc.SelectPayeeState(Stock.GetParameterValue("State2"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			// 3rd Beneficary for death contiuation
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit3"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State3"));
			Web.waitForElement(dc,"Disbursement");
			Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("Disburse3"), false);		
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City3"));
			dc.SelectPayeeState(Stock.GetParameterValue("State3"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			Web.waitForElement(dc,"Create_Policy");
			Web.selectDropDownOption(dc, "Create_Policy", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Create_Payment");
			Web.selectDropDownOption(dc, "Create_Payment", Stock.GetParameterValue("CreatePolicy"), false);
			Web.waitForElement(dc,"Spousal_Type");
			Web.selectDropDownOption(dc, "Spousal_Type", Stock.GetParameterValue("SpousalType"), false);
			dc.ClickUpdatePayee();
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			trs.doubleclickTBTransaction();
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse1"));
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse2"));
			trs.VerifynewContractID(Stock.GetParameterValue("Disburse3"));
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathPending_DeathClaim_Multiplebeneficary(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.get();
			g.ClickRoleSilderBar();
			g.GetDirectorID();
			g.ClickRoleSilderBar();
			Summary su = new Summary(g);
			SelectPartner sp = new SelectPartner(su);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and taken the Directory ID", true);
			
			Home om = new Home(g);
			om.get();
			om.EnterDirectorID(Common.Contractinfo.get("DirectorID"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Directory ID", true);
			
			DetailsSearch ds = new DetailsSearch(om);
			ds.get();
			ds.Selectcontractrow();
			Web.waitForElement(ds, "PartyProfile_Button");
			Web.clickOnElement(ds, "PartyProfile_Button");
			Reporter.logEvent(Status.INFO, "In Detail Search page", "page is displayed and Selected the Policy", true);
			
			DemographicChange Demo = new DemographicChange(ds);
			Demo.get();
			Demo.ClickonDeathpending();
			Reporter.logEvent(Status.INFO, "In Demographic Change page", "page is displayed and Selected the Death Pending", true);
			
			DeathPending dp = new DeathPending(Demo);
			dp.get();
			dp.EnterDeathPendingEffectiveDate(Stock.GetParameterValue("DODeathdate"));
			Web.selectDropDownOption(dp, "Life_Status", Stock.GetParameterValue("LifeStatus"), false);
			dp.EnterDateOfDeath(Stock.GetParameterValue("DODeathdate"));
			Web.clickOnElement(dp, "DeathPending_CheckBox");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Pending page", "page is displayed and Death Pending Transaction done", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			om.get();
			om.entercontractid(Common.Contractinfo.get("Contractid"));
			Web.waitForElement(om, "Serach_Button");
			Web.clickOnElement(om, "Serach_Button");
			Reporter.logEvent(Status.INFO, "In Home page", "page is displayed and Entered the Contract ID", true);
			
			g.get();
			g.VerifyDeathStatus();
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Verified the status as Death Pending", true);
			
			DeathClaim dc = new DeathClaim(dp);
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit1"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State3"));			
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City3"));
			dc.SelectPayeeState(Stock.GetParameterValue("State3"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			// 2nd payee
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit2"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State2"));			
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City2"));
			dc.SelectPayeeState(Stock.GetParameterValue("State2"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim_Multiplebeneficary(int itr, Map<String, String> testdata) {

		try {
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    	
			*//**
			 * Step 16 - Enter Fund information
			 * .
			 *//*	
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
		    Web.clickOnElement(su,"Summary_Finishbtn");			    
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");	*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			General g = new General(landing);
			g.CLickonDeathClaimSubmenu();
			Reporter.logEvent(Status.INFO, "In General page", "page is displayed and Clicked on DeathClaim Submenu", true);
			
			DeathClaim dc = new DeathClaim(g);			
			dc.get();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit1"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State"));
		//	Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("ctradd_realtime"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City"));
			dc.SelectPayeeState(Stock.GetParameterValue("State"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			//2nd payee added
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit2"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State2"));
		//	Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("ctradd_realtime"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City2"));
			dc.SelectPayeeState(Stock.GetParameterValue("State2"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			//3rd payee added
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit3"));
			dc.SelectPayeeResState(Stock.GetParameterValue("State3"));
		//	Web.selectDropDownOption(dc, "Disbursement", Stock.GetParameterValue("ctradd_realtime"), false);
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterPersonalDOB(Stock.GetParameterValue("Dateofbirth"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("City3"));
			dc.SelectPayeeState(Stock.GetParameterValue("State3"));
			dc.Enterpayeezipcode();
			dc.ClickOkbutton("Click");
			Thread.sleep(1500);
			Common.switchto_mainwindow();
			Thread.sleep(1500);
			dc.ClickUpdatePayee();
			Summary su = new Summary(dc);
			SelectPartner sp = new SelectPartner(su);
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "In Death Claim page", "page is displayed and Entered the Death details", true);
			
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(dc);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the PA-Deathclaim transaction happen on the effective date which
			// we have given
			trs.verifyPA_DEAThCLAIMtransaction(Stock.GetParameterValue("DCEffectivedate"));
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the PA-DEathclaim tranasaction", true);
			
			// want to verify whether the status check change to D-death 
			trs.verifystatusD_Death();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed status as D-Death", true);
		    Web.clickOnElement(su, "Summary_Homebtn");
			Web.waitForElement(sp, "accumulationlink");
			
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}
