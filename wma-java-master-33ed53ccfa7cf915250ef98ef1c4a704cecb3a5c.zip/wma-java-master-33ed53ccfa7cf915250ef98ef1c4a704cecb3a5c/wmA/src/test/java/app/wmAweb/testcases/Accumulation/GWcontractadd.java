package app.wmAweb.testcases.Accumulation;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BeneficiaryInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.HCCExpressAdd;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.OwnerInfo;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.RIAInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;

public class GWcontractadd {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	
//*************************TEST CASE 1.1 Add Non NY Smart track II 5 year with No Rider************************************************************************************
	/** Test Case Name:Add Non NY Smart track II 5 year with No Rider
	 * 
	 * This Test Case to Verify, user able to Add contract for the Smart track II
	 * For the non New York state 
	 * No Raider
	 * @param itr
	 * @param testdata
	 */
		@Test(dataProvider = "setData")
		public void TC1_wmA_Accumulation_AddNonNYSmartTrackII5YrwithNoRider(int itr, Map<String, String> testdata) {

			try {
				
				
				
				Reporter.initializeReportForTC(
						itr,
						Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
								.currentThread().getId())
								+ "_"
								+ Stock.getConfigParam("BROWSER"));
				Reporter
				.logEvent(
						Status.INFO,
						"Test Data used for this Test Case:",
						printTestData(),
						false);
				/**
				 * Step 1 -PreRequisite: 1.Login wmA Application
				 * Login Successful to UAT-Support home page
				 * verify the wmA home page user successfully and navigate to the 
				 * Hover mouse over menu item Accumulation and select Contract Add
				 */
			/*	LandingPage landing = new LandingPage();
				SelectPartner sp = new SelectPartner(landing);
				sp.get();
				Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
				Web.clickOnElement(sp,"accumulationlink");
				
				*//**
				 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
				 * Partner is successfully selected and Select Criteria Page is loaded
				 * 
				 *//*		
				sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
				Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
				Web.clickOnElement(sp,"Next_Button");
				*//**
				 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
				 * Step 4 - Select Variable  from the Product field.
				 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
				 * .
				 *//*		
				SelectCriteria sc = new SelectCriteria(sp);
				sc.get();
				sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
				Web.clickOnElement(sp,"Next_Button");
				*//**
				 * Step 6 - Select Base Plan from the drop-down
				 * Step 7 - Select Statutory Company - GWA from the drop-down
				 * Step 8 - Select any Line of Business from column
				 * 
				 * .
				 *//*	
				SelectPlan pln = new SelectPlan (sc);
				pln.get();				
				pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));	
				Web.clickOnElement(sp,"Next_Button");
				*//**
				 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
				 * Step 10 - Select Role/Type: Advisor from the drop down
				 * Step 11 - Enter First Year % and Renewal % and click Next
				 * .
				 *//*	
				
				 ProducerInfo pi = new ProducerInfo(pln);
				 pi.get();			
				 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
				 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
				 Common.switchto_newwindow();
				 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
				 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
				 Common.switchto_mainwindow();
				 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
				 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
				 Web.clickOnElement(sp,"Next_Button");				 
				 *//**
					 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
					 * .
					 *//*				    
			    AnnuitantInfo ai = new AnnuitantInfo(pi);
			    ai.get();			    
			    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
			    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			    Web.clickOnElement(sp,"Next_Button");			    
			    *//**
				 * Step 13 - Enter contract information
				 * .
				 *//*	
			    ContractInfo ci = new ContractInfo(ai);
			    ci.get();
			    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			    Web.clickOnElement(sp,"Next_Button");
			    *//**
				 * Step 14 - Enter Billing information
				 * .
				 *//*				    
			    BillingInfo bi = new BillingInfo(ci);
			    bi.get();
			    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			    Web.clickOnElement(sp,"Next_Button");
			    *//**
				 * Step 15 - Enter Fund information
				 * .
				 *//*	
			
				FundInfo fi = new FundInfo(bi);
				fi.get();
				fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
				Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
				Web.clickOnElement(sp,"Next_Button");
				 *//**
				 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
				 * .
				 *//*					
				Summary su = new Summary(fi);
				su.get();				
				Web.waitForElement(su, "Summary_Realtimewait");
			    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
			    Web.clickOnElement(su,"Summary_Finishbtn");			
				
			    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				
				su.getpolicynumber();			   
				Web.clickOnElement(su,"Summary_Homebtn");
				Web.waitForElement(sp,"accumulationlink");*/
				Common.CreateContractAdd();
				
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
						.getCause().getMessage(), true);
			} catch (Error ae) {
				ae.printStackTrace();
				Globals.error = ae;
				Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
						"Assertion Failed!!", true);

			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		
//*************************TEST CASE 1.2 Add Non NY Smart track II 5 year with Max Rider************************************************************************************
		/** Test Case Name:Add Non NY Smart track II 5 year with Max Rider
		 * 
		 * This Test Case to Verify, user able to Add contract for the Smart track II
		 * For the  New York state 
		 * No Raider
		 * @param itr
		 * @param testdata
		 */
			@Test(dataProvider = "setData")
			public void TC2_wmA_Accumulation_AddNYSmartTrackII5YrwithMaxRider(int itr, Map<String, String> testdata) {

				try {
					
					
					
					Reporter.initializeReportForTC(
							itr,
							Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
									.currentThread().getId())
									+ "_"
									+ Stock.getConfigParam("BROWSER"));
					Reporter
					.logEvent(
							Status.INFO,
							"Test Data used for this Test Case:",
							printTestData(),
							false);
					/**
					 * Step 1 -PreRequisite: 1.Login wmA Application
					 * Login Successful to UAT-Support home page
					 * verify the wmA home page user successfully and navigate to the 
					 * Hover mouse over menu item Accumulation and select Contract Add
					 */
				/*	LandingPage landing = new LandingPage();
					SelectPartner sp = new SelectPartner(landing);
					sp.get();
					Web.clickOnElement(sp,"accumulationlink");					
					*//**
					 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
					 * Partner is successfully selected and Select Criteria Page is loaded
					 * 
					 *//*	
					sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
					Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
					Web.clickOnElement(sp,"Next_Button");
					*//**
					 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
					 * Step 4 - Select Variable  from the Product field.
					 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
					 * .
					 *//*		
					SelectCriteria sc = new SelectCriteria(sp);
					sc.get();
					sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));					
					Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
					Web.clickOnElement(sp,"Next_Button");
					*//**
					 * Step 6 - Select Base Plan from the drop-down
					 * Step 7 - Select Statutory Company - GWA from the drop-down
					 * Step 8 - Select any Line of Business from column
					 * 
					 * .
					 *//*	
					SelectPlan pln = new SelectPlan (sc);
					pln.get();					
					pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
					Web.clickOnElement(pln,"ClickOnriderbox");
					Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
					Web.clickOnElement(sp,"Next_Button");
					*//**
					 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
					 * Step 10 - Select Role/Type: Advisor from the drop down
					 * Step 11 - Enter First Year % and Renewal % and click Next
					 * .
					 *//*						
					 ProducerInfo pi = new ProducerInfo(pln);
					 pi.get();
					 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
					 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
					 Common.switchto_newwindow();
					 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
					 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
					 Common.switchto_mainwindow();
					 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));					 
					 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
					 Web.clickOnElement(sp,"Next_Button");					 
					 *//**
						 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
						 * .
						 *//*					    
				    AnnuitantInfo ai = new AnnuitantInfo(pi);
				    ai.get();				    
				    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));				    
				    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
				    Web.clickOnElement(sp,"Next_Button");				    
				    *//**
					 * Step 13 - Enter contract information
					 * .
					 *//*	
				    ContractInfo ci = new ContractInfo(ai);
				    ci.get();
				    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
				    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
				    Web.clickOnElement(sp,"Next_Button");
				    *//**
					 * Step 14 - Enter Billing information
					 * .
					 *//*					    
				    BillingInfo bi = new BillingInfo(ci);
				    bi.get();
				    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
				    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
				    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
				    Web.clickOnElement(sp,"Next_Button");				    
				    *//**
					 * Step 15 - Enter HCC Express Add information
					 * .
					 *//*					    
					HCCExpressAdd rider = new HCCExpressAdd(bi);
					Web.waitForElement(rider, "HCC_Select_RiderType");
					Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);				
				    Web.clickOnElement(rider,"HCC_ClickOn_Add");		
				    Web.waitForElement(rider, "HCC_Select_RiderPlan");
				    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);			
					Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
					Web.clickOnElement(sp,"Next_Button");				
				    *//**
					 * Step 16 - Enter Fund information
					 * .
					 *//*					
					FundInfo fi = new FundInfo(rider);
					fi.get();
					fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
					Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
					Web.clickOnElement(sp,"Next_Button");
					 *//**
					 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
					 * .
					 *//*						
					Summary su = new Summary(fi);
					su.get();					
					Web.waitForElement(su, "Summary_Realtimewait");
				    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);			    				    
				    Web.clickOnElement(su,"Summary_Finishbtn");				
					su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
					su.getpolicynumber();
					Web.clickOnElement(su,"Summary_Homebtn");*/
					Common.CreateContractAdd();
							
				} catch (Exception e) {
					e.printStackTrace();
					Globals.exception = e;
					Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
							.getCause().getMessage(), true);
				} catch (Error ae) {
					ae.printStackTrace();
					Globals.error = ae;
					Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
							"Assertion Failed!!", true);

				} finally {
					try {
						Reporter.finalizeTCReport();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		
//*************************TEST CASE 1.3 Add Non NY Smart track Advisor with Fixed Rider************************************************************************************
			/** Test Case Name:Add Non NY Smart track Advisor with Fixed Rider
			 * 
			 * This Test Case to Verify, user able to Add contract for the Smart track II
			 * For the  New York state 
			 * No Raider
			 * @param itr
			 * @param testdata
			 */
				@Test(dataProvider = "setData")
				public void TC3_wmA_Accumulation_AddNonNYSmartTrackAdvisorwithFixedRider(int itr, Map<String, String> testdata) {

					try {
						
						
						
						Reporter.initializeReportForTC(
								itr,
								Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
										.currentThread().getId())
										+ "_"
										+ Stock.getConfigParam("BROWSER"));
						Reporter
						.logEvent(
								Status.INFO,
								"Test Data used for this Test Case:",
								printTestData(),
								false);
						/**
						 * Step 1- PreRequisite: 1.Login wmA Application
						 * Login Successful to UAT-Support home page
						 * verify the wmA home page user successfully and navigate to the 
						 * Hover mouse over menu item Accumulation and select Contract Add
						 */
					/*	LandingPage landing = new LandingPage();
						SelectPartner sp = new SelectPartner(landing);
						sp.get();
						Web.clickOnElement(sp,"Submenu_contractAdd");
						*//**
						 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
						 * Partner is successfully selected and Select Criteria Page is loaded
						 * 
						 *//*		
						sp.selectpartner( Stock.GetParameterValue("SelectPartner"));				
						Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
						Web.clickOnElement(sp,"Next_Button");
						*//**
						 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
						 * Step 4 - Select Variable  from the Product field.
						 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
						 * .
						 *//*		
						SelectCriteria sc = new SelectCriteria(sp);
						sc.get();
						sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));						
						Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
						Web.clickOnElement(sp,"Next_Button");
						*//**
						 * Step 6 - Select Base Plan from the drop-down
						 * Step 7 - Select Statutory Company - GWA from the drop-down
						 * Step 8 - Select any Line of Business from column
						 * 
						 * .
						 *//*	
						SelectPlan pln = new SelectPlan (sc);
						pln.get();						
						pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
						Web.clickOnElement(pln,"ClickOnriderbox");
						Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
						Web.clickOnElement(sp,"Next_Button");
						*//**
						 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
						 * Step 10 - Select Role/Type: Advisor from the drop down
						 * Step 11 - Enter First Year % and Renewal % and click Next
						 * .
						 *//*							
						 ProducerInfo pi = new ProducerInfo(pln);
						 pi.get();
						 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
						 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
						 Common.switchto_newwindow();
						 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
						 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
						 Common.switchto_mainwindow();
						 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));						 
						 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
						 Web.clickOnElement(sp,"Next_Button");						 
						 *//**
							 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
							 * .
							 *//*						    
					    AnnuitantInfo ai = new AnnuitantInfo(pi);
					    ai.get();					    
					    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));					    
					    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
					    Web.clickOnElement(sp,"Next_Button");					    
					    *//**
						 * Step 13 - Enter contract information
						 * .
						 *//*	
					    ContractInfo ci = new ContractInfo(ai);
					    ci.get();
					    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
					    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
					    Web.clickOnElement(sp,"Next_Button");
					    *//**
						 * Step 14 - Enter Billing information
						 * .
						 *//*						    
					    BillingInfo bi = new BillingInfo(ci);
					    bi.get();
					    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
					    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
					    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
					    Web.clickOnElement(sp,"Next_Button");					    
					    *//**
						 * Step 15 - Enter HCC Express Add information
						 * .
						 *//*						    
						HCCExpressAdd rider = new HCCExpressAdd(bi);
						Web.waitForElement(rider, "HCC_Select_RiderType");
						Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);					
					    Web.clickOnElement(rider,"HCC_ClickOn_Add");
					    Web.waitForElement(rider, "HCC_Select_RiderPlan");
					    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);					
						Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
						Web.clickOnElement(sp,"Next_Button");					
					    *//**
						 * Step 16 - Enter Fund information
						 * .
						 *//*						
						FundInfo fi = new FundInfo(rider);
						fi.get();
						fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
						Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
						Web.clickOnElement(sp,"Next_Button");
						 *//**
						 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
						 * .
						 *//*							
						Summary su = new Summary(fi);
						su.get();						
						Web.waitForElement(su, "Summary_Realtimewait");
					    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);					
					    Web.clickOnElement(su,"Summary_Finishbtn");					
						su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
						su.getpolicynumber();
						Web.clickOnElement(su,"Summary_Homebtn");*/
						
						Common.CreateContractAdd();
								
					} catch (Exception e) {
						e.printStackTrace();
						Globals.exception = e;
						Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
								.getCause().getMessage(), true);
					} catch (Error ae) {
						ae.printStackTrace();
						Globals.error = ae;
						Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
								"Assertion Failed!!", true);

					} finally {
						try {
							Reporter.finalizeTCReport();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				}
		
//*************************TEST CASE 1.4 Add  NY Smart track II 5 year with No Rider************************************************************************************
				/** Test Case Name:Add  NY Smart track II 5 year with No Rider
				 * 
				 * This Test Case to Verify, user able to Add contract for the Smart track II
				 * For the non New York state 
				 * No Raider
				 * @param itr
				 * @param testdata
				 */
					@Test(dataProvider = "setData")
					public void TC4_wmA_Accumulation_AddNYSmartTrackAdvisorwithnoRider(int itr, Map<String, String> testdata) {

						try {
							
							
							
							Reporter.initializeReportForTC(
									itr,
									Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
											.currentThread().getId())
											+ "_"
											+ Stock.getConfigParam("BROWSER"));
							Reporter
							.logEvent(
									Status.INFO,
									"Test Data used for this Test Case:",
									printTestData(),
									false);
							/**
							 * Step 1 -PreRequisite: 1.Login wmA Application
							 * Login Successful to UAT-Support home page
							 * verify the wmA home page user successfully and navigate to the 
							 * Hover mouse over menu item Accumulation and select Contract Add
							 */
					/*		LandingPage landing = new LandingPage();
							SelectPartner sp = new SelectPartner(landing);
							sp.get();
							Web.clickOnElement(sp,"Submenu_contractAdd");
							*//**
							 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
							 * Partner is successfully selected and Select Criteria Page is loaded
							 * 
							 *//*	
							sp.selectpartner( Stock.GetParameterValue("SelectPartner"));						
							Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
							Web.clickOnElement(sp,"Next_Button");
							*//**
							 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
							 * Step 4 - Select Variable  from the Product field.
							 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
							 * .
							 *//*		
							SelectCriteria sc = new SelectCriteria(sp);
							sc.get();
							sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));							
							Web.clickOnElement(sp,"Next_Button");
							*//**
							 * Step 6 - Select Base Plan from the drop-down
							 * Step 7 - Select Statutory Company - GWA from the drop-down
							 * Step 8 - Select any Line of Business from column
							 * 
							 * .
							 *//*	
							SelectPlan pln = new SelectPlan (sc);
							pln.get();							
							pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));				
							Web.clickOnElement(sp,"Next_Button");
							*//**
							 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
							 * Step 10 - Select Role/Type: Advisor from the drop down
							 * Step 11 - Enter First Year % and Renewal % and click Next
							 * .
							 *//*								
							 ProducerInfo pi = new ProducerInfo(pln);
							pi.get();
							pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
							Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
							Common.switchto_newwindow();
							Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
							Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
							Common.switchto_mainwindow();
							pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));							 
						    Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
							Web.clickOnElement(sp,"Next_Button");							 
							 *//**
								 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
								 * .
								 *//*							    
						    AnnuitantInfo ai = new AnnuitantInfo(pi);
						    ai.get();						    
						    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));						    
						    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
						    Web.clickOnElement(sp,"Next_Button");						    
						    *//**
							 * Step 12 - Enter contract information
							 * .
							 *//*	
						    ContractInfo ci = new ContractInfo(ai);
						    ci.get();
						    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
						    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
						    Web.clickOnElement(sp,"Next_Button");
						    *//**
							 * Step 13 - Enter Billing information
							 * .
							 *//*							    
						    BillingInfo bi = new BillingInfo(ci);
						    bi.get();
						    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
						    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
						    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
						    Web.clickOnElement(sp,"Next_Button");
						    *//**
							 * Step 14 - Enter Fund information
							 * .
							 *//*							
							FundInfo fi = new FundInfo(bi);
							fi.get();
							fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
							Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
							Web.clickOnElement(sp,"Next_Button");
							 *//**
							 * Step 14 - Click submit real time processing summary Finish button verify the Transaction message
							 * .
							 *//*								
							Summary su = new Summary(fi);
							su.get();							
							Web.waitForElement(su, "Summary_Realtimewait");
						    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);						
						    Web.clickOnElement(su,"Summary_Finishbtn");						
							su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
							su.getpolicynumber();
							Web.clickOnElement(su,"Summary_Homebtn");*/
							
							Common.CreateContractAdd();
									
						} catch (Exception e) {
							e.printStackTrace();
							Globals.exception = e;
							Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
									.getCause().getMessage(), true);
						} catch (Error ae) {
							ae.printStackTrace();
							Globals.error = ae;
							Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
									"Assertion Failed!!", true);

						} finally {
							try {
								Reporter.finalizeTCReport();
							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					}
//*************************TEST CASE 1.5 Add Non NY Schwab Advisor Choice with Fixed Rider************************************************************************************
					/** Test Case Name:Add Non NY Schwab Advisor Choice with Fixed Rider
					 * 
					 * This Test Case to Verify, user able to dd Non NY Schwab Advisor Choice with Fixed Rider
					 * For the non newyork state 
					 * No Raider
					 * @param itr
					 * @param testdata
					 */
						@Test(dataProvider = "setData")
						public void TC5_wmA_Accumulation_AddNonNYSchwabAdvisorChoicewithFixedRider(int itr, Map<String, String> testdata) {

							try {
								
								
								
								Reporter.initializeReportForTC(
										itr,
										Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
												.currentThread().getId())
												+ "_"
												+ Stock.getConfigParam("BROWSER"));
								Reporter
								.logEvent(
										Status.INFO,
										"Test Data used for this Test Case:",
										printTestData(),
										false);
								/**
								 * Step 1 -PreRequisite: 1.Login wmA Application
								 * Login Successful to UAT-Support home page
								 * verify the wmA home page user successfully and navigate to the 
								 * Hover mouse over menu item Accumulation and select Contract Add
								 */
						/*		LandingPage landing = new LandingPage();
								SelectPartner sp = new SelectPartner(landing);
								sp.get();
								Web.clickOnElement(sp,"Submenu_contractAdd");
								*//**
								 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
								 * Partner is successfully selected and Select Criteria Page is loaded
								 * 
								 *//*	
								sp.selectpartner( Stock.GetParameterValue("SelectPartner"));							
								Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
								Web.clickOnElement(sp,"Next_Button");
								*//**
								 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
								 * Step 4 - Select Variable  from the Product field.
								 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
								 * .
								 *//*		
								SelectCriteria sc = new SelectCriteria(sp);
								sc.get();
								sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));								
								Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
								Web.clickOnElement(sp,"Next_Button");
								*//**
								 * Step 6 - Select Base Plan from the drop-down
								 * Step 7 - Select Statutory Company - GWA from the drop-down
								 * Step 8 - Select any Line of Business from column
								 * 
								 * .
								 *//*	
								SelectPlan pln = new SelectPlan (sc);
								pln.get();								
								pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
								Web.clickOnElement(pln,"ClickOnriderbox");
								Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
								Web.clickOnElement(sp,"Next_Button");
								*//**
								 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
								 * Step 10 - Select Role/Type: Advisor from the drop down
								 * Step 11 - Enter First Year % and Renewal % and click Next
								 * .
								 *//*									
								 ProducerInfo pi = new ProducerInfo(pln);
								 pi.get();
								 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
								 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
								 Common.switchto_newwindow();
								 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
								 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
								 Common.switchto_mainwindow();
								 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));								 
								 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
								 Web.clickOnElement(sp,"Next_Button");								 
								 *//**
									 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
									 * .
									 *//*								    
							    AnnuitantInfo ai = new AnnuitantInfo(pi);
							    ai.get();							    
							    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));							    
							    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
							    Web.clickOnElement(sp,"Next_Button");							    
							    *//**
								 * Step 13 - Enter contract information
								 * .
								 *//*	
							    ContractInfo ci = new ContractInfo(ai);
							    ci.get();
							    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
							    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
							    Web.clickOnElement(sp,"Next_Button");
							    *//**
								 * Step 14 - Enter Billing information
								 * .
								 *//*								    
							    BillingInfo bi = new BillingInfo(ci);
							    bi.get();
							    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
							    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
							    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
							    Web.clickOnElement(sp,"Next_Button");							    
							    *//**
								 * Step 15 - Enter HCC Express Add information
								 * .
								 *//*								    
								HCCExpressAdd rider = new HCCExpressAdd(bi);
								Web.waitForElement(rider, "HCC_Select_RiderType");
								Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);							
							    Web.clickOnElement(rider,"HCC_ClickOn_Add");						
							    Web.waitForElement(rider, "HCC_Select_RiderPlan");
							    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);						
								Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
								Web.clickOnElement(sp,"Next_Button");							
							    *//**
								 * Step 16 - Enter Fund information
								 * .
								 *//*								
								FundInfo fi = new FundInfo(rider);
								fi.get();
								fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
								Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
								Web.clickOnElement(sp,"Next_Button");
								 *//**
								 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
								 * .
								 *//*									
								Summary su = new Summary(fi);
								su.get();								
								Web.waitForElement(su, "Summary_Realtimewait");
							    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);							
							    Web.clickOnElement(su,"Summary_Finishbtn");							
								su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
								su.getpolicynumber();
								Web.clickOnElement(su,"Summary_Homebtn");*/
								
								Common.CreateContractAdd();
								
										
							} catch (Exception e) {
								e.printStackTrace();
								Globals.exception = e;
								Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
										.getCause().getMessage(), true);
							} catch (Error ae) {
								ae.printStackTrace();
								Globals.error = ae;
								Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
										"Assertion Failed!!", true);

							} finally {
								try {
									Reporter.finalizeTCReport();
								} catch (Exception e1) {
									e1.printStackTrace();
								}
							}
						}
//*************************TEST CASE 1.6 Add NY Schwab One Source Choice with FixedRider************************************************************************************
						/** Test Case Name:Add NY Schwab One Source Choice with FixedRider
						 * 
						 * This Test Case to Verify, user able to  Add NY Schwab One Source Choice with FixedRider
						 * For the  newyork state 
						 * No Raider
						 * @param itr
						 * @param testdata
						 */
							@Test(dataProvider = "setData")
							public void TC6_wmA_Accumulation_AddNYSchwabOneSourceChoicewithFixedRider(int itr, Map<String, String> testdata) {

								try {
									
									
									
									Reporter.initializeReportForTC(
											itr,
											Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
													.currentThread().getId())
													+ "_"
													+ Stock.getConfigParam("BROWSER"));
									Reporter
									.logEvent(
											Status.INFO,
											"Test Data used for this Test Case:",
											printTestData(),
											false);
									/**
									 * Step 1 -Pre-Requisite: 1.Login wmA Application
									 * Login Succesful to UAT-Support home page
									 * verify the wmA home page user successfully and navigate to the 
									 * Hover mouse over menu item Accumulation and select Contract Add
									 */
						/*			LandingPage landing = new LandingPage();
									SelectPartner sp = new SelectPartner(landing);
									sp.get();
									Web.clickOnElement(sp,"Submenu_contractAdd");
									*//**
									 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
									 * Partner is successfully selected and Select Criteria Page is loaded
									 * 
									 *//*	
									sp.selectpartner( Stock.GetParameterValue("SelectPartner"));								
									Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
									Web.clickOnElement(sp,"Next_Button");
									*//**
									 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
									 * Step 4 - Select Variable  from the Product field.
									 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
									 * .
									 *//*		
									SelectCriteria sc = new SelectCriteria(sp);
									sc.get();
									sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));									
									Reporter.logEvent(Status.INFO, "Select Criteria", "page is displayed", true);
									Web.clickOnElement(sp,"Next_Button");
									*//**
									 * Step 6 - Select Base Plan from the drop-down
									 * Step 7 - Select Statutory Company - GWA from the drop-down
									 * Step 8 - Select any Line of Business from column
									 * 
									 * .
									 *//*	
									SelectPlan pln = new SelectPlan (sc);
									pln.get();									
									pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
									Web.clickOnElement(pln,"ClickOnriderbox");
									Reporter.logEvent(Status.INFO, "Select Plan", "page is displayed", true);
									Web.clickOnElement(sp,"Next_Button");
									*//**
									 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
									 * Step 10 - Select Role/Type: Advisor from the drop down
									 * Step 11 - Enter First Year % and Renewal % and click Next
									 * .
									 *//*										
									 ProducerInfo pi = new ProducerInfo(pln);
									 pi.get();
									 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
									 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
									 Common.switchto_newwindow();
									 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
									 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
									 Common.switchto_mainwindow();
									 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));									 
									 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
									 Web.clickOnElement(sp,"Next_Button");									 
									 *//**
										 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
										 * .
										 *//*									    
								    AnnuitantInfo ai = new AnnuitantInfo(pi);
								    ai.get();								    
								    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));								    
								    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
								    Web.clickOnElement(sp,"Next_Button");								    
								    *//**
									 * Step 13 - Enter contract information
									 * .
									 *//*	
								    ContractInfo ci = new ContractInfo(ai);
								    ci.get();
								    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
								    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
								    Web.clickOnElement(sp,"Next_Button");
								    *//**
									 * Step 14 - Enter Billing information
									 * .
									 *//*									    
								    BillingInfo bi = new BillingInfo(ci);
								    bi.get();
								    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
								    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
								    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
								    Web.clickOnElement(sp,"Next_Button");								    
								    *//**
									 * Step 15 - Enter HCC Express Add information
									 * .
									 *//*									    
									HCCExpressAdd rider = new HCCExpressAdd(bi);
									Web.waitForElement(rider, "HCC_Select_RiderType");
									Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);							
								    Web.clickOnElement(rider,"HCC_ClickOn_Add");							
								    Web.waitForElement(rider, "HCC_Select_RiderPlan");
								    Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);								
									Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
									Web.clickOnElement(sp,"Next_Button");							
								    *//**
									 * Step 16 - Enter Fund information
									 * .
									 *//*									
									FundInfo fi = new FundInfo(rider);
									fi.get();
									fi.entercoveredfund(Stock.GetParameterValue("GROWTHINV"));
									Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
									Web.clickOnElement(sp,"Next_Button");
									 *//**
									 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
									 * .
									 *//*										
									Summary su = new Summary(fi);
									su.get();									
									Web.waitForElement(su, "Summary_Realtimewait");
								    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);								
								    Web.clickOnElement(su,"Summary_Finishbtn");								
									su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
									su.getpolicynumber();
									Web.clickOnElement(su,"Summary_Homebtn");*/
									Common.CreateContractAdd();
											
								} catch (Exception e) {
									e.printStackTrace();
									Globals.exception = e;
									Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
											.getCause().getMessage(), true);
								} catch (Error ae) {
									ae.printStackTrace();
									Globals.error = ae;
									Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
											"Assertion Failed!!", true);

								} finally {
									try {
										Reporter.finalizeTCReport();
									} catch (Exception e1) {
										e1.printStackTrace();
									}
								}
							}
							
//*************************TEST CASE 1.7 Add Non NY Smart track II 5 year with No Rider************************************************************************************
            /** Test Case Name:Add Non NY Smart track II 5 year with No Rider
			 * 
			 * This Test Case to Verify, user able to Add Non NY Smart track II 5 year with No Rider
			 * For the non newyork state 
			 * No Raider
			 * @param itr
			 * @param testdata
			 */
								@Test(dataProvider = "setData")
								public void TC7_wmA_Accumulation_AddSchwabAdvisorChoicewithnoriderRIA(int itr, Map<String, String> testdata) {

									try {
										
										
										
										Reporter.initializeReportForTC(
												itr,
												Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
														.currentThread().getId())
														+ "_"
														+ Stock.getConfigParam("BROWSER"));
										Reporter
										.logEvent(
												Status.INFO,
												"Test Data used for this Test Case:",
												printTestData(),
												false);
										/**
										 * Step 1 -Pre-Requisite: 1.Login wmA Application
										 * Login Succesful to UAT-Support home page
										 * verify the wmA home page user successfully and navigate to the 
										 * Hover mouse over menu item Accumulation and select Contract Add
										 */
										LandingPage landing = new LandingPage();
										SelectPartner sp = new SelectPartner(landing);
										sp.get();
										Web.clickOnElement(sp,"Submenu_contractAdd");
										/**
										 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
										 * Partner is successfully selected and Select Criteria Page is loaded
										 * 
										 */		
										sp.selectpartner( Stock.GetParameterValue("SelectPartner"));								
										Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
										Web.clickOnElement(sp,"Next_Button");
										/**
										 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
										 * Step 4 - Select Variable  from the Product field.
										 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
										 * .
										 */		
										SelectCriteria sc = new SelectCriteria(sp);
										sc.get();
										sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));										
										Web.clickOnElement(sp,"Next_Button");
										/**
										 * Step 6 - Select Base Plan from the drop-down
										 * Step 7 - Select Statutory Company - GWA from the drop-down
										 * Step 8 - Select any Line of Business from column
										 * 
										 * .
										 */	
										SelectPlan pln = new SelectPlan (sc);
										pln.get();										
										pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));							
										Web.clickOnElement(sp,"Next_Button");
										/**
										 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
										 * Step 10 - Select Role/Type: Advisor from the drop down
										 * Step 11 - Enter First Year % and Renewal % and click Next
										 * .
										 */											
										 ProducerInfo pi = new ProducerInfo(pln);
										 pi.get();
										 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
										 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
										 Common.switchto_newwindow();
										 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
										 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
										 Common.switchto_mainwindow();
										 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));										 
										 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
										 Web.clickOnElement(sp,"Next_Button");										 
										 /**
											 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
											 * .
											 */										    
									    AnnuitantInfo ai = new AnnuitantInfo(pi);
									    ai.get();
									    Web.waitForElement(ai, "AnnuitantInfo_ClickOnRIAcheckbox");
									    Web.clickOnElement(ai,"AnnuitantInfo_ClickOnRIAcheckbox");
									    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));									    
									    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
									    Web.clickOnElement(sp,"Next_Button");									    
									    /**
										 * Step 13 - Enter RIA information
										 * .
										 */										    
									    RIAInfo ri = new RIAInfo(ai);
									    ri.get();
									    ri.EnterRIAFirstName("firstname");
									    ri.EnterRIALastNAme("LastName");
									    ri.EnterRIAssn("SocialSecurityNumber");
									    ri.EnterRIADOB(Stock.GetParameterValue("Dateofbirth"));
									    Web.selectDropDownOption(ri, "RIAInfo_Gender", Stock.GetParameterValue("Gender"), false);									  
									    ri.EnterRIAStartdate(Stock.GetParameterValue("RIAstartdate"));
									    ri.EnterRIAenddate(Stock.GetParameterValue("RIAstartdate"));
									    ri.EnterRIAaddressline1("ResidentAddress");
									    ri.EnterRIAcity(Stock.GetParameterValue("City"));
									    Web.selectDropDownOption(ri, "RIAInfo_State", Stock.GetParameterValue("State"), false);									   
									    ri.EnterRIAzipcode("ZIP");									    
									    Reporter.logEvent(Status.INFO, "RIA Info", "page is displayed", true);
									    Web.clickOnElement(sp,"Next_Button");									    
									    /**
										 * Step 14 - Enter contract information
										 * .
										 */	
									    ContractInfo ci = new ContractInfo(ri);
									    ci.get();
									    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
									    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
									    Web.clickOnElement(sp,"Next_Button");
									    /**
										 * Step 15 - Enter Billing information
										 * .
										 */										    
									    BillingInfo bi = new BillingInfo(ci);
									    bi.get();
									    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
									    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
									    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
									    Web.clickOnElement(sp,"Next_Button");
									    /**
										 * Step 16 - Enter Fund information
										 * .
										 */										
										FundInfo fi = new FundInfo(bi);
										fi.get();
										fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
										Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
										Web.clickOnElement(sp,"Next_Button");
										 /**
										 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
										 * .
										 */											
										Summary su = new Summary(fi);
										su.get();										
										Web.waitForElement(su, "Summary_Realtimewait");
									    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);									
									    Web.clickOnElement(su,"Summary_Finishbtn");									
										su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
										su.getpolicynumber();
										Web.clickOnElement(su,"Summary_Homebtn");
										
												
									} catch (Exception e) {
										e.printStackTrace();
										Globals.exception = e;
										Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
												.getCause().getMessage(), true);
									} catch (Error ae) {
										ae.printStackTrace();
										Globals.error = ae;
										Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
												"Assertion Failed!!", true);

									} finally {
										try {
											Reporter.finalizeTCReport();
										} catch (Exception e1) {
											e1.printStackTrace();
										}
									}
								}

//*************************TEST CASE 1.8 Add Wells Fargo Custodial Contract************************************************************************************
								/** Test Case Name:Add Wells Fargo Custodial Contract
								 * 
								 * This Test Case to Verify, user able to Add Wells Fargo Custodial Contract								
								 * No Raider
								 * @param itr
								 * @param testdata
								 */
									@Test(dataProvider = "setData")
									public void TC8_wmA_Accumulation_AddWellsFargoCustodialContract(int itr, Map<String, String> testdata) {

										try {
											
											
											
										Reporter.initializeReportForTC(
													itr,
													Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
															.currentThread().getId())
															+ "_"
															+ Stock.getConfigParam("BROWSER"));
											Reporter
											.logEvent(
													Status.INFO,
													"Test Data used for this Test Case:",
													printTestData(),
													false);
											/**
											 * Step 1 -PreRequisite: 1.Login wmA Application
											 * Login Successful to UAT-Support home page
											 * verify the wmA home page user successfully and navigate to the 
											 * Hover mouse over menu item Accumulation and select Contract Add
											 */
											LandingPage landing = new LandingPage();
											SelectPartner sp = new SelectPartner(landing);
											sp.get();
											Web.clickOnElement(sp,"Submenu_contractAdd");
											/**
											 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Yr product and click Next.
											 * Partner is successfully selected and Select Criteria Page is loaded
											 * 
											 */		
											sp.selectpartner( Stock.GetParameterValue("SelectPartner"));										
											Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
											Web.clickOnElement(sp,"Next_Button");
											/**
											 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
											 * Step 4 - Select Variable  from the Product field.
											 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
											 * .
											 */		
											SelectCriteria sc = new SelectCriteria(sp);
											sc.get();
											sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));											
											Web.clickOnElement(sp,"Next_Button");
											/**
											 * Step 6 - Select Base Plan from the drop-down
											 * Step 7 - Select Statutory Company - GWA from the drop-down
											 * Step 8 - Select any Line of Business from column
											 * 
											 * .
											 */	
											SelectPlan pln = new SelectPlan (sc);
											pln.get();											
											pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));								
											Web.clickOnElement(sp,"Next_Button");
											/**
											 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
											 * Step 10 - Select Role/Type: Advisor from the drop down
											 * Step 11 - Enter First Year % and Renewal % and click Next
											 * .
											 */	
											
											 ProducerInfo pi = new ProducerInfo(pln);
											 pi.get();
											 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
											 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
											 Common.switchto_newwindow();
											 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
											 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
											 Common.switchto_mainwindow();
											 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));											 
											 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
											 Web.clickOnElement(sp,"Next_Button");											 
											 /**
												 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
												 * .
												 */											    
										    AnnuitantInfo ai = new AnnuitantInfo(pi);
										    ai.get();
										    Web.waitForElement(ai, "AnnuitantInfo_Diffirentfromowner");
										    Web.clickOnElement(ai,"AnnuitantInfo_Diffirentfromowner");										   
										    Web.selectDropDownOption(ai, "AnnuitantInfo_Ownershipcode", Stock.GetParameterValue("OwnerShipCode"), false);										   
										    Web.selectDropDownOption(ai, "AnnuitantInfo_NuberofBeneficiary", Stock.GetParameterValue("NoOfbeneficiary"), false);										
										    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),Stock.GetParameterValue("State"));										    
										    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
										    Web.clickOnElement(sp,"Next_Button");										    
										    /**
											 * Step 13 - Enter owner information
											 * .
											 */											    
										    OwnerInfo oi = new OwnerInfo(ai);
										    oi.get();
										    Web.waitForElement(oi, "Ownerinfo_Waitforsearchbtn");										   
										    Web.clickOnElement(oi,"OwnerInfo_CilckonPartysearch");										 
										    Common.switchto_newwindow();
										    Web.waitForElement(oi, "Ownerinfo_ClickOnBothbtn");
										    Web.clickOnElement(oi,"Ownerinfo_ClickOnBothbtn");										
										    oi.EnterOwnerInfoLastNameSearch(Stock.GetParameterValue("OwnerInfoLastname"));
										    Web.waitForElement(oi, "OwnerInfo_CilckonPartyAdd");
										    Web.clickOnElement(oi,"OwnerInfo_CilckonPartyAdd");										     
										    Web.waitForElement(oi, "Ownerinfo_Select1strow");
										    Web.clickOnElement(oi,"Ownerinfo_Select1strow");										
										    Web.waitForElement(oi, "Ownerinfo_ClickOnOkbtn");
										    Web.clickOnElement(oi,"Ownerinfo_ClickOnOkbtn");										
										    Common.switchto_mainwindow();
										    Reporter.logEvent(Status.INFO, "Owner Info", "page is displayed", true);
										    Web.clickOnElement(sp,"Next_Button");
										    /**
											 * Step 14 - Enter Beneficiary information
											 * .
											 */											    
										    BeneficiaryInfo ben = new BeneficiaryInfo(oi);
										    ben.EnterBeneficiaryFirstName("FirstName");
										    ben.Enterlastname("LastName");
										    ben.EnterBeneficiarySSN("SocialSecurityNumber");
										    ben.EnterBeneficiaryDOB(Stock.GetParameterValue("Dateofbirth"));
										    Web.selectDropDownOption(ben, "BeneficiaryInfo_Gender", Stock.GetParameterValue("Gender"), false);										   
										    Web.selectDropDownOption(ben, "BeneficiaryInfo_Type", Stock.GetParameterValue("BeneficiaryType"), false);										   
										    Web.selectDropDownOption(ben, "BeneficiaryInfo_Relationship", Stock.GetParameterValue("BeneficiaryRelationship"), false);										 
										    ben.EnterBeneficiaryPercentage(Stock.GetParameterValue("BeneficiaryPercent"));
										    ben.Enter1stAddress("ResidentAddress");
										    ben.EnterBeneficiaryCity(Stock.GetParameterValue("City"));
										    Web.selectDropDownOption(ben, "BeneficiaryInfo_State", Stock.GetParameterValue("State"), false);										 
										    ben.EnterBeneficiaryZIPcode("ZIP");										   
										    Reporter.logEvent(Status.INFO, "Beneficiary Info", "page is displayed", true);
										    Web.clickOnElement(sp,"Next_Button");										    
										    /**
											 * Step 15 - Enter contract information
											 * .
											 */	
										    ContractInfo ci = new ContractInfo(ben);
										    ci.get();
										    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
										    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
										    Web.clickOnElement(sp,"Next_Button");
										    /**
											 * Step 16 - Enter Billing information
											 * .
											 */											    
										    BillingInfo bi = new BillingInfo(ci);
										    bi.get();
										    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
										    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
										    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
										    Web.clickOnElement(sp,"Next_Button");
										    /**
											 * Step 17 - Enter Fund information
											 * .
											 */											
											FundInfo fi = new FundInfo(bi);
											fi.get();
											fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
											Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
											Web.clickOnElement(sp,"Next_Button");
											 /**
											 * Step 18 - Click submit real time processing summary Finish button verify the Transaction message
											 * .
											 */												
											Summary su = new Summary(fi);
											su.get();											
											Web.waitForElement(su, "Summary_Realtimewait");
										    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);										
										    Web.clickOnElement(su,"Summary_Finishbtn");										
											su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));											su.getpolicynumber();
											Web.clickOnElement(su,"Summary_Homebtn");
											
													
										} catch (Exception e) {
											e.printStackTrace();
											Globals.exception = e;
											Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
													.getCause().getMessage(), true);
										} catch (Error ae) {
											ae.printStackTrace();
											Globals.error = ae;
											Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
													"Assertion Failed!!", true);

										} finally {
											try {
												Reporter.finalizeTCReport();
											} catch (Exception e1) {
												e1.printStackTrace();
											}
										}
									}
									
}
