package app.wmAweb.testcases.signIn;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;


import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.LoginPagewmA;

public class LoginwmAtestcase {

	
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	LoginPagewmA login;
	String tcName;
	String Dcrypt;
	String userpass;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
		
	}

	


	@Test(dataProvider = "setData")
	public void TC1_wmA_Signup(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			Dcrypt = null;
			LoginPagewmA login = new LoginPagewmA();
		
			login.get();
			
			/*login.submitLoginCredentials(
					
				
				 * String username = System.getProperty("USERID");
				 * String password = System.getProperty("SYS_PASSWORD");
				 *  Stock.getConfigParam("AppURL" + "_"
														
                                        + Stock.getConfigParam("TEST_ENV"));
		
			  Web.getDriver().get(url);
				 
					
					lib.Stock.GetParameterValue("username"),
					lib.Stock.GetParameterValue("password"),Stock.GetParameterValue("Environment"));*/
			
			if (System.getProperty("SYS_PASSWORD").trim().length() > 0 && System.getProperty("SYS_PASSWORD").trim().startsWith("ER"))
			{
				Dcrypt = System.getProperty("SYS_PASSWORD").trim();
				Dcrypt = Dcrypt.substring(2);
				String decodedPwd = Common.decryptXOR(Dcrypt, "lockUnlock");
				userpass = decodedPwd;
			}
			else
			{
				userpass = System.getProperty("SYS_PASSWORD").trim();
			}
			
			String ENV = Stock.getConfigParam("ENV" + "_"

                                        + Stock.getConfigParam("TEST_ENV"));
			
			if(System.getProperty("USERID").trim().length() > 0)
			{
				//login.submitLoginCredentials(System.getProperty("USERID"), System.getProperty("SYS_PASSWORD"), ENV);
				login.submitLoginCredentials(System.getProperty("USERID"), userpass, ENV);
			}
			else
			{
				login.submitLoginCredentials(lib.Stock.GetParameterValue("username"),
						lib.Stock.GetParameterValue("password"), ENV);
									
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
}
