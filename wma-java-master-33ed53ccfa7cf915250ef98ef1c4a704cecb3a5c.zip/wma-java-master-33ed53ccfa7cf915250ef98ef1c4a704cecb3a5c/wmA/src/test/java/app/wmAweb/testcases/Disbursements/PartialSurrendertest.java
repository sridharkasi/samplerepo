package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Disbursements.PartialSurrender;

public class PartialSurrendertest {
	
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.wmA.Disbursements.PartialSurrender psurrender;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PartialSurrender(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
			psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();
			psurrender.clickpartialsurrender();
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
			psurrender.EnterSurrenderamount(Stock.GetParameterValue("SurrenderAmount"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
//*********************PRO RATA PERCENTAGE TEST CASE*********************	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PSurrenderProratapercentage(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
			psurrender.clickhomebutton();
			psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();
			psurrender.clickpartialsurrender();
			
			psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			psurrender.EnterProrataPercentage(Stock.GetParameterValue("SurrenderPercentage"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
//*******************************************Partial Surrender Fund Percentage TEST CASE***********************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PSurrenderFundPercentage(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
			psurrender.clickhomebutton();
			psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();
			psurrender.clickpartialsurrender();
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
	
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
		    psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
		    Thread.sleep(2000);
			psurrender.EnterFundPercentage(Stock.GetParameterValue("SurrenderPercentage"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			
			
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	//**************************************Partial Surrender Fund Amount Test Case**************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PSurrenderFundAmount(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
			psurrender.clickhomebutton();
			psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();
			psurrender.clickpartialsurrender();
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
			psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			psurrender.EnterFundAmount(Stock.GetParameterValue("SurrenderAmount"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
//**********************************Partial Fund Unit TEST CASE*****************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PSurrenderFundUnits(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
			psurrender.clickhomebutton();
			psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();
			psurrender.clickpartialsurrender();
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
			psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			psurrender.EnterFundUnit(Stock.GetParameterValue("SurrenderUnits"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}


}
