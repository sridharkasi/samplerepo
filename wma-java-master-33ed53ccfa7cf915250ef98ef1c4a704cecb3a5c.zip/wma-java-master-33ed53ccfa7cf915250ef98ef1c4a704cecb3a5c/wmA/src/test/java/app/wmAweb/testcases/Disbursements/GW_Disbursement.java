package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.FullSurrender;
import pageobjects.wmA.Disbursements.SystematicWithdrawal;
import pageobjects.wmA.Disbursements.UpdateSystematicWithdrawal;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Value.Value;

public class GW_Disbursement {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	
	String tcName;
	static String printTestData="";
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	

	private String printTestData() throws Exception {
		printTestData="";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if(!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData=printTestData+entry.getKey() + "="+ entry.getValue() +"\n";
		}
	 return printTestData;
	}
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_SystematicWithdrawal(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
			/*LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		   
		    
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			su.clicksystematicwithdrawal();
			
			SystematicWithdrawal swd = new SystematicWithdrawal(su);
			swd.get();
			/*swd.clickhomebutton();
			swd.entercontractid(Stock.GetParameterValue("ContractID"));
			swd.clicksearchbutton();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded and entered the contratc id", true);*/
			
			swd.clickaddbutton();
			swd.setsyseffectivedate(Stock.GetParameterValue("EffectiveDate_sys"));			
			swd.setstartdate(Stock.GetParameterValue("Startdate"));
			swd.setenddate(Stock.GetParameterValue("Enddate"));
			swd.transactionlevel(Stock.GetParameterValue("TransactionLevel"));
			swd.paymentmode(Stock.GetParameterValue("Paymentmode"));			
			swd.EnterFundAmount(Stock.GetParameterValue("PayoutAmount"));
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));
			swd.clicksumbmit();
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//*******************
			swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			//********************/
			Reporter.logEvent(Status.INFO, "Systematic withdrawal page", "page is Loaded after and entered the data", true);
			swd.clickhistorysubmenu();
			
			Transaction trs = new Transaction(swd);
			trs.get();
			
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the GK transaction happen on the effective date which we have given
			trs.verifyGKtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GK tranasaction", true);
			trs.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(trs);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("Startdate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			//Want to verify whether TK transaction is trigger after doing the real time update
			trs.verifyTKtransaction();
			
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the TK transaction", true);
			trs.ClickonValueSubmenu();
			
			Value val = new Value(RTU);
			val.get();
			val.EnterEffectivedatevalue(Stock.GetParameterValue("Startdate"));
			
			Web.clickOnElement(val, "Value_updateButton");
			//Web.waitForElement(val, "WaitforValuetable");
/*
			Web.isWebEementEnabled(val, "Value_updateButton");
			Web.waitForElement(val, "Value_updateButton");*/
			// want to verify the amount is reduced in the value page for the amount which we have given in the 
			
			Common.ValuesTableDisbursement();			
			
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verifyed the fund amount", true);
			swd.clicksystematicwithdrawal();
			
			// Want to verify the next payout date in the systematic information page.
			swd.VerifyNextpayoutDate();
			Reporter.logEvent(Status.INFO, "Systematic withdrawal Page", "page is Loaded and verifiyed next payout date", true);
			trs.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("NextPayoutDate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and updated the date", true);
			Thread.sleep(5000);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			trs.verifyNextpayoutTKtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the next TK transcation", true);
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}


	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_ChangeSystematicWithdrawal(int itr, Map<String, String> testdata) {
try {
			
			
			
			Reporter.initializeReportForTC(
					itr,
					Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
							.currentThread().getId())
							+ "_"
							+ Stock.getConfigParam("BROWSER"));
			Reporter
			.logEvent(
					Status.INFO,
					"Test Data used for this Test Case:",
					printTestData(),
					false);
			
		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		   
		    
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			 
			
			
			Summary su = new Summary(pa);
			su.get();		
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			su.clicksystematicwithdrawal();
			
			SystematicWithdrawal swd = new SystematicWithdrawal(su);
			swd.get();
			/*swd.clickhomebutton();
			swd.entercontractid(Stock.GetParameterValue("ContractID"));
			swd.clicksearchbutton();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded and entered the contratc id", true);*/
			
			swd.clickaddbutton();
			swd.setsyseffectivedate(Stock.GetParameterValue("EffectiveDate_sys"));			
			swd.setstartdate(Stock.GetParameterValue("Startdate"));
			swd.setenddate(Stock.GetParameterValue("Enddate"));
			swd.transactionlevel(Stock.GetParameterValue("TransactionLevel"));
			swd.paymentmode(Stock.GetParameterValue("Paymentmode"));			
			swd.EnterFundAmount(Stock.GetParameterValue("PayoutAmount"));
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));
			swd.clicksumbmit();
		//	swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			//*******************
			swd.clickoverirde();
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			//********************/
			Reporter.logEvent(Status.INFO, "Systematic withdrawal page", "page is Loaded after and entered the data", true);
			swd.clickhistorysubmenu();
			
			Transaction trs = new Transaction(swd);
			trs.get();
			
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the GK transaction happen on the effective date which we have given
			trs.verifyGKtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GK tranasaction", true);
			trs.ClickonmaintenanceSubmenu();
			
			Realtime_update RTU = new Realtime_update(trs);
			RTU.get();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("Startdate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			//Want to verify whether TK transaction is trigger after doing the real time update
			trs.verifyTKtransaction();
			
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the TK transaction", true);
			trs.ClickonValueSubmenu();
			
			Value val = new Value(RTU);
			val.get();
			val.EnterEffectivedatevalue(Stock.GetParameterValue("Startdate"));
			
			Web.clickOnElement(val, "Value_updateButton");
			//Web.waitForElement(val, "WaitforValuetable");
/*
			Web.isWebEementEnabled(val, "Value_updateButton");
			Web.waitForElement(val, "Value_updateButton");*/
			// want to verify the amount is reduced in the value page for the amount which we have given in the 
			
			Common.ValuesTableDisbursement();			
			
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and verifyed the fund amount", true);
			swd.clicksystematicwithdrawal();
			
			// Want to verify the next payout date in the systematic information page.
			swd.VerifyNextpayoutDate();
			Reporter.logEvent(Status.INFO, "Systematic withdrawal Page", "page is Loaded and verifiyed next payout date", true);
			trs.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("NextPayoutDate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and updated the date", true);
			//Added wait
			Thread.sleep(10000);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			trs.verifyNextpayoutTKtransaction();
		
			//update systematic withdrawal script start
			swd.clicksystematicwithdrawal();
			UpdateSystematicWithdrawal Changesys =new UpdateSystematicWithdrawal(val);
			Changesys.get();
			Changesys.selectrow1();
			Changesys.clickupdatebutton();
			Changesys.updateeffectivedate(Stock.GetParameterValue("UpdateEffectivedate"));
			Changesys.UpdateStartDate(Stock.GetParameterValue("UpdateStartdate"));
			Changesys.updatemodeoption(Stock.GetParameterValue("UpdateModeoption"));
			Changesys.RealtimeDrpDwn(Stock.GetParameterValue("UpdateSys_realtime"));
			Changesys.clicksumbmit();
			Changesys.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Update systematic withdrawal Page", "page is Loaded and entered the data", true);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			trs.verifyLPOItransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the LPOI transcation", true);
			trs.ClickonmaintenanceSubmenu();
			RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("UpdateStartdate"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));			
			swd.clicksumbmit();
			Reporter.logEvent(Status.INFO, "Real Time update Page", "page is Loaded and Submitted the next tk date", true);
			swd.clickhistorysubmenu();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			trs.verifyUpdatesTKsubseqtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifyed the next updated TK transcation", true);
			
			
} catch (Exception e) {
	e.printStackTrace();
	Globals.exception = e;
	Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
			.getCause().getMessage(), true);
} catch (Error ae) {
	ae.printStackTrace();
	Globals.error = ae;
	Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
			"Assertion Failed!!", true);

} finally {
	try {
		Reporter.finalizeTCReport();
	} catch (Exception e1) {
		e1.printStackTrace();
	}
}
}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_FullSurrender(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
		
			/*LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();		
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp,"accumulationlink");
			
			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
			 * Partner is successfully selected and Select Criteria Page is loaded
			 * 
			 *//*		
			sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
			 * Step 4 - Select Variable  from the Product field.
			 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
			 * .
			 *//*		
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down
			 * Step 7 - Select Statutory Company - GWA from the drop-down
			 * Step 8 - Select any Line of Business from column
			 * 
			 * .
			 *//*	
			SelectPlan pln = new SelectPlan (sc);
			pln.get();				
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp,"Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
			 * Step 10 - Select Role/Type: Advisor from the drop down
			 * Step 11 - Enter First Year % and Renewal % and click Next
			 * .
			 *//*	
			
			 ProducerInfo pi = new ProducerInfo(pln);
			 pi.get();			
			 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			 Common.switchto_newwindow();
			 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			 Common.switchto_mainwindow();
			 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
			 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");				 
			 *//**
				 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
				 * .
				 *//*				    
		    AnnuitantInfo ai = new AnnuitantInfo(pi);
		    ai.get();			    
		    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
		    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");			    
		    *//**
			 * Step 13 - Enter contract information
			 * .
			 *//*	
		    ContractInfo ci = new ContractInfo(ai);
		    ci.get();
		    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 14 - Enter Billing information
			 * .
			 *//*				    
		    BillingInfo bi = new BillingInfo(ci);
		    bi.get();
		    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		    Web.clickOnElement(sp,"Next_Button");
		    *//**
			 * Step 15 - Enter Fund information
			 * .
			 *//*	
		   
		    
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.GrowthINV(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp,"Next_Button");
			 *//**
			 * Step 16 - Click submit real time processing summary Finish button verify the Transaction message
			 * .
			 *//*	
			
			 PaymentAdd pa = new PaymentAdd(fi);
			 pa.get();
			 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			 Web.clickOnElement(sp,"Next_Button");
			
			
			Summary su = new Summary(pa);
			su.get();				
			Web.waitForElement(su, "Summary_Realtimewait");
		    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
		    Web.clickOnElement(su,"Summary_Finishbtn");			
		    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			
			if(System.getProperty("ContractID")==null) {
				System.out.println("Contract ID is not given and its null");
				Common.CreateContractAdd();
			}else if(System.getProperty("ContractID").trim().length()>0) {
				Common.contractsearchandFundINFO(System.getProperty("ContractID"));
			}else {
				System.out.println("Contract ID is not given and its null");
				Common.CreateContractAdd();
			}
		
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			
			su.clickfullsurrender();
			
			FullSurrender fsurrender = new FullSurrender(su);
			fsurrender.get();
			/*fsurrender.clickhomebutton();
			fsurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			fsurrender.clicksearchbutton();
			fsurrender.clickfullsurrender();*/
			fsurrender.seteffectivedatefullsurrender(Stock.GetParameterValue("EffectiveDate_full"));
		//	fsurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			fsurrender.clickoverirde();
			fsurrender.RealtimeDrpDwn(Stock.GetParameterValue("Full_realtime"));
			fsurrender.clicksumbmit();
			fsurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Full Surrender page", "page is displayed", true);
			
			General g = new General(fsurrender);
			g.clickhistorysubmenu();
			
			Transaction trs = new Transaction(g);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			Thread.sleep(3000);
			trs.VerifyTAtransaction();
			trs.VerifyStatusS();
			Reporter.logEvent(Status.INFO, "History Page", "page is displayed", true);
			Web.clickOnElement(su,"Summary_Homebtn");
			
			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
}
