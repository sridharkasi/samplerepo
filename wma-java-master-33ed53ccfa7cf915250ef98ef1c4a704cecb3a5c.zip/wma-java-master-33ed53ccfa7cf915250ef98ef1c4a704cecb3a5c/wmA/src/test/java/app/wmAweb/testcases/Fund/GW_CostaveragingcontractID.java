package app.wmAweb.testcases.Fund;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.Fund.Costaveraging;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Party.DeathPending;
import pageobjects.wmA.Party.DemographicChange;
import pageobjects.wmA.Value.Value;
import pageojects.wmA.Search.DetailsSearch;

public class GW_CostaveragingcontractID {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_Costaveraging_New_CostAveragee(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			Common.contractsearchandFundINFO(System.getProperty("ContractID"));

			LandingPage landing = new LandingPage();
			General g = new General(landing);

			g.ClickonmaintenanceSubmenu();

			Realtime_update RTU = new Realtime_update(g);
			RTU.get();
			// RTU.enterrealtimeupdateEffectivedate(System.getProperty("BeginDate"));
			RTU.setRealTimedateCAchange(Stock.GetParameterValue("CAEffectivedate"));

			Summary su = new Summary(RTU); // Overide_Button
			Web.waitForElement(su, "Overide_Button");
			Web.clickOnElement(su, "Overide_Button");
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Realtime update Page", "page is Loaded and date is updated", true);

			g.ClickonValueSubmenu();
			Value val = new Value(g);
			val.get();

			if (System.getProperty("BeginDate") == null) {

				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
			} else if (System.getProperty("BeginDate").trim().length() > 0) {
				val.EnterEffectivedatevalueGAW(System.getProperty("BeginDate"));

			} else {
				val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
			}

			Web.clickOnElement(val, "Value_updateButton");
			// Want to store value and excepted amount
			Common.CAvaluesTableInitial();
			Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and stored the value for calculation", true);

			g.ClickCostAveraging();
            if(System.getProperty("TrxType").equalsIgnoreCase("Amount")) {
			if (System.getProperty("TrxFrequency").equalsIgnoreCase("Annual")) {

				Costaveraging CA = new Costaveraging(g);
         		CA.clickCostaverageaddbutton();
				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
				
				Common.CostaverageTransferfund_EContract();
				Thread.sleep(5000);
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.waitForElement(su, "Summary_Realtime");
				Web.clickOnElement(su, "Summary_Submitbtn");
				Thread.sleep(3000);
				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
				g.clickhistorysubmenu();
				Transaction trs = new Transaction(CA);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the GC transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyGCtransaction();
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyGCtransaction();

				} else {
					trs.verifyGCtransaction();
				}

				// trs.doubleclickGCTransaction();
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
						true);

				g.ClickonmaintenanceSubmenu();

				RTU.get();

				if (System.getProperty("TrxEffectiveDate") == null) {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

				} else {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				}

				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
				RTU.clicksumbmit();
				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
						true);

				g.clickhistorysubmenu();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the OES transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

				} else {
					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				}

				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
						true);

				g.ClickonValueSubmenu();

				if (System.getProperty("TrxEffectiveDate") == null) {

					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

				} else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				}

				Web.clickOnElement(val, "Value_updateButton");
				Web.waitForElement(val, "WaitforValuetable");
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Common.ValuesTable();
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Web.clickOnElement(su, "Summary_Homebtn");
			} else if (System.getProperty("TrxFrequency").equalsIgnoreCase("Monthly")) {
				Costaveraging CA = new Costaveraging(g);
				CA.clickCostaverageaddbutton();
				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
				
				Common.CostaverageTransferfund_EContract();
				Thread.sleep(5000);
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.waitForElement(su, "Summary_Realtime");
				Web.clickOnElement(su, "Summary_Submitbtn");
				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
				g.clickhistorysubmenu();
				Transaction trs = new Transaction(CA);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the GC transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyGCtransaction();
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyGCtransaction();

				} else {
					trs.verifyGCtransaction();
				}

				// trs.doubleclickGCTransaction();
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
						true);

				g.ClickonmaintenanceSubmenu();

				RTU.get();

				if (System.getProperty("TrxEffectiveDate") == null) {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

				} else {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				}

				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
				RTU.clicksumbmit();
				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
						true);

				g.clickhistorysubmenu();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the OES transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

				} else {
					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				}

				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
						true);

				g.ClickonValueSubmenu();

				if (System.getProperty("TrxEffectiveDate") == null) {

					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

				} else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				}

				Web.clickOnElement(val, "Value_updateButton");
				Web.waitForElement(val, "WaitforValuetable");
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Common.ValuesTable();
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Web.clickOnElement(su, "Summary_Homebtn");
			}

			else if (System.getProperty("TrxFrequency").equalsIgnoreCase("Quarterly")) {
				Costaveraging CA = new Costaveraging(g);
				CA.clickCostaverageaddbutton();
				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
			    CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
				
				Common.CostaverageTransferfund_EContract();
				Thread.sleep(5000);
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.waitForElement(su, "Summary_Realtime");
				Web.clickOnElement(su, "Summary_Submitbtn");
				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
				g.clickhistorysubmenu();
				Transaction trs = new Transaction(CA);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the GC transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyGCtransaction();
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyGCtransaction();

				} else {
					trs.verifyGCtransaction();
				}

				// trs.doubleclickGCTransaction();
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
						true);

				g.ClickonmaintenanceSubmenu();

				RTU.get();

				if (System.getProperty("TrxEffectiveDate") == null) {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

				} else {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				}

				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
				RTU.clicksumbmit();
				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
						true);

				g.clickhistorysubmenu();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the OES transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

				} else {
					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				}

				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
						true);

				g.ClickonValueSubmenu();

				if (System.getProperty("TrxEffectiveDate") == null) {

					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

				} else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				}

				Web.clickOnElement(val, "Value_updateButton");
				Web.waitForElement(val, "WaitforValuetable");
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Common.ValuesTable();
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Web.clickOnElement(su, "Summary_Homebtn");
			}

			else if (System.getProperty("TrxFrequency").equalsIgnoreCase("SemiAnnual")) {
				Costaveraging CA = new Costaveraging(g);
				CA.clickCostaverageaddbutton();
				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
				
				Common.CostaverageTransferfund_EContract();
				Thread.sleep(5000);
				Web.waitForElement(su, "Summary_Realtime");
				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
				Web.waitForElement(su, "Summary_Realtime");
				Web.clickOnElement(su, "Summary_Submitbtn");
				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
				g.clickhistorysubmenu();
				Transaction trs = new Transaction(CA);
				trs.get();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the GC transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyGCtransaction();
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyGCtransaction();

				} else {
					trs.verifyGCtransaction();
				}

				// trs.doubleclickGCTransaction();
				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
						true);

				g.ClickonmaintenanceSubmenu();

				RTU.get();

				if (System.getProperty("TrxEffectiveDate") == null) {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

				} else {
					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
				}

				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
				RTU.clicksumbmit();
				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
						true);

				g.clickhistorysubmenu();
				Web.waitForElement(trs, "Transaction_updateBT");
				Web.clickOnElement(trs, "Transaction_updateBT");
				// want to verify whether the OES transaction happen on the effective date which
				// we have given

				if (System.getProperty("TrxEffectiveDate") == null) {

					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

				} else {
					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
				}

				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
						true);

				g.ClickonValueSubmenu();

				if (System.getProperty("TrxEffectiveDate") == null) {

					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

				} else {
					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
				}

				Web.clickOnElement(val, "Value_updateButton");
				Web.waitForElement(val, "WaitforValuetable");
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Common.ValuesTable();
				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
				Web.clickOnElement(su, "Summary_Homebtn");
			}
            }
            
            else if (System.getProperty("TrxType").equalsIgnoreCase("Percent"))
            {
    			if (System.getProperty("TrxFrequency").equalsIgnoreCase("Annual")) {

    				Costaveraging CA = new Costaveraging(g);
    				CA.clickCostaverageaddbutton();
    				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
    				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
    				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
    				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
    			
    				Common.CostaverageTransferfund_EContractPercentage();
    				//Common.CostaverageTransferfundTrial();
    				Thread.sleep(5000);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.clickOnElement(su, "Summary_Submitbtn");
    				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
    				g.clickhistorysubmenu();
    				Transaction trs = new Transaction(CA);
    				trs.get();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the GC transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyGCtransaction();
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyGCtransaction();

    				} else {
    					trs.verifyGCtransaction();
    				}

    				// trs.doubleclickGCTransaction();
    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
    						true);

    				g.ClickonmaintenanceSubmenu();

    				RTU.get();

    				if (System.getProperty("TrxEffectiveDate") == null) {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

    				} else {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
    				RTU.clicksumbmit();
    				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
    						true);

    				g.clickhistorysubmenu();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the OES transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

    				} else {
    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
    						true);

    				g.ClickonValueSubmenu();

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

    				} else {
    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Web.clickOnElement(val, "Value_updateButton");
    				Web.waitForElement(val, "WaitforValuetable");
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Common.ValuesTable();
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Web.clickOnElement(su, "Summary_Homebtn");
    			} else if (System.getProperty("TrxFrequency").equalsIgnoreCase("Monthly")) {
    				Costaveraging CA = new Costaveraging(g);
    				CA.clickCostaverageaddbutton();
    				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
    				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
    				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
    				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
    			
    				Common.CostaverageTransferfund_EContractPercentage();
    				Thread.sleep(5000);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.clickOnElement(su, "Summary_Submitbtn");
    				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
    				g.clickhistorysubmenu();
    				Transaction trs = new Transaction(CA);
    				trs.get();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the GC transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyGCtransaction();
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyGCtransaction();

    				} else {
    					trs.verifyGCtransaction();
    				}

    				// trs.doubleclickGCTransaction();
    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
    						true);

    				g.ClickonmaintenanceSubmenu();

    				RTU.get();

    				if (System.getProperty("TrxEffectiveDate") == null) {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

    				} else {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
    				RTU.clicksumbmit();
    				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
    						true);

    				g.clickhistorysubmenu();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the OES transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

    				} else {
    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
    						true);

    				g.ClickonValueSubmenu();

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

    				} else {
    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Web.clickOnElement(val, "Value_updateButton");
    				Web.waitForElement(val, "WaitforValuetable");
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Common.ValuesTable();
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Web.clickOnElement(su, "Summary_Homebtn");
    			}

    			else if (System.getProperty("TrxFrequency").equalsIgnoreCase("Quarterly")) {
    				Costaveraging CA = new Costaveraging(g);
    				CA.clickCostaverageaddbutton();
    				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
    				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
    				CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
    				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
    			
    				Common.CostaverageTransferfund_EContractPercentage();
    				Thread.sleep(5000);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.clickOnElement(su, "Summary_Submitbtn");
    				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
    				g.clickhistorysubmenu();
    				Transaction trs = new Transaction(CA);
    				trs.get();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the GC transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyGCtransaction();
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyGCtransaction();

    				} else {
    					trs.verifyGCtransaction();
    				}

    				// trs.doubleclickGCTransaction();
    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
    						true);

    				g.ClickonmaintenanceSubmenu();

    				RTU.get();

    				if (System.getProperty("TrxEffectiveDate") == null) {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

    				} else {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
    				RTU.clicksumbmit();
    				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
    						true);

    				g.clickhistorysubmenu();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the OES transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

    				} else {
    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
    						true);

    				g.ClickonValueSubmenu();

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

    				} else {
    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Web.clickOnElement(val, "Value_updateButton");
    				Web.waitForElement(val, "WaitforValuetable");
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Common.ValuesTable();
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Web.clickOnElement(su, "Summary_Homebtn");
    			}

    			else if (System.getProperty("TrxFrequency").trim().contains("Semi"))
    				
    				     
    			{
    				Costaveraging CA = new Costaveraging(g);
    				CA.clickCostaverageaddbutton();
    				CA.seteffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.setNumberofTransfer(Stock.GetParameterValue("Numoftransfer"));
    				CA.setBegindate(Stock.GetParameterValue("CAEffectivedate"));
    				CA.SelectCATransfertype(Stock.GetParameterValue("TransferType"));
    		        CA.SelectCATransferfrequency1(Stock.GetParameterValue("SelectFreqeuncy"));
    				CA.SelectTransDay(Stock.GetParameterValue("Numoftransfer"));
    				Common.CostaverageTransferfund_EContractPercentage();
    				Thread.sleep(5000);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
    				Web.waitForElement(su, "Summary_Realtime");
    				Web.clickOnElement(su, "Summary_Submitbtn");
    				CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);
    				g.clickhistorysubmenu();
    				Transaction trs = new Transaction(CA);
    				trs.get();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the GC transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyGCtransaction();
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyGCtransaction();

    				} else {
    					trs.verifyGCtransaction();
    				}

    				// trs.doubleclickGCTransaction();
    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction",
    						true);

    				g.ClickonmaintenanceSubmenu();

    				RTU.get();

    				if (System.getProperty("TrxEffectiveDate") == null) {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					RTU.enterrealtimeupdateEffectivedate(System.getProperty("TrxEffectiveDate"));

    				} else {
    					RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
    				RTU.clicksumbmit();
    				RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
    				Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered",
    						true);

    				g.clickhistorysubmenu();
    				Web.waitForElement(trs, "Transaction_updateBT");
    				Web.clickOnElement(trs, "Transaction_updateBT");
    				// want to verify whether the OES transaction happen on the effective date which
    				// we have given

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					trs.verifyCostaverageOEStransaction(System.getProperty("TrxEffectiveDate"));

    				} else {
    					trs.verifyCostaverageOEStransaction(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction",
    						true);

    				g.ClickonValueSubmenu();

    				if (System.getProperty("TrxEffectiveDate") == null) {

    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				} else if (System.getProperty("TrxEffectiveDate").trim().length() > 0) {
    					val.EnterEffectivedatevalueGAW(System.getProperty("TrxEffectiveDate"));

    				} else {
    					val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));
    				}

    				Web.clickOnElement(val, "Value_updateButton");
    				Web.waitForElement(val, "WaitforValuetable");
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Common.ValuesTable();
    				Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
    				Web.clickOnElement(su, "Summary_Homebtn");
    			}
            }

			else {
				System.out.println("No option selected in arugments");
			}

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}
