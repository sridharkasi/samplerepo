package app.wmAweb.testcases.Fund;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.Fund.AssetRebalance;
import pageobjects.wmA.Fund.Costaveraging;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Premiums_Billing.PremiumDeposit;
import pageobjects.wmA.Value.Value;

public class GW_CostAveraging {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Fund_Costaveraging_New_CostAveragee(int itr, Map<String, String> testdata) {
	try {

		Reporter.initializeReportForTC(itr,
				Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread
						.currentThread().getId())
						+ "_"
						+ Stock.getConfigParam("BROWSER"));
		Reporter
		.logEvent(
				Status.INFO,
				"Test Data used for this Test Case:",
				printTestData(),
				false);
		
		/*LandingPage landing = new LandingPage();
		SelectPartner sp = new SelectPartner(landing);
		sp.get();		
		Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
		Web.clickOnElement(sp,"accumulationlink");
		
		*//**
		 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year product and click Next.
		 * Partner is successfully selected and Select Criteria Page is loaded
		 * 
		 *//*		
		sp.selectpartner( Stock.GetParameterValue("SelectPartner"));			
		Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
		Web.clickOnElement(sp,"Next_Button");
		*//**
		 * Step 3 - Enter an effective date which should match the current system date in the envrionment.
		 * Step 4 - Select Variable  from the Product field.
		 * Step 5 - Select a non-NY state from the Issue State drop-down box and click next
		 * .
		 *//*		
		SelectCriteria sc = new SelectCriteria(sp);
		sc.get();
		sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"),Stock.GetParameterValue("IssueState"));				
		Web.clickOnElement(sp,"Next_Button");
		*//**
		 * Step 6 - Select Base Plan from the drop-down
		 * Step 7 - Select Statutory Company - GWA from the drop-down
		 * Step 8 - Select any Line of Business from column
		 * 
		 * .
		 *//*	
		SelectPlan pln = new SelectPlan (sc);
		pln.get();				
		pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"),Stock.GetParameterValue("StatutoryCompany"), Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));		
		Web.clickOnElement(pln, "ClickOnCashCheckbox");
		Web.clickOnElement(sp,"Next_Button");
		*//**
		 * Step 9 - Click on Party Search and search for an advisor to add onto the contract.
		 * Step 10 - Select Role/Type: Advisor from the drop down
		 * Step 11 - Enter First Year % and Renewal % and click Next
		 * .
		 *//*	
		
		 ProducerInfo pi = new ProducerInfo(pln);
		 pi.get();			
		 pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
		 Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
		 Common.switchto_newwindow();
		 Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
		 Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
		 Common.switchto_mainwindow();
		 pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"), Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));				 
		 Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
		 Web.clickOnElement(sp,"Next_Button");				 
		 *//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and Address fields and click next.
			 * .
			 *//*				    
	    AnnuitantInfo ai = new AnnuitantInfo(pi);
	    ai.get();			    
	    ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),  Stock.GetParameterValue("City"),  Stock.GetParameterValue("State"));			    
	    Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
	    Web.clickOnElement(sp,"Next_Button");			    
	    *//**
		 * Step 13 - Enter contract information
		 * .
		 *//*	
	    ContractInfo ci = new ContractInfo(ai);
	    ci.get();
	    ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
	    Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
	    Web.clickOnElement(sp,"Next_Button");
	    *//**
		 * Step 14 - Enter Billing information
		 * .
		 *//*				    
	    BillingInfo bi = new BillingInfo(ci);
	    bi.get();
	    bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
	    bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
	    Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
	    Web.clickOnElement(sp,"Next_Button");
	    	
		*//**
		 * Step 16 - Enter Fund information
		 * .
		 *//*	
		FundInfo fi = new FundInfo(bi);
		fi.get();
		fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
		Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
		Web.clickOnElement(sp,"Next_Button");
		 *//**
		 * Step 17 - Click submit real time processing summary Finish button verify the Transaction message
		 * .
		 *//*	
		
		 PaymentAdd pa = new PaymentAdd(fi);
		 pa.get();
		 pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
		 pa.MemoCode(Stock.GetParameterValue("MemoCode"));
		 Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
		 Web.clickOnElement(sp,"Next_Button");
		
		
		Summary su = new Summary(pa);
		su.get();				
		Web.waitForElement(su, "Summary_Realtimewait");
	    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		    
	    Web.clickOnElement(su,"Summary_Finishbtn");			    
	    su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));			
		su.getpolicynumber();
		Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
		Web.clickOnElement(su, "Summary_NavigateButton");
		Web.waitForElement(su, "Summary_Fund");*/
		Common.CreateContractAdd();
		LandingPage landing = new LandingPage();
		Summary su = new Summary(landing);		
        General g = new General(su);
		g.get();
		
		g.ClickonValueSubmenu();
		Value val = new Value(g);
		val.get();
		val.EnterEffectivedatevalueGAW(Stock.GetParameterValue("CAEffectivedate"));			
		Web.clickOnElement(val, "Value_updateButton");
		// Want to store value and excepted amount
		Common.CAvaluesTableInitial();
		Reporter.logEvent(Status.INFO, "Value Page", "page is Loaded and stored the value for calculation", true);
		
		g.ClickCostAveraging();
		
		Costaveraging CA=new Costaveraging(g);
	    CA.clickCostaverageaddbutton();
		CA.EnterEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
		CA.Numberoftransfer(Stock.GetParameterValue("Numoftransfer"));
		CA.EnterBegindate(Stock.GetParameterValue("CAEffectivedate"));
	    CA.SelectTransferType(Stock.GetParameterValue("TransferType"));
	    Thread.sleep(5000);
	    CA.SelectTransferDay(Stock.GetParameterValue("Numoftransfer"));
		Common.CostaverageTransferfund();
		Web.waitForElement(su, "Summary_Realtime");
	    Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);		
	    Web.clickOnElement(su,"Summary_Submitbtn");	
	    CA.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		Reporter.logEvent(Status.INFO, "Coverage Average Page", "page is Loaded and Entered the data", true);

		g.clickhistorysubmenu();
		Transaction trs = new Transaction(CA);
		trs.get();
		Web.waitForElement(trs, "Transaction_updateBT");
		Web.clickOnElement(trs, "Transaction_updateBT");
		// want to verify whether the GC transaction happen on the effective date which
		// we have given
		trs.verifyGCtransaction();
		Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the GC tranasaction", true);

		g.ClickonmaintenanceSubmenu();
		Realtime_update RTU = new Realtime_update(trs);
		RTU.get();
		RTU.enterrealtimeupdateEffectivedate(Stock.GetParameterValue("CAEffectivedate"));
		RTU.RealtimeDrpDwn(Stock.GetParameterValue("ctradd_realtime"));
		RTU.clicksumbmit();
		RTU.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		Reporter.logEvent(Status.INFO, "Real time update Page", "page is Loaded and Start date is entered", true);

		g.clickhistorysubmenu();
		Web.waitForElement(trs, "Transaction_updateBT");
		Web.clickOnElement(trs, "Transaction_updateBT");
		// want to verify whether the RB transaction happen on the effective date which
		// we have given
		trs.verifyCostaverageOEStransaction();
		Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the OES tranasaction", true);
		
		g.ClickonValueSubmenu();
		
		val.get();
	    val.EnterEffectivedatevalue(Stock.GetParameterValue("CAEffectivedate"));		   
	    Web.clickOnElement(val, "Value_updateButton");
	    Web.waitForElement(val, "WaitforValuetable");
	    Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
	    Common.ValuesTable();
       Reporter.logEvent(Status.INFO, "Value Screen", "page is displayed", true);
	    Web.clickOnElement(su, "Summary_Homebtn");
	    SelectPartner sp = new SelectPartner(val);
		Web.waitForElement(sp, "accumulationlink");

	} catch (Exception e) {
		e.printStackTrace();
		Globals.exception = e;
		Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
	} catch (Error ae) {
		ae.printStackTrace();
		Globals.error = ae;
		Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

	} finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}


}
