package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.Disbursements.LandingPage;

public class DeathClaimTest {
	
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.wmA.Disbursements.DeathClaim dclaim;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			DeathClaim dc = new DeathClaim(landing);
			dc.clickhomebutton();
			dc.entercontractid(Stock.GetParameterValue("ContractID"));
			dc.ClickOnSearchButton();
			dc.clickondeathclaim();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.SelectDSourceCode(Stock.GetParameterValue("Dcsourcecode"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("Dcpayeestate"));
			dc.ClickOnPartySearch();
			Common.switchto_newwindow();
			dc.ClickOnCancelButton();
			Common.switchto_mainwindow();
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("Dcpersonaleffectivedate"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("Dccity"));
			dc.SelectPayeeState(Stock.GetParameterValue("Dcpayeestate"));
			dc.Enterpayeezipcode();
			dc.Enterpayeeremmaingzip(Stock.GetParameterValue("Dcremainzip"));
			dc.ClickOkbutton("Click");
			Common.switchto_mainwindow();
			dc.ClickUpdatePayee();
			dc.RealtimeDrpDwn(Stock.GetParameterValue("DC_realtime"));
			dc.clicksumbmit();
	
			
			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

}
