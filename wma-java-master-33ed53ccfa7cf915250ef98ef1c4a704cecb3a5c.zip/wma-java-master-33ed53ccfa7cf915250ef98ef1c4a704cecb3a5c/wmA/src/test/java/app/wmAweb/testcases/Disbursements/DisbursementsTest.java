package app.wmAweb.testcases.Disbursements;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Disbursements.DeathClaim;
import pageobjects.wmA.Disbursements.FullSurrender;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.Disbursements.SystematicWithdrawal;
import pageobjects.wmA.Disbursements.UpdateSystematicWithdrawal;

public class DisbursementsTest {
private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.wmA.Disbursements.FullSurrender fsurrender;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	//***************************Partial Surrender test case******************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_PartialSurrender(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			PartialSurrender psurrender = new PartialSurrender(landing);
		/*	psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			psurrender.clicksearchbutton();*/
			psurrender.clickpartialsurrender();
			psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
			psurrender.EnterSurrenderamount(Stock.GetParameterValue("SurrenderAmount"));
			psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
			psurrender.clicksumbmit();
			psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			psurrender.clickhomebutton();

			//String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
//****************************************Full Surrender Test Case*****************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_FullSurrender(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();

            FullSurrender fsurrender = new FullSurrender(landing);


			//FullSurrender fsurrender = new FullSurrender();
		/*	fsurrender.clickhomebutton();
			fsurrender.entercontractid(Stock.GetParameterValue("ContractID"));
			fsurrender.clicksearchbutton();*/
			fsurrender.clickfullsurrender();
			fsurrender.seteffectivedatefullsurrender(Stock.GetParameterValue("EffectiveDate_full"));
			fsurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
			fsurrender.RealtimeDrpDwn(Stock.GetParameterValue("Full_realtime"));
			fsurrender.clicksumbmit();
			fsurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			fsurrender.clickhomebutton();

			
			
			//String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	//***********************************************Systematic Withdrawal Test case*********************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_SystematicWithdrawal(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LandingPage landing = new LandingPage();
			SystematicWithdrawal swd = new SystematicWithdrawal(landing);
		/*	swd.clickhomebutton();
			swd.entercontractid(Stock.GetParameterValue("ContractID"));
			swd.clicksearchbutton();*/
			swd.clicksystematicwithdrawal();
			swd.clickaddbutton();
			
			swd.setstartdate(Stock.GetParameterValue("Startdate"));
			swd.setenddate(Stock.GetParameterValue("Enddate"));
			swd.setsyseffectivedate(Stock.GetParameterValue("EffectiveDate_sys"));
			swd.paymentmode(Stock.GetParameterValue("Paymentmode"));
			swd.transactionlevel(Stock.GetParameterValue("TransactionLevel"));
			swd.payoutamount(Stock.GetParameterValue("PayoutAmount"));
			swd.syssourcecode(Stock.GetParameterValue("SourceCode"));
			swd.RealtimeDrpDwn(Stock.GetParameterValue("Sys_realtime"));
			swd.clicksumbmit();
			swd.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			
			
			
			//String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	//******************************************Update Systematic Withdrawal Test case************************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_ChangeSystematicWithdrawal(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			UpdateSystematicWithdrawal Changesys =new UpdateSystematicWithdrawal(landing);
		/*	Changesys.clickhomebutton();
			Changesys.entercontractid(Stock.GetParameterValue("ContractID"));
			Changesys.clicksearchbutton(); */
			Changesys.clicksystematicwithdrawal();
			Changesys.selectrow1();
			Changesys.clickupdatebutton();
			Changesys.updateeffectivedate(Stock.GetParameterValue("UpdateEffectivedate"));
			Changesys.UpdateStartDate(Stock.GetParameterValue("UpdateStartdate"));
			Changesys.updatemodeoption(Stock.GetParameterValue("UpdateModeoption"));
			Changesys.RealtimeDrpDwn(Stock.GetParameterValue("UpdateSys_realtime"));
			Changesys.clicksumbmit();
			Changesys.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Changesys.clickhomebutton();
			
			
		//	String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	//*******************************Death Claim Test Case*******************************************
	@Test(dataProvider = "setData")
	public void TC1_wmA_Disbursements_DeathClaim(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
			LandingPage landing = new LandingPage();
			DeathClaim dc = new DeathClaim(landing);
		/*	dc.clickhomebutton();
			dc.entercontractid(Stock.GetParameterValue("ContractID"));
			dc.ClickOnSearchButton();*/
			dc.clickondeathclaim();
			dc.EnterEffectiveDate(Stock.GetParameterValue("DCEffectivedate"));
			dc.EnterDeathDate(Stock.GetParameterValue("DODeathdate"));
			dc.SelectDeathCause(Stock.GetParameterValue("Dccause"));
			dc.SelectDSourceCode(Stock.GetParameterValue("Dcsourcecode"));
			dc.ClickOnAddbutton();
			dc.EnterPayeePercentage(Stock.GetParameterValue("Dcpercentbenifit"));
			dc.SelectPayeeResState(Stock.GetParameterValue("Dcpayeestate"));
			dc.ClickOnPartySearch();
			Common.switchto_newwindow();
			dc.ClickOnCancelButton();
			Common.switchto_mainwindow();
			dc.ClickonPayeePartyadd();
			Common.switchto_newwindow();
			dc.EnterPersonalEffectiveDate(Stock.GetParameterValue("Dcpersonaleffectivedate"));
			dc.EnterPayeeFirstName();
			dc.EnterPayeeLastName();
			dc.EnterPayeeAddressline1();
			dc.EnterPayeeCity(Stock.GetParameterValue("Dccity"));
			dc.SelectPayeeState(Stock.GetParameterValue("Dcpayeestate"));
			dc.Enterpayeezipcode();
			dc.Enterpayeeremmaingzip(Stock.GetParameterValue("Dcremainzip"));
			dc.ClickOkbutton("Click");
			Common.switchto_mainwindow();
			dc.ClickUpdatePayee();
			dc.RealtimeDrpDwn(Stock.GetParameterValue("DC_realtime"));
			dc.clicksumbmit();
			dc.clickhomebutton();
	
			
		//	String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	//*********************PRO RATA PERCENTAGE TEST CASE*********************	
		@Test(dataProvider = "setData")
		public void TC1_wmA_Disbursements_PSurrenderProratapercentage(int itr, Map<String, String> testdata) {

			try {
				Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

				LandingPage landing = new LandingPage();
				PartialSurrender psurrender = new PartialSurrender(landing);
			/*	psurrender.clickhomebutton();
				psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
				psurrender.clicksearchbutton();*/
				psurrender.clickpartialsurrender();
				psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
				psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
				psurrender.EnterProrataPercentage(Stock.GetParameterValue("SurrenderPercentage"));
				psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
				
				psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
				
				psurrender.clicksumbmit();
				psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				psurrender.clickhomebutton();

				//String errMsg = "";
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
						.getCause().getMessage(), true);
			} catch (Error ae) {
				ae.printStackTrace();
				Globals.error = ae;
				Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
						"Assertion Failed!!", true);

			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		//*******************************************Partial Surrender Fund Percentage TEST CASE***********************
		@Test(dataProvider = "setData")
		public void TC1_wmA_Disbursements_PSurrenderFundPercentage(int itr, Map<String, String> testdata) {

			try {
				Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

				LandingPage landing = new LandingPage();
				PartialSurrender psurrender = new PartialSurrender(landing);
			/*	psurrender.clickhomebutton();
				psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
				psurrender.clicksearchbutton();*/
				psurrender.clickpartialsurrender();
				psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
		
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
			    psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
			    Thread.sleep(2000);
				psurrender.EnterFundPercentage(Stock.GetParameterValue("SurrenderPercentage"));
				psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
				psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
				psurrender.clicksumbmit();
				psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				psurrender.clickhomebutton();
				
			//	String errMsg = "";
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
						.getCause().getMessage(), true);
			} catch (Error ae) {
				ae.printStackTrace();
				Globals.error = ae;
				Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
						"Assertion Failed!!", true);

			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		
		//**************************************Partial Surrender Fund Amount Test Case**************************************
		@Test(dataProvider = "setData")
		public void TC1_wmA_Disbursements_PSurrenderFundAmount(int itr, Map<String, String> testdata) {

			try {
				Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

				LandingPage landing = new LandingPage();
				PartialSurrender psurrender = new PartialSurrender(landing);
		/*		psurrender.clickhomebutton();
				psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
				psurrender.clicksearchbutton(); */
				psurrender.clickpartialsurrender();
				psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
				psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
				psurrender.EnterFundAmount(Stock.GetParameterValue("SurrenderAmount"));
				psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
				psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
				psurrender.clicksumbmit();
				psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				psurrender.clickhomebutton();
				//String errMsg = "";
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
						.getCause().getMessage(), true);
			} catch (Error ae) {
				ae.printStackTrace();
				Globals.error = ae;
				Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
						"Assertion Failed!!", true);

			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		
		//**********************************Partial Fund Unit TEST CASE*****************************************
		@Test(dataProvider = "setData")
		public void TC1_wmA_Disbursements_PSurrenderFundUnits(int itr, Map<String, String> testdata) {

			try {
				Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

				LandingPage landing = new LandingPage();
				PartialSurrender psurrender = new PartialSurrender(landing);
			/*	psurrender.clickhomebutton();
				psurrender.entercontractid(Stock.GetParameterValue("ContractID"));
				psurrender.clicksearchbutton();*/
				psurrender.clickpartialsurrender();
				psurrender.seteffectivedate(Stock.GetParameterValue("EffectiveDate"));
				psurrender.SelectTransactionLevel(Stock.GetParameterValue("TransactionLevel"));
				Thread.sleep(5000);
				psurrender.SelectTransactionIndicator(Stock.GetParameterValue("TransactionType"));
				
				psurrender.EnterFundUnit(Stock.GetParameterValue("SurrenderUnits"));
				psurrender.selectsourcecode(Stock.GetParameterValue("SourceCode"));
				psurrender.RealtimeDrpDwn(Stock.GetParameterValue("partial_realtime"));
				psurrender.clicksumbmit();
				psurrender.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
				psurrender.clickhomebutton();

				//String errMsg = "";
			} catch (Exception e) {
				e.printStackTrace();
				Globals.exception = e;
				Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
						.getCause().getMessage(), true);
			} catch (Error ae) {
				ae.printStackTrace();
				Globals.error = ae;
				Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
						"Assertion Failed!!", true);

			} finally {
				try {
					Reporter.finalizeTCReport();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}


		
}
