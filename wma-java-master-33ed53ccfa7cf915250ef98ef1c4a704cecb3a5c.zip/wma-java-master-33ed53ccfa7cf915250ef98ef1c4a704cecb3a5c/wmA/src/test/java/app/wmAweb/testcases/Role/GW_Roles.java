package app.wmAweb.testcases.Role;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.management.relation.Role;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.Disbursements.PartialSurrender;
import pageobjects.wmA.Fund.AssetRebalance;
import pageobjects.wmA.Fund.Costaveraging;
import pageobjects.wmA.General.General;
import pageobjects.wmA.History.Transaction;
import pageobjects.wmA.Home.Home;
import pageobjects.wmA.Maintenance.Realtime_update;
import pageobjects.wmA.Premiums_Billing.PremiumDeposit;
import pageobjects.wmA.Role.Party;
import pageobjects.wmA.Role.Role1;
import pageobjects.wmA.Value.Value;

public class GW_Roles {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;

	String tcName;
	static String printTestData = "";

	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
	}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}

	private String printTestData() throws Exception {
		printTestData = "";
		for (Map.Entry<String, String> entry : Stock.globalTestdata.get(Thread.currentThread().getId()).entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("PASSWORD"))
				printTestData = printTestData + entry.getKey() + "=" + entry.getValue() + "\n";
		}
		return printTestData;
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Role_Rolesbenificiary(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

			/*LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			g.get();
			g.clickRoleTab();

			Role1 R1 = new Role1(g);

			R1.clickRoleaddbutton();
			R1.selectbeneficery();
			R1.clickcontinuebutton();
			R1.EnterEffectivedate(Stock.GetParameterValue("EffectiveDate"));
			R1.BeneficieryInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			R1.SelectBeneficeryDetail(Stock.GetParameterValue("Beneficiery_Relationship"),
					Stock.GetParameterValue("Beneficiery_Type"), Stock.GetParameterValue("Beneficiery_percent"));
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and Entered details of role successfully",
					true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(R1);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the LBDA transaction happen on the effective date
			// which
			trs.verifyLBDAtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LBDA tranasaction", true);

			g.clickRoleTab();
			// want to verify whether the First Name of Beneficiery is Displayed
			trs.verifyNewNameRolesTable();
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and verifiyed the First name of Beneficiery ",
					true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(trs);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Role_Change_party_Replace(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			g.get();
			g.clickRoleTab();

			Role1 R1 = new Role1(g);

			R1.clickRoleaddbutton();
			R1.selectbeneficery();
			R1.clickcontinuebutton();
			R1.EnterEffectivedate(Stock.GetParameterValue("EffectiveDate"));
			R1.BeneficieryInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			R1.SelectBeneficeryDetail(Stock.GetParameterValue("Beneficiery_Relationship"),
					Stock.GetParameterValue("Beneficiery_Type"), Stock.GetParameterValue("Beneficiery_percent"));
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and Entered details of role successfully",
					true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(R1);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the LBDA transaction happen on the effective date
			// which
			trs.verifyLBDAtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LBDA tranasaction", true);

			g.clickRoleTab();
			// want to verify whether the First Name of Beneficiery is Displayed
			trs.verifyNewNameRolesTable();
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and verifiyed the First name of Beneficiery ",
					true);
			R1.clickRolename();
			R1.clickRoleChangeButton();
			R1.EnterEffectivedateUpdateBenificery(Stock.GetParameterValue("EffectiveDate"));
			R1.UpdateBeneficeryRelation(Stock.GetParameterValue("Beneficiery_Update_Relationship"));
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			Thread.sleep(10000);
			g.clickhistorysubmenu();
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the LBDC transaction happen on the effective date
			// which
			trs.verifyLBDCtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LBDC tranasaction", true);
			g.clickRoleTab();
			R1.clickRolename();
			// want to verify whether the Relationship status has been changed.
			R1.verifyBeneficieryStatuschange(Stock.GetParameterValue("Beneficiery_Update_Relationship"));
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(trs);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	@Test(dataProvider = "setData")
	public void TC1_wmA_Role_Update_party_Address(int itr, Map<String, String> testdata) {
		try {

			Reporter.initializeReportForTC(itr, Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())
					+ "_" + Stock.getConfigParam("BROWSER"));
			Reporter.logEvent(Status.INFO, "Test Data used for this Test Case:", printTestData(), false);

		/*	LandingPage landing = new LandingPage();
			SelectPartner sp = new SelectPartner(landing);
			sp.get();
			Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
			Web.clickOnElement(sp, "accumulationlink");

			*//**
			 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
			 * product and click Next. Partner is successfully selected and Select Criteria
			 * Page is loaded
			 * 
			 *//*
			sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
			Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 3 - Enter an effective date which should match the current system date
			 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
			 * Select a non-NY state from the Issue State drop-down box and click next .
			 *//*
			SelectCriteria sc = new SelectCriteria(sp);
			sc.get();
			sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
			 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
			 * column
			 * 
			 * .
			 *//*
			SelectPlan pln = new SelectPlan(sc);
			pln.get();
			pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
					Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
			Web.clickOnElement(pln, "ClickOnCashCheckbox");
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 9 - Click on Party Search and search for an advisor to add onto the
			 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
			 * Enter First Year % and Renewal % and click Next .
			 *//*

			ProducerInfo pi = new ProducerInfo(pln);
			pi.get();
			pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
			Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
			Common.switchto_newwindow();
			Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
			Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
			Common.switchto_mainwindow();
			pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
					Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
			Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 12 - Add a new client by filling out the Annuitant Information and
			 * Address fields and click next. .
			 *//*
			AnnuitantInfo ai = new AnnuitantInfo(pi);
			ai.get();
			ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 13 - Enter contract information .
			 *//*
			ContractInfo ci = new ContractInfo(ai);
			ci.get();
			ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
			Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 14 - Enter Billing information .
			 *//*
			BillingInfo bi = new BillingInfo(ci);
			bi.get();
			bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
			bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
			Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			*//**
			 * Step 16 - Enter Fund information .
			 *//*
			FundInfo fi = new FundInfo(bi);
			fi.get();
			fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
			Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");
			*//**
			 * Step 17 - Click submit real time processing summary Finish button verify the
			 * Transaction message .
			 *//*

			PaymentAdd pa = new PaymentAdd(fi);
			pa.get();
			pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
			pa.MemoCode(Stock.GetParameterValue("MemoCode"));
			Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
			Web.clickOnElement(sp, "Next_Button");

			Summary su = new Summary(pa);
			su.get();
			Web.waitForElement(su, "Summary_Realtimewait");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Finishbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			su.getpolicynumber();
			Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
			Web.clickOnElement(su, "Summary_NavigateButton");
			Web.waitForElement(su, "Summary_Fund");*/
			Common.CreateContractAdd();
			LandingPage landing = new LandingPage();
			Summary su = new Summary(landing);
			General g = new General(su);
			g.get();
			g.clickRoleTab();

			Role1 R1 = new Role1(g);

			R1.clickRoleaddbutton();
			R1.selectbeneficery();
			R1.clickcontinuebutton();
			R1.EnterEffectivedate(Stock.GetParameterValue("EffectiveDate"));
			R1.BeneficieryInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
					Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			R1.SelectBeneficeryDetail(Stock.GetParameterValue("Beneficiery_Relationship"),
					Stock.GetParameterValue("Beneficiery_Type"), Stock.GetParameterValue("Beneficiery_percent"));
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and Entered details of role successfully",
					true);

			g.clickhistorysubmenu();
			Transaction trs = new Transaction(R1);
			trs.get();
			Web.waitForElement(trs, "Transaction_updateBT");
			Web.clickOnElement(trs, "Transaction_updateBT");
			// want to verify whether the LBDA transaction happen on the effective date
			// which
			trs.verifyLBDAtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LBDA tranasaction", true);

			g.clickRoleTab();
			// want to verify whether the First Name of Beneficiery is Displayed
			trs.verifyNewNameRolesTable();
			Reporter.logEvent(Status.INFO, "Role Page", "page is Loaded and verifiyed the First name of Beneficiery ",
					true);
			R1.clickRolename();
			R1.clickRoleUpdateButton();
			R1.EnterEffectivedateAddUpdateBenificery(Stock.GetParameterValue("EffectiveDate"));
			R1.UpdateBeneficeryCountry(Stock.GetParameterValue("Beneficiery_Country"));
			Web.waitForElement(su, "Summary_Realtime");
			Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
			Web.clickOnElement(su, "Summary_Submitbtn");
			su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
			Thread.sleep(5000);
			Party P1=new Party(su);
			P1.clickPartyhistorysubmenu();
			P1.get();
			
			// want to verify whether the LDF transaction happen on the effective date
			// which
			//trs.verifyLDFtransaction();
			Reporter.logEvent(Status.INFO, "History Page", "page is Loaded and verifiyed the LDF tranasaction", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			Home H1= new Home(P1);
			H1.entercontractid(Common.Contractinfo.get("Contractid"));
			H1.Clickonserachbutton();
			Thread.sleep(15000);
			g.clickRoleTab();
			R1.clickRolename();
			// want to verify whether the Country status has been changed.
			R1.verifyBeneficieryCountrychange(Stock.GetParameterValue("Beneficiery_Country"));
			Reporter.logEvent(Status.INFO, "Role Page", " Role page is Loaded and verifiyed Beneficiery_Country status", true);
			Web.clickOnElement(su, "Summary_Homebtn");
			SelectPartner sp = new SelectPartner(trs);
			Web.waitForElement(sp, "accumulationlink");

		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured", "Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

	}

}
