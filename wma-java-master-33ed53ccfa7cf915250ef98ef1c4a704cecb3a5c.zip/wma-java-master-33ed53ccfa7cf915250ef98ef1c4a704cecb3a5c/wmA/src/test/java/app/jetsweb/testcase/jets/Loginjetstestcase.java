package app.jetsweb.testcase.jets;

import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import pageobjects.jets.LoginPagejets;



public class Loginjetstestcase {
	
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	pageobjects.jets.LoginPagejets login;
	String tcName;
	
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}
	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}
	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
	}
	
	@Test(dataProvider = "setData")
	public void TC1_jets_Signup(int itr, Map<String, String> testdata) {

		try {
			Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));

			LoginPagejets login = new LoginPagejets();
		
			login.get();
			login.submitLoginCredentials(
					lib.Stock.GetParameterValue("username"),
					lib.Stock.GetParameterValue("password"));
			login.clickcontratinquiry();
			lib.Reporter
			.logEvent(
					Status.PASS,
					"Contract inquiry is clicked",
					"No error message is displayed after submiting login credentials\nExpected error message on clicking on Sign In button",
					true);
			login.ContractNumber(Stock.GetParameterValue("Contract_Number"));
			login.cilcksearch();
			login.contracttable();
			

			String errMsg = "";
		} catch (Exception e) {
			e.printStackTrace();
			Globals.exception = e;
			Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
					.getCause().getMessage(), true);
		} catch (Error ae) {
			ae.printStackTrace();
			Globals.error = ae;
			Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
					"Assertion Failed!!", true);

		} finally {
			try {
				Reporter.finalizeTCReport();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}
	
	
	

}


