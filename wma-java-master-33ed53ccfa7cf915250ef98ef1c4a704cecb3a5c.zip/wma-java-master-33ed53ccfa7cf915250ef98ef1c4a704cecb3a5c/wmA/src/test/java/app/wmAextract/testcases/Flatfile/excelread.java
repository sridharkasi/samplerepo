package app.wmAextract.testcases.Flatfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class excelread {

	public void excelread() throws IOException {
		   String dataFile = "C:\\testdat.xlsx";

		    File file = new File(dataFile);

		    FileInputStream inputStream = new FileInputStream(file);

		    Workbook workbook = new XSSFWorkbook(inputStream);
		    
		    try {
		        // Read sheet inside the workbook by its name
		        //org.apache.poi.ss.usermodel.Sheet sh = workbook.getSheet("ContractEventsRecords");
		    	Sheet sh = workbook.getSheet("ContractEventsRecords");
		        int totalNoOfRows = sh.getLastRowNum() - sh.getFirstRowNum();
		        
		        Row headerrow = sh.getRow(0);
		        System.out.println(headerrow);
		        HashMap<String, String> map = new HashMap<String, String>();

		        for (int row = 1; row < totalNoOfRows; row++) {

		            Row row1 = sh.getRow(row);
		            System.out.println(row1);
		         //   if ((row1.getCell(0).getStringCellValue()).equals(Testcasename)) {
		                for (int col = 1; col < row1.getLastCellNum(); col++) {
		                    map.put(headerrow.getCell(col).getStringCellValue(), row1.getCell(col).getStringCellValue());
		                }

		          //  /./}
		            System.out.println(map);// TODO Auto-generated method stub

		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
	}

	
	public static Map<String, String> fectchdata(){
		Map<String, String> data = new HashMap <String, String> ();
		
		String Fieldname;
		String Position;
		String Value;
		String value1;

		try {
			FileInputStream fis = new FileInputStream(new File("C:\\testdat.xlsx"));
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
			XSSFSheet sheet =workbook.getSheet("ContractEventsRecords");
			// get the number of rows
			int rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			//data = new String[rowCount][columnCount];


			// loop through the rows
			System.out.println(rowCount);
			XSSFRow row;
			for(int i=1; i <rowCount+1; i++){
				Fieldname = null;
				Position = null;
				Value = null; value1 = null;
				try {
					 row = sheet.getRow(i);
					 
					if (!row.getCell(2).getStringCellValue().equals(""))
					{
						
						Fieldname = row.getCell(0).getStringCellValue();
						Position = row.getCell(1).getStringCellValue();
						Value = row.getCell(2).getStringCellValue();
						
						value1 = Position +"|"+ Value;
						
						data.put(Fieldname, value1);
					}
					
					
					
					
					
				} catch(NullPointerException e)
		        {
		            //System.out.print("NullPointerException Caught");
		       
				}
				
				
			}
			fis.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
		
	}
	
	@Test
	public void gethashmap() {
		Map<String, String> data = fectchdata();
		//for (int i=0; i<data.size(); i++)
		//{
			System.out.println(data.values());
			
			System.out.println(data.keySet());
			String tstData;
			String Startpos, EndPos;
			String[] Positions;
			String[] Splitvalues;
			
			for(Entry<String, String> entry : data.entrySet()) {
			    String key = entry.getKey();
			    String value = entry.getValue();
			    System.out.println(key);
			    
			    Splitvalues = value.split("|");
			    
			    tstData = Splitvalues[1];
			    Positions = Splitvalues[0].split(",");
			    //Startpos = Positions[0];
			    //EndPos = Positions[1];
				
			    System.out.println("testdata "+tstData);
				//System.out.println("Position "+Startpos+" and "+EndPos);
			   // System.out.println(Positions.)
			    //System.out.println(value.split("|"));
			}
		//}
	}
	
	//for (int i=0; i<map.)
}
