package app.wmAextract.testcases.Flatfile;


import java.io.FileNotFoundException;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import core.framework.Globals;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class FlatfilePOV {
	private LinkedHashMap<Integer, Map<String, String>> testData = null;
	
	String tcName;
	static String printTestData="";
	String input;
	String Filepath;
	
	
	//LoadableComponent<?> parent;*/
	@BeforeClass
	public void InitTest() throws Exception {
		Reporter.initializeModule(this.getClass().getName());
			}

	@DataProvider
	public Object[][] setData(Method tc) throws Exception {
		prepTestData(tc);
		return Stock.setDataProvider(this.testData);
	}

	private void prepTestData(Method testCase) throws Exception {
		this.testData = Stock.getTestData(this.getClass().getPackage().getName(), testCase.getName());
		//System.out.println(this.testData);
	}
	
	@SuppressWarnings("unlikely-arg-type")
	@Test(dataProvider = "setData")
	public void TC2_wmA_Flatfile_Verification(int itr, Map<String, String> testdata) throws FileNotFoundException {
	
		//this.parent.get();
		 //Stock.getConfigParam("AppURL" + "_"

	                                      //  + Stock.getConfigParam("TEST_ENV"));
	try {
		Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId())+"_"+Stock.getConfigParam("BROWSER"));
		//Reporter.initializeReportForTC(itr,Globals.GC_MANUAL_TC_REPORTER_MAP.get(Thread.currentThread().getId()));//+"_"+Stock.getConfigParam("BROWSER"));
		Web.getDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		input = Stock.GetParameterValue("TexttoFind");
		Filepath = Stock.GetParameterValue("Filepath");
		//Common.flatfileverification(Stock.getConfigParam("input"),Stock.getConfigParam("Filepath"));
		Common.flatfileverification(Stock.GetParameterValue("ContractNumber"),"ContractNumber");
		Common.flatfileverification(Stock.GetParameterValue("CUSIPNumber"),"CUSIPNumber");
		Common.flatfileverification(Stock.GetParameterValue("ContractStatus"),"ContractStatus");
		Common.flatfileverification(Stock.GetParameterValue("ContractState"),"ContractState");
		
		//flatfileverification(String input, String Filepath, String selectionString)
		//Stock.
		/*for (int i=0; i<=testData.size(); i++)
		{
			System.out.println(testData.get(i).);
		}*/
		/*for (Entry<Integer, Map<String, String>> entry : testData.entrySet()) {
			 // Integer key = entry.getKey();
			  //System.out.println(entry.getKey().);
			 // Map<String, String> value = entry.getValue();
			  System.out.println(testData.get(entry));
			  // do stuff
			}*/
		
	}
	catch (Exception e) {
		e.printStackTrace();
		Globals.exception = e;
		Reporter.logEvent(Status.FAIL, "A run time exception occured.", e
				.getCause().getMessage(), true);
	} catch (Error ae) {
		ae.printStackTrace();
		Globals.error = ae;
		Reporter.logEvent(Status.FAIL, "Assertion Error Occured",
				"Assertion Failed!!", true);

	} finally {
		try {
			Reporter.finalizeTCReport();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
}
	

}
