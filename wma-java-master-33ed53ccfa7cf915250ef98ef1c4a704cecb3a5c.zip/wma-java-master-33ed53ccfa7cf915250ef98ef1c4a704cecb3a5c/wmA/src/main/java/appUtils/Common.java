package appUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Random;

import lib.DB;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.AnnuitantInfo;
import pageobjects.wmA.Accumulation.BillingInfo;
import pageobjects.wmA.Accumulation.Co_AnnuitantInfo;
import pageobjects.wmA.Accumulation.Co_Owner;
import pageobjects.wmA.Accumulation.ContractInfo;
import pageobjects.wmA.Accumulation.FundInfo;
import pageobjects.wmA.Accumulation.HCCExpressAdd;
import pageobjects.wmA.Accumulation.LPAInfo;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.Accumulation.OwnerInfo;
import pageobjects.wmA.Accumulation.PATInfo;
import pageobjects.wmA.Accumulation.PayerInfo;
import pageobjects.wmA.Accumulation.PaymentAdd;
import pageobjects.wmA.Accumulation.ProducerInfo;
import pageobjects.wmA.Accumulation.RIAInfo;
import pageobjects.wmA.Accumulation.SAAInfo;
import pageobjects.wmA.Accumulation.SelectCriteria;
import pageobjects.wmA.Accumulation.SelectPartner;
import pageobjects.wmA.Accumulation.SelectPlan;
import pageobjects.wmA.Accumulation.SuccessorInfo;
import pageobjects.wmA.Accumulation.Summary;
import pageobjects.wmA.General.General;
import pageobjects.wmA.Home.Home;
import sun.misc.BASE64Decoder;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.annotation.JsonFormat.Value;

import core.framework.Globals;
import io.inbot.testfixtures.Person;
import io.inbot.testfixtures.RandomNameGenerator;

public class Common {

	/**
	 * <pre>
	 * Method to return the no of plans associated to a user from db
	 * 
	 * @return noOfPlans
	 */

	public static final String GC_DEFAULT_SPONSER = "Empower";
	public static double ncFundtotal;
	public static double frmFundtotal;
	static List<String> lstDisbursmentReason = new ArrayList<String>();
	static List<String> lstDistributionMethod = new ArrayList<String>();
	static List<String> lstDistributionMethodTimings = new ArrayList<String>();
	@FindBy(xpath = ".//*[@id='utility-nav']/.//a[@id='topHeaderUserProfileName']")
	public static WebElement lblUserName;
	@FindBy(name = "legacyFeatureIframe")
	public static WebElement iframeLegacyFeature;
	@FindBy(xpath = "//button[text()[normalize-space()='Dismiss']]")
	public static WebElement lnkDismiss;
	@FindBy(id = "nextbutton")
	public static WebElement NextButton;

	@FindBy(xpath = "//table[@id='mainform:TransferFund']/tbody/tr")
	public static List<WebElement> FundTableTB;

	@FindBy(xpath = "//table[@id='mainform:AllocationFund']/tbody/tr")
	private List<WebElement> CoveredFundrow;

	// @FindBy(xpath="//table[@id='mainform:ValuesFundVals']/tbody/tr")
	@FindBy(xpath = "//table[@id='mainform:ValuesFundVals']/tbody/tr")

	public static List<WebElement> ValuesTableTB;

	@FindBy(xpath = "//span[@id='mainform:ValuesFundVals:0:valuesValuesFundValsFundValue']")
	public static WebElement DisbursementTab;

	public static HashMap<String, String> Fundtable = new HashMap<String, String>();
	public static HashMap<String, String> Disbursementtable = new HashMap<String, String>();
	public static HashMap<String, String> CovFund = new HashMap<String, String>();
	public static HashMap<String, String> CovFundinfo = new HashMap<String, String>();
	public static HashMap<String, String> NonCFund = new HashMap<String, String>();
	public static HashMap<String, String> NonCFundinfo = new HashMap<String, String>();
	public static HashMap<String, String> GawFundOLD = new HashMap<String, String>();
	public static HashMap<String, String> GawFundPRC = new HashMap<String, String>();
	public static HashMap<String, String> GawFundNEW = new HashMap<String, String>();
	public static HashMap<String, String> RBFundPRC = new HashMap<String, String>();
	public static HashMap<String, String> Contractinfo = new HashMap<String, String>();
	public static HashMap<String, String> FreeoutAmountValue = new HashMap<String, String>();
	public static HashMap<String, String> NewRoleEnter = new HashMap<String, String>();
	
	public static String lWrider;
	public static String EWrider;
	public static String MaximumBenefitvalue;
	public static String RMDGrossvalue;

	public static int From_Fund_Number;
	public static String From_Fund_Name;
	public static int From_Fund_Value;
	public static int To_Fund_Number_1;
	public static String To_Fund_Name_1;
	public static int To_Fund_Value_1;
	public static int To_Fund_Number_2;
	public static String To_Fund_Name_2;
	public static int To_Fund_Value_2;

	public static String FundArr[];

	private static DecimalFormat df2 = new DecimalFormat(".##");

	// private static String lnkDismiss=
	// "//button[text()[normalize-space()='Dismiss']]";
	private static String userName = "";
	static String userFromDatasheet = null;
	private static String textField = "//*[contains(text(),'webElementText')]";
	private static String errorMessage = "//*[text()='webElementText']";
	public static String Mainwindow;
	public static String Newwindow;
	// =======================================================================================================================================================================

	public Common() {

		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	/**
	 * Method is used to Click the sub menu in wmA
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void ClickSubmenu(WebElement x) {
		JavascriptExecutor js = (JavascriptExecutor) Web.getDriver();
		js.executeScript("arguments[0].click();", x);

	}

	/*
	 * public static void JsEntervalue( WebElement x) { String x; JavascriptExecutor
	 * js = (JavascriptExecutor) Web.getDriver();
	 * js.executeScript("arguments[0].value=", x);
	 * 
	 * }
	 */

//==========================================================================================

	/**
	 * Method is used to delete cookies
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void deletecookies() {

		JavascriptExecutor js = (JavascriptExecutor) Web.getDriver();

		js.executeScript("localStorage.clear();");

		js.executeScript("sessionStorage.clear();");

		Web.getDriver().manage().deleteAllCookies();

	}

//****************************************************************************************************************************

	/**
	 * Method is used to select the dropdown by value
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void selectbyvalue(WebElement obj, String value) {

		Select selc = new Select(obj);
		selc.selectByVisibleText(value);
	}
	
	public static void selectbyvalues(WebElement obj, String value) {

		Select selc = new Select(obj);
		selc.selectByValue(value);
	}

//****************************************************************************************************************************
	/**
	 * Method is used to Switcwindoow in wmA
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void switchwindow(String CaseString, WebElement E) {

		String Parentwindow = Web.getDriver().getWindowHandle();

		for (String winhandles : Web.getDriver().getWindowHandles()) {
			if (!winhandles.equalsIgnoreCase(Parentwindow)) {
				Web.getDriver().switchTo().window(winhandles);

				switch (CaseString) {
				case "click":
					E.click();
					break;

				case "setText":
					E.sendKeys("");
					break;
				default:
					System.out.println("Not in the list");
					break;
				}
			}

			Web.getDriver().switchTo().window(Parentwindow);
		}

	}

//****************************************************************************************************************************
	/**
	 * Method is used to switch main window
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void switchto_mainwindow() {

		Web.getDriver().switchTo().window(Mainwindow);

	}
//****************************************************************************************************************************

	/**
	 * Method is used to switch to new window
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static void switchto_newwindow() {
		Mainwindow = Web.getDriver().getWindowHandle();

		for (String winhandles : Web.getDriver().getWindowHandles()) {
			if (!winhandles.equalsIgnoreCase(Mainwindow)) {
				Web.getDriver().switchTo().window(winhandles);

			}
		}

	}

///================================================================================================================================

	public static boolean verifyStringIsInNumberFormat(String value) {
		int number;
		boolean lblDisplayed;
		try {

			number = Integer.parseInt(value);
			lblDisplayed = true;
		} catch (NumberFormatException ex) {
			lblDisplayed = false;
		}
		return lblDisplayed;
	}

	public static String checkEnv(String envName) {
		if (envName.contains("PROJ")) {
			return Globals.DB_TYPE.get("PROJ");
		}
		if (envName.contains("QA")) {
			return Globals.DB_TYPE.get("QA");
		}
		if (envName.contains("PROD")) {
			return Globals.DB_TYPE.get("PROD");
		}
		return null;
	}

//****************************************************************************************************************************	
	private static String progressBar = "//*[@class='loader']";
	/*
	 * @Author :- Siddartha
	 * 
	 * @Date :- 17 - Oct -2016
	 * 
	 * @ Method:-
	 */

	public static void waitForProgressBar() {
		int iTimeInSecond = 30;
		try {
			int iCount = 0;
			while (FindElement(progressBar).isDisplayed()) {
				if (Web.isWebElementDisplayed(lnkDismiss)) {
					Web.clickOnElement(lnkDismiss);
				}
				if (iCount == iTimeInSecond) {
					break;
				}

				System.out.println("Progress Bar displaying..");
				Thread.sleep(1000);
				iCount++;
			}

		} catch (Exception e) {

		}

	}

	// ****************************************************************************************************************************
	public static WebElement FindElement(String sElement) {
		return lib.Web.getDriver().findElement(By.xpath(sElement));
	}

	public static boolean isAlerPresent() throws InterruptedException {
		try {
			Thread.sleep(5000);
			Web.getDriver().switchTo().alert();
			System.out.println("Alert Present");
			return true;
		} catch (NoAlertPresentException ex) {
			System.out.println("No Alert Present");
			return false;
		}

	}

	// ****************************************************************************************************************************

	public static void HandlePopAlert() {
		try {

			Alert alert = Web.getDriver().switchTo().alert();
			String sPopText = alert.getText();
			System.out.println(sPopText);
			alert.accept();
			Thread.sleep(5000);
		} catch (Exception e) {

		}

	}

	// ****************************************************************************************************************************
	public static boolean switchToLegacyFutureFrame() {
		try {
			Web.getDriver().switchTo().defaultContent();
			Web.waitForElement(iframeLegacyFeature);
			if (Web.isWebElementDisplayed(iframeLegacyFeature)) {
				Web.getDriver().switchTo().frame(iframeLegacyFeature);
			}
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	// ****************************************************************************************************************************

	public static boolean isTextFieldDisplayed(String fieldName) {
		boolean isTextDisplayed = false;
		try {
			WebElement txtField = Web.getDriver().findElement(By.xpath(textField.replace("webElementText", fieldName)));

			isTextDisplayed = Web.isWebElementDisplayed(txtField, true);

		} catch (NoSuchElementException e) {

			isTextDisplayed = false;
		}

		return isTextDisplayed;
	}

	// ****************************************************************************************************************************
	/**
	 * Method to verify Label is Displayed
	 * 
	 * @param labelName
	 * @return
	 */
	public static boolean isLabelDisplayed(String labelName) {
		boolean isTextDisplayed = false;
		try {
			WebElement txtField = Web.getDriver().findElement(By.xpath(textField.replace("webElementText", labelName)));

			isTextDisplayed = Web.isWebElementDisplayed(txtField, true);

			if (isTextDisplayed)
				lib.Reporter.logEvent(Status.PASS, "Verify " + labelName + "   Label is Displayed",
						"'" + labelName + "' Label is Displayed", true);

		} catch (NoSuchElementException e) {
			lib.Reporter.logEvent(Status.FAIL, "Verify " + labelName + "   Label is Displayed",
					"'" + labelName + "' Label is Not Displayed", true);
			isTextDisplayed = false;
		}

		return isTextDisplayed;
	}

//****************************************************************************************************************************
	/**
	 * Method to verify Error Message is Displayed
	 * 
	 * @param errorMsg
	 * @return
	 */
	public static boolean isErrorMessageDisplayed(String errorMsg) {
		boolean isErrorMessageDisplayed = false;
		try {
			WebElement txtField = Web.getDriver()
					.findElement(By.xpath(errorMessage.replace("webElementText", errorMsg)));

			isErrorMessageDisplayed = Web.isWebElementDisplayed(txtField, true);

			if (isErrorMessageDisplayed)
				lib.Reporter.logEvent(Status.PASS, "Verify Error Message" + errorMsg + " is Displayed",
						"'" + errorMsg + "'Error Message is Displayed", false);

		} catch (NoSuchElementException e) {
			lib.Reporter.logEvent(Status.FAIL, "Verify Error Message" + errorMsg + " is Displayed",
					"'" + errorMsg + "'Error Message is not Displayed", true);
			isErrorMessageDisplayed = false;
		}

		return isErrorMessageDisplayed;
	}

//****************************************************************************************************************************	
	/**
	 * 
	 * @param format
	 * @return
	 * @throws Exception
	 */
	public static String getFutureDate(String format) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 20);
		String date = dateFormat.format(calendar.getTime());
		System.out.println("DATE" + date);
		return date;
	}

//****************************************************************************************************************************
	/**
	 * 
	 * @param format
	 * @param futeureDate
	 * @return
	 * @throws Exception
	 */
	public static String getFutureDate(String format, int futeureDate) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, futeureDate);
		String date = dateFormat.format(calendar.getTime());
		System.out.println("DATE" + date);
		return date;
	}

	public static String getCurrentDate(String format) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar calendar = Calendar.getInstance();
		String date = dateFormat.format(calendar.getTime());
		System.out.println("DATE: " + date);
		return date;
	}

//****************************************************************************************************************************	
	/**
	 * Method to get the Plan Name
	 * 
	 * @param gc_Id 194044
	 * @return planName
	 * @throws SQLException /** Method to update default_code in Address Table
	 * @author srsksr
	 * @throws Exception
	 */
	/**
	 * Method Sets Date into particular format like ex:mm/dd/yyyy and returns Date
	 * in String Format type
	 * 
	 * @author gbhrgv
	 * @param date
	 * @param Dateformat type ex:mm/dd/yyyy
	 */
	public static String setSimpleFormatDate(String sdate, String dateformatType) {
		SimpleDateFormat sfd = new SimpleDateFormat(dateformatType);
		String sdate1 = null;
		try {
			Date date = sfd.parse(sdate);
			sdate1 = sfd.format(date);
			System.out.println(sdate1);
		} catch (Exception e) {
			Reporter.logEvent(Status.FAIL, "Date Parse Exception Accured", "", true);
		}
		return sdate1;
	}

//****************************************************************************************************************************
	private static String remove = "REMOVE";
	private static String blank = "BLANK";

	/**
	 * <pre>
	 * It returns the request url
	 * 
	 * @param baseURL of the request url mostly static part of the url.
	 * @param params  other parameters (mandatory or optional) of the request url
	 * @return string url
	 */
	public static String formRequestURLPPTWeb(String baseURL, String... params) {
		String requestURL = baseURL;
		try {
			if (params.length > 0) {
				for (String param : params) {
					if (!(param.contains(remove) || param.contains(blank) || param.contains("?"))) {
						if (requestURL.endsWith("/")) {
							requestURL = requestURL + param;
						} else if (requestURL.endsWith("&")) {
							requestURL = requestURL + param;
						} else {
							requestURL = requestURL + "/" + param;
						}
					}
					if (param.contains(blank)) {
						param = param.replace(blank, "");
						requestURL = requestURL + "/" + param;
					}
					if (param.contains("?")) {
						if (requestURL.endsWith("/")) {
							requestURL = requestURL.substring(0, requestURL.length() - 1).trim();
						}
						requestURL = requestURL + param;
					}
				}
				if (requestURL.endsWith("/")) {
					requestURL = requestURL.substring(0, requestURL.length() - 1).trim();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestURL;
	}

//****************************************************************************************************************************	
	/**
	 * Method is used to verify Flat files
	 * 
	 * @author srdksn
	 * @param input
	 * @param selectionString
	 */

	public static void flatfileverification(String input, String selectionString) throws FileNotFoundException {
		// TODO Auto-generated method stub

		File file = new File(Stock.getConfigParam("POVPath"));// "C:\\Flatfile.POV");

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(file);

		while (sc.hasNextLine()) {
			int FromPos = 0;
			int ToPos = 0;
			String linefromfile = sc.nextLine();
			if (linefromfile.contains(input)) {
				// a match!!

				switch (selectionString.toLowerCase()) {
				case "cusipnumber":
					FromPos = 35;
					ToPos = 44;
					break;

				case "contractnumber":
					FromPos = 5;
					ToPos = 35;
					break;

				case "contractstatus":
					FromPos = 44;
					ToPos = 46;
					break;

				case "contractstate":
					FromPos = 186;
					ToPos = 188;
					break;
				default:
					System.out.println("Not in the list");
					break;
				}

				System.out.println(linefromfile.substring(FromPos, ToPos));

				if (linefromfile.substring(FromPos, ToPos).trim().equalsIgnoreCase(input)) {
					try {

						System.out.println("text [" + input + "] found between [" + FromPos + " and]" + ToPos);
					} catch (Exception e) {

						System.out.println("I found" + input + " between [" + FromPos + " and]" + ToPos);
					}
					break;
				} else {

					break;
				}

			}
		}

	}

//****************************************************************************************************************************      
	public static Map<String, String> fectchdata(String Sheetname) {
		Map<String, String> data = new HashMap<String, String>();

		String Fieldname;
		String Position;
		String Value;
		String value1;

		try {
			FileInputStream fis = new FileInputStream(new File("C:\\wmA_Automation\\testdat.xlsx"));
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(fis);

			// XSSFSheet sheet =workbook.getSheet("ContractEventsRecords");
			XSSFSheet sheet = workbook.getSheet(Sheetname);
			// get the number of rows
			int rowCount = sheet.getLastRowNum();

			// get the number of columns
			int columnCount = sheet.getRow(0).getLastCellNum();
			// data = new String[rowCount][columnCount];

			// loop through the rows
			// System.out.println(rowCount);
			XSSFRow row;
			for (int i = 1; i < rowCount + 1; i++) {
				Fieldname = null;
				Position = null;
				Value = null;
				value1 = null;
				try {
					row = sheet.getRow(i);

					if (!row.getCell(2).getStringCellValue().equals("")) {

						Fieldname = row.getCell(0).getStringCellValue();
						Position = row.getCell(1).getStringCellValue();
						Value = row.getCell(2).getStringCellValue();

						value1 = Position + "|" + Value;

						data.put(Fieldname, value1);
					}

				} catch (NullPointerException e) {
					// System.out.print("NullPointerException Caught");

				}

			}
			fis.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;

	}

//****************************************************************************************************************************	   	
	// @Test
	public static void gethashmap(String Sheetname) throws FileNotFoundException {
		Map<String, String> data = fectchdata(Sheetname);

		System.out.println(data.values());

		System.out.println(data.keySet());
		String tstData;
		String FromPosition, ToPosition;
		String[] Positions;
		String[] Splitvalues;

		for (Entry<String, String> entry : data.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue().trim();

			System.out.println(key);
			System.out.println(value);

			Splitvalues = value.split("\\|");
			System.out.println(Splitvalues[0]);
			System.out.println(Splitvalues[1]);

			tstData = Splitvalues[1];
			Positions = Splitvalues[0].split("\\,");
			FromPosition = Positions[0];
			ToPosition = Positions[1];

			// System.out.println("testdata "+tstData);
			// System.out.println("Position "+Startpos+" and "+EndPos);
			System.out.println("******************************");
			// ******************************************code**********************************************

			/**
			 * Method is used to verify POV files
			 * 
			 * @author srdksn
			 * @param
			 * @param
			 */

			File file = new File(Stock.getConfigParam("POVPath"));
			Scanner sc = new Scanner(file);

			while (sc.hasNextLine()) {
				int FromPos = Integer.parseInt(FromPosition);
				int ToPos = Integer.parseInt(ToPosition);
				String linefromfile = sc.nextLine();
				if (linefromfile.contains(tstData)) {

					// System.out.println("Inline Value
					// ["+linefromfile.substring(FromPos,ToPos).trim());
					if (linefromfile.substring(FromPos - 1, ToPos).trim().equalsIgnoreCase(tstData)) {

						try {

							System.out.println("text [" + tstData + "] found between [" + FromPos + " and]" + ToPos);
						} catch (Exception e) {
							System.out.println("I found" + tstData + " between [" + FromPos + " and]" + ToPos);
							break;
						}
						break;
					}

					else if (linefromfile.contains("END.")) {

						System.out.println(tstData + " between [" + FromPos + " and]" + ToPos + " not found");
						break;
					}
				}

			}

			// }
		}
	}

//****************************************************************************************************************************
	/**
	 * Method is used to create a dynamic SSN
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static String generateSSN() {
		long timeSeed = System.nanoTime(); // to get the current date time value

		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed); // mixing up the time and
														// rand number.

		String s = midSeed + "";
		String subStr = s.substring(0, 9);

		System.out.println(subStr);
		return subStr;
	}

//****************************************************************************************************************************
	/**
	 * Method is used to Create dynamic firstname
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */

	public static String firstnameGenerator() {

		String firstname = "Automation";
		long timeSeed = System.nanoTime();
		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed);
		String s = midSeed + "";
		String subStr = s.substring(0, 3);

		return firstname + subStr;

	}

//****************************************************************************************************************************
	/**
	 * Method is used to Create Random vaild firstname
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */

	public static String randomvaildFirstname() {
		Random rand = new Random();

		int n = rand.nextInt(5000) + 1;
		RandomNameGenerator randomNameGenerator = new RandomNameGenerator(n);

		Person p = randomNameGenerator.nextPerson();
		String a = p.getFirstName();
		return a;
	}
//****************************************************************************************************************************

	/**
	 * Method is used to Create Random valid Last name
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */

	public static String randomvaildLastname() {
		Random rand = new Random();

		int n = rand.nextInt(5000) + 1;
		RandomNameGenerator randomNameGenerator = new RandomNameGenerator(n);

		Person p = randomNameGenerator.nextPerson();
		String lname = p.getLastName();
		return lname;
	}

//****************************************************************************************************************************   
	/**
	 * Method is used to Create Agent name
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */
	public static String AgentnameGenerator() {

		String firstname = "AGENT";
		long timeSeed = System.nanoTime();
		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed);
		String s = midSeed + "";
		String subStr = s.substring(0, 1);

		return firstname + subStr;

	}

//****************************************************************************************************************************	 
	/**
	 * Method is used to Create Zip code
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */
	public static String AutoZipcode() {
		long timeSeed = System.nanoTime(); // to get the current date time value

		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed); // mixing up the time and
														// rand number.

		String s = midSeed + "";
		String subStr = s.substring(0, 5);

		System.out.println(subStr);
		return subStr;
	}

//****************************************************************************************************************************   
	/**
	 * Method is used to Create dynamic last name
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static String lastnameGenerator() {
		String lastname = "Test";
		long timeSeed = System.nanoTime();
		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed);
		String s = midSeed + "";
		String subStr = s.substring(0, 3);

		return lastname + subStr;

	}

//****************************************************************************************************************************
	/**
	 * Method is used to Create dynamic address
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 */
	public static String AddressGenerator() {
		String Address = "Automation Address-";
		long timeSeed = System.nanoTime();
		double randSeed = Math.random() * 1000; // random number generation

		long midSeed = (long) (timeSeed * randSeed);
		String s = midSeed + "";
		String subStr = s.substring(0, 3);

		return Address + subStr;

	}

//****************************************************************************************************************************	 
	/**
	 * Method is used in Fund Transfer test case to enter the Fund
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */
	public static void Transferfund() throws InterruptedException {

		try {
			Thread.sleep(2000);
		} catch (Exception e) {

		}

		// String multfund = Stock.getConfigParam("MultipleFund");

		int multifundnumber = Integer.parseInt(Stock.GetParameterValue("MultipleFund"));
		int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));

		// int initialvalue;
		double frmfundvalue = 0;
		boolean Cfund = false;
		double frmfundtotpercentage = 0;
		String FromfundNumber = null;
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th")).size();
		int Frompercent = 0;
		int Topercent = 0;
		int valuehead = 0;
		String percentfrom = "From Percent";
		String dollarfrom = "From/Remaining Amount";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(percentfrom) || fud.equalsIgnoreCase(dollarfrom)) {
				Frompercent = i;
				break;
			}
		}
		String percentTo = "To Percent";
		String dollarTo = "To Amount";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(dollarTo) || fud.equalsIgnoreCase(percentTo)) {
				Topercent = i;
				break;
			}
		}

		String val = "Value";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(val)) {
				valuehead = i;
				break;
			}
		}

		int cnt;
		int tofu = 0;
		String too3 = null;
		int tbrow = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr")).size();

		if (tbrow > multifundnumber) {
			for (int i = 1; i <= multifundnumber + 1; i++) {
				if (i == 1) {
					Fundtable.put("FundNumer_" + i,
							Web.getDriver()
									.findElement(
											By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
									.getText());
					Fundtable.put("FundName_" + i,
							Web.getDriver()
									.findElement(
											By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
									.getText());

					// String getvalue =
					// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
					FromfundNumber = Fundtable.get("FundNumer_" + i);
					Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
							.click();
					Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
							.sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

					Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
							"[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
					// Fundtable.put
					/*
					 * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
					 * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
					 */

					// String splitamt1 = splitamt[0].trim().toString();
					String fFundvalue;
					fFundvalue = Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span"))
							.getText();
					fFundvalue = fFundvalue.trim().toString();

					String[] delimit = fFundvalue.split("[$]");
					String arr1[] = null;
					if (delimit[1].contains(",")) {
						arr1 = delimit[1].split(",");

					}

					if (arr1.length > 0) {

						String foo = arr1[0];
						for (int a = 1; a < arr1.length; a++) {
							foo = foo + arr1[a];

						}
						fFundvalue = foo;
					} else {
						fFundvalue = delimit[1].trim().toString();
					}

					/// ********************************************

					if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
						String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

						// String splitamt1 = splitamt[0].trim().toString();

						double x = Double.parseDouble(splitamt[0]) / 100;
						// double y = Double.parseDouble(Delimit1.toString());
						double y = Double.parseDouble(fFundvalue);

						// y = Double.parseDouble(df2.format(fFundvalue));
						// double z = x * y;
						System.out.println(df2.format(y));

						frmfundvalue = x * y;

						// add percentage value

						String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

						frmFundtotal = x * Double.parseDouble(paymtAmount);

						// String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
						// String[] splitamttofund =
						// Stock.GetParameterValue("Ftfromtransfer").split("%");

						/*
						 * Double amount = Double.parseDouble(splitamt[0]);
						 * 
						 * 
						 * 
						 * Double Tofundvalue = (amount/100)* frmfundvalue;
						 */

						// Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
						// Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
						// *********************************************************************************************
						/*
						 * String toString = Double.toString(Tofundvalue);
						 * 
						 * 
						 * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
						 * 
						 * String too2 =toString.substring(toString.lastIndexOf("."),
						 * toString.lastIndexOf(".")+3);
						 * 
						 * too3 = too1+too2;
						 */
						// *********************************************************************************************

					} else {

						// String splitamt1 = splitamt[0].trim().toString();

						double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
						// double y = Double.parseDouble(Delimit1.toString());
						double y = Double.parseDouble(fFundvalue);

						// y = Double.parseDouble(df2.format(fFundvalue));
						// double z = x * y;
						System.out.println(df2.format(y));

						frmfundvalue = y - x;

						// Stock.GetParameterValue("Ftfromtransfer")
						// frmFundtotal = Double.parseDouble("PaymentAmount") -
						// Double.parseDouble("Ftfromtransfer");

						// add percentage value
					}

					System.out.println(frmfundvalue);
					// *********************************************

					String tostring = Double.toString(frmfundvalue);

					// Fundtable.put("FromFundValue_"+i,tostring);
					// Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
					String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

					String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

					String foo3 = foo1 + foo2;

					// Fundtable.put("FromFundValue_"+i,new
					// DecimalFormat("##.##").format(frmfundvalue).toString());

					Fundtable.put("FromFundValue_" + i, foo3);

					System.out.println(Fundtable.get("FromFundValue_" + i));

					/*
					 * } else {
					 * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
					 * 
					 * 
					 * 
					 * System.out.println(Fundtable.get("FromFundValue_"+i)); }
					 */

				} else {
					cnt = i - 1;
					if (cfundnumber >= 1) {
						int cfundcnt = 1;
						tofu = 1;
						// for (int j=2; j<FundTableTB.size();j++) {
						for (int j = 2; j < tbrow; j++) {

							String str = Web.getDriver()
									.findElement(By.xpath(
											"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
									.getText();
							System.out.println(str);
							if (str.equalsIgnoreCase("c")) {
								Cfund = true;

								Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
										+ j + "]/td[" + Topercent + "]/input")).click();
								// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
								Web.getDriver()
										.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
												+ "]/td[" + Topercent + "]/input"))
										.sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

								// if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
								if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
									// tofund
									String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
									Double amount = Double.parseDouble(splitamtf[0]);

									Double Tofundvalue = (amount / 100) * frmfundvalue;

									String toString = Double.toString(Tofundvalue);

									String too1 = toString.substring(0, (toString.lastIndexOf(".")));

									String too2 = toString.substring(toString.lastIndexOf("."),
											toString.lastIndexOf(".") + 3);

									too3 = too1 + too2;
									// tofund
									// Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
									// Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
									/*
									 * String toString = Double.toString(Tofundvalue);
									 * 
									 * 
									 * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
									 * 
									 * String too2 =toString.substring(toString.lastIndexOf("."),
									 * toString.lastIndexOf(".")+3);
									 * 
									 * String too3 = too1+too2;
									 */
									// Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
									// Fundtable.put("ToFundValue_"+tofu,new
									// DecimalFormat("##.##").format(Tofundvalue).toString());

									// Double amount = Double.parseDouble(splitamt[0]);

									// Double Tofundvalue = (amount/100)* frmfundvalue;

									Fundtable.put("ToFundValue_" + tofu, too3);

									Fundtable.put("ToFundNumer_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
													.getText());
									Fundtable.put("ToFundName_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
													.getText());
									Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
											"[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
													+ Fundtable.get("ToFundNumer_" + tofu) + "]",
											false);
									/*
									 * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
									 * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
									 */

									System.out.println(Fundtable.get("ToFundValue_" + tofu));
								}

								else {

									// Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
									System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

									Fundtable.put("ToFundValue_" + tofu,
											Stock.GetParameterValue("FTtransferTO" + tofu));
									System.out.println(Fundtable.get("ToFundValue_" + tofu));
									Fundtable.put("ToFundNumer_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
													.getText());
									Fundtable.put("ToFundName_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
													.getText());
									Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
											"[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
													+ Fundtable.get("ToFundNumer_" + tofu) + "]",
											false);
									/*
									 * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
									 * System.out.println(Fundtable.get("ToFundValue_"+cnt));
									 * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
									 * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
									 */
								}

								if (cfundcnt == cfundnumber) {
									cfundnumber = 0;
									if (Noncfundnumber >= 1) {
										i = multifundnumber;
									} else {
										i = (multifundnumber + 1);
									}
									break;
								} else {
									cfundcnt = cfundcnt + 1;
								}
								tofu = tofu + 1;
							}

						}

						if (Cfund) {
							System.out.println("Cfund Displayed");
						} else {
							System.out.println("No Cfund Displayed");
						}
					} else {

						// Fundtable.put("ToFundValue_"+tofu,too3);
						Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
								.click();
						Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
										+ Topercent + "]/input"))
								.sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

						Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
								.getText());
						Fundtable.put("ToFundName_" + cnt, Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
								.getText());
						// Fundtable.put("ToFundValue_"+cnt,
						// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

						if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
							String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
							Double amount = Double.parseDouble(splitvalue[0]);
							Double Tofundvalue = (amount) / 100 * frmfundvalue;

							String toString = Double.toString(Tofundvalue);

							String too1 = toString.substring(0, (toString.lastIndexOf(".")));

							String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

							too3 = too1 + too2;
							Fundtable.put("ToFundValue_" + cnt, too3);
							frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
							Reporter.logEvent(Status.INFO,
									"From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
									"[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
											+ Fundtable.get("ToFundNumer_" + cnt) + "]",
									false);

						} else {
							Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
							frmFundtotal = frmFundtotal
									+ Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
							Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
									"[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
											+ Fundtable.get("ToFundNumer_" + cnt) + "]",
									false);
						}

						System.out.println(i);
						System.out.println(Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
								.getText());
						System.out.println(Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
								.getText());
						System.out.println(Fundtable.get("ToFundValue_" + cnt));

						// Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
						// "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
						// ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
					}

				}

			}

		} else {

			System.out.println("Table has Less row number than required Fund numbers");
		}

		if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
			frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
		}

	}

//****************************************************************************************************************************	  
	
	public static void TransferfundNewContract() throws InterruptedException {

		try {
			Thread.sleep(2000);
		} catch (Exception e) {

		}

		// String multfund = Stock.getConfigParam("MultipleFund");

		int multifundnumber = Integer.parseInt(Stock.GetParameterValue("MultipleFund"));
		int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CffundTransfer"));
		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfundTransfer"));

		// int initialvalue;
		double frmfundvalue = 0;
		boolean Cfund = false;
		double frmfundtotpercentage = 0;
		String FromfundNumber = null;
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th")).size();
		int Frompercent = 0;
		int Topercent = 0;
		int valuehead = 0;
		String percentfrom = "From Percent";
		String dollarfrom = "From/Remaining Amount";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(percentfrom) || fud.equalsIgnoreCase(dollarfrom)) {
				Frompercent = i;
				break;
			}
		}
		String percentTo = "To Percent";
		String dollarTo = "To Amount";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(dollarTo) || fud.equalsIgnoreCase(percentTo)) {
				Topercent = i;
				break;
			}
		}

		String val = "Value";
		for (int i = 1; i <= num; i++) {
			String fud = Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
			if (fud.equalsIgnoreCase(val)) {
				valuehead = i;
				break;
			}
		}

		int cnt;
		int tofu = 0;
		String too3 = null;
		int tbrow = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr")).size();

		if (tbrow > multifundnumber) {
			for (int i = 1; i <= multifundnumber + 1; i++) {
				if (i == 1) {
					Fundtable.put("FundNumer_" + i,
							Web.getDriver()
									.findElement(
											By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
									.getText());
					Fundtable.put("FundName_" + i,
							Web.getDriver()
									.findElement(
											By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
									.getText());

					// String getvalue =
					// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
					FromfundNumber = Fundtable.get("FundNumer_" + i);
					Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
							.click();
					Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
							.sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

					Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
							"[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
					// Fundtable.put
					/*
					 * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
					 * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
					 */

					// String splitamt1 = splitamt[0].trim().toString();
					String fFundvalue;
					fFundvalue = Web.getDriver().findElement(By.xpath(
							"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span"))
							.getText();
					fFundvalue = fFundvalue.trim().toString();

					String[] delimit = fFundvalue.split("[$]");
					String arr1[] = null;
					if (delimit[1].contains(",")) {
						arr1 = delimit[1].split(",");

					}

					if (arr1.length > 0) {

						String foo = arr1[0];
						for (int a = 1; a < arr1.length; a++) {
							foo = foo + arr1[a];

						}
						fFundvalue = foo;
					} else {
						fFundvalue = delimit[1].trim().toString();
					}

					/// ********************************************

					if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
						String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

						// String splitamt1 = splitamt[0].trim().toString();

						double x = Double.parseDouble(splitamt[0]) / 100;
						// double y = Double.parseDouble(Delimit1.toString());
						double y = Double.parseDouble(fFundvalue);

						// y = Double.parseDouble(df2.format(fFundvalue));
						// double z = x * y;
						System.out.println(df2.format(y));

						frmfundvalue = x * y;

						// add percentage value

						String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

						frmFundtotal = x * Double.parseDouble(paymtAmount);

						// String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
						// String[] splitamttofund =
						// Stock.GetParameterValue("Ftfromtransfer").split("%");

						/*
						 * Double amount = Double.parseDouble(splitamt[0]);
						 * 
						 * 
						 * 
						 * Double Tofundvalue = (amount/100)* frmfundvalue;
						 */

						// Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
						// Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
						// *********************************************************************************************
						/*
						 * String toString = Double.toString(Tofundvalue);
						 * 
						 * 
						 * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
						 * 
						 * String too2 =toString.substring(toString.lastIndexOf("."),
						 * toString.lastIndexOf(".")+3);
						 * 
						 * too3 = too1+too2;
						 */
						// *********************************************************************************************

					} else {

						// String splitamt1 = splitamt[0].trim().toString();

						double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
						// double y = Double.parseDouble(Delimit1.toString());
						double y = Double.parseDouble(fFundvalue);

						// y = Double.parseDouble(df2.format(fFundvalue));
						// double z = x * y;
						System.out.println(df2.format(y));

						frmfundvalue = y - x;

						// Stock.GetParameterValue("Ftfromtransfer")
						// frmFundtotal = Double.parseDouble("PaymentAmount") -
						// Double.parseDouble("Ftfromtransfer");

						// add percentage value
					}

					System.out.println(frmfundvalue);
					// *********************************************
					frmfundvalue = Math.round(frmfundvalue * 100.0) / 100.0;
					String tostring = Double.toString(frmfundvalue);

					// Fundtable.put("FromFundValue_"+i,tostring);
					// Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
				//	String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

				//	String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

				//	String foo3 = foo1 + foo2;

					// Fundtable.put("FromFundValue_"+i,new
					// DecimalFormat("##.##").format(frmfundvalue).toString());

					Fundtable.put("FromFundValue_" + i, Common.trimspecialcharacter(tostring));

					System.out.println(Fundtable.get("FromFundValue_" + i));

					/*
					 * } else {
					 * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
					 * 
					 * 
					 * 
					 * System.out.println(Fundtable.get("FromFundValue_"+i)); }
					 */

				} else {
					cnt = i - 1;
					if (cfundnumber >= 1) {
						int cfundcnt = 1;
						tofu = 1;
						// for (int j=2; j<FundTableTB.size();j++) {
						for (int j = 2; j < tbrow; j++) {

							String str = Web.getDriver()
									.findElement(By.xpath(
											"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
									.getText();
							System.out.println(str);
							if (str.equalsIgnoreCase("c")) {
								Cfund = true;

								Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
										+ j + "]/td[" + Topercent + "]/input")).click();
								// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
								Web.getDriver()
										.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
												+ "]/td[" + Topercent + "]/input"))
										.sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

								// if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
								if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
									// tofund
									String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
									Double amount = Double.parseDouble(splitamtf[0]);

									Double Tofundvalue = (amount / 100) * frmfundvalue;

									String toString = Double.toString(Tofundvalue);

									String too1 = toString.substring(0, (toString.lastIndexOf(".")));

									String too2 = toString.substring(toString.lastIndexOf("."),
											toString.lastIndexOf(".") + 3);

									too3 = too1 + too2;
									// tofund
									// Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
									// Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
									/*
									 * String toString = Double.toString(Tofundvalue);
									 * 
									 * 
									 * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
									 * 
									 * String too2 =toString.substring(toString.lastIndexOf("."),
									 * toString.lastIndexOf(".")+3);
									 * 
									 * String too3 = too1+too2;
									 */
									// Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
									// Fundtable.put("ToFundValue_"+tofu,new
									// DecimalFormat("##.##").format(Tofundvalue).toString());

									// Double amount = Double.parseDouble(splitamt[0]);

									// Double Tofundvalue = (amount/100)* frmfundvalue;

									Fundtable.put("ToFundValue_" + tofu, too3);

									Fundtable.put("ToFundNumer_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
													.getText());
									Fundtable.put("ToFundName_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
													.getText());
									Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
											"[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
													+ Fundtable.get("ToFundNumer_" + tofu) + "]",
											false);
									/*
									 * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
									 * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
									 */

									System.out.println(Fundtable.get("ToFundValue_" + tofu));
								}

								else {

									// Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
									System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

									Fundtable.put("ToFundValue_" + tofu,
											Stock.GetParameterValue("FTtransferTO" + tofu));
									System.out.println(Fundtable.get("ToFundValue_" + tofu));
									Fundtable.put("ToFundNumer_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
													.getText());
									Fundtable.put("ToFundName_" + tofu,
											Web.getDriver().findElement(By.xpath(
													"//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
													.getText());
									Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
											"[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
													+ Fundtable.get("ToFundNumer_" + tofu) + "]",
											false);
									/*
									 * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
									 * System.out.println(Fundtable.get("ToFundValue_"+cnt));
									 * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
									 * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
									 * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
									 */
								}

								if (cfundcnt == cfundnumber) {
									cfundnumber = 0;
									if (Noncfundnumber >= 1) {
										i = multifundnumber;
									} else {
										i = (multifundnumber + 1);
									}
									break;
								} else {
									cfundcnt = cfundcnt + 1;
								}
								tofu = tofu + 1;
							}

						}

						if (Cfund) {
							System.out.println("Cfund Displayed");
						} else {
							System.out.println("No Cfund Displayed");
						}
					} else {

						// Fundtable.put("ToFundValue_"+tofu,too3);
						Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
								.click();
						Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
										+ Topercent + "]/input"))
								.sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

						Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
								.getText());
						Fundtable.put("ToFundName_" + cnt, Web.getDriver()
								.findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
								.getText());
						// Fundtable.put("ToFundValue_"+cnt,
						// Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

						if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
							String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
							Double amount = Double.parseDouble(splitvalue[0]);
							Double Tofundvalue = (amount) / 100 * frmfundvalue;

							String toString = Double.toString(Tofundvalue);

							String too1 = toString.substring(0, (toString.lastIndexOf(".")));

							String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

							too3 = too1 + too2;
							Fundtable.put("ToFundValue_" + cnt, too3);
							frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
							Reporter.logEvent(Status.INFO,
									"From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
									"[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
											+ Fundtable.get("ToFundNumer_" + cnt) + "]",
									false);

						} else {
							Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
							frmFundtotal = frmFundtotal
									+ Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
							Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
									"[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
											+ Fundtable.get("ToFundNumer_" + cnt) + "]",
									false);
						}

						System.out.println(i);
						System.out.println(Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
								.getText());
						System.out.println(Web.getDriver().findElement(By.xpath(
								"//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
								.getText());
						System.out.println(Fundtable.get("ToFundValue_" + cnt));

						// Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
						// "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
						// ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
					}

				}

			}

		} else {

			System.out.println("Table has Less row number than required Fund numbers");
		}

		if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
			frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
		}

	}

//****************************************************************************************************************************	
	/**
	 * Method is used in Fund Transfer test case to Verify the value in the
	 * valuation page
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */
	public static void ValuesTable() {

		@SuppressWarnings("unused")
		String FundNumber;
		@SuppressWarnings("unused")
		String FundName;
		@SuppressWarnings("unused")
		String Fundvalue;
		@SuppressWarnings("unused")
		String Tabledata;
		@SuppressWarnings("unused")
		Boolean passflag;
		int tbsize;
		double calculation = 0;
		double tableval = 0;
		double fundval = 0;
		// table[@id='mainform:ValuesFundVals']/tbody/tr
		tbsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr")).size();
		for (int j = 1; j <= Fundtable.size(); j++) {

			for (int i = 1; i <= tbsize; i++) {
				if (j == 1) {
					FundNumber = "FundNumer_" + j;
					FundName = "FundName_" + j;
					Fundvalue = "FromFundValue_" + j;
				} else {
					FundNumber = "ToFundNumer_" + (j - 1);
					FundName = "ToFundName_" + (j - 1);
					Fundvalue = "ToFundValue_" + (j - 1);
				}

				Tabledata = Web.getDriver()
						.findElement(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[1]"))
						.getText();

				if (Tabledata.equalsIgnoreCase(Fundtable.get(FundNumber))) {
					String tablevalue;
					tablevalue = Web.getDriver()
							.findElement(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[7]"))
							.getText();

					// Fundvalue = String.format( "%.2f", Fundvalue );

					String[] delimit = tablevalue.split("[$]");
					String arr1[] = null;
					if (delimit[1].contains(",")) {
						arr1 = delimit[1].split(",");

						// }

						// if (arr1.length >0 )
						// {

						String foo = arr1[0];
						for (int a = 1; a < arr1.length; a++) {
							foo = foo + arr1[a];

						}
						tablevalue = foo;
					} else {
						tablevalue = delimit[1].trim().toString();
					}

					/*
					 * if (tablevalue.equalsIgnoreCase(Fundtable.get(Fundvalue))) {
					 * Reporter.logEvent(Status.PASS,"For the Fund Number["
					 * +Tabledata+"] Expected  value  ["+Fundtable.get(Fundvalue)+" ]"
					 * ,"Vs Actual value [ " + tablevalue + " ]", false);
					 * //System.out.println("Pass"); passflag = true; }
					 */
					tableval = Double.parseDouble(tablevalue);
					fundval = Double.parseDouble(Fundtable.get(Fundvalue));

				//	if (tablevalue.equalsIgnoreCase(Fundtable.get(Fundvalue))) {
					if (tableval == fundval) {
						Reporter.logEvent(
								Status.PASS, "For the Fund Number[" + Tabledata + "] Expected  value  ["
										+ Fundtable.get(Fundvalue) + " ]",
								"Vs Actual value [ " + tableval + " ]", false);
						// Reporter.logEvent(Status.PASS,"Expected value ["+Fundtable.get(Fundvalue)+"
						// ]","Present in the Actual text [ " + tablevalue + " ]", false);
						// System.out.println("Pass");
						passflag = true;
					}

					else {
						if (tableval > fundval) {
							calculation = tableval - fundval;
						} else {
							calculation = fundval - tableval;
						}

						if (calculation > 0.001 && calculation < 0.02) {
							// System.out.println("Minor difference spotted with the range 0.01 = ["+
							// calculation+"]");
							// Reporter.logEvent(Status.PASS, "Table value ["+tablevalue+"]", "Expected
							// Value ["+Fundtable.get(Fundvalue)+"]", false);
							Reporter.logEvent(Status.PASS,
									"For the Fund Number[" + Tabledata + "] Expected  value  ["
											+ Fundtable.get(Fundvalue) + " ]",
									"Vs Actual value [ " + tableval + " ]", false);
							// Reporter.logEvent(Status.INFO, "Minor difference spotted", "in the range of
							// 0.01",false);
							// Reporter.logEvent(Status.PASS,"Expected value ["+tablevalue+" ]"," present in
							// the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");
							passflag = false;
						} else {
							// System.out.println("Table value and Expected value Differ by [ "+
							// calculation+"]");
							Reporter.logEvent(Status.FAIL,
									"For the Fund Number[" + Tabledata + "] Expected  value  ["
											+ Fundtable.get(Fundvalue) + " ]",
									"Vs Actual value [ " + tableval + " ]", false);
							// Reporter.logEvent(Status.FAIL,"Expected value ["+Fundtable.get(Fundvalue)+"
							// ]"," not present in the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");
							passflag = false;
						}

					}
					/*
					 * else {
					 * Reporter.logEvent(Status.FAIL,"Expected  value  ["+Fundtable.get(Fundvalue)
					 * +" ]"," not present in the Actual text [ " + tablevalue + " ]", false);
					 * System.out.println("Fail"); passflag = false; }
					 */
					break;
				}

			}
		}

	}

//****************************************************************************************************************************	   	
	/**
	 * Method is used to trim the Special character for the String
	 * 
	 * @author srdksn
	 * @param String
	 * @param
	 * @return value
	 */
	public static String trimspecialcharacter(String value) {

		if (value.contains("$")) {

			String[] delimit = value.split("[$]");
			String arr1[] = null;
			if (delimit[1].contains(",")) {
				arr1 = delimit[1].split(",");

			} else {
				value = delimit[1].trim().toString();
				return value;
			}

			if (arr1.length > 0) {

				String foo = arr1[0];
				for (int a = 1; a < arr1.length; a++) {
					foo = foo + arr1[a];

				}
				value = foo;
			} else {
				value = delimit[1].trim().toString();
			}

			// value = String.format( "%.2f", value );

			return value;

		} else {
			return value.trim();
		}
	}

	public static String trimspecialcharacterpercentage(String value) {

		if (value.contains("%")) {

			String[] delimit = value.split("[%]");
			String arr1[] = null;
			if (delimit[1].contains(",")) {
				arr1 = delimit[1].split(",");

			} else {
				value = delimit[1].trim().toString();
				return value;
			}

			if (arr1.length > 0) {

				String foo = arr1[0];
				for (int a = 1; a < arr1.length; a++) {
					foo = foo + arr1[a];

				}
				value = foo;
			} else {
				value = delimit[1].trim().toString();
			}

			// value = String.format( "%.2f", value );

			return value;

		} else {
			return value.trim();
		}
	}

//****************************************************************************************************************************	   	
	/**
	 * Method is used in History page to verify the Transaction
	 * 
	 * @author srdksn
	 * @param String
	 * @param
	 * @return
	 */

	public static void historytable(String col, String ExpText, String excpecteddate) {
		String excdate = excpecteddate;
		int column = 0;
		boolean psf = false;
		switch (col.toLowerCase())

		{
		case "trxcode":

			column = 2;
			break;

		case "effdate":
			column = 4;
			break;

		default:

			break;
		}

		int Rowcount = Web.getDriver()
				.findElements(By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr"))
				.size();

		for (int i = 1; i <= Rowcount; i++) {
			if (Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr["
							+ i + "]/td[" + column + "]"))
					.getText().equalsIgnoreCase(ExpText)
					&& Web.getDriver()
							.findElement(
									By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr["
											+ i + "]/td[" + 4 + "]"))
							.getText().trim().equalsIgnoreCase(excdate.trim())) {
				Reporter.logEvent(Status.PASS, "Transaction Table: Expected ext [" + ExpText + "]",
						"Vs Actual value [ " + ExpText + " ]", false);
				psf = true;
				break;
			}
			/*
			 * else {
			 * Reporter.logEvent(Status.FAIL,"Transaction Table: Expected ext ["+ExpText+
			 * "]","Vs Actual value [ " + ExpText + " ]", false); }
			 */
		}
		if (!psf) {
			Reporter.logEvent(Status.FAIL, "Transaction Table: Expected ext [" + ExpText + "]",
					"Vs Actual value [ " + ExpText + " ]", false);
		}
	}

//****************************************************************************************************************************   	
	public static void NOTinhistorytable(String col, String ExpText, String excpecteddate) {
		String excdate = excpecteddate;
		int column = 0;
		boolean psf = false;
		switch (col.toLowerCase())

		{
		case "trxcode":

			column = 2;
			break;

		case "effdate":
			column = 4;
			break;

		default:

			break;
		}

		int Rowcount = Web.getDriver()
				.findElements(By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr"))
				.size();

		for (int i = 1; i <= Rowcount; i++) {
			if (Web.getDriver()
					.findElement(By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr["
							+ i + "]/td[" + column + "]"))
					.getText().equalsIgnoreCase(ExpText)
					&& Web.getDriver()
							.findElement(
									By.xpath("//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr["
											+ i + "]/td[" + 4 + "]"))
							.getText().trim().equalsIgnoreCase(excdate.trim())) {
				Reporter.logEvent(Status.FAIL, "Transaction Table: Expected ext [" + ExpText + "]",
						"Vs Actual value [ " + ExpText + " ]", false);
				psf = true;
				break;
			}
			/*
			 * else {
			 * Reporter.logEvent(Status.FAIL,"Transaction Table: Expected ext ["+ExpText+
			 * "]","Vs Actual value [ " + ExpText + " ]", false); }
			 */
		}
		if (!psf) {
			Reporter.logEvent(Status.PASS, "Transaction Table: Expected ext [" + ExpText + "]",
					"Vs Not Presented in the transaction", false);
		}
	}

	/**
	 * Method is used in GW_Disbursement test case to verify value after the
	 * transaction done (SW)
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */

	public static void ValuesTableDisbursement() {
		try {
			double calculation = 0;
			Thread.sleep(10000);
			Web.waitForElement(DisbursementTab);
			// System.out.println(DisbursementTab.getText());
			String value = Web.getDriver()
					.findElement(By.xpath("//span[@id='mainform:ValuesFundVals:0:valuesValuesFundValsFundValue']"))
					.getText();

			String valuetb = trimspecialcharacter(value);
			Double.parseDouble(Disbursementtable.get("FundValue"));

			if (Double.parseDouble(Disbursementtable.get("FundValue")) == Double.parseDouble(valuetb)) {
				Reporter.logEvent(Status.PASS,
						"Transaction Table: Expected Value  [$" + Disbursementtable.get("FundValue") + "]",
						"Vs Actual value [$ " + valuetb + " ]", false);
				
			} /*else {
				Reporter.logEvent(Status.FAIL,
						"Transaction Table: Expected Value  [$" + Disbursementtable.get("FundValue") + "]",
						"Vs Actual value [$ " + valuetb + " ]", false);
			}*/
			//*****************code for .5 difference *****
			else if (Double.parseDouble(valuetb) > Double.parseDouble(Disbursementtable.get("FundValue"))) {
				calculation = Double.parseDouble(valuetb) - Double.parseDouble(Disbursementtable.get("FundValue"));
				calculation = Math.round(calculation * 100.0) / 100.0;
			} else {
				calculation = Double.parseDouble(Disbursementtable.get("FundValue")) - Double.parseDouble(valuetb);
				calculation = Math.round(calculation * 100.0) / 100.0;
			}
			if (calculation >= 0.01 && calculation < 0.02 || calculation == 0.0) {
			
				Reporter.logEvent(Status.PASS,
						"Transaction Table: Expected Value  [$" + Disbursementtable.get("FundValue") + "]",
						"Vs Actual value [$ " + valuetb + " ]", false);
			//	Reporter.logEvent(Status.INFO, "Minor difference spotted", "in the range of 0.01", false);
			} else {		
				Reporter.logEvent(Status.FAIL,
						"Transaction Table: Expected Value  [$" + Disbursementtable.get("FundValue") + "]",
						"Vs Actual value [$ " + valuetb + " ]", false);
			}
		} catch (Exception e) {
			Reporter.logEvent(Status.FAIL, "Exception", "Vs Actual value [$ " + e + " ]", false);
		}

	}

//****************************************************************************************************************************

	public static void valuesTableInitialValues_PROratainvestmentonly() {
		try {
			Thread.sleep(3500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			int valuesTBsize = 0;
			Double surrendper;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			String Acumvalue;
			Double Noncfvalue;
			Double Newvalue;
			String Per = "Percent";
			String Amt = "Amount";
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							GawFundPRC.put(Tabledata, tablevalue);
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							if (!pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText().isEmpty()) {
								cashvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							} else {
								cashvalue = Common
										.trimspecialcharacter(pageobjects.wmA.Value.Value.EWCoveredfundvalue.getText());
							}
							if (Stock.GetParameterValue("TransactionType").equalsIgnoreCase(Amt)) {
								Acumvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
								Noncfvalue = Double.parseDouble(Acumvalue) - Double.parseDouble(cashvalue);								
								percentage = (Double.parseDouble(tablevalue) / Noncfvalue);
								Newvalue = Double.parseDouble(Stock.GetParameterValue("SurrenderAmount")) * percentage;
								Newvalue = Math.round(Newvalue * 100.00) / 100.0;
								Newvalue = Double.parseDouble(tablevalue) - Newvalue;
								Newvalue = Math.round(Newvalue * 100.00) / 100.0;
								GawFundPRC.put(Tabledata, Newvalue.toString());
							} else if (Stock.GetParameterValue("TransactionType").equalsIgnoreCase(Per)) {
								Acumvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
								Noncfvalue = Double.parseDouble(Acumvalue) - Double.parseDouble(cashvalue);
								surrendper = Noncfvalue
										* Double.parseDouble(Stock.GetParameterValue("SurrenderPercent"));
								surrendper = surrendper/100;
								percentage = (Double.parseDouble(tablevalue) / Noncfvalue);
								Newvalue = surrendper * percentage;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								Newvalue = Double.parseDouble(tablevalue) - Newvalue;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, Newvalue.toString());
							}

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
	public static void valuesTableInitialValues_PROratainvestmentonly_ContractId() {
		try {
			Thread.sleep(3500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {

			int valuesTBsize = 0;
			Double surrendper;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			String Acumvalue;
			Double Noncfvalue;
			Double Newvalue;
			String Per = "Percent";
			String Amt = "Amount";
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							GawFundPRC.put(Tabledata, tablevalue);
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							if (!pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText().isEmpty()) {
								cashvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							} else {
								cashvalue = Common
										.trimspecialcharacter(pageobjects.wmA.Value.Value.EWCoveredfundvalue.getText());
							}
							if (System.getProperty("TrxType").equalsIgnoreCase(Amt)) {
								Acumvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
								Noncfvalue = Double.parseDouble(Acumvalue) - Double.parseDouble(cashvalue);
								percentage = (Double.parseDouble(tablevalue) / Noncfvalue);
								Newvalue = Double.parseDouble(System.getProperty("PSurrenderValue")) * percentage;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								Newvalue = Double.parseDouble(tablevalue) - Newvalue;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, Newvalue.toString());
							} else if (System.getProperty("TrxType").equalsIgnoreCase(Per)) {
								Acumvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
								Noncfvalue = Double.parseDouble(Acumvalue) - Double.parseDouble(cashvalue);
								surrendper = Noncfvalue
										* Double.parseDouble(System.getProperty("PSurrenderValue"));
								surrendper = surrendper/100;
								percentage = (Double.parseDouble(tablevalue) / Noncfvalue);
								Newvalue = surrendper * percentage;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								Newvalue = Double.parseDouble(tablevalue) - Newvalue;
								Newvalue = Math.round(Newvalue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, Newvalue.toString());
							}

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************	   	
	/**
	 * Method is used in GAW Payout to store the value before transaction
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */

	public static void valuesTableInitial_Values() {

		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							if (lWrider != null) {
								cashvalue = Common.trimspecialcharacter(
										pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							} else {
								cashvalue = Common
										.trimspecialcharacter(pageobjects.wmA.Value.Value.EWCoveredfundvalue.getText());
							}

							/*
							 * percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue))
							 * * 100; percentage = Math.round(percentage * 100.0) / 100.0;
							 */
							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));

							GawFundPRC.put(Tabledata, percentage.toString());
							break;

						}
					}

				}

			}

			/*
			 * if (NonCFund.size() >=1 ) { for(int i =1; i<=NonCFund.size(); i++) { for(int
			 * j =1; j<=valuesTBsize; j++) { Tabledata =
			 * Web.getDriver().findElement(By.xpath(
			 * "//table[@id='mainform:ValuesFundVals']/tbody/tr["+j+"]/td[1]")).getText();
			 * if (NonCFund.get("NonNCFund"+i).equalsIgnoreCase(Tabledata)) { tablevalue
			 * =Web.getDriver().findElement(By.xpath(
			 * "//table[@id='mainform:ValuesFundVals']/tbody/tr["+j+"]/td[7]")).getText();
			 * GawFundOLD.put(Tabledata, tablevalue); tablevalue =
			 * Common.trimspecialcharacter(tablevalue);
			 * 
			 * if (!pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText().isEmpty())
			 * { cashvalue = Common.trimspecialcharacter(pageobjects.wmA.Value.Value.
			 * BenefitCoveredFundValue.getText()); } else { cashvalue =
			 * Common.trimspecialcharacter(pageobjects.wmA.Value.Value.EWCoveredfundvalue.
			 * getText()); }
			 * 
			 * percentage = (Double.parseDouble(tablevalue) /
			 * Double.parseDouble(cashvalue)); //Newvalue = Math.round(Newvalue * 100.0) /
			 * 100.0; GawFundPRC.put(Tabledata, percentage.toString());
			 * 
			 * 
			 * } }
			 * 
			 * }
			 * 
			 * }
			 */
		} catch (Exception e) {
			System.out.println(e);
		}
	}
//****************************************************************************************************************************

	/**
	 * Method is used in Asset rebalance test case to Verify the fund value before
	 * transaction
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */

	public static void valuesTableInitial_AssetRebalance_CFandNCF() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;
			String Coveredcashvalue;

			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {

					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							/*cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							Percent = Stock.GetParameterValue("Assetrebalance_percent");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = percentage;*/
							GawFundPRC.put(Tabledata, tablevalue);
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {

					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							// Percent = Stock.GetParameterValue("Assetrebalance_percent");
							Coveredcashvalue =Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// updated by srid
							Percent = RBFundPRC.get("NonNCFund" + i);
							// *****************************
							Percent = Common.trimspecialcharacter(Percent);
							percentage =Double.parseDouble(cashvalue)-Double.parseDouble(Coveredcashvalue);
							percentage = percentage * Double.parseDouble(Percent);
							percentage = percentage / 100;
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Newvalue = percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// ****************************************************************************************************************************
	public static void valuesTableInitial_AssetRebalancewithAllocationChange_CFandNCF() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;

			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {

					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							Percent = Stock.GetParameterValue("Assetrebalance_percent");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = percentage;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {

					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Stock.GetParameterValue("PremiumAdditonal");
							// Percent = Stock.GetParameterValue("Assetrebalance_percent");

							// updated by srid
							Percent = RBFundPRC.get("NonNCFund" + i);
							// *****************************
							Percent = Common.trimspecialcharacter(Percent);
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Newvalue = percentage + Double.parseDouble(tablevalue);
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************	
	/**
	 * Method is used in Allocation change test case to Verify the fund value before
	 * transaction
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */

	public static void valuesTableInitial_AllocationChange_CFandNCF() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;
			int cnt;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Stock.GetParameterValue("PremiumAdditonal");
							Percent = Stock.GetParameterValue("Allocation" + cnt);
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = Double.parseDouble(tablevalue) + percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Stock.GetParameterValue("PremiumAdditonal");
							Percent = Stock.GetParameterValue("Allocation" + cnt);
							Percent = Common.trimspecialcharacter(Percent);
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Newvalue = Double.parseDouble(tablevalue) + percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
//****************************************************************************************************************************
	public static void valuesTableInitial_AllocationChange_CFandNCF_EContract() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;
			int cnt;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = System.getProperty("PaymentAmount");
							Percent = Common.CovFundinfo.get("CovFundPercent" + cnt);
							Percent = Percent.replaceAll("%", "");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = Double.parseDouble(tablevalue) + percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = System.getProperty("PaymentAmount");
							Percent = Common.NonCFundinfo.get("NonNCPercent" + cnt);
							Percent = Percent.replaceAll("%", "");
							Percent = Common.trimspecialcharacter(Percent);
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Newvalue = Double.parseDouble(tablevalue) + percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());

						}
						
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
//****************************************************************************************************************************

	public static void valuesTableInitial_Assetrebalance_CFandNCF_EContract() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Coveredcashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;
			int cnt;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							/*cashvalue = Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							Percent = Common.CovFundinfo.get("CovPercet" + cnt);
							Percent = Percent.replaceAll("%", "");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = Double.parseDouble(tablevalue) + percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;*/
							GawFundPRC.put(Tabledata, tablevalue);
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							Coveredcashvalue =Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							cashvalue = Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							
							Percent = Common.NonCFundinfo.get("NonCovPercet" + cnt);
							Percent = Percent.replaceAll("%", "");
							Percent = Common.trimspecialcharacter(Percent);
							percentage =  Double.parseDouble(cashvalue) - Double.parseDouble(Coveredcashvalue);
							percentage = percentage * Double.parseDouble(Percent);
							percentage = percentage / 100;
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Newvalue = percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, Newvalue.toString());

						}
						
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
//****************************************************************************************************************************
	/**
	 * Method is used in ILAV Partial Surrender test case to Verify the fund value before
	 * transaction
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */

	public static void valuesTableInitial_ILVAPartialSurrender() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			String Percent;
			Double percentage;
			Double Newvalue;
			int cnt;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Stock.GetParameterValue("SurrenderAmt");
							Percent = Stock.GetParameterValue("GROWTHINV");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = Double.parseDouble(tablevalue) - percentage;
							GawFundPRC.put(Tabledata, Newvalue.toString());
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							cashvalue = Stock.GetParameterValue("SurrenderAmt");
							Percent = Stock.GetParameterValue("GROWTHINV");
							percentage = Double.parseDouble(cashvalue) * Double.parseDouble(Percent);
							percentage = percentage / 100;
							Newvalue = Double.parseDouble(tablevalue) - percentage;
							GawFundPRC.put(Tabledata, Newvalue.toString());

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
//****************************************************************************************************************************
	public static void CAvaluesTableInitial() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;			
			int cnt;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {

						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);
							
							
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					cnt = i;
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);
							

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************
	/**
	 * Method is used in RMD payout test case to Verify the fund value before
	 * transaction
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */
	public static void valuesTableInitial_Values_RMD_CFandNCF() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}
			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());

							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));

							GawFundPRC.put(Tabledata, percentage.toString());
							break;

						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());

							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));
							// Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							GawFundPRC.put(Tabledata, percentage.toString());

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************	
	/**
	 * Method is used in GAW payout test case to Verify the GAW amount before the
	 * transaction
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */
	public static void Calculate_GawmaxFundSpecific() {

		try {

			String Gawlimit = Disbursementtable.get("MaxGaw");
			String GawpaymentMode = Stock.GetParameterValue("Paymentmode");
			int paymode = 0;
			double GawAmnt = 0;
			double GawamntforFund = 0;
			double GawamnttobeDeductedFund = 0;
			double Newvalue = 0;
			double Gawmax = 0;
			double Gawfrequency = 0;

			if (GawpaymentMode.equalsIgnoreCase("monthly")) {
				paymode = 12;
			} else if (GawpaymentMode.equalsIgnoreCase("quarterly")) {
				paymode = 4;
			} else if (GawpaymentMode.equalsIgnoreCase("annual")) {
				paymode = 1;
			}

			Gawmax = Double.parseDouble(Gawlimit);
			// Gawmax = Math.round(Gawmax * 100.0) / 100.0;

			// GawAmnt = Double.parseDouble(Gawlimit) / paymode;
			Gawfrequency = Gawmax / paymode;
			Gawfrequency = Math.round(Gawfrequency * 100.0) / 100.0;

			for (String key : GawFundPRC.keySet()) {
				String oldvalue = GawFundOLD.get(key);
				oldvalue = trimspecialcharacter(oldvalue);
				String temp = GawFundPRC.get(key);
				// new
				GawAmnt = Gawfrequency * Double.parseDouble(temp);

				// GawamntforFund = Double.parseDouble(temp)/100 * GawAmnt; **old

				// new
				GawAmnt = Math.round(GawAmnt * 100.0) / 100.0;
				// GawamnttobeDeductedFund = GawAmnt - GawamntforFund; **old
				Newvalue = Double.parseDouble(oldvalue) - GawAmnt;// GawamnttobeDeductedFund;

				Newvalue = Math.round(Newvalue * 100.0) / 100.0;
				GawFundNEW.put(key, Double.toString(Newvalue));

				// System.out.println( key );
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}

//****************************************************************************************************************************	
	/**
	 * Method is used in RMD payout test case to Verify the RMD Amount before the
	 * Transaction in RMD Quote page
	 * 
	 * @author srdksn
	 * @param
	 * @param
	 * @return
	 */
	public static void RMDCalculation() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			String RmdGrossVal = RMDGrossvalue;
			// String ContractDate = Stock.GetParameterValue("EffectiveDate").trim();
			String EffectiveDate = Stock.GetParameterValue("EffectiveDate_sys").trim();
			int RMDInterval;
			double RMD = 0.0;
			double RMDQuarter = 3;
			double rmdclc;
			String RMDPaymentmode;
			String[] delimit = EffectiveDate.split("/");
			String splitvalue = delimit[2];
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate YearEndDate = LocalDate.parse("12/31/" + splitvalue, dateTimeFormatter);
			LocalDate EEffectiveDate = LocalDate.parse(EffectiveDate, dateTimeFormatter);

			// Period p = Period.between(YearEndDate, EEffectiveDate);
			Period p = Period.between(EEffectiveDate, YearEndDate);

			RMDPaymentmode = Stock.GetParameterValue("Paymentmode").trim();
			RMDInterval = (p.getMonths()) + 1;
			// System.out.println(Math.ceil(a))
			if (RMDPaymentmode.equalsIgnoreCase("monthly")) {
				RMD = Double.parseDouble(RmdGrossVal) / RMDInterval;
				// RMD = Math.ceil(RMD);

				RMD = Math.round(RMD * 100.0) / 100.0;
			} else if (RMDPaymentmode.equalsIgnoreCase("quarterly")) {
				RMDQuarter = Math.ceil(RMDQuarter);
				rmdclc = RMDInterval / RMDQuarter;
				rmdclc = Math.ceil(rmdclc);
				RMD = Double.parseDouble(RmdGrossVal) / rmdclc;
				RMD = Math.round(RMD * 100.0) / 100.0;
			} else if (RMDPaymentmode.equalsIgnoreCase("annual")) {
				RMD = Double.parseDouble(RmdGrossVal);
				/// RMD = Math.ceil(RMD);
				RMD = Math.round(RMD * 100.0) / 100.0;
			}
			GawFundNEW.put("RMDMonthlyvalue",Double.toString(RMD) );
			// Covered fund 1 - 1666.67 (2000/6000 * 100 = 0.33; 0.33*1000 = 333.33;
			// 2000-333.33 = 1666.67)
			double RMDNew;
			double Newvalue;
			for (String key : GawFundPRC.keySet()) {
				String oldvalue = GawFundOLD.get(key);
				oldvalue = trimspecialcharacter(oldvalue);
				String temp = GawFundPRC.get(key);
				// new
				RMDNew = RMD * Double.parseDouble(temp);

				// GawamntforFund = Double.parseDouble(temp)/100 * GawAmnt; **old

				// new
				RMDNew = Math.round(RMDNew * 100.0) / 100.0;
				// GawamnttobeDeductedFund = GawAmnt - GawamntforFund; **old
				Newvalue = Double.parseDouble(oldvalue) - RMDNew;// GawamnttobeDeductedFund;

				Newvalue = Math.round(Newvalue * 100.0) / 100.0;
				GawFundNEW.put(key, Double.toString(Newvalue));

				// System.out.println( key );
			}

		} catch (Exception e) {

		}

	}

//****************************************************************************************************************************
	/**
	 * Method is used in Allocation Change test case to Verify the fund value after
	 * the transaction
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */
	public static void VerifyFundAllocationChange() {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {
			String tablevalue;
			double calculation = 0;
			int valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}

			for (String key : GawFundPRC.keySet()) {

				String temp = GawFundPRC.get(key);
				for (int i = 1; i <= valuesTBsize; i++) {
					if (Web.getDriver()
							.findElement(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[1]"))
							.getText().trim().equalsIgnoreCase(key)) {
						tablevalue = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[7]"))
								.getText();
						tablevalue = trimspecialcharacter(tablevalue);
						if (Double.parseDouble(temp) == Double.parseDouble(tablevalue)) {
							System.out.println(
									"Values Table for the Fund [" + key + "] is [" + Double.parseDouble(tablevalue)
											+ "] matching with expected value [" + Double.parseDouble(temp) + "]");
							Reporter.logEvent(Status.PASS, "For the Fund number [" + key + "]",
									" Table values displayed correctly", false);
							Reporter.logEvent(Status.INFO,
									"Values Table for the Fund [" + key + "] is [" + Double.parseDouble(tablevalue) + "]",
									"matching with expected value [" + Double.parseDouble(temp) + "]", false);
							break;
						}
						/*
						 * else {
						 * Reporter.logEvent(Status.FAIL,"Values Table["+Double.parseDouble(tablevalue)+
						 * "]", "Not matching with expected value ["+Double.parseDouble(temp)+"]",
						 * false); break; }
						 */
						if (Double.parseDouble(temp) > Double.parseDouble(tablevalue)) {
							calculation = Double.parseDouble(temp) - Double.parseDouble(tablevalue);
							calculation = Math.round(calculation * 100.0) / 100.0;
						} else {
							calculation = Double.parseDouble(tablevalue) - Double.parseDouble(temp);
							calculation = Math.round(calculation * 100.0) / 100.0;
						}

						if (calculation >= 0.01 && calculation < 0.02) {
							// System.out.println("Minor difference spotted with the range 0.01 = ["+
							// calculation+"]");
							// Reporter.logEvent(Status.PASS, "Table value ["+tablevalue+"]", "Expected
							// Value ["+Fundtable.get(Fundvalue)+"]", false);
							Reporter.logEvent(Status.PASS,
									"For the Fund Number[" + key + "] Expected  value  [" + temp + " ]",
									"Vs Actual value [ " + temp + " ]", false);
							// Reporter.logEvent(Status.INFO, "Minor difference spotted", "in the range of
							// 0.01",false);
							// Reporter.logEvent(Status.PASS,"Expected value ["+tablevalue+" ]"," present in
							// the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");
							break;

						} else {
							// System.out.println("Table value and Expected value Differ by [ "+
							// calculation+"]");
							Reporter.logEvent(Status.FAIL, "For the Fund number [" + key + "]",
									" Table values are not displayed correctly", false);
							Reporter.logEvent(Status.INFO,
									"For the Fund Number[" + key + "] Expected  value  [" + temp + " ]",
									"Vs Actual value [ " + tablevalue + " ]", false);
							// Reporter.logEvent(Status.FAIL,"Expected value ["+Fundtable.get(Fundvalue)+"
							// ]"," not present in the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");

						}
						break;
					}
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************	

	// This is to validate the fund value information in the Values Table
	/**
	 * Method is used in GAW and RMD test case to Verify the fund value after the
	 * transaction
	 * 
	 * @author blsbrm
	 * @param
	 * @param
	 * @return
	 */
	public static void VerifyFundTableValues() {
		try {
			Thread.sleep(10000);
		} catch (Exception e) {

		}
		try {

			String tablevalue;
			double calculation = 0;
			int valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}

			// Double.parseDouble(Disbursementtable.get("FundValue"));

			for (String key : GawFundNEW.keySet()) {

				String temp = GawFundNEW.get(key);
				Double.parseDouble(temp);

				for (int i = 1; i <= valuesTBsize; i++) {
					if (Web.getDriver()
							.findElement(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[1]"))
							.getText().trim().equalsIgnoreCase(key)) {
						tablevalue = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + i + "]/td[7]"))
								.getText();
						tablevalue = trimspecialcharacter(tablevalue);
						if (Double.parseDouble(temp) == Double.parseDouble(tablevalue)) {
							System.out.println(
									"Values Table for the Fund [" + key + "] is" + Double.parseDouble(tablevalue)
											+ "] matching with expected value [" + Double.parseDouble(temp) + "]");
							Reporter.logEvent(Status.PASS, "For the Fund number [" + key + "]",
									" Table values displayed correctly", false);
							Reporter.logEvent(Status.INFO,
									"Values Table for the Fund [" + key + "] is" + Double.parseDouble(tablevalue) + "]",
									"matching with expected value [" + Double.parseDouble(temp) + "]", false);
							break;
						}
						/*
						 * else {
						 * Reporter.logEvent(Status.FAIL,"Values Table["+Double.parseDouble(tablevalue)+
						 * "]", "Not matching with expected value ["+Double.parseDouble(temp)+"]",
						 * false); break; }
						 */
						if (Double.parseDouble(temp) > Double.parseDouble(tablevalue)) {
							calculation = Double.parseDouble(temp) - Double.parseDouble(tablevalue);
							calculation = Math.round(calculation * 100.0) / 100.0;
						} else {
							calculation = Double.parseDouble(tablevalue) - Double.parseDouble(temp);
							calculation = Math.round(calculation * 100.0) / 100.0;
						}

						if (calculation >= 0.01 && calculation < 0.02) {
							// System.out.println("Minor difference spotted with the range 0.01 = ["+
							// calculation+"]");
							// Reporter.logEvent(Status.PASS, "Table value ["+tablevalue+"]", "Expected
							// Value ["+Fundtable.get(Fundvalue)+"]", false);
							Reporter.logEvent(Status.PASS,
									"For the Fund Number[" + key + "] Expected  value  [" + temp + " ]",
									"Vs Actual value [ " + tablevalue + " ]", false);
							Reporter.logEvent(Status.INFO, "Minor difference spotted", "in the range of 0.01", false);
							// Reporter.logEvent(Status.PASS,"Expected value ["+tablevalue+" ]"," present in
							// the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");
							break;

						} else {
							// System.out.println("Table value and Expected value Differ by [ "+
							// calculation+"]");
							Reporter.logEvent(Status.FAIL, "For the Fund number [" + key + "]",
									" Table values are not displayed correctly", false);
							Reporter.logEvent(Status.INFO,
									"For the Fund Number[" + key + "] Expected  value  [" + temp + " ]",
									"Vs Actual value [ " + tablevalue + " ]", false);
							// Reporter.logEvent(Status.FAIL,"Expected value ["+Fundtable.get(Fundvalue)+"
							// ]"," not present in the Actual text [ " + tablevalue + " ]", false);
							// System.out.println("Fail");

						}
						break;
					}
				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

//****************************************************************************************************************************
	// This is to validate the fund value information in the Values Table
	/**
	 * Method is used in Partial Surrender for pro rata basis only test case to
	 * Initialize the fund value before the transaction
	 * 
	 * @author Anjali
	 * @param
	 * @param
	 * @return
	 */
	public static void valuesTableInitial_Values_ProRateBasis_CFandNCF(String proRatAbasistype) {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			String percent = "Surrender Percent:";
			String Amt = "Amount";
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			Double Dedecuttedamount;
			Double NewFundValue;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}

			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));

							if (proRatAbasistype.equalsIgnoreCase(Amt)) {

								Dedecuttedamount = percentage
										* Double.parseDouble(Stock.GetParameterValue("SurrenderAmt"));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;

								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

							else {
								Dedecuttedamount = percentage
										* ((Double.parseDouble(Stock.GetParameterValue("SurrenderPer")) / 100)
												* Double.parseDouble(cashvalue));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}
						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());

							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));
							if (proRatAbasistype.equalsIgnoreCase(Amt)) {

								Dedecuttedamount = percentage
										* Double.parseDouble(Stock.GetParameterValue("SurrenderAmt"));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;

								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

							else {
								Dedecuttedamount = percentage
										* ((Double.parseDouble(Stock.GetParameterValue("SurrenderPer")) / 100)
												* Double.parseDouble(cashvalue));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void valuesTableInitial_Values_ProRateBasis_CFandNCF_ContractID(String proRatAbasistype) {
		try {
			Thread.sleep(5000);
		} catch (Exception e) {

		}
		try {

			int valuesTBsize = 0;
			
			String percent = "Percent";
			String Amt = "Amount";
			String Tabledata;
			String tablevalue;
			String cashvalue;
			Double percentage;
			Double Dedecuttedamount;
			Double NewFundValue;
			valuesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr"))
					.size();
			if (valuesTBsize < 1) {
				Reporter.logEvent(Status.FAIL, "Values Table", " [Empty] ", false);
				return;
			}

			if (CovFund.size() >= 1) {
				for (int i = 1; i <= CovFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (CovFund.get("CovFundNumb" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							tablevalue = Common.trimspecialcharacter(tablevalue);
							GawFundOLD.put(Tabledata, tablevalue);

							// cashvalue =
							// Common.trimspecialcharacter(pageobjects.wmA.Value.Value.BenefitCoveredFundValue.getText());
							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());
							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));

							if (proRatAbasistype.equalsIgnoreCase(Amt)) {

								Dedecuttedamount = percentage
										* Double.parseDouble(System.getProperty("PSurrenderValue"));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;

								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

							else {
								Dedecuttedamount = percentage
										* ((Double.parseDouble(System.getProperty("PSurrenderValue")) / 100)
												* Double.parseDouble(cashvalue));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}
						}
					}

				}

			}

			if (NonCFund.size() >= 1) {
				for (int i = 1; i <= NonCFund.size(); i++) {
					for (int j = 1; j <= valuesTBsize; j++) {
						Tabledata = Web.getDriver()
								.findElement(
										By.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[1]"))
								.getText();
						if (NonCFund.get("NonNCFund" + i).equalsIgnoreCase(Tabledata)) {
							tablevalue = Web.getDriver()
									.findElement(By
											.xpath("//table[@id='mainform:ValuesFundVals']/tbody/tr[" + j + "]/td[7]"))
									.getText();
							GawFundOLD.put(Tabledata, tablevalue);
							tablevalue = Common.trimspecialcharacter(tablevalue);

							cashvalue = Common
									.trimspecialcharacter(pageobjects.wmA.Value.Value.AccumulatedCashValue.getText());

							percentage = (Double.parseDouble(tablevalue) / Double.parseDouble(cashvalue));
							if (proRatAbasistype.equalsIgnoreCase(Amt)) {

								Dedecuttedamount = percentage
										* Double.parseDouble(System.getProperty("PSurrenderValue"));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;

								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

							else {
								Dedecuttedamount = percentage
										* ((Double.parseDouble(System.getProperty("PSurrenderValue")) / 100)
												* Double.parseDouble(cashvalue));
								NewFundValue = (Double.parseDouble(tablevalue) - Dedecuttedamount);
								NewFundValue = Math.round(NewFundValue * 100.0) / 100.0;
								GawFundPRC.put(Tabledata, NewFundValue.toString());
								break;
							}

						}
					}

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void CreateContractAdd() throws Exception {
		try {
		
		LandingPage landing = new LandingPage();
		SelectPartner sp = new SelectPartner(landing);
		sp.get();
		Reporter.logEvent(Status.INFO, "Home Page", "page is Loaded", true);
		Web.clickOnElement(sp, "accumulationlink");

		/**
		 * Step 2 -Select a partner that is available to sell the Smart Track II 5 Year
		 * product and click Next. Partner is successfully selected and Select Criteria
		 * Page is loaded
		 * 
		 */
		sp.selectpartner(Stock.GetParameterValue("SelectPartner"));
		Reporter.logEvent(Status.INFO, "Select Partner", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 3 - Enter an effective date which should match the current system date
		 * in the envrionment. Step 4 - Select Variable from the Product field. Step 5 -
		 * Select a non-NY state from the Issue State drop-down box and click next .
		 */
		SelectCriteria sc = new SelectCriteria(sp);
		sc.get();
		sc.EnterSelectCriteriaInfo(Stock.GetParameterValue("EffectiveDate"), Stock.GetParameterValue("IssueState"));
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 6 - Select Base Plan from the drop-down Step 7 - Select Statutory
		 * Company - GWA from the drop-down Step 8 - Select any Line of Business from
		 * column
		 * 
		 * .
		 */
		SelectPlan pln = new SelectPlan(sc);
		pln.get();
		pln.EnterSelectPlanEntries(Stock.GetParameterValue("BasePlan"), Stock.GetParameterValue("StatutoryCompany"),
				Stock.GetParameterValue("LineofBusiness"), Stock.GetParameterValue("IssueState"));
	//	Web.clickOnElement(pln, "ClickOnriderbox");
		Web.clickOnElement(pln, "ClickOnCashCheckbox");
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 9 - Click on Party Search and search for an advisor to add onto the
		 * contract. Step 10 - Select Role/Type: Advisor from the drop down Step 11 -
		 * Enter First Year % and Renewal % and click Next .
		 */

		ProducerInfo pi = new ProducerInfo(pln);
		pi.get();
		pi.setLastname(Stock.GetParameterValue("ProducerInfo_Lname"));
		Web.clickOnElement(pi, "Producerinfo_Clickonpartysearch");
		Common.switchto_newwindow();
		Web.clickOnElement(pi, "Producerinfo_Select1strowparty");
		Web.clickOnElement(pi, "Producerinfo_ClickonOkbtn");
		Common.switchto_mainwindow();
		pi.ProfileInfoEntries(Stock.GetParameterValue("Roletype"), Stock.GetParameterValue("Profile"),
				Stock.GetParameterValue("Firstyear"), Stock.GetParameterValue("Renewal"));
		Reporter.logEvent(Status.INFO, "Producer Info", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 12 - Add a new client by filling out the Annuitant Information and
		 * Address fields and click next. .
		 */
		AnnuitantInfo ai = new AnnuitantInfo(pi);
		ai.get();
		ai.AnnuitantInformation(Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("Gender"),
				Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
		if(System.getProperty("OwnerShipType")==null) {
			System.out.println("OwnerShip Type is not selected for this test case");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("OI")) {
			ai.ClickonOwnerInfo();			
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("PI")) {
			ai.ClickonPayorInfo();
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("SI")) {
			ai.CliconSuccessorInfo();
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("COA")) {
			ai.ClickonCoAnnuintantInfo();
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("RI")) {
			ai.ClickonRIA();
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("SA")) {
			ai.ClickonSA();
		}
		else if(System.getProperty("OwnerShipType").equalsIgnoreCase("LPA")) {
			ai.ClickonLPA();
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("PA")) {
			ai.ClickonPA();
		}
		else if(System.getProperty("OwnerShipType").equalsIgnoreCase("COO")) {
			ai.ClickonCOO();
		}
		else {
			System.out.println("OwnerShip value is not given or invaild");
		}
		Reporter.logEvent(Status.INFO, "Annuitant Info", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		
		if(System.getProperty("OwnerShipType")==null) {
			System.out.println("OwnerShip Type is not selected for this test case");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("OI")) {
			OwnerInfo oi = new OwnerInfo(ai);
			oi.get();
			oi.OwnerInfoDeatils(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("PI")) {			
			PayerInfo poi = new PayerInfo(ai);
			poi.get();			
			poi.payerinfodetails(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("SI")) {			
			SuccessorInfo si = new SuccessorInfo(ai);
			si.get();
			si.SuccessorInfoDeatils(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("COA")) {			
			Co_AnnuitantInfo CO = new Co_AnnuitantInfo(ai);
			CO.get();
			CO.CoAnnuitantInfoDeatils(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("RI")) {
			RIAInfo ri = new RIAInfo(ai);
			ri.get();
			ri.RIPDetails(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"), Stock.GetParameterValue("EffectiveDate"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("SA")) {
			SAAInfo SA = new SAAInfo(ai);
			SA.get();
			SA.SAADetails(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"), Stock.GetParameterValue("EffectiveDate"));
			Web.clickOnElement(sp, "Next_Button");	
			
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("LPA")) {
			LPAInfo LPA = new LPAInfo(ai);
			LPA.get();
			LPA.LPADetails(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"), Stock.GetParameterValue("EffectiveDate"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("PA")) {
			PATInfo PA = new PATInfo(ai);
			PA.get();
			PA.PATDetails(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"), Stock.GetParameterValue("EffectiveDate"));
			Web.clickOnElement(sp, "Next_Button");
		}else if(System.getProperty("OwnerShipType").equalsIgnoreCase("COO")) {
			Co_Owner COO = new Co_Owner(ai);
			COO.get();
			COO.Co_OwnerInfoDeatils(Stock.GetParameterValue("Gender"), Stock.GetParameterValue("Dateofbirth"), Stock.GetParameterValue("City"), Stock.GetParameterValue("State"));
			Web.clickOnElement(sp, "Next_Button");
		}
		else {
			System.out.println("OwnerShip value is not given or invaild");
		}
		/**
		 * Step 13 - Enter contract information .
		 */
		ContractInfo ci = new ContractInfo(ai);
		ci.get();
		ci.AnnuityRetAge(Stock.GetParameterValue("RetirementAge"));
		Reporter.logEvent(Status.INFO, "Contract Info", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 14 - Enter Billing information .
		 */
		BillingInfo bi = new BillingInfo(ci);
		bi.get();
		bi.ModelPremeium(Stock.GetParameterValue("ModalPremium"));
		bi.InitialPayment(Stock.GetParameterValue("InitialDepositPremium"));
		Reporter.logEvent(Status.INFO, "Billing info", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 15 - Enter Rider information .
		 */
		HCCExpressAdd rider = new HCCExpressAdd(bi);
		 if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null) {
			 System.out.println("Rider Page will not be there for this test case");
		 }
		 else if( System.getProperty("RiderType")!=null || Stock.GetParameterValue("RiderType") != null){
			 if(System.getProperty("RiderType")!=null && (System.getProperty("RiderType").trim().length()>0)) {
				 rider.get();
					Web.waitForElement(rider, "HCC_Select_RiderType");
					rider.SelectRidertype(Stock.GetParameterValue("RiderType"));
					//Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);
					Web.clickOnElement(rider, "HCC_ClickOn_Add");
					Web.waitForElement(rider, "HCC_Select_RiderPlan");
					rider.SelectRiderPlan();
				//	Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);
					Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
					Web.clickOnElement(sp, "Next_Button");
	    		}else if(Stock.GetParameterValue("RiderType") != null && Stock.GetParameterValue("RiderType").length()>0) {
	    			rider.get();
	    			Web.waitForElement(rider, "HCC_Select_RiderType");
	    			rider.SelectRidertype(Stock.GetParameterValue("RiderType"));
	    			//Web.selectDropDownOption(rider, "HCC_Select_RiderType", Stock.GetParameterValue("RiderType"), false);
	    			Web.clickOnElement(rider, "HCC_ClickOn_Add");
	    			Web.waitForElement(rider, "HCC_Select_RiderPlan");
	    			rider.SelectRiderPlan();
	    		//	Web.selectDropDownOption(rider, "HCC_Select_RiderPlan", Stock.GetParameterValue("RiderPlan"), false);
	    			Reporter.logEvent(Status.INFO, "HCC Express Add", "page is displayed", true);
	    			Web.clickOnElement(sp, "Next_Button");
	    		}
				 
		 }else {
			 System.out.println("Rider is not selected so HCC Express page will not be there");
		 }
		
		/**
		 * Step 16 - Enter Fund information .
		 */
		FundInfo fi = new FundInfo(rider);
		fi.get();
		fi.enterfundMultiple(Stock.GetParameterValue("GROWTHINV"));
		Reporter.logEvent(Status.INFO, "Fund Info", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");
		/**
		 * Step 17 - Click submit real time processing summary Finish button verify the
		 * Transaction message .
		 */

		PaymentAdd pa = new PaymentAdd(fi);
		pa.get();
		pa.PaymentAmount(Stock.GetParameterValue("PaymentAmount"));
		pa.MemoCode(Stock.GetParameterValue("MemoCode"));
		Reporter.logEvent(Status.INFO, "Payment Add", "page is displayed", true);
		Web.clickOnElement(sp, "Next_Button");

		Summary su = new Summary(pa);
		su.get();
		Web.waitForElement(su, "Summary_Realtimewait");
		Web.clickOnElement(su, "Overide_Button");
		Web.waitForElement(su, "Summary_Realtimewait");
		Web.selectDropDownOption(su, "Summary_Realtime", Stock.GetParameterValue("ctradd_realtime"), false);
		Web.clickOnElement(su, "Summary_Finishbtn");
		su.VerifyErrorText(Stock.GetParameterValue("ErrorText"));
		su.getpolicynumber();
		Reporter.logEvent(Status.INFO, "Summary page", "page is displayed", true);
		Web.clickOnElement(su, "Summary_NavigateButton");
		Web.waitForElement(su, "Summary_Fund");
		}
		catch(Exception e) {
			 Reporter.logEvent(Status.FAIL, "Ecxception ", e.toString(), true); 
		}
	}
	
	public static void contractsearchandFundINFO(String contractid) {
		LandingPage landing = new LandingPage();
		Home om = new Home(landing);
		om.entercontractid(contractid);
		om.Clickonserachbutton();
		
		General g = new General(om);
		g.get();
		g.ClickFundSilderBar();
		g.getFundINFO();
		g.ClickFundSilderBar();
	}
	
	//****************************************************************************************************************************          
    /**
    * Method is used in Fund Transfer test case to enter the Fund
    * 
     * @author Anjali
    * @param
    * @param
    * @return
    */
    public static void CostaverageTransferfund() throws InterruptedException {

             try {
                       Thread.sleep(2000);
             } catch (Exception e) {

             }

             // String multfund = Stock.getConfigParam("MultipleFund");

             int multifundnumber = Integer.parseInt(Stock.GetParameterValue("MultipleFund"));
             int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
             int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));

             // int initialvalue;
             double frmfundvalue = 0;
             boolean Cfund = false;
             double frmfundtotpercentage = 0;
             String FromfundNumber = null;
             int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th")).size();
             int Frompercent = 0;
             int Topercent = 0;
             int valuehead = 0;
             String percentfrom = "From Percent";
             String amountfrom = "From Amount";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(percentfrom) || fud.equalsIgnoreCase(amountfrom)) {
                                Frompercent = i;
                                break;
                       }
             }
             String percentTo = "To Percent";
             String amountTo = "To Amount";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(amountTo) || fud.equalsIgnoreCase(percentTo)) {
                                Topercent = i;
                                break;
                       }
             }

             String val = "Fund Value";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(val)) {
                                valuehead = i;
                                break;
                       }
             }

             int cnt;
             int tofu = 0;
             String too3 = null;
             int tbrow = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr")).size();

             if (tbrow > multifundnumber) {
                       for (int i = 1; i <= multifundnumber + 1; i++) {
                                if (i == 1) {
                                          Fundtable.put("FundNumer_" + i,
                                                             Web.getDriver()
                                                                                .findElement(
                                                                                                    By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                                .getText());
                                          Fundtable.put("FundName_" + i,
                                                             Web.getDriver()
                                                                                .findElement(
                                                                                                    By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                                .getText());

                                          // String getvalue =
                                          // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                          FromfundNumber = Fundtable.get("FundNumer_" + i);
                                          Web.getDriver().findElement(By.xpath(
                                                             "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                             .click();
                                          Web.getDriver().findElement(By.xpath(
                                                             "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                              .sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

                                          Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                             "[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
                                          // Fundtable.put
                                          /*
                                          * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                          * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                          */

                                          // String splitamt1 = splitamt[0].trim().toString();
                                          String fFundvalue = null;
                                          for (String key : GawFundOLD.keySet()) {

                              				String temp = GawFundOLD.get(key);
                              				
                              				if(key.equalsIgnoreCase(FromfundNumber)) {
                              					fFundvalue = temp;
                              				}
                                          }
                                         
                                          //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                       //   fFundvalue = fFundvalue.trim().toString();

                                      /*    String[] delimit = fFundvalue.split("[$]");
                                          String arr1[] = null;
                                          if (delimit[1].contains(",")) {
                                                    arr1 = delimit[1].split(",");

                                          }

                                          if (arr1.length > 0) {

                                                    String foo = arr1[0];
                                                    for (int a = 1; a < arr1.length; a++) {
                                                             foo = foo + arr1[a];

                                                    }
                                                    fFundvalue = foo;
                                          } else {
                                                    fFundvalue = delimit[1].trim().toString();
                                          }*/

                                          /// ********************************************

                                          if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
                                                    String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                    // String splitamt1 = splitamt[0].trim().toString();

                                                    double x = Double.parseDouble(splitamt[0]) / 100;
                                                    // double y = Double.parseDouble(Delimit1.toString());
                                                    double y = Double.parseDouble(fFundvalue);

                                                    // y = Double.parseDouble(df2.format(fFundvalue));
                                                    // double z = x * y;
                                                    System.out.println(df2.format(y));

                                                    frmfundvalue = x * y;

                                                    // add percentage value

                                                    String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                                    frmFundtotal = x * Double.parseDouble(paymtAmount);

                                                    // String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                                    // String[] splitamttofund =
                                                    // Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                    /*
                                                    * Double amount = Double.parseDouble(splitamt[0]);
                                                    * 
                                                     * 
                                                     * 
                                                     * Double Tofundvalue = (amount/100)* frmfundvalue;
                                                    */

                                                    // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                    // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                    // *********************************************************************************************
                                                    /*
                                                    * String toString = Double.toString(Tofundvalue);
                                                    * 
                                                     * 
                                                     * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                    * 
                                                     * String too2 =toString.substring(toString.lastIndexOf("."),
                                                    * toString.lastIndexOf(".")+3);
                                                    * 
                                                     * too3 = too1+too2;
                                                    */
                                                    // *********************************************************************************************

                                          } else {

                                                    // String splitamt1 = splitamt[0].trim().toString();

                                                    double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
                                                    // double y = Double.parseDouble(Delimit1.toString());
                                                    double y = Double.parseDouble(fFundvalue);

                                                    // y = Double.parseDouble(df2.format(fFundvalue));
                                                    // double z = x * y;
                                                    System.out.println(df2.format(y));

                                                    frmfundvalue = y - x;

                                                    // Stock.GetParameterValue("Ftfromtransfer")
                                                    // frmFundtotal = Double.parseDouble("PaymentAmount") -
                                                    // Double.parseDouble("Ftfromtransfer");

                                                    // add percentage value
                                          }

                                          System.out.println(frmfundvalue);
                                          // *********************************************

                                          String tostring = Double.toString(frmfundvalue);

                                          // Fundtable.put("FromFundValue_"+i,tostring);
                                          // Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
/*                                             String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

                                          String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

                                          String foo3 = foo1 + foo2;*/

                                          // Fundtable.put("FromFundValue_"+i,new
                                          // DecimalFormat("##.##").format(frmfundvalue).toString());

                                          Fundtable.put("FromFundValue_" + i, tostring);

                                          System.out.println(Fundtable.get("FromFundValue_" + i));

                                          /*
                                          * } else {
                                          * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
                                          * 
                                           * 
                                           * 
                                           * System.out.println(Fundtable.get("FromFundValue_"+i)); }
                                          */

                                } else {
                                          cnt = i - 1;
                                          if (cfundnumber >= 1) {
                                                    int cfundcnt = 1;
                                                    tofu = 1;
                                                    // for (int j=2; j<FundTableTB.size();j++) {
                                                    for (int j = 2; j < tbrow; j++) {

                                                             String str = Web.getDriver()
                                                                                .findElement(By.xpath(
                                                                                                    "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                                .getText();
                                                             System.out.println(str);
                                                             if (str.equalsIgnoreCase("c")) {
                                                                       Cfund = true;
                                                                      

                                                                       Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                          + j + "]/td[" + Topercent + "]/input")).click();
                                                                       
                                                                       Thread.sleep(5000);
                                                                       // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                       Web.getDriver()
                                                                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                             + "]/td[" + Topercent + "]/input"))
                                                                                          .sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                       // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                       if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
                                                                                // tofund
                                                                                String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
                                                                                Double amount = Double.parseDouble(splitamtf[0]);

                                                                                Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                                String toString = Double.toString(Tofundvalue);

                                                                                String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                                String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                                    toString.lastIndexOf(".") + 3);

                                                                                too3 = too1 + too2;
                                                                                // tofund
                                                                                // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                                // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                                /*
                                                                                * String toString = Double.toString(Tofundvalue);
                                                                                * 
                                                                                 * 
                                                                                 * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                                * 
                                                                                 * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                                * toString.lastIndexOf(".")+3);
                                                                                * 
                                                                                 * String too3 = too1+too2;
                                                                                */
                                                                                // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                                // Fundtable.put("ToFundValue_"+tofu,new
                                                                                // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                                // Double amount = Double.parseDouble(splitamt[0]);

                                                                                // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                                Fundtable.put("ToFundValue_" + tofu, too3);

                                                                                Fundtable.put("ToFundNumer_" + tofu,
                                                                                                    Web.getDriver().findElement(By.xpath(
                                                                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                       .getText());
                                                                                Fundtable.put("ToFundName_" + tofu,
                                                                                                    Web.getDriver().findElement(By.xpath(
                                                                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                       .getText());
                                                                                Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                    "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                       + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                    false);
                                                                                /*
                                                                                * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                                * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                                */

                                                                                 System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                       }

                                                                       else {

                                                                                // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                                 System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                                Fundtable.put("ToFundValue_" + tofu,
                                                                                                    Stock.GetParameterValue("FTtransferTO" + tofu));
                                                                                 System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                                Fundtable.put("ToFundNumer_" + tofu,
                                                                                                    Web.getDriver().findElement(By.xpath(
                                                                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                       .getText());
                                                                                Fundtable.put("ToFundName_" + tofu,
                                                                                                    Web.getDriver().findElement(By.xpath(
                                                                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                       .getText());
                                                                                Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                    "[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
                                                                                                                       + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                    false);
                                                                                /*
                                                                                * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                                * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                                * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                                * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                                */
                                                                       }

                                                                       if (cfundcnt == cfundnumber) {
                                                                                cfundnumber = 0;
                                                                                if (Noncfundnumber >= 1) {
                                                                                          i = multifundnumber;
                                                                                } else {
                                                                                          i = (multifundnumber + 1);
                                                                                }
                                                                                break;
                                                                       } else {
                                                                                cfundcnt = cfundcnt + 1;
                                                                       }
                                                                       tofu = tofu + 1;
                                                             }

                                                    }

                                                    if (Cfund) {
                                                             System.out.println("Cfund Displayed");
                                                    } else {
                                                             System.out.println("No Cfund Displayed");
                                                    }
                                          } else {

                                                    // Fundtable.put("ToFundValue_"+tofu,too3);
                                                    Web.getDriver().findElement(By.xpath(
                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                       .click();
                                                    Thread.sleep(5000);
                                                    Web.getDriver()
                                                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                          + Topercent + "]/input"))
                                                                       .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

                                                    Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                       .getText());
                                                    Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                       .getText());
                                                    // Fundtable.put("ToFundValue_"+cnt,
                                                    // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                                    if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
                                                             String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
                                                             Double amount = Double.parseDouble(splitvalue[0]);
                                                             Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                             String toString = Double.toString(Tofundvalue);

                                                             String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                             String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                              too3 = too1 + too2;
                                                             Fundtable.put("ToFundValue_" + cnt, too3);
                                                             frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                             Reporter.logEvent(Status.INFO,
                                                                                "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                                "[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
                                                                                                    + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                                false);

                                                    } else {
                                                             Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
                                                             frmFundtotal = frmFundtotal
                                                                                + Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
                                                             Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                "[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
                                                                                                    + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                                false);
                                                    }

                                                    System.out.println(i);
                                                    System.out.println(Web.getDriver().findElement(By.xpath(
                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                       .getText());
                                                    System.out.println(Web.getDriver().findElement(By.xpath(
                                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                       .getText());
                                                    System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                                    // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                                    // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                                    // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                          }

                                }

                       }

             } else {

                       System.out.println("Table has Less row number than required Fund numbers");
             }

             if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
                       frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
             }

    }

    
    /**
     * Function Decrypt
     * 
     * 
     */
     public static String decryptXOR(String message, String key){
            try {
           if (message==null || key==null ) return null;
           BASE64Decoder decoder = new BASE64Decoder();
           char[] keys=key.toCharArray();
           char[] mesg=new String(decoder.decodeBuffer(message)).toCharArray();

           int ml=mesg.length;
           int kl=keys.length;
           char[] newmsg=new char[ml];

           for (int i=0; i<ml; i++){
             newmsg[i]=(char)(mesg[i]^keys[i%kl]);
           }
           mesg=null; keys=null;
           return new String(newmsg);
         }
         catch ( Exception e ) {
           return null;
         } 
    }
     
  //*************************************************************************************************************************************************************
     

/**
* Method is used in costaverage percentage test case to enter the Fund
* 
  * @author Anjali
* @param
* @param
* @return
*/
public static void CostaverageTransferfund_EContractPercentage() throws InterruptedException {

          try {
                    Thread.sleep(2000);
          } catch (Exception e) {

          }

          // String multfund = Stock.getConfigParam("MultipleFund");

          int multifundnumber = Integer.parseInt(Stock.GetParameterValue("MultipleFund"));
          int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
          int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));

          // int initialvalue;
          double frmfundvalue = 0;
          boolean Cfund = false;
          double frmfundtotpercentage = 0;
          double finalfundvalue=0;
          
          
                  

          
         
          
      
          String FromfundNumber = null;
          int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th")).size();
          int Frompercent = 0;
          int Topercent = 0;
          int valuehead = 0;
          String percentfrom = "From Percent";
          String amountfrom = "From Amount";
          for (int i = 1; i <= num; i++) {
                    String fud = Web.getDriver()
                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                    if (fud.equalsIgnoreCase(percentfrom) || fud.equalsIgnoreCase(amountfrom)) {
                             Frompercent = i;
                             break;
                    }
          }
          String percentTo = "To Percent";
          String amountTo = "To Amount";
          for (int i = 1; i <= num; i++) {
                    String fud = Web.getDriver()
                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                    if (fud.equalsIgnoreCase(amountTo) || fud.equalsIgnoreCase(percentTo)) {
                             Topercent = i;
                             break;
                    }
          }

          String val = "Fund Value";
          for (int i = 1; i <= num; i++) {
                    String fud = Web.getDriver()
                                       .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                    if (fud.equalsIgnoreCase(val)) {
                             valuehead = i;
                             break;
                    }
          }

          int cnt;
          int tofu = 0;
          String too3 = null;
          int tbrow = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr")).size();
          if (System.getProperty("FromtransferPercentage") == null)
          {    
              if (tbrow > multifundnumber) {
                  for (int i = 1; i <= multifundnumber + 1; i++) {
                           if (i == 1) {
                                     Fundtable.put("FundNumer_" + i,
                                                        Web.getDriver()
                                                                           .findElement(
                                                                                               By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                           .getText());
                                     Fundtable.put("FundName_" + i,
                                                        Web.getDriver()
                                                                           .findElement(
                                                                                               By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                           .getText());

                                     // String getvalue =
                                     // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                     FromfundNumber = Fundtable.get("FundNumer_" + i);
                                     Web.getDriver().findElement(By.xpath(
                                                        "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                        .click();
                                     Web.getDriver().findElement(By.xpath(
                                                        "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                         .sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

                                     Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                        "[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
                                     // Fundtable.put
                                     /*
                                     * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                     * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                     */

                                     // String splitamt1 = splitamt[0].trim().toString();
                                     String fFundvalue = null;
                                     for (String key : GawFundOLD.keySet()) {

                                                                                String temp = GawFundOLD.get(key);
                                                                                
                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                fFundvalue = temp;
                                                                                }
                                     }
                                    
                                     //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                  //   fFundvalue = fFundvalue.trim().toString();

                                 /*    String[] delimit = fFundvalue.split("[$]");
                                     String arr1[] = null;
                                     if (delimit[1].contains(",")) {
                                               arr1 = delimit[1].split(",");

                                     }

                                     if (arr1.length > 0) {

                                               String foo = arr1[0];
                                               for (int a = 1; a < arr1.length; a++) {
                                                        foo = foo + arr1[a];

                                               }
                                               fFundvalue = foo;
                                     } else {
                                               fFundvalue = delimit[1].trim().toString();
                                     }*/

                                     /// ********************************************

                                     if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
                                               String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

                                               // String splitamt1 = splitamt[0].trim().toString();

                                               double x = Double.parseDouble(splitamt[0]) / 100;
                                               // double y = Double.parseDouble(Delimit1.toString());
                                               double y = Double.parseDouble(fFundvalue);

                                               // y = Double.parseDouble(df2.format(fFundvalue));
                                               // double z = x * y;
                                               System.out.println(df2.format(y));

                                               frmfundvalue = x * y;

                                               // add percentage value

                                               String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                               frmFundtotal = x * Double.parseDouble(paymtAmount);

                                               // String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                               // String[] splitamttofund =
                                               // Stock.GetParameterValue("Ftfromtransfer").split("%");

                                               /*
                                               * Double amount = Double.parseDouble(splitamt[0]);
                                               * 
                                                * 
                                                * 
                                                * Double Tofundvalue = (amount/100)* frmfundvalue;
                                               */

                                               // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                               // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                               // *********************************************************************************************
                                               /*
                                               * String toString = Double.toString(Tofundvalue);
                                               * 
                                                * 
                                                * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                               * 
                                                * String too2 =toString.substring(toString.lastIndexOf("."),
                                               * toString.lastIndexOf(".")+3);
                                               * 
                                                * too3 = too1+too2;
                                               */
                                               // *********************************************************************************************

                                     } else {

                                               // String splitamt1 = splitamt[0].trim().toString();

                                               double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
                                               // double y = Double.parseDouble(Delimit1.toString());
                                               double y = Double.parseDouble(fFundvalue);

                                               // y = Double.parseDouble(df2.format(fFundvalue));
                                               // double z = x * y;
                                               System.out.println(df2.format(y));

                                               frmfundvalue = y - x;

                                               // Stock.GetParameterValue("Ftfromtransfer")
                                               // frmFundtotal = Double.parseDouble("PaymentAmount") -
                                               // Double.parseDouble("Ftfromtransfer");

                                               // add percentage value
                                     }

                                     System.out.println(frmfundvalue);
                                     // *********************************************

                                     String tostring = Double.toString(frmfundvalue);

                                     // Fundtable.put("FromFundValue_"+i,tostring);
                                     // Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
/*                                             String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

                                     String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

                                     String foo3 = foo1 + foo2;*/

                                     // Fundtable.put("FromFundValue_"+i,new
                                     // DecimalFormat("##.##").format(frmfundvalue).toString());

                                     Fundtable.put("FromFundValue_" + i, tostring);

                                     System.out.println(Fundtable.get("FromFundValue_" + i));

                                     /*
                                     * } else {
                                     * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
                                     * 
                                      * 
                                      * 
                                      * System.out.println(Fundtable.get("FromFundValue_"+i)); }
                                     */

                           } else {
                                     cnt = i - 1;
                                     if (cfundnumber >= 1) {
                                               int cfundcnt = 1;
                                               tofu = 1;
                                               // for (int j=2; j<FundTableTB.size();j++) {
                                               for (int j = 2; j < tbrow; j++) {

                                                        String str = Web.getDriver()
                                                                           .findElement(By.xpath(
                                                                                               "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                           .getText();
                                                        System.out.println(str);
                                                        if (str.equalsIgnoreCase("c")) {
                                                                  Cfund = true;
                                                                 

                                                                  Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                     + j + "]/td[" + Topercent + "]/input")).click();
                                                                  
                                                                  Thread.sleep(5000);
                                                                  // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                  Web.getDriver()
                                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                        + "]/td[" + Topercent + "]/input"))
                                                                                     .sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                  // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                  if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
                                                                           // tofund
                                                                           String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
                                                                           Double amount = Double.parseDouble(splitamtf[0]);

                                                                           Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                           String toString = Double.toString(Tofundvalue);

                                                                           String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                           String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                               toString.lastIndexOf(".") + 3);

                                                                           too3 = too1 + too2;
                                                                           // tofund
                                                                           // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                           // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                           /*
                                                                           * String toString = Double.toString(Tofundvalue);
                                                                           * 
                                                                            * 
                                                                            * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                           * 
                                                                            * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                           * toString.lastIndexOf(".")+3);
                                                                           * 
                                                                            * String too3 = too1+too2;
                                                                           */
                                                                           // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                           // Fundtable.put("ToFundValue_"+tofu,new
                                                                           // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                           // Double amount = Double.parseDouble(splitamt[0]);

                                                                           // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                           Fundtable.put("ToFundValue_" + tofu, too3);

                                                                           Fundtable.put("ToFundNumer_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                  .getText());
                                                                           Fundtable.put("ToFundName_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                  .getText());
                                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                               "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                  + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                               false);
                                                                           /*
                                                                           * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                           * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                           */

                                                                            System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                  }

                                                                  else {

                                                                           // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                            System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                           Fundtable.put("ToFundValue_" + tofu,
                                                                                               Stock.GetParameterValue("FTtransferTO" + tofu));
                                                                            System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                           Fundtable.put("ToFundNumer_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                  .getText());
                                                                           Fundtable.put("ToFundName_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                  .getText());
                                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                               "[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
                                                                                                                  + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                               false);
                                                                           /*
                                                                           * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                           * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                           * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                          * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                           */
                                                                  }

                                                                  if (cfundcnt == cfundnumber) {
                                                                           cfundnumber = 0;
                                                                           if (Noncfundnumber >= 1) {
                                                                                     i = multifundnumber;
                                                                           } else {
                                                                                     i = (multifundnumber + 1);
                                                                           }
                                                                           break;
                                                                  } else {
                                                                           cfundcnt = cfundcnt + 1;
                                                                  }
                                                                  tofu = tofu + 1;
                                                        }

                                               }

                                               if (Cfund) {
                                                        System.out.println("Cfund Displayed");
                                               } else {
                                                        System.out.println("No Cfund Displayed");
                                               }
                                     } else {

                                               // Fundtable.put("ToFundValue_"+tofu,too3);
                                               Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                  .click();
                                               Thread.sleep(5000);
                                               Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                     + Topercent + "]/input"))
                                                                  .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

                                               Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                  .getText());
                                               Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                  .getText());
                                               // Fundtable.put("ToFundValue_"+cnt,
                                               // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                               if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
                                                        String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
                                                        Double amount = Double.parseDouble(splitvalue[0]);
                                                        Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                        String toString = Double.toString(Tofundvalue);

                                                        String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                        String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                         too3 = too1 + too2;
                                                        Fundtable.put("ToFundValue_" + cnt, too3);
                                                        frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                        Reporter.logEvent(Status.INFO,
                                                                           "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                           "[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
                                                                                               + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                           false);

                                               } else {
                                                        Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
                                                        frmFundtotal = frmFundtotal
                                                                           + Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
                                                        Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                           "[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
                                                                                               + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                           false);
                                               }

                                               System.out.println(i);
                                               System.out.println(Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                  .getText());
                                               System.out.println(Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                  .getText());
                                               System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                               // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                               // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                               // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                     }

                           }

                  }

        } else {

            System.out.println("Table has Less row number than required Fund numbers");
  }

        if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
                  frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
        }
}
          
          else if (System.getProperty("FromtransferPercentage").trim().length() > 0)
          {
                  if (tbrow > multifundnumber) {
                  for (int i = 1; i <= multifundnumber + 1; i++) {
                           if (i == 1) {
                                     Fundtable.put("FundNumer_" + i,
                                                        Web.getDriver()
                                                                           .findElement(
                                                                                               By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                           .getText());
                                     Fundtable.put("FundName_" + i,
                                                        Web.getDriver()
                                                                           .findElement(
                                                                                               By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                           .getText());

                                     // String getvalue =
                                     // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                     FromfundNumber = Fundtable.get("FundNumer_" + i);
                                     Web.getDriver().findElement(By.xpath(
                                                        "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                        .click();
                                    
                                     Web.getDriver().findElement(By.xpath(
                                             "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                              .sendKeys(System.getProperty("FromtransferPercentage").trim());
                                     Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                             "[" + System.getProperty("FromtransferPercentage") + "] transfered to other funds", false);
                                     
                                     
                                     
                               
                                     
                                   // Fundtable.put
                                     /*
                                     * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                     * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                     */

                                    // String splitamt1 = splitamt[0].trim().toString();
                                     String fFundvalue = null;
                                     for (String key : GawFundOLD.keySet()) {

                                                                                String temp = GawFundOLD.get(key);
                                                                                
                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                fFundvalue = temp;
                                                                                }
                                     }
                                    
                                     //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                  //   fFundvalue = fFundvalue.trim().toString();

                                 /*    String[] delimit = fFundvalue.split("[$]");
                                     String arr1[] = null;
                                     if (delimit[1].contains(",")) {
                                               arr1 = delimit[1].split(",");

                                     }

                                     if (arr1.length > 0) {

                                               String foo = arr1[0];
                                               for (int a = 1; a < arr1.length; a++) {
                                                        foo = foo + arr1[a];

                                               }
                                               fFundvalue = foo;
                                     } else {
                                               fFundvalue = delimit[1].trim().toString();
                                     }*/

                                     /// ********************************************

                                     
                                          if (System.getProperty("FromtransferPercentage").contains("%")) {
                                               String[] splitamt = System.getProperty("FromtransferPercentage").split("%");

                                               // String splitamt1 = splitamt[0].trim().toString();

                                               double x = Double.parseDouble(splitamt[0]) / 100;
                                               double y = Double.parseDouble(fFundvalue);

                                               System.out.println(df2.format(y));

                                               frmfundvalue = x * y;
                                               finalfundvalue=y-(x*y);
                                                                   
                                              

                                               // add percentage value

                                               String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                               frmFundtotal = x * Double.parseDouble(paymtAmount);



                                     } else {

                                               

                                               double x = Double.parseDouble(System.getProperty("FromtransferPercentage"));
                                               double y = Double.parseDouble(fFundvalue);

                                              
                                               System.out.println(df2.format(y));

                                               frmfundvalue = y - x;

                                             
                                     }

                                     System.out.println(frmfundvalue);
                                    

                                     String tostring = Double.toString(finalfundvalue);



                                     Fundtable.put("FromFundValue_" + i, tostring);

                                     System.out.println(Fundtable.get("FromFundValue_" + i));

                                    
                           } else {
                                     cnt = i - 1;
                                /*     frmfundvalue = Double.parseDouble(System.getProperty("Fromtransfer"));
                                       double temp1=frmfundvalue/2;
                                     String frmfundtotpercentage11=String.valueOf(temp1);*/
                                  

                                     if (cfundnumber >= 1) {
                                               int cfundcnt = 1;
                                               tofu = 1;
                                               // for (int j=2; j<FundTableTB.size();j++) {
                                               for (int j = 2; j < tbrow; j++) {

                                                        String str = Web.getDriver()
                                                                           .findElement(By.xpath(
                                                                                               "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                           .getText();
                                                        double temp1=50.0;
                                                        String frmfundtotpercentage11=String.valueOf(temp1)+"%";
                                                        System.out.println(frmfundtotpercentage11);
                                                        
                                                                  
                                                        System.out.println(str);
                                                        if (str.equalsIgnoreCase("c")) {
                                                                  Cfund = true;
                                                                 
                                                                  
                                                                    
                                                                   

                                                                  Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                     + j + "]/td[" + Topercent + "]/input")).click();
                                                                  
                                                                  Thread.sleep(5000);
                                                                  // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                  Web.getDriver()
                                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                        + "]/td[" + Topercent + "]/input"))
                                                                                     .sendKeys(frmfundtotpercentage11);

                                                                  // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                  if (frmfundtotpercentage11.contains("%")) {
                                                                           // tofund
                                                                           String[] splitamtf = frmfundtotpercentage11.split("%");
                                                                           Double amount = Double.parseDouble(splitamtf[0]);

                                                                           Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                           String toString = Double.toString(Tofundvalue);

                                                                           String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                           String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                               toString.lastIndexOf(".") + 3);

                                                                           too3 = too1 + too2;
                                                                           // tofund
                                                                           // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                           // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                           /*
                                                                           * String toString = Double.toString(Tofundvalue);
                                                                           * 
                                                                            * 
                                                                            * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                           * 
                                                                            * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                           * toString.lastIndexOf(".")+3);
                                                                           * 
                                                                            * String too3 = too1+too2;
                                                                           */
                                                                           // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                           // Fundtable.put("ToFundValue_"+tofu,new
                                                                           // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                           // Double amount = Double.parseDouble(splitamt[0]);

                                                                           // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                           Fundtable.put("ToFundValue_" + tofu, too3);

                                                                           Fundtable.put("ToFundNumer_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                  .getText());
                                                                           Fundtable.put("ToFundName_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                  .getText());
                                                                         /*  Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                               "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                  + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                               false);
                                                                         */ 
                                                                           
                                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                   "[" + frmfundtotpercentage11 + "%] transfered to ["
                                                                                                      + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                   false);
                                                                           
                                                                           /*
                                                                           * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                           * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                           */

                                                                            System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                  }

                                                                  else {   
                                                                  
                                                                 

                                                                           // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                            System.out.println(frmfundtotpercentage11);

                                                                            Fundtable.put("ToFundValue_" + tofu,
                                                                                                frmfundtotpercentage11);
                                                                                                 
                                                                            System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                           Fundtable.put("ToFundNumer_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                  .getText());
                                                                           Fundtable.put("ToFundName_" + tofu,
                                                                                               Web.getDriver().findElement(By.xpath(
                                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                  .getText());
                                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                               "[$" + frmfundtotpercentage11 + "] transfered to ["
                                                                                                                  + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                               false);
                                                                           /*
                                                                           * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                           * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                           * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                          * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                           * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                           */
                                                                  }

                                                                  if (cfundcnt == cfundnumber) {
                                                                           cfundnumber = 0;
                                                                           if (Noncfundnumber >= 1) {
                                                                                     i = multifundnumber;
                                                                           } else {
                                                                                     i = (multifundnumber + 1);
                                                                           }
                                                                           break;
                                                                  } else {
                                                                           cfundcnt = cfundcnt + 1;
                                                                  }
                                                                  tofu = tofu + 1;
                                                        }

                                               }

                                               if (Cfund) {
                                                        System.out.println("Cfund Displayed");
                                               } else {
                                                        System.out.println("No Cfund Displayed");
                                               }
                                     } else {

                                               // Fundtable.put("ToFundValue_"+tofu,too3);
                                                
                                                   
                                                    double temp1=50.0;
                                            String frmfundtotpercentage11=String.valueOf(temp1)+"%";
                                            System.out.println(frmfundtotpercentage11);
                                            
                                                  
                                          
                                            
                                                   
                                                   
                                                   Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                  .click();
                                               Thread.sleep(4000);
                                               /*Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                     + Topercent + "]/input"))
                                                                  .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));*/
                                               Web.getDriver().findElement(By.xpath(
                                                       "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                       .click();
                                              Thread.sleep(3000);
                                               Web.getDriver()
                                               .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                  + Topercent + "]/input"))
                                               .sendKeys(frmfundtotpercentage11);


                                               Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                  .getText());
                                               Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                  .getText());
                                               // Fundtable.put("ToFundValue_"+cnt,
                                               // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                               if (frmfundtotpercentage11.contains("%")) {
                                                        String[] splitvalue = frmfundtotpercentage11.split("[%]");
                                                        Double amount = Double.parseDouble(splitvalue[0]);
                                                        Double Tofundvalue = (amount) / 100 * frmfundvalue;
                                                        

                                                        String toString = Double.toString(Tofundvalue);

                                                        String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                        String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                         too3 = too1 + too2;
                                                        Fundtable.put("ToFundValue_" + cnt, too3);
                                                        frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                        Reporter.logEvent(Status.INFO,
                                                                           "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                           "[" + frmfundtotpercentage11 + "%] transfered to ["
                                                                                               + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                           false);

                                               } else {
                                                        Fundtable.put("ToFundValue_" + cnt, frmfundtotpercentage11);
                                                        frmFundtotal = frmFundtotal
                                                                           + Double.parseDouble(frmfundtotpercentage11);
                                                        Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                           "[$" + frmfundtotpercentage11 + "] transfered to ["
                                                                                               + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                           false);
                                               }

                                               System.out.println(i);
                                               System.out.println(Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                  .getText());
                                               System.out.println(Web.getDriver().findElement(By.xpath(
                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                  .getText());
                                               System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                               // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                               // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                               // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                     }
                                     

                           }

                  }

        }
              else {

                  System.out.println("Table has Less row number than required Fund numbers");
        }
              
                  double temp1=50.0;
              String frmfundtotpercentage11=String.valueOf(temp1)+"%";
              System.out.println(frmfundtotpercentage11);
              


              if (frmfundtotpercentage11.contains("%")) {
                        frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
              }

          
          }
              
              else {
                 
                  if (tbrow > multifundnumber) {
                      for (int i = 1; i <= multifundnumber + 1; i++) {
                               if (i == 1) {
                                         Fundtable.put("FundNumer_" + i,
                                                            Web.getDriver()
                                                                               .findElement(
                                                                                                   By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                               .getText());
                                         Fundtable.put("FundName_" + i,
                                                            Web.getDriver()
                                                                               .findElement(
                                                                                                   By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                               .getText());

                                         // String getvalue =
                                         // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                         FromfundNumber = Fundtable.get("FundNumer_" + i);
                                         Web.getDriver().findElement(By.xpath(
                                                            "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                            .click();
                                         Web.getDriver().findElement(By.xpath(
                                                            "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                             .sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

                                         Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                            "[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
                                         // Fundtable.put
                                         /*
                                         * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                         * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                         */

                                         // String splitamt1 = splitamt[0].trim().toString();
                                         String fFundvalue = null;
                                         for (String key : GawFundOLD.keySet()) {

                                                                                String temp = GawFundOLD.get(key);
                                                                                
                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                fFundvalue = temp;
                                                                                }
                                         }
                                        
                                         //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                      //   fFundvalue = fFundvalue.trim().toString();

                                     /*    String[] delimit = fFundvalue.split("[$]");
                                         String arr1[] = null;
                                         if (delimit[1].contains(",")) {
                                                   arr1 = delimit[1].split(",");

                                         }

                                         if (arr1.length > 0) {

                                                   String foo = arr1[0];
                                                   for (int a = 1; a < arr1.length; a++) {
                                                            foo = foo + arr1[a];

                                                   }
                                                   fFundvalue = foo;
                                         } else {
                                                   fFundvalue = delimit[1].trim().toString();
                                         }*/

                                         /// ********************************************

                                         if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
                                                   String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                   // String splitamt1 = splitamt[0].trim().toString();

                                                   double x = Double.parseDouble(splitamt[0]) / 100;
                                                  // double y = Double.parseDouble(Delimit1.toString());
                                                   double y = Double.parseDouble(fFundvalue);

                                                   // y = Double.parseDouble(df2.format(fFundvalue));
                                                   // double z = x * y;
                                                   System.out.println(df2.format(y));

                                                   frmfundvalue = x * y;

                                                   // add percentage value

                                                   String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                                   frmFundtotal = x * Double.parseDouble(paymtAmount);

                                                   // String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                                   // String[] splitamttofund =
                                                   // Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                   /*
                                                   * Double amount = Double.parseDouble(splitamt[0]);
                                                   * 
                                                    * 
                                                    * 
                                                    * Double Tofundvalue = (amount/100)* frmfundvalue;
                                                   */

                                                   // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                   // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                   // *********************************************************************************************
                                                   /*
                                                   * String toString = Double.toString(Tofundvalue);
                                                   * 
                                                    * 
                                                    * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                   * 
                                                    * String too2 =toString.substring(toString.lastIndexOf("."),
                                                   * toString.lastIndexOf(".")+3);
                                                   * 
                                                    * too3 = too1+too2;
                                                   */
                                                   // *********************************************************************************************

                                         } else {

                                                   // String splitamt1 = splitamt[0].trim().toString();

                                                   double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
                                                   // double y = Double.parseDouble(Delimit1.toString());
                                                   double y = Double.parseDouble(fFundvalue);

                                                   // y = Double.parseDouble(df2.format(fFundvalue));
                                                   // double z = x * y;
                                                   System.out.println(df2.format(y));

                                                   frmfundvalue = y - x;

                                                   // Stock.GetParameterValue("Ftfromtransfer")
                                                   // frmFundtotal = Double.parseDouble("PaymentAmount") -
                                                   // Double.parseDouble("Ftfromtransfer");

                                                   // add percentage value
                                         }

                                         System.out.println(frmfundvalue);
                                         // *********************************************

                                         String tostring = Double.toString(frmfundvalue);

                                         // Fundtable.put("FromFundValue_"+i,tostring);
                                         // Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
/*                                             String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

                                         String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

                                         String foo3 = foo1 + foo2;*/

                                         // Fundtable.put("FromFundValue_"+i,new
                                         // DecimalFormat("##.##").format(frmfundvalue).toString());

                                         Fundtable.put("FromFundValue_" + i, tostring);

                                         System.out.println(Fundtable.get("FromFundValue_" + i));

                                         /*
                                         * } else {
                                         * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
                                         * 
                                          * 
                                          * 
                                          * System.out.println(Fundtable.get("FromFundValue_"+i)); }
                                         */

                               } else {
                                         cnt = i - 1;
                                         if (cfundnumber >= 1) {
                                                   int cfundcnt = 1;
                                                   tofu = 1;
                                                   // for (int j=2; j<FundTableTB.size();j++) {
                                                   for (int j = 2; j < tbrow; j++) {

                                                            String str = Web.getDriver()
                                                                               .findElement(By.xpath(
                                                                                                   "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                               .getText();
                                                            System.out.println(str);
                                                            if (str.equalsIgnoreCase("c")) {
                                                                      Cfund = true;
                                                                     

                                                                      Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                         + j + "]/td[" + Topercent + "]/input")).click();
                                                                      
                                                                      Thread.sleep(5000);
                                                                      // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                      Web.getDriver()
                                                                                         .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                            + "]/td[" + Topercent + "]/input"))
                                                                                         .sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                      // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                      if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
                                                                               // tofund
                                                                               String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
                                                                               Double amount = Double.parseDouble(splitamtf[0]);

                                                                               Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                               String toString = Double.toString(Tofundvalue);

                                                                               String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                               String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                                   toString.lastIndexOf(".") + 3);

                                                                               too3 = too1 + too2;
                                                                               // tofund
                                                                               // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                               // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                               /*
                                                                               * String toString = Double.toString(Tofundvalue);
                                                                               * 
                                                                                * 
                                                                                * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                               * 
                                                                                * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                               * toString.lastIndexOf(".")+3);
                                                                               * 
                                                                                * String too3 = too1+too2;
                                                                               */
                                                                               // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                               // Fundtable.put("ToFundValue_"+tofu,new
                                                                               // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                               // Double amount = Double.parseDouble(splitamt[0]);

                                                                               // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                               Fundtable.put("ToFundValue_" + tofu, too3);

                                                                               Fundtable.put("ToFundNumer_" + tofu,
                                                                                                   Web.getDriver().findElement(By.xpath(
                                                                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                      .getText());
                                                                               Fundtable.put("ToFundName_" + tofu,
                                                                                                   Web.getDriver().findElement(By.xpath(
                                                                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                      .getText());
                                                                               Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                   "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                      + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                   false);
                                                                               /*
                                                                               * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                               * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                               * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                               * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                               */

                                                                                System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                      }

                                                                      else {

                                                                               // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                                System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                               Fundtable.put("ToFundValue_" + tofu,
                                                                                                   Stock.GetParameterValue("FTtransferTO" + tofu));
                                                                                System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                               Fundtable.put("ToFundNumer_" + tofu,
                                                                                                   Web.getDriver().findElement(By.xpath(
                                                                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                      .getText());
                                                                               Fundtable.put("ToFundName_" + tofu,
                                                                                                   Web.getDriver().findElement(By.xpath(
                                                                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                      .getText());
                                                                               Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                   "[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
                                                                                                                      + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                   false);
                                                                               /*
                                                                               * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                               * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                               * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                               * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                               * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                               * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                               */
                                                                      }

                                                                      if (cfundcnt == cfundnumber) {
                                                                               cfundnumber = 0;
                                                                               if (Noncfundnumber >= 1) {
                                                                                         i = multifundnumber;
                                                                               } else {
                                                                                         i = (multifundnumber + 1);
                                                                               }
                                                                               break;
                                                                      } else {
                                                                               cfundcnt = cfundcnt + 1;
                                                                      }
                                                                      tofu = tofu + 1;
                                                            }

                                                   }

                                                   if (Cfund) {
                                                            System.out.println("Cfund Displayed");
                                                   } else {
                                                            System.out.println("No Cfund Displayed");
                                                   }
                                         } else {

                                                   // Fundtable.put("ToFundValue_"+tofu,too3);
                                                   Web.getDriver().findElement(By.xpath(
                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                      .click();
                                                   Thread.sleep(5000);
                                                   Web.getDriver()
                                                                      .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                         + Topercent + "]/input"))
                                                                      .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

                                                   Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                      .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                      .getText());
                                                   Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                      .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                      .getText());
                                                   // Fundtable.put("ToFundValue_"+cnt,
                                                   // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                                   if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
                                                            String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
                                                            Double amount = Double.parseDouble(splitvalue[0]);
                                                            Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                            String toString = Double.toString(Tofundvalue);

                                                            String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                            String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                             too3 = too1 + too2;
                                                            Fundtable.put("ToFundValue_" + cnt, too3);
                                                            frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                            Reporter.logEvent(Status.INFO,
                                                                               "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                               "[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
                                                                                                   + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                               false);

                                                   } else {
                                                            Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
                                                            frmFundtotal = frmFundtotal
                                                                               + Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
                                                            Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                               "[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
                                                                                                   + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                               false);
                                                   }

                                                   System.out.println(i);
                                                   System.out.println(Web.getDriver().findElement(By.xpath(
                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                      .getText());
                                                   System.out.println(Web.getDriver().findElement(By.xpath(
                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                      .getText());
                                                   System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                                   // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                                   // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                                   // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                         }

                               }

                      }

            }
                  else {

                      System.out.println("Table has Less row number than required Fund numbers");
            }

                  if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
                            frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
                  }
                  
              }
          
          
          
          
          
        


}



//****************************************************************************************************************************          
    /**
    * Method is used in Fund Transfer test case to enter the Fund for AMount type
    * 
     * @author Anjali
    * @param
    * @param
    * @return
    */
    public static void CostaverageTransferfund_EContract() throws InterruptedException {

             try {
                       Thread.sleep(2000);
             } catch (Exception e) {

             }

             // String multfund = Stock.getConfigParam("MultipleFund");

             int multifundnumber = Integer.parseInt(Stock.GetParameterValue("MultipleFund"));
             int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
             int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));

             // int initialvalue;
             double frmfundvalue = 0;
             boolean Cfund = false;
             double frmfundtotpercentage = 0;
                                  

             
            
             
         
             String FromfundNumber = null;
             int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th")).size();
             int Frompercent = 0;
             int Topercent = 0;
             int valuehead = 0;
             String percentfrom = "From Percent";
             String amountfrom = "From Amount";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(percentfrom) || fud.equalsIgnoreCase(amountfrom)) {
                                Frompercent = i;
                                break;
                       }
             }
             String percentTo = "To Percent";
             String amountTo = "To Amount";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(amountTo) || fud.equalsIgnoreCase(percentTo)) {
                                Topercent = i;
                                break;
                       }
             }

             String val = "Fund Value";
             for (int i = 1; i <= num; i++) {
                       String fud = Web.getDriver()
                                          .findElement(By.xpath("//table[@id='mainform:TransferFund']/thead/tr/th[" + i + "]")).getText();
                       if (fud.equalsIgnoreCase(val)) {
                                valuehead = i;
                                break;
                       }
             }

             int cnt;
             int tofu = 0;
             String too3 = null;
             int tbrow = Web.getDriver().findElements(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr")).size();
             if (System.getProperty("Fromtransfer") == null)
             { 
                 if (tbrow > multifundnumber) {
                     for (int i = 1; i <= multifundnumber + 1; i++) {
                              if (i == 1) {
                                        Fundtable.put("FundNumer_" + i,
                                                           Web.getDriver()
                                                                              .findElement(
                                                                                                  By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                              .getText());
                                        Fundtable.put("FundName_" + i,
                                                           Web.getDriver()
                                                                              .findElement(
                                                                                                  By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                              .getText());

                                        // String getvalue =
                                        // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                        FromfundNumber = Fundtable.get("FundNumer_" + i);
                                        Web.getDriver().findElement(By.xpath(
                                                           "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                           .click();
                                        Web.getDriver().findElement(By.xpath(
                                                           "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                            .sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

                                        Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                           "[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
                                        // Fundtable.put
                                        /*
                                        * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                        * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                        */

                                        // String splitamt1 = splitamt[0].trim().toString();
                                        String fFundvalue = null;
                                        for (String key : GawFundOLD.keySet()) {

                                                                                String temp = GawFundOLD.get(key);
                                                                                
                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                fFundvalue = temp;
                                                                                }
                                        }
                                       
                                        //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                     //   fFundvalue = fFundvalue.trim().toString();

                                    /*    String[] delimit = fFundvalue.split("[$]");
                                        String arr1[] = null;
                                        if (delimit[1].contains(",")) {
                                                  arr1 = delimit[1].split(",");

                                        }

                                        if (arr1.length > 0) {

                                                 String foo = arr1[0];
                                                  for (int a = 1; a < arr1.length; a++) {
                                                           foo = foo + arr1[a];

                                                  }
                                                  fFundvalue = foo;
                                        } else {
                                                  fFundvalue = delimit[1].trim().toString();
                                        }*/

                                        /// ********************************************

                                        if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
                                                  String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                  // String splitamt1 = splitamt[0].trim().toString();

                                                  double x = Double.parseDouble(splitamt[0]) / 100;
                                                  // double y = Double.parseDouble(Delimit1.toString());
                                                  double y = Double.parseDouble(fFundvalue);

                                                  // y = Double.parseDouble(df2.format(fFundvalue));
                                                  // double z = x * y;
                                                  System.out.println(df2.format(y));

                                                  frmfundvalue = x * y;

                                                  // add percentage value

                                                  String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                                  frmFundtotal = x * Double.parseDouble(paymtAmount);

                                                  // String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                                  // String[] splitamttofund =
                                                  // Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                  /*
                                                  * Double amount = Double.parseDouble(splitamt[0]);
                                                  * 
                                                   * 
                                                   * 
                                                   * Double Tofundvalue = (amount/100)* frmfundvalue;
                                                  */

                                                  // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                  // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                  // *********************************************************************************************
                                                  /*
                                                  * String toString = Double.toString(Tofundvalue);
                                                  * 
                                                   * 
                                                   * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                  * 
                                                   * String too2 =toString.substring(toString.lastIndexOf("."),
                                                  * toString.lastIndexOf(".")+3);
                                                  * 
                                                   * too3 = too1+too2;
                                                  */
                                                  // *********************************************************************************************

                                        } else {

                                                  // String splitamt1 = splitamt[0].trim().toString();

                                                  double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
                                                  // double y = Double.parseDouble(Delimit1.toString());
                                                  double y = Double.parseDouble(fFundvalue);

                                                  // y = Double.parseDouble(df2.format(fFundvalue));
                                                  // double z = x * y;
                                                  System.out.println(df2.format(y));

                                                  frmfundvalue = y - x;

                                                  // Stock.GetParameterValue("Ftfromtransfer")
                                                  // frmFundtotal = Double.parseDouble("PaymentAmount") -
                                                  // Double.parseDouble("Ftfromtransfer");

                                                  // add percentage value
                                        }

                                        System.out.println(frmfundvalue);
                                        // *********************************************

                                        String tostring = Double.toString(frmfundvalue);

                                        // Fundtable.put("FromFundValue_"+i,tostring);
                                        // Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
/*                                             String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

                                        String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

                                        String foo3 = foo1 + foo2;*/

                                        // Fundtable.put("FromFundValue_"+i,new
                                        // DecimalFormat("##.##").format(frmfundvalue).toString());

                                        Fundtable.put("FromFundValue_" + i, tostring);

                                        System.out.println(Fundtable.get("FromFundValue_" + i));

                                        /*
                                        * } else {
                                        * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
                                        * 
                                         * 
                                         * 
                                         * System.out.println(Fundtable.get("FromFundValue_"+i)); }
                                        */

                              } else {
                                        cnt = i - 1;
                                        if (cfundnumber >= 1) {
                                                  int cfundcnt = 1;
                                                  tofu = 1;
                                                  // for (int j=2; j<FundTableTB.size();j++) {
                                                  for (int j = 2; j < tbrow; j++) {

                                                           String str = Web.getDriver()
                                                                              .findElement(By.xpath(
                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                              .getText();
                                                           System.out.println(str);
                                                           if (str.equalsIgnoreCase("c")) {
                                                                     Cfund = true;
                                                                    

                                                                     Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                        + j + "]/td[" + Topercent + "]/input")).click();
                                                                     
                                                                     Thread.sleep(5000);
                                                                     // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                     Web.getDriver()
                                                                                        .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                           + "]/td[" + Topercent + "]/input"))
                                                                                        .sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                     // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                     if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
                                                                              // tofund
                                                                              String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
                                                                              Double amount = Double.parseDouble(splitamtf[0]);

                                                                              Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                              String toString = Double.toString(Tofundvalue);

                                                                              String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                              String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                                  toString.lastIndexOf(".") + 3);

                                                                              too3 = too1 + too2;
                                                                              // tofund
                                                                              // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                              // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                              /*
                                                                              * String toString = Double.toString(Tofundvalue);
                                                                              * 
                                                                               * 
                                                                               * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                              * 
                                                                               * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                              * toString.lastIndexOf(".")+3);
                                                                              * 
                                                                               * String too3 = too1+too2;
                                                                              */
                                                                              // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                              // Fundtable.put("ToFundValue_"+tofu,new
                                                                              // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                              // Double amount = Double.parseDouble(splitamt[0]);

                                                                              // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                              Fundtable.put("ToFundValue_" + tofu, too3);

                                                                              Fundtable.put("ToFundNumer_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                     .getText());
                                                                              Fundtable.put("ToFundName_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                     .getText());
                                                                              Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                  "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                     + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                  false);
                                                                              /*
                                                                              * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                              * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                              */

                                                                               System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                     }

                                                                     else {

                                                                              // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                               System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                              Fundtable.put("ToFundValue_" + tofu,
                                                                                                  Stock.GetParameterValue("FTtransferTO" + tofu));
                                                                               System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                              Fundtable.put("ToFundNumer_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                     .getText());
                                                                              Fundtable.put("ToFundName_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                     .getText());
                                                                              Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                  "[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
                                                                                                                     + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                  false);
                                                                              /*
                                                                              * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                              * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                              * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                              * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                              */
                                                                     }

                                                                     if (cfundcnt == cfundnumber) {
                                                                              cfundnumber = 0;
                                                                              if (Noncfundnumber >= 1) {
                                                                                        i = multifundnumber;
                                                                              } else {
                                                                                        i = (multifundnumber + 1);
                                                                              }
                                                                              break;
                                                                     } else {
                                                                              cfundcnt = cfundcnt + 1;
                                                                     }
                                                                     tofu = tofu + 1;
                                                           }

                                                  }

                                                  if (Cfund) {
                                                           System.out.println("Cfund Displayed");
                                                  } else {
                                                           System.out.println("No Cfund Displayed");
                                                  }
                                        } else {

                                                  // Fundtable.put("ToFundValue_"+tofu,too3);
                                                  Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                     .click();
                                                  Thread.sleep(5000);
                                                  Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                        + Topercent + "]/input"))
                                                                     .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

                                                  Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                     .getText());
                                                  Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                     .getText());
                                                  // Fundtable.put("ToFundValue_"+cnt,
                                                  // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                                  if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
                                                           String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
                                                           Double amount = Double.parseDouble(splitvalue[0]);
                                                           Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                           String toString = Double.toString(Tofundvalue);

                                                           String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                           String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                            too3 = too1 + too2;
                                                           Fundtable.put("ToFundValue_" + cnt, too3);
                                                           frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                           Reporter.logEvent(Status.INFO,
                                                                              "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                              "[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
                                                                                                  + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                              false);

                                                  } else {
                                                           Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
                                                           frmFundtotal = frmFundtotal
                                                                              + Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                              "[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
                                                                                                  + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                              false);
                                                  }

                                                  System.out.println(i);
                                                  System.out.println(Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                     .getText());
                                                  System.out.println(Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                     .getText());
                                                  System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                                  // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                                  // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                                  // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                        }

                              }

                     }

           } else {

               System.out.println("Table has Less row number than required Fund numbers");
     }

           if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
                     frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
           }
}
             
             else if (System.getProperty("Fromtransfer").trim().length() > 0)
             {
                 if (tbrow > multifundnumber) {
                     for (int i = 1; i <= multifundnumber + 1; i++) {
                              if (i == 1) {
                                        Fundtable.put("FundNumer_" + i,
                                                           Web.getDriver()
                                                                              .findElement(
                                                                                                  By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                              .getText());
                                        Fundtable.put("FundName_" + i,
                                                           Web.getDriver()
                                                                              .findElement(
                                                                                                  By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                              .getText());

                                        // String getvalue =
                                        // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                        FromfundNumber = Fundtable.get("FundNumer_" + i);
                                        Web.getDriver().findElement(By.xpath(
                                                           "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                           .click();
                                       
                                        Web.getDriver().findElement(By.xpath(
                                                "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                 .sendKeys(System.getProperty("Fromtransfer").trim());
                                        Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                "[" + System.getProperty("Fromtransfer") + "] transfered to other funds", false);
                                        
                                        
                                        
                                  
                                        
                                      // Fundtable.put
                                        /*
                                        * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                        * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                        */

                                        // String splitamt1 = splitamt[0].trim().toString();
                                        String fFundvalue = null;
                                        for (String key : GawFundOLD.keySet()) {

                                                                                String temp = GawFundOLD.get(key);
                                                                                
                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                fFundvalue = temp;
                                                                                }
                                        }
                                       
                                        //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                     //   fFundvalue = fFundvalue.trim().toString();

                                    /*    String[] delimit = fFundvalue.split("[$]");
                                        String arr1[] = null;
                                        if (delimit[1].contains(",")) {
                                                  arr1 = delimit[1].split(",");

                                        }

                                        if (arr1.length > 0) {

                                                  String foo = arr1[0];
                                                  for (int a = 1; a < arr1.length; a++) {
                                                           foo = foo + arr1[a];

                                                  }
                                                  fFundvalue = foo;
                                        } else {
                                                  fFundvalue = delimit[1].trim().toString();
                                        }*/

                                        /// ********************************************

                                        
                                             if (System.getProperty("Fromtransfer").contains("%")) {
                                                  String[] splitamt = System.getProperty("Fromtransfer").split("%");

                                                  // String splitamt1 = splitamt[0].trim().toString();

                                                  double x = Double.parseDouble(splitamt[0]) / 100;
                                                  double y = Double.parseDouble(fFundvalue);

                                                  System.out.println(df2.format(y));

                                                  frmfundvalue = x * y;

                                                  // add percentage value

                                                  String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                                  frmFundtotal = x * Double.parseDouble(paymtAmount);



                                        } else {

                                                  

                                                  double x = Double.parseDouble(System.getProperty("Fromtransfer"));
                                                  double y = Double.parseDouble(fFundvalue);

                                                 
                                                  System.out.println(df2.format(y));

                                                  frmfundvalue = y - x;

                                                
                                        }

                                        System.out.println(frmfundvalue);
                                       

                                        String tostring = Double.toString(frmfundvalue);



                                        Fundtable.put("FromFundValue_" + i, tostring);

                                        System.out.println(Fundtable.get("FromFundValue_" + i));

                                       
                              } else {
                                        cnt = i - 1;
                                   /*     frmfundvalue = Double.parseDouble(System.getProperty("Fromtransfer"));
                                      double temp1=frmfundvalue/2;
                                        String frmfundtotpercentage11=String.valueOf(temp1);*/
                                 

                                        if (cfundnumber >= 1) {
                                                  int cfundcnt = 1;
                                                  tofu = 1;
                                                  // for (int j=2; j<FundTableTB.size();j++) {
                                                  for (int j = 2; j < tbrow; j++) {

                                                           String str = Web.getDriver()
                                                                              .findElement(By.xpath(
                                                                                                  "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                              .getText();
                                                           frmfundvalue = Double.parseDouble(System.getProperty("Fromtransfer"));
                                                                   
                                                                   double temp1=frmfundvalue/2;
                                                                  
                                                                   String frmfundtotpercentage11=String.valueOf(temp1);
                                                                  
                                                           System.out.println(str);
                                                           if (str.equalsIgnoreCase("c")) {
                                                                     Cfund = true;
                                                                    
                                                                     
                                                                       
                                                                                   

                                                                     Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                        + j + "]/td[" + Topercent + "]/input")).click();
                                                                     
                                                                     Thread.sleep(5000);
                                                                     // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                     Web.getDriver()
                                                                                        .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                           + "]/td[" + Topercent + "]/input"))
                                                                                        .sendKeys(frmfundtotpercentage11);

                                                                     // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                     if (frmfundtotpercentage11.contains("%")) {
                                                                              // tofund
                                                                              String[] splitamtf = frmfundtotpercentage11.split("%");
                                                                              Double amount = Double.parseDouble(splitamtf[0]);

                                                                              Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                              String toString = Double.toString(Tofundvalue);

                                                                              String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                              String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                                  toString.lastIndexOf(".") + 3);

                                                                              too3 = too1 + too2;
                                                                              // tofund
                                                                              // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                              // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                              /*
                                                                              * String toString = Double.toString(Tofundvalue);
                                                                              * 
                                                                               * 
                                                                               * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                              * 
                                                                               * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                              * toString.lastIndexOf(".")+3);
                                                                              * 
                                                                               * String too3 = too1+too2;
                                                                              */
                                                                              // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                              // Fundtable.put("ToFundValue_"+tofu,new
                                                                              // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                              // Double amount = Double.parseDouble(splitamt[0]);

                                                                              // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                              Fundtable.put("ToFundValue_" + tofu, too3);

                                                                              Fundtable.put("ToFundNumer_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                     .getText());
                                                                              Fundtable.put("ToFundName_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                     .getText());
                                                                            /*  Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                  "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                     + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                  false);
                                                                            */ 
                                                                              
                                                                              Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                      "[" + frmfundtotpercentage11 + "%] transfered to ["
                                                                                                         + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                      false);
                                                                              
                                                                              /*
                                                                              * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                              * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                              */

                                                                               System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                     }

                                                                     else {   
                                                                                  
                                                                    

                                                                              // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                               System.out.println(frmfundtotpercentage11);

                                                                               Fundtable.put("ToFundValue_" + tofu,
                                                                                                frmfundtotpercentage11);
                                                                                                 
                                                                               System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                              Fundtable.put("ToFundNumer_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                     .getText());
                                                                              Fundtable.put("ToFundName_" + tofu,
                                                                                                  Web.getDriver().findElement(By.xpath(
                                                                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                     .getText());
                                                                              Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                  "[$" + frmfundtotpercentage11 + "] transfered to ["
                                                                                                                     + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                  false);
                                                                              /*
                                                                              * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                              * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                              * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                              * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                              * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                              */
                                                                     }

                                                                     if (cfundcnt == cfundnumber) {
                                                                              cfundnumber = 0;
                                                                              if (Noncfundnumber >= 1) {
                                                                                        i = multifundnumber;
                                                                              } else {
                                                                                        i = (multifundnumber + 1);
                                                                              }
                                                                              break;
                                                                     } else {
                                                                              cfundcnt = cfundcnt + 1;
                                                                     }
                                                                     tofu = tofu + 1;
                                                           }

                                                  }

                                                  if (Cfund) {
                                                           System.out.println("Cfund Displayed");
                                                  } else {
                                                           System.out.println("No Cfund Displayed");
                                                  }
                                        } else {

                                                  // Fundtable.put("ToFundValue_"+tofu,too3);
                                                
                                                   
                                                   frmfundvalue = Double.parseDouble(System.getProperty("Fromtransfer"));
                                                       double temp1=frmfundvalue/2;
                                               String frmfundtotpercentage11=String.valueOf(temp1);
                                                  
                                             
                                               
                                                   
                                                   
                                                   Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                     .click();
                                                  Thread.sleep(4000);
                                                  /*Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                        + Topercent + "]/input"))
                                                                     .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));*/
                                                  Web.getDriver().findElement(By.xpath(
                                                          "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                          .click();
                                                 Thread.sleep(3000);
                                                  Web.getDriver()
                                                  .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                     + Topercent + "]/input"))
                                                  .sendKeys(frmfundtotpercentage11);


                                                  Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                     .getText());
                                                  Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                     .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                     .getText());
                                                  // Fundtable.put("ToFundValue_"+cnt,
                                                  // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                                  if (frmfundtotpercentage11.contains("%")) {
                                                           String[] splitvalue = frmfundtotpercentage11.split("[%]");
                                                           Double amount = Double.parseDouble(splitvalue[0]);
                                                           Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                           String toString = Double.toString(Tofundvalue);

                                                           String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                           String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                            too3 = too1 + too2;
                                                           Fundtable.put("ToFundValue_" + cnt, too3);
                                                           frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                           Reporter.logEvent(Status.INFO,
                                                                              "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                              "[" + frmfundtotpercentage11 + "%] transfered to ["
                                                                                                  + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                              false);

                                                  } else {
                                                           Fundtable.put("ToFundValue_" + cnt, frmfundtotpercentage11);
                                                           frmFundtotal = frmFundtotal
                                                                              + Double.parseDouble(frmfundtotpercentage11);
                                                           Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                              "[$" + frmfundtotpercentage11 + "] transfered to ["
                                                                                                  + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                              false);
                                                  }

                                                  System.out.println(i);
                                                  System.out.println(Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                     .getText());
                                                  System.out.println(Web.getDriver().findElement(By.xpath(
                                                                     "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                     .getText());
                                                  System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                                  // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                                  // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                                  // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                        }
                                        

                              }

                     }

           }
                 else {

                     System.out.println("Table has Less row number than required Fund numbers");
           }
                 
                 frmfundvalue = Double.parseDouble(System.getProperty("Fromtransfer"));
                        double temp1=frmfundvalue/2;
                String frmfundtotpercentage11=String.valueOf(temp1);


                 if (frmfundtotpercentage11.contains("%")) {
                           frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
                 }

             }
                 
                 else {
                                 
                     if (tbrow > multifundnumber) {
                         for (int i = 1; i <= multifundnumber + 1; i++) {
                                  if (i == 1) {
                                            Fundtable.put("FundNumer_" + i,
                                                               Web.getDriver()
                                                                                  .findElement(
                                                                                                      By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                                  .getText());
                                            Fundtable.put("FundName_" + i,
                                                               Web.getDriver()
                                                                                  .findElement(
                                                                                                      By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                                  .getText());

                                            // String getvalue =
                                            // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[1]/td[5]/span")).getText();
                                            FromfundNumber = Fundtable.get("FundNumer_" + i);
                                            Web.getDriver().findElement(By.xpath(
                                                               "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                               .click();
                                            Web.getDriver().findElement(By.xpath(
                                                               "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Frompercent + "]/input"))
                                                                .sendKeys(Stock.GetParameterValue("Ftfromtransfer"));

                                            Reporter.logEvent(Status.INFO, "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                               "[" + Stock.GetParameterValue("Ftfromtransfer") + "] transfered to other funds", false);
                                            // Fundtable.put
                                            /*
                                            * if(Stock.GetParameterValue("Ftfromtransfer").contains("%")) { String[]
                                            * splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                            */

                                            // String splitamt1 = splitamt[0].trim().toString();
                                            String fFundvalue = null;
                                            for (String key : GawFundOLD.keySet()) {

                                                                                                String temp = GawFundOLD.get(key);
                                                                                                
                                                                                                if(key.equalsIgnoreCase(FromfundNumber)) {
                                                                                                                fFundvalue = temp;
                                                                                                }
                                            }
                                           
                                            //fFundvalue = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + valuehead + "]/span")).getText();
                                         //   fFundvalue = fFundvalue.trim().toString();

                                        /*    String[] delimit = fFundvalue.split("[$]");
                                            String arr1[] = null;
                                            if (delimit[1].contains(",")) {
                                                      arr1 = delimit[1].split(",");

                                            }

                                            if (arr1.length > 0) {

                                                      String foo = arr1[0];
                                                      for (int a = 1; a < arr1.length; a++) {
                                                               foo = foo + arr1[a];

                                                      }
                                                     fFundvalue = foo;
                                            } else {
                                                      fFundvalue = delimit[1].trim().toString();
                                            }*/

                                            /// ********************************************

                                            if (Stock.GetParameterValue("Ftfromtransfer").contains("%")) {
                                                      String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                      // String splitamt1 = splitamt[0].trim().toString();

                                                      double x = Double.parseDouble(splitamt[0]) / 100;
                                                      // double y = Double.parseDouble(Delimit1.toString());
                                                      double y = Double.parseDouble(fFundvalue);

                                                      // y = Double.parseDouble(df2.format(fFundvalue));
                                                      // double z = x * y;
                                                      System.out.println(df2.format(y));

                                                      frmfundvalue = x * y;

                                                      // add percentage value

                                                      String paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));

                                                      frmFundtotal = x * Double.parseDouble(paymtAmount);

                                                      // String[] splitamt = Stock.GetParameterValue("Ftfromtransfer").split("%");
                                                      // String[] splitamttofund =
                                                      // Stock.GetParameterValue("Ftfromtransfer").split("%");

                                                      /*
                                                      * Double amount = Double.parseDouble(splitamt[0]);
                                                      * 
                                                       * 
                                                       * 
                                                       * Double Tofundvalue = (amount/100)* frmfundvalue;
                                                      */

                                                      // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                      // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                      // *********************************************************************************************
                                                      /*
                                                      * String toString = Double.toString(Tofundvalue);
                                                      * 
                                                       * 
                                                       * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                      * 
                                                       * String too2 =toString.substring(toString.lastIndexOf("."),
                                                      * toString.lastIndexOf(".")+3);
                                                      * 
                                                       * too3 = too1+too2;
                                                      */
                                                      // *********************************************************************************************

                                            } else {

                                                      // String splitamt1 = splitamt[0].trim().toString();

                                                      double x = Double.parseDouble(Stock.GetParameterValue("Ftfromtransfer"));
                                                      // double y = Double.parseDouble(Delimit1.toString());
                                                      double y = Double.parseDouble(fFundvalue);

                                                      // y = Double.parseDouble(df2.format(fFundvalue));
                                                      // double z = x * y;
                                                      System.out.println(df2.format(y));

                                                      frmfundvalue = y - x;

                                                      // Stock.GetParameterValue("Ftfromtransfer")
                                                      // frmFundtotal = Double.parseDouble("PaymentAmount") -
                                                      // Double.parseDouble("Ftfromtransfer");

                                                      // add percentage value
                                            }

                                            System.out.println(frmfundvalue);
                                            // *********************************************

                                            String tostring = Double.toString(frmfundvalue);

                                            // Fundtable.put("FromFundValue_"+i,tostring);
                                            // Fundtable.put("FromFundValue_"+i,String.format("%.2f", tostring));
    /*                                             String foo1 = tostring.substring(0, (tostring.lastIndexOf(".")));

                                            String foo2 = tostring.substring(tostring.lastIndexOf("."), tostring.lastIndexOf(".") + 3);

                                            String foo3 = foo1 + foo2;*/

                                            // Fundtable.put("FromFundValue_"+i,new
                                            // DecimalFormat("##.##").format(frmfundvalue).toString());

                                            Fundtable.put("FromFundValue_" + i, tostring);

                                            System.out.println(Fundtable.get("FromFundValue_" + i));

                                            /*
                                            * } else {
                                            * Fundtable.put("FromFundValue_"+i,Stock.GetParameterValue("Ftfromtransfer"));
                                            * 
                                             * 
                                             * 
                                             * System.out.println(Fundtable.get("FromFundValue_"+i)); }
                                            */

                                  } else {
                                            cnt = i - 1;
                                            if (cfundnumber >= 1) {
                                                      int cfundcnt = 1;
                                                      tofu = 1;
                                                      // for (int j=2; j<FundTableTB.size();j++) {
                                                      for (int j = 2; j < tbrow; j++) {

                                                               String str = Web.getDriver()
                                                                                  .findElement(By.xpath(
                                                                                                      "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[4]/span"))
                                                                                  .getText();
                                                               System.out.println(str);
                                                               if (str.equalsIgnoreCase("c")) {
                                                                         Cfund = true;
                                                                        

                                                                         Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["
                                                                                            + j + "]/td[" + Topercent + "]/input")).click();
                                                                         
                                                                         Thread.sleep(5000);
                                                                         // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[8]/input")).sendKeys(Stock.GetParameterValue("FTtransferTO"+cnt));
                                                                         Web.getDriver()
                                                                                            .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + j
                                                                                                               + "]/td[" + Topercent + "]/input"))
                                                                                            .sendKeys(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                         // if(Stock.GetParameterValue("FTtransferTO"+cnt).contains("%"))
                                                                         if (Stock.GetParameterValue("FTtransferTO" + tofu).contains("%")) {
                                                                                  // tofund
                                                                                  String[] splitamtf = Stock.GetParameterValue("FTtransferTO" + tofu).split("%");
                                                                                  Double amount = Double.parseDouble(splitamtf[0]);

                                                                                  Double Tofundvalue = (amount / 100) * frmfundvalue;

                                                                                  String toString = Double.toString(Tofundvalue);

                                                                                  String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                                                  String too2 = toString.substring(toString.lastIndexOf("."),
                                                                                                      toString.lastIndexOf(".") + 3);

                                                                                  too3 = too1 + too2;
                                                                                  // tofund
                                                                                  // Fundtable.put("ToFundValue_"+cnt, Double.toString(Tofundvalue));
                                                                                  // Fundtable.put("ToFundValue_"+tofu, Double.toString(Tofundvalue));
                                                                                  /*
                                                                                  * String toString = Double.toString(Tofundvalue);
                                                                                  * 
                                                                                   * 
                                                                                   * String too1 = toString.substring(0,(toString.lastIndexOf(".")));
                                                                                  * 
                                                                                   * String too2 =toString.substring(toString.lastIndexOf("."),
                                                                                  * toString.lastIndexOf(".")+3);
                                                                                  * 
                                                                                   * String too3 = too1+too2;
                                                                                  */
                                                                                  // Fundtable.put("ToFundValue_"+tofu, String.format("%.2f", toString));
                                                                                  // Fundtable.put("ToFundValue_"+tofu,new
                                                                                  // DecimalFormat("##.##").format(Tofundvalue).toString());

                                                                                  // Double amount = Double.parseDouble(splitamt[0]);

                                                                                  // Double Tofundvalue = (amount/100)* frmfundvalue;

                                                                                  Fundtable.put("ToFundValue_" + tofu, too3);

                                                                                  Fundtable.put("ToFundNumer_" + tofu,
                                                                                                      Web.getDriver().findElement(By.xpath(
                                                                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                         .getText());
                                                                                  Fundtable.put("ToFundName_" + tofu,
                                                                                                      Web.getDriver().findElement(By.xpath(
                                                                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                         .getText());
                                                                                  Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                      "[" + Stock.GetParameterValue("FTtransferTO" + tofu) + "%] transfered to ["
                                                                                                                         + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                      false);
                                                                                  /*
                                                                                  * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                  * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                                  * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                  * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                                  */

                                                                                   System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                         }

                                                                         else {

                                                                                  // Fundtable.put("ToFundValue_"+tofu,Stock.getConfigParam("FTtransferTO"+tofu));
                                                                                   System.out.println(Stock.GetParameterValue("FTtransferTO" + tofu));

                                                                                  Fundtable.put("ToFundValue_" + tofu,
                                                                                                      Stock.GetParameterValue("FTtransferTO" + tofu));
                                                                                   System.out.println(Fundtable.get("ToFundValue_" + tofu));
                                                                                  Fundtable.put("ToFundNumer_" + tofu,
                                                                                                      Web.getDriver().findElement(By.xpath(
                                                                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[1]"))
                                                                                                                         .getText());
                                                                                  Fundtable.put("ToFundName_" + tofu,
                                                                                                      Web.getDriver().findElement(By.xpath(
                                                                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + j + "]/td[2]"))
                                                                                                                         .getText());
                                                                                  Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                                      "[$" + Stock.GetParameterValue("FTtransferTO" + tofu) + "] transfered to ["
                                                                                                                         + Fundtable.get("ToFundNumer_" + tofu) + "]",
                                                                                                      false);
                                                                                  /*
                                                                                  * Fundtable.put("ToFundValue_"+cnt,Stock.getConfigParam("FTtransferTO"+cnt));
                                                                                  * System.out.println(Fundtable.get("ToFundValue_"+cnt));
                                                                                  * Fundtable.put("ToFundNumer_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                  * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[1]")).getText());
                                                                                  * Fundtable.put("ToFundName_"+cnt, Web.getDriver().findElement(By.xpath(
                                                                                  * "//table[@id='mainform:TransferFund']/tbody/tr["+j+"]/td[2]")).getText());
                                                                                  */
                                                                         }

                                                                         if (cfundcnt == cfundnumber) {
                                                                                  cfundnumber = 0;
                                                                                  if (Noncfundnumber >= 1) {
                                                                                            i = multifundnumber;
                                                                                  } else {
                                                                                            i = (multifundnumber + 1);
                                                                                  }
                                                                                  break;
                                                                         } else {
                                                                                  cfundcnt = cfundcnt + 1;
                                                                         }
                                                                         tofu = tofu + 1;
                                                               }

                                                      }

                                                      if (Cfund) {
                                                               System.out.println("Cfund Displayed");
                                                      } else {
                                                               System.out.println("No Cfund Displayed");
                                                      }
                                            } else {

                                                      // Fundtable.put("ToFundValue_"+tofu,too3);
                                                      Web.getDriver().findElement(By.xpath(
                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                         .click();
                                                      Thread.sleep(5000);
                                                      Web.getDriver()
                                                                         .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td["
                                                                                            + Topercent + "]/input"))
                                                                         .sendKeys(Stock.GetParameterValue("FTtransferTO" + cnt));

                                                      Fundtable.put("ToFundNumer_" + cnt, Web.getDriver()
                                                                         .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[1]"))
                                                                         .getText());
                                                      Fundtable.put("ToFundName_" + cnt, Web.getDriver()
                                                                         .findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[2]"))
                                                                         .getText());
                                                      // Fundtable.put("ToFundValue_"+cnt,
                                                      // Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]")).getText());

                                                      if (Stock.GetParameterValue("FTtransferTO" + cnt).contains("%")) {
                                                               String[] splitvalue = Stock.GetParameterValue("FTtransferTO" + cnt).split("[%]");
                                                               Double amount = Double.parseDouble(splitvalue[0]);
                                                               Double Tofundvalue = (amount) / 100 * frmfundvalue;

                                                               String toString = Double.toString(Tofundvalue);

                                                               String too1 = toString.substring(0, (toString.lastIndexOf(".")));

                                                               String too2 = toString.substring(toString.lastIndexOf("."), toString.lastIndexOf(".") + 3);

                                                                too3 = too1 + too2;
                                                               Fundtable.put("ToFundValue_" + cnt, too3);
                                                               frmfundtotpercentage = frmfundtotpercentage + Double.parseDouble(splitvalue[0]);
                                                               Reporter.logEvent(Status.INFO,
                                                                                  "From Fund Number [" + Fundtable.get("FundNumer_" + i) + " ] ",
                                                                                  "[" + Stock.GetParameterValue("FTtransferTO" + cnt) + "%] transfered to ["
                                                                                                      + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                                  false);

                                                      } else {
                                                               Fundtable.put("ToFundValue_" + cnt, Stock.GetParameterValue("FTtransferTO" + cnt));
                                                               frmFundtotal = frmFundtotal
                                                                                  + Double.parseDouble(Stock.GetParameterValue("FTtransferTO" + cnt));
                                                               Reporter.logEvent(Status.INFO, "From Fund Number [" + FromfundNumber + " ] ",
                                                                                  "[$" + Stock.GetParameterValue("FTtransferTO" + cnt) + "] transfered to ["
                                                                                                      + Fundtable.get("ToFundNumer_" + cnt) + "]",
                                                                                  false);
                                                      }

                                                      System.out.println(i);
                                                      System.out.println(Web.getDriver().findElement(By.xpath(
                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]/input"))
                                                                         .getText());
                                                      System.out.println(Web.getDriver().findElement(By.xpath(
                                                                         "//table[@id='mainform:TransferFund']/tbody/tr[" + i + "]/td[" + Topercent + "]"))
                                                                         .getText());
                                                      System.out.println(Fundtable.get("ToFundValue_" + cnt));

                                                      // Reporter.logEvent(Status.INFO,"From Fund Number ["+FromfundNumber+" ] ",
                                                      // "["+Stock.GetParameterValue("FTtransferTO"+cnt)+"%] transfered to
                                                      // ["+Fundtable.get("ToFundNumer_"+cnt)+"]", false);
                                            }

                                  }

                         }

               }
                     else {

                         System.out.println("Table has Less row number than required Fund numbers");
               }

                     if (Stock.GetParameterValue("FTtransferTO" + 1).contains("%")) {
                               frmFundtotal = (frmfundtotpercentage / 100) * frmFundtotal;
                     }
                     
                 }
             
             
             
             
             
           


    }

//******************************************************************************************************************************************************
     
     
    
}