package pageojects.wmA.Search;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class DetailsSearch extends LoadableComponent<DetailsSearch>{
	
	@FindBy(id="mainform:partyProfile")
	private  WebElement Partyprofile_BT;
	
	@FindBy(xpath = "//table[@id='mainform:PortfolioPolicyCandidate']/tbody/tr")
	private  List<WebElement> Portfolio;
	
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
		 
		 if (fieldName.trim().equalsIgnoreCase("PartyProfile_Button")) {
				return this.Partyprofile_BT;
			}
			
		 
		 Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	 
	
	public void Selectcontractrow() {
		Web.waitForElement(Partyprofile_BT);
		String ConID;
	
				 if(System.getProperty("ContractID")==null){
						 ConID = Common.Contractinfo.get("Contractid");
					}
					else if( System.getProperty("ContractID").trim().length() > 0){
						 ConID = System.getProperty("ContractID");	
					}
					else {
						 ConID = Common.Contractinfo.get("Contractid");
						 }
		for(int i=1;i<=Portfolio.size();i++) {
			String contid = Web.getDriver().findElement(By.xpath("//table[@id='mainform:PortfolioPolicyCandidate']/tbody/tr["+i+"]/td[1]")).getText();
			if(contid.equalsIgnoreCase(ConID)) {
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:PortfolioPolicyCandidate']/tbody/tr["+i+"]/td[1]")).click();
				break;
			}
		}
	}
	
	public DetailsSearch(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Partyprofile_BT);
		Assert.assertTrue(Web.isWebElementDisplayed(Partyprofile_BT),"Detail Search Page is Not Loaded\n");
	}

}
