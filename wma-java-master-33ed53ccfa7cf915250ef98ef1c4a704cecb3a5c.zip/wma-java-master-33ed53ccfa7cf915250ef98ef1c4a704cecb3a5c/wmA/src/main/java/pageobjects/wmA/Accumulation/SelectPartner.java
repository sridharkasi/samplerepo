package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class SelectPartner extends LoadableComponent<SelectPartner> {
	
	@FindBy(linkText = "Accumulation")
	private WebElement ContractAddLink;
	
	@FindBy(xpath = "//li[@id='accumulationMain']")
	private WebElement Mainmenu;
	
	@FindBy(xpath = "//li[@id='accumulationMain']/div/a")
	private WebElement submenu;
	
	@FindBy(id="mainform:contractEntryPartnerName")
	private WebElement selectPartner;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="nextbutton")
	private  WebElement NextButton;
	
	
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		
		if (fieldName.trim().equalsIgnoreCase("Submenu_contractAdd")) {
			return this.submenu;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Home_Button")) {
			return this.homebutton;
		}

		if (fieldName.trim().equalsIgnoreCase("Next_Button")) {
			return this.NextButton;
		}
		if (fieldName.trim().equalsIgnoreCase("SelectPartner_DrpDown")) {
			return this.selectPartner;
			
		}
		if (fieldName.trim().equalsIgnoreCase("accumulationlink")) {
			return this.ContractAddLink;
		}
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void clickcontractADD() throws InterruptedException {
		try {
		Web.waitForElement(Mainmenu);
		Common.ClickSubmenu(submenu);
		Reporter.logEvent(Status.PASS, "Click on Contract Add", " Selected from Accumulation tab", false);
	
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public void descriptionforcontract1_1(){
		Reporter.logEvent(Status.PASS, "Description", " Add Non-NY Smart Track II 5 Yr with No Rider", false);
		Reporter.logEvent(Status.PASS, "Test date", "Partner - Cambridge Investment research Base Plan - 13ST5Y ", false);
		
	}
	
	public void ClickNext() throws InterruptedException {
		try {
		Web.waitForElement(NextButton);
		Web.clickOnElement(NextButton);
		Reporter.logEvent(Status.PASS, "Next Button", "Clicked successfully", false);
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	private LoadableComponent<?> parent;
	public SelectPartner(LoadableComponent<?> parent){
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	public void selectpartner(String partner) throws InterruptedException {
		
		
		
		if(System.getProperty("PartnerName")==null )
		{
			Web.waitForElement(selectPartner);
			
			Common.selectbyvalue(selectPartner, partner);
		}
		else if(System.getProperty("PartnerName").trim().length() > 0)
		{
			Web.waitForElement(selectPartner);
			Web.clickOnElement(selectPartner);
			Common.selectbyvalue(selectPartner, Stock.getConfigParam(System.getProperty("PartnerName").trim()));
			//Common.selectbyvalue(selectPartner,System.getProperty("PartnerName").trim());
		}
		else
		{
			Web.waitForElement(selectPartner);
		
			Common.selectbyvalue(selectPartner, partner);
		}
		
	}
	
	
	
//	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());		

	}
		
	

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(ContractAddLink);
		Assert.assertTrue(Web.isWebElementDisplayed(ContractAddLink),"Landing Page is Not Loaded\n");
		
	}
	

}
