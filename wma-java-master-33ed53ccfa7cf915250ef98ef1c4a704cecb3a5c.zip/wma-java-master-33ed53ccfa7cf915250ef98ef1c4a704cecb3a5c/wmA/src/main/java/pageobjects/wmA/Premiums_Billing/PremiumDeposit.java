package pageobjects.wmA.Premiums_Billing;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class PremiumDeposit extends LoadableComponent<PremiumDeposit>{
	
	@FindBy(id="mainform:premiumPaymentEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	@FindBy(id="mainform:premiumPaymentPaymentAmount")
	private static WebElement PaymentAmount;
	
	@FindBy(id="mainform:premiumPaymentMemoCode")
	private static WebElement MemoCode_LB;
	
	@FindBy (id="realtimeselect")
	private  WebElement RealtimeDrpDwn;
	
	@FindBy (id="submitbutton")
	private  WebElement FinishButton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
			

			// My Accounts
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtime")) {
				return this.RealtimeDrpDwn;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Finishbtn")) {
				return this.FinishButton;
			}
			
								

			Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	 
	  public void VerifyErrorText(String expectedtext) {
			try {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
			
		}
			catch (Exception e) {
				Reporter.logEvent(Status.FAIL,"Display Expected error text messaage","took Longer than normal", true);
				e.printStackTrace();
			}	
		}
	
	 
	public void SelectMemoCode(String memo) throws InterruptedException {
		Web.waitForElement(MemoCode_LB);
		Web.selectDropDownOption(MemoCode_LB, memo);
		Thread.sleep(1500);
	}
	
	public void EnterPaymentAmount(String Amt) {
		
		if(System.getProperty("PaymentAmount")==null)
		{
			Web.waitForElement(PaymentAmount);
			Web.setTextToTextBox(PaymentAmount, Amt);
			 if(PaymentAmount.getAttribute("value").equalsIgnoreCase(Amt)) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+Amt+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+Amt+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("PaymentAmount").trim().length() > 0)
		{
			Web.waitForElement(PaymentAmount);
			Web.setTextToTextBox(PaymentAmount, System.getProperty("PaymentAmount"));
			 if(PaymentAmount.getAttribute("value").equalsIgnoreCase(System.getProperty("PaymentAmount"))) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+System.getProperty("PaymentAmount")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+System.getProperty("PaymentAmount")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(PaymentAmount);
			Web.setTextToTextBox(PaymentAmount, Amt);
			 if(PaymentAmount.getAttribute("value").equalsIgnoreCase(Amt)) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+Amt+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Payment Amount", "the Payment Amount is["+Amt+"] not entered sucessfully", true);
			 }
		}
	
	}
	
	public void EnterEffectiveDate(String Effectivedate) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, Effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(Effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Effective date", "the Effective date is["+Effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Effective date", "the Effective date is["+Effectivedate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB,  System.getProperty("TrxEffectiveDate"));
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase( System.getProperty("TrxEffectiveDate"))) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, Effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(Effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Premimum/bilings page enter the Effective date", "the Effective date is["+Effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Premimum/bilings page enter the Effective date", "the Effective date is["+Effectivedate+"] not entered sucessfully", true);
			 }
		}
		
	}
	
	
	public PremiumDeposit(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Effectivedate_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate_TB),"Premium/billings Page is Not Loaded\n");
		
	}

}
