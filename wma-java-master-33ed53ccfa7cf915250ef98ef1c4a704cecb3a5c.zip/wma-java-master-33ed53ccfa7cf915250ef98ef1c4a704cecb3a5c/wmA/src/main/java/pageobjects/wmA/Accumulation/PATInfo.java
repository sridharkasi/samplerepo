package pageobjects.wmA.Accumulation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class PATInfo extends LoadableComponent<PATInfo>{
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataFirstName")
	private  WebElement PAT_FirstName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataLastName")
	private  WebElement PAT_LastName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataTaxIdNumber")
	private  WebElement PAT_SSN_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataBirthdate_input")
	private  WebElement PAT_Dob_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataSexCode")
	private  WebElement PAT_Gender_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataStartDate_input")
	private  WebElement PAT_Startdate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataEndDate_input")
	private  WebElement PAT_enddate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataAddressLine1")
	private  WebElement PAT_Addres1_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataCity")
	private  WebElement PAT_City_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataState")
	private  WebElement PAT_State_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataZipPostalCode")
	private  WebElement PAT_Zip_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryPowerOfAttorneyDataZipPostalCode4")
	private  WebElement PAT_remaingZIP_TB;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("PATInfo_Gender")) {
			return this.PAT_Gender_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("PATInfo_State")) {
			return this.PAT_State_LB;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	
	public void EnterPATzipcode(String zip) {
		
		String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(PAT_Zip_TB, zip1);
		if(PAT_Zip_TB.getAttribute("value").equalsIgnoreCase(zip1)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", true);
		}
	}
	
	public void SelectPATstate (String state) {
	Web.selectDropDownOption(PAT_State_LB, state);
	
	}
	
	public void EnterPATcity(String city) {
		Web.setTextToTextBox(PAT_City_TB, city);
		if(PAT_City_TB.getAttribute("value").equalsIgnoreCase(city)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the City", "the City is["+ city+"] is Entered successfully", false);
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the City", "the City is["+ city+"] is Entered successfully", true);
		}
	}
	
	public void EnterPATaddressline1 (String addrss) {
		String Address = Common.AddressGenerator();
		Web.setTextToTextBox(PAT_Addres1_TB, Address);
		if(PAT_Addres1_TB.getAttribute("value").equalsIgnoreCase(Address)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", true);
		}
	}
	
	public void EnterPATenddate(String enddate) {
		Web.setTextToTextBox(PAT_enddate_TB, enddate);
		if(PAT_enddate_TB.getAttribute("value").equalsIgnoreCase(enddate)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", true);
		}
		}
	
	public void EnterPATStartdate(String sdate) {
		Web.setTextToTextBox(PAT_Startdate_TB, sdate);
		if(PAT_Startdate_TB.getAttribute("value").equalsIgnoreCase(sdate)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", true);
		}
	}
	
	public void SelectPATgender(String Gender) {
		Web.selectDropDownOption(PAT_Gender_LB, Gender);
	}
	
	public void EnterPATDOB(String dob) {
		Web.setTextToTextBox(PAT_Dob_TB, dob);
		if(PAT_Dob_TB.getAttribute("value").equalsIgnoreCase(dob)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", true);
		}
	}
	
	public void EnterPATssn(String ssn) {
		String SSN = Common.generateSSN();
		Web.setTextToTextBox(PAT_SSN_TB, SSN);
		if(PAT_SSN_TB.getAttribute("value").equalsIgnoreCase(SSN)) {
			lib.Reporter.logEvent(Status.PASS, "In the PAT Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", false);			
		}
		else {
			lib.Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", true);
		}
	}
	
	public void EnterPATLastNAme(String Lname) {
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(PAT_LastName_TB, Lnames);
		if(PAT_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", true);
		}
	}
	
	public void EnterPATFirstName (String Fname) throws InterruptedException {
		
		Web.waitForElement(PAT_FirstName_TB);
		String FirName = Common.randomvaildFirstname();
		Web.setTextToTextBox(PAT_FirstName_TB, FirName);
		if(PAT_FirstName_TB.getAttribute("value").equalsIgnoreCase(FirName)) {
			Reporter.logEvent(Status.PASS, "In the PAT Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the PAT Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", true);
		}
	}
	
	
	
	public void PATDetails(String Gentype,String DOB,String city,String state ,String Startdate) throws ParseException {
		Web.waitForElement(PAT_FirstName_TB);	
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(PAT_FirstName_TB, Fnames);
		if(PAT_FirstName_TB.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In PAT page Enter the payer First name", "The PAT First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In PAT page Enter the payer First name", "The PAT First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(PAT_LastName_TB);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(PAT_LastName_TB, Lnames);
		if(PAT_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In PAT page Enter the payer Last name", "The PAT Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In PAT page Enter the PAT Last name", "The PAT  Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(PAT_Gender_LB);
		Web.selectDropDownOption(PAT_Gender_LB, Gentype);
		Web.waitForElement(PAT_SSN_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(PAT_SSN_TB, ssn);
		Web.waitForElement(PAT_Dob_TB);		
		Web.setTextToTextBox(PAT_Dob_TB, DOB);
		
		if(PAT_Dob_TB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In PAT Info page Enter the DOB", "The PAT DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In PATInfo page Enter the  DOB", "The PAT DOB is ["+ DOB+"] entered Successfully", true);
		}
		
		if(System.getProperty("EffectiveDate")==null)
		{
			Web.waitForElement(PAT_Startdate_TB);
			 Web.setTextToTextBox(PAT_Startdate_TB, Startdate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(PAT_Startdate_TB);
			Web.setTextToTextBox(PAT_Startdate_TB, System.getProperty("EffectiveDate").trim());	
								
		}else {
			Web.waitForElement(PAT_Startdate_TB);
			 Web.setTextToTextBox(PAT_Startdate_TB, Startdate);
		}

		
		int z=1;
		String enddate;
		if(System.getProperty("EffectiveDate")==null)
		{
			
			enddate = Startdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(PAT_enddate_TB);
			 Web.setTextToTextBox(PAT_enddate_TB, enddate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0) {
			
		enddate = System.getProperty("EffectiveDate");
		enddate = enddate.replaceAll("[/]", "");
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(enddate));
		c.add(Calendar.YEAR, z); // number of days to add
		enddate = sdf.format(c.getTime());
		
			Web.waitForElement(PAT_enddate_TB);
			Web.setTextToTextBox(PAT_enddate_TB, enddate);	
								
		}else {
			enddate = Startdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(PAT_enddate_TB);
			 Web.setTextToTextBox(PAT_enddate_TB, enddate);
		}
		
		Web.waitForElement(PAT_Addres1_TB);	
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(PAT_Addres1_TB, address);
		if(PAT_Addres1_TB.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In PAT page Enter the address", "The PAT address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In PAT page Enter the address", "The PAT address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(PAT_City_TB);
				 Web.setTextToTextBox(PAT_City_TB, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(PAT_City_TB);
				Web.setTextToTextBox(PAT_City_TB, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(PAT_City_TB);
				 Web.setTextToTextBox(PAT_City_TB, city);
			}
			Web.waitForElement(PAT_Zip_TB);	
			String Zip = Common.AutoZipcode();
			Web.setTextToTextBox(PAT_Zip_TB, Zip);			
			if(PAT_Zip_TB.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In PATInfo page Enter the Zipcode", "The PAT Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In PATInfo page Enter the Zipcode", "The PAT Zipcode is ["+ Zip+"] entered Successfully", true);
			}
			
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(PAT_State_LB);
				 Web.selectDropDownOption(PAT_State_LB, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(PAT_State_LB);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(PAT_State_LB, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(PAT_State_LB);
				 Web.selectDropDownOption(PAT_State_LB, state);
			}
	}
	

	
	public PATInfo (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(PAT_FirstName_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(PAT_FirstName_TB),"Login Page is Not Loaded\n");
	
	}

}
