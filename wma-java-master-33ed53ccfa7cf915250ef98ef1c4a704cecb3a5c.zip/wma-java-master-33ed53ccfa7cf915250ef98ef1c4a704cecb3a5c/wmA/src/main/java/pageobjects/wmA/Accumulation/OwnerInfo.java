package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class OwnerInfo extends LoadableComponent<OwnerInfo>{
	
	@FindBy(id="mainform:ownersearch")
	private  WebElement Ownerinfo_partysearch_BT;
	
	@FindBy(id="mainform:search")
	private  WebElement Ownerinfo_Party_BT;
	
	@FindBy(id="mainform:searchType:0")
	private  WebElement Ownerinfo_Both_RB;
	
	@FindBy(id="mainform:clientNameCandidateLastName")
	private  WebElement Ownerinfo_lastname_TB;
	
	@FindBy(xpath="//div/table[@id='mainform:Results']/tbody/tr[@id='Results_0']")
	private  WebElement Ownerinfo_FirstRow_C;
	
	@FindBy(id="submitbutton")
	private  WebElement Ownerinfo_ok_BT;
	
	@FindBy(xpath=".//*[@id='annEaOwner1']/tbody/tr[1]/td")
	private  WebElement Ownersearchwait;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryContractEntryOwnerDataTaxIdNumber")
	private static WebElement Taxid_TB;
	
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryOwnerDataCompanyIndivCode']")
	private  WebElement Ownerinfo_IndivCode;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataPrefix']")
	private  WebElement Ownerinfo_Prefix;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataFirstName']")
	private  WebElement Ownerinfo_Firstname;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataLastName']")
	private  WebElement Ownerinfo_Lastname;
	
	@FindBy(xpath="//input[@id='mainform:ownersearch']")
	private  WebElement Ownerinfo_PartySearch;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataName']")
	private  WebElement Ownerinfo_Corporation;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryOwnerDataSexCode']")
	private  WebElement Ownerinfo_Gender;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataBirthdate_input']")
	private  WebElement Ownerinfo_DOB;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataAddressLine1']")
	private  WebElement Ownerinfo_Residentaddress;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataCity']")
	private  WebElement Ownerinfo_City;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryOwnerDataState']")
	private  WebElement Ownerinfo_state;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryOwnerDataCountryCode']")
	private  WebElement Ownerinfo_Country;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataZipPostalCode']")
	private  WebElement Ownerinfo_Zipcode;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("OwnerInfo_CilckonPartyAdd")) {
			return this.Ownerinfo_Party_BT;
		}
		
		if (fieldName.trim().equalsIgnoreCase("OwnerInfo_CilckonPartysearch")) {
			return this.Ownerinfo_partysearch_BT;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Ownerinfo_ClickOnOkbtn")) {
			return this.Ownerinfo_ok_BT;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Ownerinfo_ClickOnBothbtn")) {
			return this.Ownerinfo_Both_RB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Ownerinfo_Waitforsearchbtn")) {
			return this.Ownersearchwait;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Ownerinfo_Select1strow")) {
			return this.Ownerinfo_FirstRow_C;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void OwnerInfoDeatils(String Gentype,String DOB,String city,String state) {
		Web.waitForElement(Ownerinfo_Firstname);
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(Ownerinfo_Firstname, Fnames);
		if(Ownerinfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the owner First name", "The ownerFirst name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the owner First name", "The owner First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(Ownerinfo_Lastname);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(Ownerinfo_Lastname, Lnames);
		if(Ownerinfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the owner Last name", "The ownerLastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the owner Last name", "The owner Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(Ownerinfo_Gender);
		Web.selectDropDownOption(Ownerinfo_Gender, Gentype);
		Web.waitForElement(Taxid_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(Taxid_TB, ssn);
		Web.waitForElement(Ownerinfo_DOB);		
		Web.setTextToTextBox(Ownerinfo_DOB, DOB);
		if(Ownerinfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the DOB", "The ownerDOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the  DOB", "The owner DOB is ["+ DOB+"] entered Successfully", true);
		}
		Web.waitForElement(Ownerinfo_Residentaddress);
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(Ownerinfo_Residentaddress, address);
		if(Ownerinfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the address", "The owner address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the address", "The owner address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(Ownerinfo_City);
				 Web.setTextToTextBox(Ownerinfo_City, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(Ownerinfo_City);
				Web.setTextToTextBox(Ownerinfo_City, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(Ownerinfo_City);
				 Web.setTextToTextBox(Ownerinfo_City, city);
			}
		 Web.waitForElement(Ownerinfo_Zipcode);	
		 String Zip = Common.AutoZipcode();
		 Web.setTextToTextBox(Ownerinfo_Zipcode, Zip);
			if(Ownerinfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the Zipcode", "The owner Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the Zipcode", "The owner Zipcode is ["+ Zip+"] entered Successfully", true);
			}
		 
		 if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(Ownerinfo_state);
				 Web.selectDropDownOption(Ownerinfo_state, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(Ownerinfo_state);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(Ownerinfo_state, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(Ownerinfo_state);
				 Web.selectDropDownOption(Ownerinfo_state, state);
			}
	}
	
	public void EnterOwnerInfoLastNameSearch(String Lnames) {
		Web.waitForElement(Ownerinfo_lastname_TB);		
		Web.setTextToTextBox(Ownerinfo_lastname_TB, Lnames);
		if(Ownerinfo_lastname_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Owner Info page Enter the owner Last name", "The owner last name is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Owner Info page Enter the owner Last name", "The owner last name is ["+ Lnames+"] entered Successfully", true);
		}
	}

	
	public OwnerInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Ownerinfo_partysearch_BT);
		Assert.assertTrue(Web.isWebElementDisplayed(Ownerinfo_partysearch_BT),"Owner Page is Not Loaded\n");
	
	}

}
