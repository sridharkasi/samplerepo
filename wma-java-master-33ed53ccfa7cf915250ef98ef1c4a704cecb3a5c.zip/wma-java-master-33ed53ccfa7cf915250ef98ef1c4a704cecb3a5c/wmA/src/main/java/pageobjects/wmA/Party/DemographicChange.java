package pageobjects.wmA.Party;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import appUtils.Common;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class DemographicChange extends LoadableComponent<DemographicChange> {
	@FindBy(id="mainform:directoryTransactionEffectiveDate_input")
	private static WebElement DemochangeEffectivedate_TB;
	
	@FindBy(xpath = "//li[@id='PartyDeath_ID']/a")
	private static WebElement Deathpending_Submenu;
	
	public void ClickonDeathpending() {
		Web.waitForElement(Deathpending_Submenu);
		Common.ClickSubmenu(Deathpending_Submenu);
	}

	public DemographicChange(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {		
		Web.waitForElement(DemochangeEffectivedate_TB);		
		Assert.assertTrue(Web.isWebElementDisplayed(DemochangeEffectivedate_TB),"Demographic Change Page is Not Loaded\n");
		
	}

}
