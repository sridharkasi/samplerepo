package pageobjects.wmA.Disbursements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class FullSurrender extends LoadableComponent<FullSurrender> {
	
	@FindBy(partialLinkText ="Disbursements")
	private static WebElement Disbursement;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id ="mainform:searchButton")
	private static WebElement searchbutton;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Full Surrender')]")
	private static WebElement fs;
	
	@FindBy(id = "mainform:fullSurrenderEffectiveDate_input")
	private static WebElement effdate;
	
	@FindBy(id = "mainform:fullSurrenderSourceCode")
	private static WebElement fsource;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	 @FindBy(id="overridebox")
	  private static WebElement overidebox;
	  
	  public void clickoverirde() {
		  
		 // Web.waitForElement(ErrorText);
		 /* try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		  Web.waitForElement(overidebox);
		  Web.clickOnElement(overidebox);
		  if(overidebox.isSelected()){
				
			  Reporter.logEvent(Status.PASS, "In Full Surrender page Click on override button ", "the Override button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Full Surrender page Click on override button", "the Override button is not clicked sucessfully", true);
			 }
	  }
	   
	
	/*public FullSurrender () {
		PageFactory.initElements(lib.Web.getDriver(), this);
	}*/
	
	public FullSurrender (LoadableComponent<?> parent) {

        this.parent = new LandingPage();

        PageFactory.initElements(lib.Web.getDriver(), this);

	} 


	
	public void clickhomebutton () {
		Web.waitForElement(homebutton);
		Web.clickOnElement(homebutton);
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
	}
	
	public void clicksearchbutton() {
		Web.waitForElement(searchbutton);
		Web.clickOnElement(searchbutton);
	}
	  public void clickfullsurrender() {
		  Web.waitForElement(fs);
	    	Common.ClickSubmenu(fs);
	    }
	  
	  public void seteffectivedatefullsurrender(String effectivedate) {
			if(System.getProperty("TrxEffectiveDate")==null)
			{
				 Web.waitForElement(effdate);
			    	Web.setTextToTextBox(effdate, effectivedate);
			    	 if(effdate.getAttribute("value").equalsIgnoreCase(effectivedate)) {
						 Reporter.logEvent(Status.PASS, "In Full Surrender page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
					 }
					 else {
						 Reporter.logEvent(Status.FAIL, "In Full Surrender page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
					 }
			}
			else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
			{
				 Web.waitForElement(effdate);
			    	Web.setTextToTextBox(effdate, System.getProperty("TrxEffectiveDate"));
			    	 if(effdate.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate"))) {
						 Reporter.logEvent(Status.PASS, "In Full Surrender page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
					 }
					 else {
						 Reporter.logEvent(Status.FAIL, "In Full Surrender page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
					 }
								
			}else {
				 Web.waitForElement(effdate);
			    	Web.setTextToTextBox(effdate, effectivedate);
			    	 if(effdate.getAttribute("value").equalsIgnoreCase(effectivedate)) {
						 Reporter.logEvent(Status.PASS, "In Full Surrender page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
					 }
					 else {
						 Reporter.logEvent(Status.FAIL, "In Full Surrender page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
					 }
		 
			}
	    }
	  
	    public void selectsourcecode(String source) {
	    	Web.waitForElement(fsource);
	    	Web.selectDropDownOption(fsource, source);
	    }
		public void RealtimeDrpDwn(String selectrealtime) {
			Web.waitForElement(RealtimeDrpDwn);
			 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
			 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
		}
		
	    public void clicksumbmit() {
	    	Web.waitForElement(submit);
	    	Web.clickOnElement(submit);
	    }
	    
		public void VerifyErrorText(String expectedtext) {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
			
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		 this.parent.get();

         Web.waitForPageToLoad(Web.getDriver());


	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		  Web.waitForElement(effdate);

          Assert.assertTrue(Web.isWebElementDisplayed(effdate),"Full surrender Page is Not Loaded\n");


	}

}
