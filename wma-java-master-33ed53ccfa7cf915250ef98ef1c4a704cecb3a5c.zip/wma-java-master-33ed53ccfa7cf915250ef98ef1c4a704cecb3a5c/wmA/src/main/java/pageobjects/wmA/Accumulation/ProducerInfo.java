package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class ProducerInfo extends LoadableComponent<ProducerInfo>{
	
	private LoadableComponent<?> parent;

	@FindBy(id="mainform:advisorLastName")
	private WebElement lastname;
	
	@FindBy(id="mainform:advisorSearch")
	private WebElement AdvisorSearch;
	
	@FindBy(id="submitbutton")
	private WebElement OKButton;
	
	@FindBy(id="nextbutton")
	private  WebElement NextButton;
	
	@FindBy(xpath ="//table[@id='mainform:Advisor']/tbody/tr")
	private  WebElement SelectRowPartySearch;
	
	//==
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoRoleTypeCode")
	private  WebElement RoleType;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoRoleTypeCode")
	private  WebElement RoleType2;

	@FindBy (id="mainform:AdvisorAgentInfo:0:advisorAgentInfoAgentProfile")
	private  WebElement Profile;
	
	@FindBy (id="mainform:AdvisorAgentInfo:1:advisorAgentInfoAgentProfile")
	private  WebElement Profile2;
	
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoFirstYearPercent")
	private  WebElement FirstYrPercentage;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoFirstYearPercent")
	private  WebElement FirstYrPercentage2;
	
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoRenewalPercent")
	private  WebElement RnwalPercentage;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoRenewalPercent")
	private  WebElement RnwalPercentage2;
	
	@FindBy (id="mainform:AdvisorAgentInfo:0:advisorAgentInfoCommissionAgencyCode")
	private  WebElement CommisionAgncy;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoAgentFirstName")
	private WebElement AdvisoryFirstName_TB1;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoAgentFirstName")
	private WebElement AdvisoryFirstName_TB2;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		
		if (fieldName.trim().equalsIgnoreCase("Producerinfo_lastname")) {
			return this.lastname;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Producerinfo_Clickonpartysearch")) {
			return this.AdvisorSearch;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Producerinfo_Select1strowparty")) {
			return this.SelectRowPartySearch;
		}
	
		if (fieldName.trim().equalsIgnoreCase("Producerinfo_RoleType")) {
			return this.RoleType;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Producerinfo_Profile")) {
			return this.Profile;
		}
		
		if (
				fieldName.trim().equalsIgnoreCase("Producerinfo_Firstyrpercent")) {
			return this.FirstYrPercentage;
		}
		
		if (
				fieldName.trim().equalsIgnoreCase("Producerinfo_Rnwalpercent")) {
			return this.RnwalPercentage;
		}
		
		if (
				fieldName.trim().equalsIgnoreCase("Producerinfo_Commissonagency")) {
			return this.CommisionAgncy;
		}
		
		if (
				fieldName.trim().equalsIgnoreCase("Producerinfo_ClickonOkbtn")) {
			return this.OKButton;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void selectpartysearch() {
		Web.clickOnElement(SelectRowPartySearch);
		 Reporter.logEvent(Status.PASS, " In producer info page click on Party search button ", " The Party search button is clicked successfully ", false);
	}
	public void selectpartyOKButton() {
		Web.clickOnElement(OKButton);
		 Reporter.logEvent(Status.PASS, " In producer info page click on Ok button ", " The Ok button is clicked and the party is successfully added to the contract", false);
	}
	
	
	public void setLastname(String Lname) throws InterruptedException {

		if(System.getProperty("ProducerInfo_Lname")==null)
		{
			Web.waitForElement(lastname);
			 Web.setTextToTextBox(lastname, Lname);
		}
		else if( System.getProperty("ProducerInfo_Lname").trim().length() > 0)
		{
			Web.waitForElement(lastname);
			Web.setTextToTextBox(lastname, System.getProperty("ProducerInfo_Lname").trim());	
								
		}else {
			Web.waitForElement(lastname);
			 Web.setTextToTextBox(lastname, Lname);
		}
		
/*		Web.waitForElement(lastname);
		 Web.setTextToTextBox(lastname, Lname);
		 Assert.assertTrue(lastname.getAttribute("value").contains(Lname), "Profile set with value [ :"+Lname+"]");
		 Reporter.logEvent(Status.PASS, "In producer info page enter the Last Name ","The  Last Name is ["+ Lname+"] entered Successfully", false);*/
		
	}
	
	public void AdvisorSearch() {
		 Web.clickOnElement(AdvisorSearch);
		 Reporter.logEvent(Status.PASS, "In the Producer Info page click on Advisor search button","The Advisor search button Clicked Successfully", false);
		
	}
	
	public void ClickNext() throws InterruptedException {
	
		Web.clickOnElement(NextButton);
		Reporter.logEvent(Status.PASS, "Next button","Clicked Successfully", false);
		
	}
	
	public void switchtowindow(String Casestring) {
	
		Common.switchwindow(Casestring, SelectRowPartySearch);
		Common.switchwindow(Casestring, OKButton);
		}
	
	public void ProfileInfoEntries(String roletype, String profile, String Firstyrpercent, String RnwalPercent) {
		 Web.waitForElement(RoleType);
		 Web.selectDropDownOption(RoleType, roletype);	
		/* Web.setTextToTextBox(Profile, profile);		
		 Assert.assertTrue(Profile.getAttribute("value").contains(profile), "Profile set with value [ :"+profile+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Profile", "the Profile is["+ profile+"] is Entered successfully", false);*/		
		 Common.Contractinfo.put("AdvisoryFirstName1",AdvisoryFirstName_TB1.getAttribute("value") );
		 Web.setTextToTextBox(FirstYrPercentage, Firstyrpercent);
		 Assert.assertTrue(FirstYrPercentage.getAttribute("value").contains(Firstyrpercent), "first yr percentage set with value [ :"+Firstyrpercent+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the First year percentage", "the First year percentage is["+ Firstyrpercent+"] is Entered successfully", false);		
		 Web.setTextToTextBox(RnwalPercentage, RnwalPercent);
		 Assert.assertTrue(RnwalPercentage.getAttribute("value").contains(RnwalPercent), "Renewal percentage set with value [ :"+RnwalPercent+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Renewal Percentage" ,"the Renewal Percentage is["+ RnwalPercent+"] is Entered successfully", false);
		/* String Agencyname =Common.AgentnameGenerator();
		 Web.setTextToTextBox(CommisionAgncy, Agencyname);
		 Assert.assertTrue(CommisionAgncy.getAttribute("value").contains(Agencyname), "Commision set with value [ :"+Agencyname+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Commission Agency", "the Commission Agency is["+ Agencyname+"] is Entered successfully", false);*/
		
		
	
	}
	
	public void ProfileInfoEntries2(String roletype, String profile, String Firstyrpercent, String RnwalPercent) {
		 Web.waitForElement(RoleType2);
		 Web.selectDropDownOption(RoleType2, roletype);	
		 Web.setTextToTextBox(Profile2, profile);		
		 Assert.assertTrue(Profile2.getAttribute("value").contains(profile), "Profile set with value [ :"+profile+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Profile", "the Profile is["+ profile+"] is Entered successfully", false);		
		 Common.Contractinfo.put("AdvisoryFirstName2",AdvisoryFirstName_TB2.getAttribute("value") );
		 Web.setTextToTextBox(FirstYrPercentage2, Firstyrpercent);
		 Assert.assertTrue(FirstYrPercentage2.getAttribute("value").contains(Firstyrpercent), "first yr percentage set with value [ :"+Firstyrpercent+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the First year percentage", "the First year percentage is["+ Firstyrpercent+"] is Entered successfully", false);		
		 Web.setTextToTextBox(RnwalPercentage2, RnwalPercent);
		 Assert.assertTrue(RnwalPercentage2.getAttribute("value").contains(RnwalPercent), "Renewal percentage set with value [ :"+RnwalPercent+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Renewal Percentage" ,"the Renewal Percentage is["+ RnwalPercent+"] is Entered successfully", false);
		/* String Agencyname =Common.AgentnameGenerator();
		 Web.setTextToTextBox(CommisionAgncy, Agencyname);
		 Assert.assertTrue(CommisionAgncy.getAttribute("value").contains(Agencyname), "Commision set with value [ :"+Agencyname+"]");
		 Reporter.logEvent(Status.PASS, "In the Producer Info page enter the Commission Agency", "the Commission Agency is["+ Agencyname+"] is Entered successfully", false);*/
		
		
	
	}
	
	
	public ProducerInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	
	}
	
	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(lastname);
		Assert.assertTrue(Web.isWebElementDisplayed(lastname),"Login Page is Not Loaded\n");
	
	}

}

