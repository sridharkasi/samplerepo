package pageobjects.wmA.Home;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;


public class Home extends LoadableComponent<Home> {
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id="mainform:searchButton")
	private  WebElement searhbtn;
	
	@FindBy(id="mainform:clientRequestDirectoryId")
	private static WebElement Directorid_TB;
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
		 
		 if (fieldName.trim().equalsIgnoreCase("Serach_Button")) {
				return this.searhbtn;
			}
		 
		 Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	public void EnterDirectorID(String dir) {
		Web.waitForElement(Directorid_TB);
		Web.setTextToTextBox(Directorid_TB, dir);
		if(Directorid_TB.getAttribute("value").equalsIgnoreCase(dir))
			 Reporter.logEvent(Status.PASS, "In Home page enter the Director Id", "The Director Id is["+dir+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Home page enter the Director Id", "The Director Id is["+dir+"] Not entered sucessfully", false);
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
		if(contractsearch.getAttribute("value").equalsIgnoreCase(contractid))
			 Reporter.logEvent(Status.PASS, "In Home page enter the Contract Id", "The Contract Id is["+contractid+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Home page enter the Contract Id", "The Contract Id is["+contractid+"] Not entered sucessfully", false);
	}
	
	public void Clickonserachbutton () {
        Web.waitForElement(searhbtn);
        Web.clickOnElement(searhbtn);
        }

	
	public Home(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(contractsearch);
		Assert.assertTrue(Web.isWebElementDisplayed(contractsearch),"Home Page is Not Loaded\n");
	}
	
	
	
}
