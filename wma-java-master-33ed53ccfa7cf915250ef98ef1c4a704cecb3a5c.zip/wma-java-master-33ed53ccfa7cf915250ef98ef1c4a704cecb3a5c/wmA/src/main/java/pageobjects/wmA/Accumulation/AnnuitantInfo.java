package pageobjects.wmA.Accumulation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class AnnuitantInfo extends LoadableComponent<AnnuitantInfo>{
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataFirstName")
	private  WebElement AnnuityFirstName;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataLastName")
	private  WebElement AnnuityLastName;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataBirthdate_input")
	private  WebElement AnnuityDOB;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataSexCode")
	private  WebElement AnnuityGender;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataAddressLine1")
	private  WebElement Address;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataCity")
	private  WebElement AnnuityCity;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataTaxIdNumber")
	private  WebElement AnnuitySSN;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataZipPostalCode")
	private  WebElement AnnuityZip;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataZipPostalCode4")
	private  WebElement AnnuityZipRemaining;
	
	@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataState")
	private  WebElement AnnuityState;
	//===
	
	@FindBy(id="mainform:contractEntryRetirementAge")
	private  WebElement AnnuityRetAge;
	
	@FindBy(id="mainform:ownerDifferentThanInsuredInd")
	private  WebElement Annitantinfo_Differ_CB;
	
	@FindBy(id="mainform:contractEntryOwnershipCode")
	private  WebElement Annitantinfo_Ownercode_LB;
	
	@FindBy(id="mainform:nbrOfBeneficiaries")
	private  WebElement Annitantinfo_nobenficiaries_LB;
	
	@FindBy(id="mainform:search")
	private  WebElement Annitantinfo_Partysearch_C;
	
	@FindBy(id="mainform:searchType:0")
	private  WebElement Annitantinfo_Both_RB;
	
	@FindBy(id="mainform:clientNameCandidateLastName")
	private  WebElement Annitantinfo_lastname_TB;
	
	@FindBy(xpath="//div/table[@id='mainform:Results']/tbody/tr[@id='Results_0']")
	private  WebElement Annitantinfo_FirstRow_C;
	
	@FindBy(id="mainform:annEaRiaInd")
	private  WebElement Annitantinfo_Registerinvestmentadvisor_CB;
	
	@FindBy(id="submitbutton")
	private  WebElement Annitantinfo_ok_BT;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntrySocSecVerificationInd")
	private WebElement SSNVerification_TB;
	
	@FindBy(id="mainform:payorDifferentThanOwnerInd")
	private static WebElement PayorInfo_CB;
	
	@FindBy(id="mainform:ownerDifferentThanInsuredInd")
	private static WebElement ownerInfo_CB;
	
	@FindBy(id="mainform:successorInd")
	private static WebElement Successor_CB;
	
	@FindBy(id="mainform:coAnnuitantInd")
	private static WebElement CoAnnuitant_CB;
	
	@FindBy(id="mainform:annEaRiaInd")
	private static WebElement RIA_CB;
	
	@FindBy(id="mainform:annEaSaaInd")
	private static WebElement SaleAssitant_CB;
	
	@FindBy(id="mainform:annEaLpaInd")
	private static WebElement LimitedPowerOfAttorney_CB;
	
	@FindBy(id="mainform:annEaPatInd")
	private static WebElement PowerOfAttroney_CB;
	
	@FindBy(id="mainform:coOwnerInd")
	private static WebElement CoOwner_CB;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_ClickOnRIAcheckbox")) {
			return this.Annitantinfo_Registerinvestmentadvisor_CB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Firstname")) {
			return this.AnnuityFirstName;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_LastName")) {
			return this.AnnuityLastName;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_SSN")) {
			return this.AnnuitySSN;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_DoB")) {
			return this.AnnuityDOB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Gender")) {
			return this.AnnuityGender;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Address")) {
			return this.Address;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_City")) {
			return this.AnnuityCity;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_State")) {
			return this.AnnuityState;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Zipcode")) {
			return this.AnnuityZip;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Diffirentfromowner")) {
			return this.Annitantinfo_Differ_CB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_Ownershipcode")) {
			return this.Annitantinfo_Ownercode_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("AnnuitantInfo_NuberofBeneficiary")) {
			return this.Annitantinfo_nobenficiaries_LB;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void ClickonCOO() {
		Web.waitForElement(CoOwner_CB);
		Web.clickOnElement(CoOwner_CB);
	}
	
	public void ClickonPA() {
		Web.waitForElement(PowerOfAttroney_CB);
		Web.clickOnElement(PowerOfAttroney_CB);
	}
	public void ClickonLPA() {
		Web.waitForElement(LimitedPowerOfAttorney_CB);
		Web.clickOnElement(LimitedPowerOfAttorney_CB);
	}
	public void ClickonRIA() {
		Web.waitForElement(RIA_CB);
		Web.clickOnElement(RIA_CB);
	}
	public void ClickonSA() {
		Web.waitForElement(SaleAssitant_CB);
		Web.clickOnElement(SaleAssitant_CB);
	}
	public void ClickonOwnerInfo() {
		Web.waitForElement(ownerInfo_CB);
		Web.clickOnElement(ownerInfo_CB);
	}
	
	public void ClickonPayorInfo() {
		Web.waitForElement(PayorInfo_CB);
		Web.clickOnElement(PayorInfo_CB);
	}
	
	public void CliconSuccessorInfo() {
		Web.waitForElement(Successor_CB);
		Web.clickOnElement(Successor_CB);
	}
	
	public void ClickonCoAnnuintantInfo() {
		Web.waitForElement(CoAnnuitant_CB);
		Web.clickOnElement(CoAnnuitant_CB);
	}
	
	public void EnterAnnitantLastNameSearch(String AnnitantLastname) {
		Web.setTextToTextBox(Annitantinfo_lastname_TB, AnnitantLastname);
		Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity Last name in the search box", "the Annuity last name is["+AnnitantLastname+"] entered sucessfully in the search box", false);
	}
	
	
	public void AnnuitantInformation(String AnnuityDOBtx, String Anuitygendr,  String anuitCity,  String  state) {
				
			 Web.waitForElement(AnnuityFirstName);
			String firstname1 = Common.randomvaildFirstname();
			 Web.setTextToTextBox(AnnuityFirstName, firstname1);
			 Assert.assertTrue(AnnuityFirstName.getAttribute("value").contains(firstname1), "first name set with value [ :"+firstname1+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity FirstName", "the Annuity FirstName is["+firstname1+"] entered sucessfully", false);		
			 String LAstname = Common.randomvaildLastname();
			 Web.setTextToTextBox(AnnuityLastName, LAstname);			
			 if(AnnuityLastName.getAttribute("value").equalsIgnoreCase(LAstname)) {
				 Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity LastName", "the Annuity LastName is["+LAstname+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Annuitant Info page enter the Annuity LastName", "the Annuity LastName is["+LAstname+"] not entered sucessfully", true);
			 }
			 
			 if(System.getProperty("Dateofbirth")==null)
				{
					Web.waitForElement(AnnuityDOB);
					 Web.setTextToTextBox(AnnuityDOB, AnnuityDOBtx);
				}
				else if( System.getProperty("Dateofbirth").trim().length() > 0)
				{
					Web.waitForElement(AnnuityDOB);
					Web.setTextToTextBox(AnnuityDOB, System.getProperty("Dateofbirth").trim());	
										
				}else {
					Web.waitForElement(AnnuityDOB);
					 Web.setTextToTextBox(AnnuityDOB, AnnuityDOBtx);
				}
			 
			/* Web.setTextToTextBox(AnnuityDOB, AnnuityDOBtx);
			 Assert.assertTrue(AnnuityDOB.getAttribute("value").contains(AnnuityDOBtx), "Date of birth set with value [ :"+AnnuityDOBtx+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity Date of birth", "The Date of birth is["+ AnnuityDOBtx+"] entered sucessfully", false);*/			 
			 Web.selectDropDownOption(AnnuityGender, Anuitygendr);
			 String SSNnum = Common.generateSSN();			
			 Web.setTextToTextBox(AnnuitySSN, SSNnum);	
			 Assert.assertTrue(AnnuitySSN.getAttribute("value").contains(SSNnum), "SSN set with value [ :"+SSNnum+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page Enter the Annuity SSN ", "SSN is["+SSNnum+"] entered sucessfully",false);
			 String anuityaddres1 = Common.AddressGenerator();
			 Web.setTextToTextBox(Address, anuityaddres1);			
			 Assert.assertTrue(Address.getAttribute("value").contains(anuityaddres1), "Gender with value [ :"+anuityaddres1+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity Address", "The Annuity Address is["+anuityaddres1+"] entered sucessfully", false);
			
			 if(System.getProperty("City")==null)
				{
					Web.waitForElement(AnnuityCity);
					 Web.setTextToTextBox(AnnuityCity, anuitCity);
				}
				else if( System.getProperty("City").trim().length() > 0)
				{
					Web.waitForElement(AnnuityCity);
					Web.setTextToTextBox(AnnuityCity, System.getProperty("City").trim());	
										
				}else {
					Web.waitForElement(AnnuityCity);
					 Web.setTextToTextBox(AnnuityCity, anuitCity);
				}
			 
			/* Web.setTextToTextBox(AnnuityCity, anuitCity);	
			 Assert.assertTrue(AnnuityCity.getAttribute("value").contains(anuitCity), "City set with value [ :"+anuitCity+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page enter the Annuity City", "The city is ["+anuitCity+"] entered sucessfully", true);*/
			 String zip1 = Common.AutoZipcode();
			 Web.setTextToTextBox(AnnuityZip, zip1);	
			 Assert.assertTrue(AnnuityZip.getAttribute("value").contains(zip1), "Zip set with value [ :"+zip1+"]");
			 Reporter.logEvent(Status.PASS, "In Annuitant Info page Enter the Zip code", "Zip code is["+zip1+"] entered", false);			
				if(System.getProperty("IssueState")==null)
				{
					Web.waitForElement(AnnuityState);
					 Web.selectDropDownOption(AnnuityState, state);
				}
				else if( System.getProperty("IssueState").trim().length() > 0)
				{
					Web.waitForElement(AnnuityState);
					//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
					Common.selectbyvalues(AnnuityState, System.getProperty("IssueState").trim());										
				}else {
					Web.waitForElement(AnnuityState);
					 Web.selectDropDownOption(AnnuityState, state);
				}
			 
		//	 Web.selectDropDownOption(AnnuityState, state);
			 Select sel = new Select(Web.getDriver().findElement(By.id("mainform:contractEntrySocSecVerificationInd")));
			 WebElement opt = sel.getFirstSelectedOption();
			 String ss = opt.getText();
			 Common.Contractinfo.put("SSNVerifcation",ss );
	}

	public AnnuitantInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(AnnuityFirstName);
		Assert.assertTrue(Web.isWebElementDisplayed(AnnuityFirstName),"Annuitant Info Page is Not Loaded\n");
		
	}

}
