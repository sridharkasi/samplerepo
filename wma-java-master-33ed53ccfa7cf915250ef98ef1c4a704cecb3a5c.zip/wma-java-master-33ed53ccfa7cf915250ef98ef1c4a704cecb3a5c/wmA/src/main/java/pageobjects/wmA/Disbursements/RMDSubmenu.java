package pageobjects.wmA.Disbursements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.General.General;

public class RMDSubmenu extends LoadableComponent<RMDSubmenu>{
	
	@FindBy(id="mainform:update")
	private static WebElement Updatequote_BT;
	
	@FindBy(xpath="//input[contains(@id,'EffectiveDate')]")
	private static WebElement Effectivedate_TB;
	
    @FindBy(xpath="//input[contains(@id,'StartDate')]")
	private static WebElement Startdate_TB;
    
  
    @FindBy(xpath="//input[contains(@id,'EndDate')] ")
	private static WebElement Enddate_TB;
    
    @FindBy(xpath="//input[contains(@id,'PayoutDate')]")
   	private static WebElement Nextpayout_TB;
    
    @FindBy(xpath="//input[contains(@id,'OverrideAmt')]")
   	private static WebElement RMD_OverrideAmt;
    
 
    @FindBy(xpath="//select[contains(@id,'MrdType')]")
   	private static WebElement RMD_Type;
    
    @FindBy(xpath="//select[contains(@id,'SourceCode')] ")
   	private static WebElement RMD_Sourcecode;
    
    
    
    
	
	
	
	public void enterEffectivedate (String Effectivedate) {
		Web.waitForElement(Effectivedate_TB);
		Web.setTextToTextBox(Effectivedate_TB, Effectivedate);
		if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(Effectivedate))
			 Reporter.logEvent(Status.PASS, "In RMD  page enter the Effective date", "the Effective date is["+Effectivedate+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In RMD page enter the Effective date", "the Effective date is["+Effectivedate+"] Not entered sucessfully", false);
	}
	
	
	public void enterStartdate (String Startdate) {
		Web.waitForElement(Startdate_TB);
		Web.setTextToTextBox(Startdate_TB, Startdate);
		if(Startdate_TB.getAttribute("value").equalsIgnoreCase(Startdate))
			 Reporter.logEvent(Status.PASS, "In RMD  page enter the Start date", "the Start date is["+Startdate+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In RMD  page enter the Start date", "the Start date is["+Startdate+"] Not entered sucessfully", false);
	}
	
	public void enterEnddate (String Enddate) {
		Web.waitForElement(Enddate_TB);
		Web.setTextToTextBox(Enddate_TB, Enddate);
		if(Enddate_TB.getAttribute("value").equalsIgnoreCase(Enddate))
			 Reporter.logEvent(Status.PASS, "In RMD  page enter the End date", "the End date is["+Enddate+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In RMD  page enter the End date", "the End date is["+Enddate+"] Not entered sucessfully", false);
	}
	
	public void enterNextpayoutdate (String Nextpayoutdate) {
		Web.waitForElement(Nextpayout_TB);
		Web.setTextToTextBox(Nextpayout_TB, Nextpayoutdate);
		if(Nextpayout_TB.getAttribute("value").equalsIgnoreCase(Nextpayoutdate))
			 Reporter.logEvent(Status.PASS, "In RMD  page enter the Nextpayout date", "the Nextpayout date is["+Nextpayoutdate+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In RMD  page enter the Nextpayout date", "the Nextpayout date is["+Nextpayoutdate+"] Not entered sucessfully", false);
	}
	
	
	public void SelectRMDType(String rmdtype) {
		Web.waitForElement(RMD_Type);
		Web.selectDropDownOption(RMD_Type, rmdtype);
		
	}
	
	public void SelectSourcecode(String SC) {
		Web.waitForElement(RMD_Sourcecode);
		Web.selectDropDownOption(RMD_Sourcecode, SC);
		
	}
	public void enteroverrideamount(String override){
		Web.waitForElement(RMD_OverrideAmt);
		Web.setTextToTextBox(RMD_OverrideAmt, override);
	}

	public void ClickOnUpdateButton() {
		Web.waitForElement(Updatequote_BT);
		Web.clickOnElement(Updatequote_BT);
	}
	
	
	public RMDSubmenu (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}


	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Effectivedate_TB);
		// TODO Auto-generated method stub
		Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate_TB),"Rmd Quote Page is Not Loaded\n");
	}

}


