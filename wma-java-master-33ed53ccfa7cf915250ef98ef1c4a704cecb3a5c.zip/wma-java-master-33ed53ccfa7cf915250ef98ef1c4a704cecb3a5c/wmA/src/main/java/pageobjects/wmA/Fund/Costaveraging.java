package pageobjects.wmA.Fund;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.General.General;

public class Costaveraging extends LoadableComponent<Costaveraging> {

	@FindBy(name = "mainform:cmdAdd")
	private static WebElement Costaveraging_addbutton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;

	@FindBy(xpath = "//input[@id='mainform:dcaAddEffectiveDate_input']")
	private static WebElement Effectivedate_TB;

	@FindBy(id = "mainform:dcaAddGcBeginDate_input")
	private static WebElement Begindate;

	@FindBy(id = "mainform:dcaAddNumberOfTransfers")
	private static WebElement NumberTransfer;

	@FindBy(id = "mainform:transferType")
	private static WebElement Transfertype;

	@FindBy(xpath = "//Select[@id='mainform:dcaAddTransferDay']")
	private static WebElement TransferDay;

	@FindBy(xpath = "//input[@id='mainform:TransferFund:0:transferFundFromAmount']")
	private static WebElement FrmAMount;
	
	
	@FindBy(xpath = "//input[@id='mainform:TransferFund:2:transferFundToAmount']")
	private static WebElement ToAMount;
	
	
	@FindBy(id="mainform:dcaAddTransferFrequency")
	private static WebElement CAFrequency;
	
	@FindBy(id="mainform:dcaAddNumberOfTransfers")
	private static WebElement CANumberofTransfer;
	
	@FindBy(id="mainform:transferType")
    private static WebElement CAtrxindicator;



	
	public void seteffectivedate(String effdate) throws InterruptedException {
        
        if(System.getProperty("TrxEffectiveDate")==null)
                        {
                        Web.waitForElement(Effectivedate_TB);
        Web.setTextToTextBox(Effectivedate_TB, effdate);
        if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effdate))
                                         Reporter.logEvent(Status.PASS, "In Cost Average page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
                        else
                                         Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
                        }
                        else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
                        {
                                        Web.waitForElement(Effectivedate_TB);
                                        Web.setTextToTextBox(Effectivedate_TB, System.getProperty("TrxEffectiveDate").trim());
                                                        
                            if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate").trim()))
                                                        Reporter.logEvent(Status.PASS, "In  Cost Average page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] entered sucessfully", false);
                                        else
                                                        Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] Not entered sucessfully", false);
                                                                                                                        
                        }else {
                                        Web.waitForElement(Effectivedate_TB);
                        Web.setTextToTextBox(Effectivedate_TB, effdate);
                        if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effdate))
                                                        Reporter.logEvent(Status.PASS, "In  Cost Average page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
                                        else
                                                        Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
                        }
        

        }

	
	public void SelectCATransfertype(String trxtype) {
        if(System.getProperty("TrxType")==null)
        {
                        Web.waitForElement(CAtrxindicator);
                        Web.selectDropDownOption(CAtrxindicator, trxtype);
        }
        else if( System.getProperty("TrxType").trim().length() > 0)
        {
                        Web.waitForElement(CAtrxindicator);
                        Web.selectDropDownOption(CAtrxindicator, System.getProperty("TrxType").trim());    
                                                                                                        
        }else {
                        Web.waitForElement(CAtrxindicator);
                        Web.selectDropDownOption(CAtrxindicator, trxtype);
        }
        

        Web.waitForElement(CAtrxindicator);
	}
	
	public void setBegindate(String Bgndate) throws InterruptedException {
        
        if(System.getProperty("BeginDate")==null)
        {
                        Web.waitForElement(Begindate);
        Web.setTextToTextBox(Begindate, Bgndate);
        if(Begindate.getAttribute("value").equalsIgnoreCase(Bgndate))
                                        Reporter.logEvent(Status.PASS, "In Cost Average page enter the Begin date", "the Begin date is["+Bgndate+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Begin date", "the Begin date is["+Bgndate+"] Not entered sucessfully", false);
        }
        else if( System.getProperty("BeginDate").trim().length() > 0)
        {
                        Web.waitForElement(Begindate);
                        Web.setTextToTextBox(Begindate, System.getProperty("BeginDate").trim());
                                        
        if(Begindate.getAttribute("value").equalsIgnoreCase(System.getProperty("BeginDate").trim()))
                                        Reporter.logEvent(Status.PASS, "In  Cost Average page enter theBegin date", "the Begin  is["+System.getProperty("TrxEffectiveDate").trim()+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Begin date", "the Begin date is["+System.getProperty("TrxEffectiveDate").trim()+"] Not entered sucessfully", false);
                                                                                                        
        }else {
                        Web.waitForElement(Begindate);
        Web.setTextToTextBox(Begindate, Bgndate);
        if(Begindate.getAttribute("value").equalsIgnoreCase( Bgndate))
                                        Reporter.logEvent(Status.PASS, "In  Cost Average page enter the Begin date", "the Effective date is["+Begindate+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In  Cost Average page enter the Begin date", "the Effective date is["+Begindate+"] Not entered sucessfully", false);
        }
        

	}


	
	public void SelectCATransferfrequency1 (String trxfrequency) {
        String trxfreq=null;
        if(System.getProperty("TrxFrequency")==null)
        {
                        Web.waitForElement(CAFrequency);
                        Web.selectDropDownOption(CAFrequency, trxfrequency);
        }
        else if(System.getProperty("TrxFrequency").trim().length() > 0)
        {
                        if (System.getProperty("TrxFrequency").trim().contains("Annual"))
                        {
                                        trxfreq="1";
                        }
                        else if (System.getProperty("TrxFrequency").trim().contains("Monthly"))
                        {
                                        trxfreq="12";
                        }
                        else if (System.getProperty("TrxFrequency").trim().contains("Quarterly"))
                        {
                                        trxfreq="4";
                        }
                        else if (System.getProperty("TrxFrequency").trim().contains("Semi"))
                        {
                                        trxfreq="2";
                        }
                        
                        else
                        {
                                        Reporter.logEvent(Status.FAIL, "In Costaverage page enter the correct ", "Transferfrequency"+trxfreq, true);
                                        return;
                        }
                        Web.waitForElement(CAFrequency);
                        Common.selectbyvalues(CAFrequency, trxfreq);
                                                                                        
        }else {
                        Web.waitForElement(CAFrequency);
                        Web.selectDropDownOption(CAFrequency, trxfrequency);
        }
	}

	public void SelectTransDay(String Transday) throws InterruptedException {
        
        
        Thread.sleep(3000);
        if(System.getProperty("TrnsferDay")==null)
        {   
              Web.waitForElement(TransferDay);
              Web.selectDropDownOption(TransferDay, Transday);
        }
        else if( System.getProperty("TrnsferDay").trim().length() > 0)
        {
              Web.waitForElement(TransferDay);
              Web.selectDropDownOption(TransferDay, System.getProperty("TrnsferDay").trim());       
                                                 
        }else {
              Web.waitForElement(TransferDay);
              Web.selectDropDownOption(TransferDay, Transday);
        }
        
 
        Web.waitForElement(TransferDay);
	}
	

   
    
    public void setNumberofTransfer(String NtransferDay) {
          if(System.getProperty("NumberofTransfer")==null)
          {
                 Web.waitForElement(CANumberofTransfer);
                 Web.setTextToTextBox(CANumberofTransfer, NtransferDay);
          }
          else if( System.getProperty("NumberofTransfer").trim().length() > 0)
          {
                 Web.waitForElement(CANumberofTransfer);
                 Web.setTextToTextBox(CANumberofTransfer, System.getProperty("NumberofTransfer").trim()); 
                                                    
          }else {
                 Web.waitForElement(CANumberofTransfer);
                 Web.setTextToTextBox(CANumberofTransfer, NtransferDay);
          }
          
    
          Web.waitForElement(CANumberofTransfer);
    }




	
	public void clickCostaverageaddbutton() {

		Web.waitForElement(Costaveraging_addbutton);
		Web.clickOnElement(Costaveraging_addbutton);
	}
		
	

	
	public void EnterEffectivedate(String effectivedate) {
		Web.waitForElement(Effectivedate_TB);
		Web.setTextToTextBox(Effectivedate_TB, effectivedate);
		if (Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
			Reporter.logEvent(Status.PASS, "In Cost Average page enter the Effective date",
					"the Effective date is[" + effectivedate + "] entered sucessfully", false);
		} else {
			Reporter.logEvent(Status.FAIL, "In Cost Average page enter the Effective date",
					"the Effective date is[" + effectivedate + "] not entered sucessfully", true);
		}
	}

	public void Numberoftransfer(String NumofTransfer) {
		Web.waitForElement(NumberTransfer);
		Web.setTextToTextBox(NumberTransfer, NumofTransfer);
		if (NumberTransfer.getAttribute("value").equalsIgnoreCase(NumofTransfer)) {
			Reporter.logEvent(Status.PASS, "In Cost Average page enter the Number of transfer",
					"the No. of transfer is[" + NumofTransfer + "] entered sucessfully", false);
		} else {
			Reporter.logEvent(Status.FAIL, "In Cost Average page enter the Number of transfer",
					"the No. of transfer is[" + NumofTransfer + "] not entered sucessfully", true);
		}
	}

	public void EnterBegindate(String Begindte) {
		Web.waitForElement(Begindate);
		Web.setTextToTextBox(Begindate, Begindte);
		if (Begindate.getAttribute("value").equalsIgnoreCase(Begindte)) {
			Reporter.logEvent(Status.PASS, "In Cost Average page enter the Begin date",
					"the Begin date is[" + Begindte + "] entered sucessfully", false);
		} else {
			Reporter.logEvent(Status.FAIL, "In Cost Average page enter the Begin date",
					"the Begin date is[" + Begindte + "] not entered sucessfully", true);
		}
	}

	public void SelectTransferType(String type) {
		Web.waitForElement(Transfertype);
		Web.selectDropDownOption(Transfertype, type);
	}

	public void SelectTransferDay(String TDay) 
	{
		Web.waitForElement(TransferDay);
		Web.selectDropDownOption(TransferDay, TDay);

	}

	public void VerifyErrorText(String expectedtext) {
		try {
		Web.waitForElement(ErrorText);	
		String Expected = Stock.GetParameterValue("ErrorText");
		String Actual = ErrorText.getText();		
		Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
		Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		
	}
		catch (Exception e) {
			Reporter.logEvent(Status.FAIL,"Display Expected error text messaage","took Longer than normal", true);
			e.printStackTrace();
		}	
	}
	public void EnterfromAmout(String frmamt) 
	
	{
		Web.waitForElement(FrmAMount);
		Web.setTextToTextBox(FrmAMount, frmamt);
	}
	
	
public void EnterToAmout(String Toamt) 
	
	{
		Web.waitForElement(ToAMount);
		Web.setTextToTextBox(ToAMount, Toamt);
	}
	
public Costaveraging(LoadableComponent<?> parent) {
	this.parent = new LandingPage();
	PageFactory.initElements(lib.Web.getDriver(), this);
}


LoadableComponent<?> parent;


	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Costaveraging_addbutton);
		Assert.assertTrue(Web.isWebElementDisplayed(Costaveraging_addbutton), "Costaveraging  is Not Loaded\n");
	}

}
