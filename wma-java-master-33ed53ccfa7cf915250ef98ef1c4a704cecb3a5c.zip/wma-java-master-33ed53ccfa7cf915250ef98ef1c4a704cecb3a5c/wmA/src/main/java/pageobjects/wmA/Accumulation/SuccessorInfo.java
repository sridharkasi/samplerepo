
package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class SuccessorInfo extends LoadableComponent<SuccessorInfo>{
	
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataPrefix']")
	private  WebElement Succesorinfo_Prefix;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataFirstName']")
	private  WebElement Succesorinfo_Firstname;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataLastName']")
	private  WebElement Succesorinfo_Lastname;
	
	@FindBy(xpath="//input[@id='mainform:succesorsearch']")
	private  WebElement Succesorinfo_PartySearch;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntrySuccessorAnnDataSexCode']")
	private  WebElement Succesorinfo_Gender;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataBirthdate_input']")
	private  WebElement Succesorinfo_DOB;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataAddressLine1']")
	private  WebElement Succesorinfo_Residentaddress;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataCity']")
	private  WebElement Succesorinfo_City;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntrySuccessorAnnDataState']")
	private  WebElement Succesorinfo_state;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntrySuccessorAnnDataCountryCode']")
	private  WebElement Succesorinfo_Country;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntrySuccessorAnnDataZipPostalCode']")
	private  WebElement Succesorinfo_Zipcode;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryContractEntrySuccessorAnnDataTaxIdNumber")
	private static WebElement taxid_TB;
	
	public void SuccessorInfoDeatils(String Gentype,String DOB,String city,String state) {
		Web.waitForElement(Succesorinfo_Firstname);	
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(Succesorinfo_Firstname, Fnames);
		if(Succesorinfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Succesor info page Enter the payer First name", "The successor First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesor info page Enter the payer First name", "The succeseor First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(Succesorinfo_Lastname);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(Succesorinfo_Lastname, Lnames);
		if(Succesorinfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the payer Last name", "The Succesor Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the owner Last name", "The Succesor  Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(Succesorinfo_Gender);
		Web.selectDropDownOption(Succesorinfo_Gender, Gentype);
		Web.waitForElement(taxid_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(taxid_TB, ssn);
		Web.waitForElement(Succesorinfo_DOB);		
		Web.setTextToTextBox(Succesorinfo_DOB, DOB);
		if(Succesorinfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the DOB", "The Succesor DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the  DOB", "The Succesor DOB is ["+ DOB+"] entered Successfully", true);
		}
		Web.waitForElement(Succesorinfo_Residentaddress);
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(Succesorinfo_Residentaddress, address);
		if(Succesorinfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the address", "The Succesor address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the address", "The Succesor address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(Succesorinfo_City);
				 Web.setTextToTextBox(Succesorinfo_City, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(Succesorinfo_City);
				Web.setTextToTextBox(Succesorinfo_City, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(Succesorinfo_City);
				 Web.setTextToTextBox(Succesorinfo_City, city);
			}
		 Web.waitForElement(Succesorinfo_Zipcode);	
		 String Zip = Common.AutoZipcode();
			Web.setTextToTextBox(Succesorinfo_Zipcode, Zip);
			if(Succesorinfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the Zipcode", "The Succesor Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the Zipcode", "The Succesor Zipcode is ["+ Zip+"] entered Successfully", true);
			}
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(Succesorinfo_state);
				 Web.selectDropDownOption(Succesorinfo_state, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(Succesorinfo_state);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(Succesorinfo_state, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(Succesorinfo_state);
				 Web.selectDropDownOption(Succesorinfo_state, state);
			}
	}

	
	public void EnterSuccesorinfoFirstname(String Fnames) {
		Web.waitForElement(Succesorinfo_Firstname);		
		Web.setTextToTextBox(Succesorinfo_Firstname, Fnames);
		if(Succesorinfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Succesor info page Enter the payer First name", "The successor First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesor info page Enter the payer First name", "The succeseor First name is ["+ Fnames+"] entered Successfully", true);
		}
	}

	
	public void EnterSuccesorinfoLastname(String Lnames) {
		Web.waitForElement(Succesorinfo_Lastname);		
		Web.setTextToTextBox(Succesorinfo_Lastname, Lnames);
		if(Succesorinfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the payer Last name", "The Succesor Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the owner Last name", "The Succesor  Last name is ["+ Lnames+"] entered Successfully", true);
		}
	}
	
	public void SelectSuccesorinfoGender(String Gentype)
	
	{
		Web.waitForElement(Succesorinfo_Gender);
		Web.selectDropDownOption(Succesorinfo_Gender, Gentype);
	}
	
	public void EnterSuccesorinfoDOB(String DOB) {
		Web.waitForElement(Succesorinfo_DOB);		
		Web.setTextToTextBox(Succesorinfo_DOB, DOB);
		if(Succesorinfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the DOB", "The Succesor DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the  DOB", "The Succesor DOB is ["+ DOB+"] entered Successfully", true);
		}
	}
	
	
	public void EnterSuccesorinfoaddress(String address) {
		Web.waitForElement(Succesorinfo_Residentaddress);		
		Web.setTextToTextBox(Succesorinfo_Residentaddress, address);
		if(Succesorinfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the address", "The Succesor address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the address", "The Succesor address is ["+ address+"] entered Successfully", true);
		}
	}
	
	
	public void EnterSuccesorinfocity(String city) {
		Web.waitForElement(Succesorinfo_City);		
		Web.setTextToTextBox(Succesorinfo_City, city);
		if(Succesorinfo_City.getAttribute("value").equalsIgnoreCase(city)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the city", "The Succesor city is ["+ city+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the city", "The Succesor city is ["+ city+"] entered Successfully", true);
		}
	}
	
	
	public void EnterSuccesorinfozip(String Zip) {
		Web.waitForElement(Succesorinfo_Zipcode);		
		Web.setTextToTextBox(Succesorinfo_Zipcode, Zip);
		if(Succesorinfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Succesorinfo page Enter the Zipcode", "The Succesor Zipcode is ["+ Zip+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Succesorinfo page Enter the Zipcode", "The Succesor Zipcode is ["+ Zip+"] entered Successfully", true);
		}
	}
	
public void SelectSuccesorinfoState(String state)
	
	{
		Web.waitForElement(Succesorinfo_state);
		Web.selectDropDownOption(Succesorinfo_state, state);
	}

public void SelectSuccesorinfoCountry(String country)

{
	Web.waitForElement(Succesorinfo_Country);
	Web.selectDropDownOption(Succesorinfo_Country, country	);
}
	
	public SuccessorInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Succesorinfo_Firstname);
		Assert.assertTrue(Web.isWebElementDisplayed(Succesorinfo_Firstname),"Successorinfo Page is Not Loaded\n");
	
	}

}

	
	


