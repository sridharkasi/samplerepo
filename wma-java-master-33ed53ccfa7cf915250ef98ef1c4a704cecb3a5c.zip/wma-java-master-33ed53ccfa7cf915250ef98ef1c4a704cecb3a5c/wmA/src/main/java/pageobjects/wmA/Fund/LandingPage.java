package pageobjects.wmA.Fund;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;


public class LandingPage  extends LoadableComponent<LandingPage>{
	
	//locators
	@FindBy(linkText = "Accumulation")
	private WebElement ContractAddLink;
	
	@FindBy(xpath = "//li[@id='accumulationMain']/div/a")
	private WebElement submenu;
	
	@FindBy(id= "iconform:mainIcon")
	private   WebElement homebutton;
	
	@FindBy(id="nextbutton")
	private  WebElement NextButton;
	
	//Variables
	@SuppressWarnings("unused")
	private LoadableComponent<?> parent;

	/**
	 * Constructor taking parent as input
	 * 
	 * @param parent
	 */
	
	
	
	public LandingPage() {
		
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		
		if (fieldName.trim().equalsIgnoreCase("Menu_Accumulation")) {
			return this.ContractAddLink;
		}

		
		if (fieldName.trim().equalsIgnoreCase("Submenu_contractAdd")) {
			return this.submenu;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Home_Button")) {
			return this.homebutton;
		}

		if (fieldName.trim().equalsIgnoreCase("Next_Button")) {
			return this.NextButton;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	/*Section 1 load and isLoaded methods
	 *In the isLoaded method verify the page is available use any element assertion on the page
	 *In the load() method add previous page.get to get the page
	 */
	@Override
	protected void load() {

		homebutton.click();
	// Web.actionsClickOnElement(homebutton);
		try {
			if (Common.isAlerPresent()) {
				
				Common.HandlePopAlert();
				Web.waitForElement(ContractAddLink);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	@Override
	protected void isLoaded() throws Error {
		
		Assert.assertTrue(Web.isWebElementDisplayed(this.ContractAddLink),"wmA Landing Page is Not Loaded\n");
	}

	
	
	public void clickcontractADD() {
		try {
			Common.ClickSubmenu(submenu);
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	}
	
	public void ClickNext() {
		try {
			Web.clickOnElement(NextButton);
		}
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	}
}
