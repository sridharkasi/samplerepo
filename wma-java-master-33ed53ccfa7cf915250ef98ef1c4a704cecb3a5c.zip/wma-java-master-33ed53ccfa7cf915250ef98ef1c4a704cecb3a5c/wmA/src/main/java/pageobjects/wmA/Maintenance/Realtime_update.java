package pageobjects.wmA.Maintenance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import org.openqa.selenium.support.FindBy;

import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class Realtime_update extends LoadableComponent<Realtime_update>{
	
	@FindBy(id="mainform:realtimeUpdateEffectiveDate_input")
	private static WebElement realtimeeffectivedate;
	
	@FindBy(id="mainform:update")
	private  WebElement HistoryupdateBT;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy(id="overridebox")
	private  WebElement overidebox;
	
	public void clickoverirde() {
		Web.waitForElement(overidebox);
		Web.clickOnElement(overidebox);
	}
	
	public void setRealTimedateCAchange(String CAed) throws InterruptedException {
        
        if(System.getProperty("BeginDate")==null)
        {
                        Web.waitForElement(realtimeeffectivedate);
        Web.setTextToTextBox(realtimeeffectivedate, CAed);
        if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(CAed))
                                        Reporter.logEvent(Status.PASS, "In Real Time page enter the Effective date date", "the Effective Date is["+CAed+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In Real Time page enter the Effective date ", "the Effective Date is["+CAed+"] Not entered sucessfully", false);
        }
        else if( System.getProperty("BeginDate").trim().length() > 0)
        {
                        Web.waitForElement(realtimeeffectivedate);
                        Web.setTextToTextBox(realtimeeffectivedate, System.getProperty("BeginDate").trim());
                                        
            if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(System.getProperty("BeginDate").trim()))
                                        Reporter.logEvent(Status.PASS, "In Real Time page enter the Effective date ", "the Effective Date is["+System.getProperty("BeginDate").trim()+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In Real Time page enter the Effective date ", "the Effective Date["+System.getProperty("BeginDate").trim()+"] Not entered sucessfully", false);
                                                                                                        
        }else {
                        Web.waitForElement(realtimeeffectivedate);
        Web.setTextToTextBox(realtimeeffectivedate, CAed);
        if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase( CAed))
                                        Reporter.logEvent(Status.PASS, "In Real Time page enter the Effective date ", "the Effective Dateis["+CAed+"] entered sucessfully", false);
                        else
                                        Reporter.logEvent(Status.FAIL, "In Real Time page enter the Effective date ", "the Effective Date is["+CAed+"] Not entered sucessfully", false);
        }
        

	}

	
	public void VerifyErrorText(String expectedtext) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(ErrorText);	
		String Expected = expectedtext;
		String Actual = ErrorText.getText();
		if(ErrorText.getText().contains(Expected)){
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
	}
		
	public void RealtimeDrpDwn(String selectrealtime) {
		Web.waitForElement(RealtimeDrpDwn);
		 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
		 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
	}
	
	 public void clicksumbmit() {
		 //  Web.waitForElement(submit);
	   	Web.clickOnElement(submit);
	   	if(submit.isDisplayed()){
			
			  Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page Click on Submit button ", "the Submit button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page Click on Submit button", "the Submit button is not clicked sucessfully", true);
			 }
	   }
	
	public void enterrealtimeupdateEffectivedate(String Effdate) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(realtimeeffectivedate);
			Web.setTextToTextBox(realtimeeffectivedate, Effdate);
			Web.waitForElement(realtimeeffectivedate);
			 if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(realtimeeffectivedate);
			Web.setTextToTextBox(realtimeeffectivedate,  System.getProperty("TrxEffectiveDate"));
			Web.waitForElement(realtimeeffectivedate);
			 if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase( System.getProperty("TrxEffectiveDate"))) {
				 Reporter.logEvent(Status.PASS, "In Realtime update page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Realtime update page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(realtimeeffectivedate);
			Web.setTextToTextBox(realtimeeffectivedate, Effdate);
			Web.waitForElement(realtimeeffectivedate);
			 if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
		
		
	}
	
	public void enterrealtimeupdateEffectivedateAssetrebal(String Effdate) {
	
			Web.waitForElement(realtimeeffectivedate);
			Web.setTextToTextBox(realtimeeffectivedate, Effdate);
			Web.waitForElement(realtimeeffectivedate);
			 if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Realtime update page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		
		
		
	}
	
	public void setRealTimedateFavchange(String Faved) throws InterruptedException {
        
        if(System.getProperty("FavEffectDate")==null)
        {
               Web.waitForElement(realtimeeffectivedate);
        Web.setTextToTextBox(realtimeeffectivedate, Faved);
        if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(Faved))
                     Reporter.logEvent(Status.PASS, "In real Time page enter the Effective Date", "the Effective Date is["+Faved+"] entered sucessfully", false);
               else
                     Reporter.logEvent(Status.FAIL, "In  real Time page enter the Effective Date", "the Effective Date is["+Faved+"] Not entered sucessfully", false);
        }
        else if( System.getProperty("FavEffectDate").trim().length() > 0)
        {
               Web.waitForElement(realtimeeffectivedate);
               Web.setTextToTextBox(realtimeeffectivedate, System.getProperty("FavEffectDate").trim());
                      
            if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase(System.getProperty("FavEffectDate").trim()))
                     Reporter.logEvent(Status.PASS, "In  real Time page enter the Effective Date", "the Effective Date is["+System.getProperty("FavEffectDate").trim()+"] entered sucessfully", false);
               else
                      Reporter.logEvent(Status.FAIL, "In  real Time page enter the Effective Date", "the effective Date is["+System.getProperty("FavEffectDate").trim()+"] Not entered sucessfully", false);
                                                 
        }else {
               Web.waitForElement(realtimeeffectivedate);
        Web.setTextToTextBox(realtimeeffectivedate, Faved);
        if(realtimeeffectivedate.getAttribute("value").equalsIgnoreCase( Faved))
                     Reporter.logEvent(Status.PASS, "In real Time page enter the Effective Date", "the Effective Date is["+Faved+"] entered sucessfully", false);
               else
                     Reporter.logEvent(Status.FAIL, "In  real Time page enter the Effective Date", "the Effective Date is["+Faved+"] Not entered sucessfully", false);
        }
        

 }


	public Realtime_update(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(realtimeeffectivedate);
		Assert.assertTrue(Web.isWebElementDisplayed(realtimeeffectivedate),"Maintenance reatime update Page is Not Loaded\n");
	}

}
