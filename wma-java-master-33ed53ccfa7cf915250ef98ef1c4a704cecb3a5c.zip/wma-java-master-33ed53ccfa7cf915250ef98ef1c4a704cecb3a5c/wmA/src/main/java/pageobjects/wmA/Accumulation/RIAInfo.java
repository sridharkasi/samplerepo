package pageobjects.wmA.Accumulation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class RIAInfo extends LoadableComponent<RIAInfo>{
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorFirstName")
	private  WebElement RIA_FirstName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorLastName")
	private  WebElement RIA_LastName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorTaxIdNumber")
	private  WebElement RIA_SSN_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorBirthdate_input")
	private  WebElement RIA_Dob_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorSexCode")
	private  WebElement RIA_Gender_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorStartDate_input")
	private  WebElement RIA_Startdate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorEndDate_input")
	private  WebElement RIA_enddate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorAddressLine1")
	private  WebElement RIA_Addres1_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorCity")
	private  WebElement RIA_City_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorState")
	private  WebElement RIA_State_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorZipPostalCode")
	private  WebElement RIA_Zip_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryRegisteredInvestmentAdvisorZipPostalCode4")
	private  WebElement RIA_remaingZIP_TB;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("RIAInfo_Gender")) {
			return this.RIA_Gender_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("RIAInfo_State")) {
			return this.RIA_State_LB;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	public void RIPDetails(String Gentype,String DOB,String city,String state, String sdate) throws ParseException {
		Web.waitForElement(RIA_FirstName_TB);
		String FirName = Common.randomvaildFirstname();
		Web.setTextToTextBox(RIA_FirstName_TB, FirName);
		if(RIA_FirstName_TB.getAttribute("value").equalsIgnoreCase(FirName)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", true);
		}
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(RIA_LastName_TB, Lnames);
		if(RIA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Last Name", "the Last Name is["+ Lnames+"] is entered successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Last Name", "the Last Name is["+ Lnames+"] is entered successfully", true);
		}
		String SSN = Common.generateSSN();
		Web.setTextToTextBox(RIA_SSN_TB, SSN);
		if(RIA_SSN_TB.getAttribute("value").equalsIgnoreCase(SSN)) {
			lib.Reporter.logEvent(Status.PASS, "In the RIA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", false);			
		}
		else {
			lib.Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", true);
		}
		Web.setTextToTextBox(RIA_Dob_TB, DOB);
		if(RIA_Dob_TB.getAttribute("value").equalsIgnoreCase(DOB)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Date of birth", "the Date of birth ["+ DOB+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Date of birth", "the Date of birth ["+ DOB+"] is entered successfully", true);
		}
		Web.waitForElement(RIA_Gender_LB);
		Web.selectDropDownOption(RIA_Gender_LB, Gentype);
		if(System.getProperty("EffectiveDate")==null)
		{
			Web.waitForElement(RIA_Startdate_TB);
			 Web.setTextToTextBox(RIA_Startdate_TB, sdate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(RIA_Startdate_TB);
			Web.setTextToTextBox(RIA_Startdate_TB, System.getProperty("EffectiveDate").trim());	
								
		}else {
			Web.waitForElement(RIA_Startdate_TB);
			 Web.setTextToTextBox(RIA_Startdate_TB, sdate);
		}
		//Web.setTextToTextBox(RIA_Startdate_TB, sdate);
		int z=1;
		String enddate;
		if(System.getProperty("EffectiveDate")==null)
		{
			
			enddate = sdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(RIA_enddate_TB);
			 Web.setTextToTextBox(RIA_enddate_TB, enddate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0) {
			
		enddate = System.getProperty("EffectiveDate");
		enddate = enddate.replace("/", "");
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(enddate));
		c.add(Calendar.YEAR, z); // number of days to add
		enddate = sdf.format(c.getTime());
		
			Web.waitForElement(RIA_enddate_TB);
			Web.setTextToTextBox(RIA_enddate_TB, enddate);	
								
		}else {
			enddate = sdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(RIA_enddate_TB);
			 Web.setTextToTextBox(RIA_enddate_TB, enddate);
		}
		
		
		String Address = Common.AddressGenerator();
		Web.setTextToTextBox(RIA_Addres1_TB, Address);
		if(RIA_Addres1_TB.getAttribute("value").equalsIgnoreCase(Address)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", true);
		}
		String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(RIA_Zip_TB, zip1);
		if(RIA_Zip_TB.getAttribute("value").equalsIgnoreCase(zip1)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", true);
		}
		if(System.getProperty("IssueState")==null)
		{
			Web.waitForElement(RIA_State_LB);
			 Web.selectDropDownOption(RIA_State_LB, state);
		}
		else if( System.getProperty("IssueState").trim().length() > 0)
		{
			Web.waitForElement(RIA_State_LB);
			//Web.selectDropDownOption(RIA_State_LB, System.getProperty("IssueState").trim());
			Common.selectbyvalues(RIA_State_LB, System.getProperty("IssueState").trim());										
		}else {
			Web.waitForElement(RIA_State_LB);
			 Web.selectDropDownOption(RIA_State_LB, state);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(RIA_City_TB);
				 Web.setTextToTextBox(RIA_City_TB, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(RIA_City_TB);
				Web.setTextToTextBox(RIA_City_TB, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(RIA_City_TB);
				 Web.setTextToTextBox(RIA_City_TB, city);
			}
	}
	
	public void EnterRIAzipcode(String zip) {
		
		String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(RIA_Zip_TB, zip1);
		if(RIA_Zip_TB.getAttribute("value").equalsIgnoreCase(zip1)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", true);
		}
	}
	
	public void SelectRIAstate (String state) {
	Web.selectDropDownOption(RIA_State_LB, state);
	
	}
	
	public void EnterRIAcity(String city) {
		Web.setTextToTextBox(RIA_City_TB, city);
		if(RIA_City_TB.getAttribute("value").equalsIgnoreCase(city)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the City", "the City is["+ city+"] is Entered successfully", false);
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the City", "the City is["+ city+"] is Entered successfully", true);
		}
	}
	
	public void EnterRIAaddressline1 (String addrss) {
		String Address = Common.AddressGenerator();
		Web.setTextToTextBox(RIA_Addres1_TB, Address);
		if(RIA_Addres1_TB.getAttribute("value").equalsIgnoreCase(Address)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", true);
		}
	}
	
	public void EnterRIAenddate(String enddate) throws ParseException {
		
		int z=1;
		
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(enddate));
		c.add(Calendar.YEAR, z); // number of days to add
		enddate = sdf.format(c.getTime());
		Web.setTextToTextBox(RIA_enddate_TB, enddate);
		if(RIA_enddate_TB.getAttribute("value").equalsIgnoreCase(enddate)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", true);
		}
		}
	
	public void EnterRIAStartdate(String sdate) {
		Web.setTextToTextBox(RIA_Startdate_TB, sdate);
		if(RIA_Startdate_TB.getAttribute("value").equalsIgnoreCase(sdate)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", true);
		}
	}
	
	public void SelectRIAgender(String Gender) {
		Web.selectDropDownOption(RIA_Gender_LB, Gender);
	}
	
	public void EnterRIADOB(String dob) {
		Web.setTextToTextBox(RIA_Dob_TB, dob);
		if(RIA_Dob_TB.getAttribute("value").equalsIgnoreCase(dob)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", true);
		}
	}
	
	public void EnterRIAssn(String ssn) {
		String SSN = Common.generateSSN();
		Web.setTextToTextBox(RIA_SSN_TB, SSN);
		if(RIA_SSN_TB.getAttribute("value").equalsIgnoreCase(SSN)) {
			lib.Reporter.logEvent(Status.PASS, "In the RIA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", false);			
		}
		else {
			lib.Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", true);
		}
	}
	
	public void EnterRIALastNAme(String Lname) {
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(RIA_LastName_TB, Lnames);
		if(RIA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", true);
		}
	}
	
	public void EnterRIAFirstName (String Fname) throws InterruptedException {
		
		Web.waitForElement(RIA_FirstName_TB);
		String FirName = Common.randomvaildFirstname();
		Web.setTextToTextBox(RIA_FirstName_TB, FirName);
		if(RIA_FirstName_TB.getAttribute("value").equalsIgnoreCase(FirName)) {
			Reporter.logEvent(Status.PASS, "In the RIA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the RIA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", true);
		}
	}
	
	public RIAInfo (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(RIA_FirstName_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(RIA_FirstName_TB),"Login Page is Not Loaded\n");
	
	}

}
