package pageobjects.wmA.Maintenance;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class ProducerInformation extends LoadableComponent<ProducerInformation>{
	
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoAgentLastName")
	private static WebElement AdvisorLastName_TB;
	
	@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoAgentFirstName")
	private static WebElement AdvisoryFirstName_TB;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoAgentFirstName")
	private static WebElement AdvisoryFirstName_TB2;
	
	@FindBy(id="mainform:AdvisorAgentInfo:1:advisorAgentInfoAgentLastName")
	private static WebElement AdvisorLastName_TB2;
	
	@FindBy(id="mainform:producerProfileEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	public void EnterEffectivedate(String eff) {
		Web.waitForElement(Effectivedate_TB);
		Web.setTextToTextBox(Effectivedate_TB, eff);
		
	}
	
	public void VerifFirstName1() {
		Web.waitForElement(AdvisoryFirstName_TB);
		if(AdvisoryFirstName_TB.getAttribute("value").equalsIgnoreCase(Common.Contractinfo.get("AdvisoryFirstName1"))) {
			 Reporter.logEvent(Status.PASS, "In Producer Information the excpected 1st Adivosry First name is ["+Common.Contractinfo.get("AdvisoryFirstName1")+"]", "the Actual First name is["+AdvisoryFirstName_TB.getAttribute("value")+"] is displayed sucessfully", false);
		}else {
			 Reporter.logEvent(Status.FAIL, "In Producer Information the excpected 1st Adivosry First name is ["+Common.Contractinfo.get("AdvisoryFirstName1")+"]", "the Actual First name is["+AdvisoryFirstName_TB.getAttribute("value")+"] is not displayed sucessfully", false);
		}
	}
	
	public void VerifFirstName2() {
		Web.waitForElement(AdvisoryFirstName_TB);
		if(AdvisoryFirstName_TB2.getAttribute("value").equalsIgnoreCase(Common.Contractinfo.get("AdvisoryFirstName2"))) {
			 Reporter.logEvent(Status.PASS, "In Producer Information the excpected 2nd Adivosry First name is ["+Common.Contractinfo.get("AdvisoryFirstName2")+"]", "the Actual First name is["+AdvisoryFirstName_TB2.getAttribute("value")+"] is displayed sucessfully", false);
		}else {
			 Reporter.logEvent(Status.FAIL, "In Producer Information the excpected 2nd Adivosry First name is ["+Common.Contractinfo.get("AdvisoryFirstName2")+"]", "the Actual First name is["+AdvisoryFirstName_TB2.getAttribute("value")+"] is not displayed sucessfully", false);
		}
	}
	
	public void VerifyAdivsoryLastName1() {
		Web.waitForElement(AdvisorLastName_TB);
		if(AdvisorLastName_TB.getAttribute("value").equalsIgnoreCase(Stock.GetParameterValue("ProducerInfo_Lname"))) {
			 Reporter.logEvent(Status.PASS, "In Producer Information the excpected 1st Adivosry last name is ["+Stock.GetParameterValue("ProducerInfo_Lname")+"]", "the Actual last name is["+AdvisorLastName_TB.getAttribute("value")+"] is displayed sucessfully", false);
		}else {
			 Reporter.logEvent(Status.FAIL, "In Producer Information the excpected 1st Adivosry last name is ["+Stock.GetParameterValue("ProducerInfo_Lname")+"]", "the Actual last name is["+AdvisorLastName_TB.getAttribute("value")+"] is not displayed sucessfully", false);
		}
	}
	
	public void VerifyAdivsoryLastName2() {
		Web.waitForElement(AdvisorLastName_TB2);
		if(AdvisorLastName_TB2.getAttribute("value").equalsIgnoreCase(Stock.GetParameterValue("ProducerInfo_Lname2"))) {
			 Reporter.logEvent(Status.PASS, "In Producer Information the excpected 2nd Adivosry last name is ["+Stock.GetParameterValue("ProducerInfo_Lname2")+"]", "the Actual last name is["+AdvisorLastName_TB2.getAttribute("value")+"] is displayed sucessfully", false);
		}else {
			 Reporter.logEvent(Status.FAIL, "In Producer Information the excpected 2nd Adivosry last name is ["+Stock.GetParameterValue("ProducerInfo_Lname2")+"]", "the Actual last name is["+AdvisorLastName_TB2.getAttribute("value")+"] is not displayed sucessfully", false);
		}
	}

	public ProducerInformation(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(AdvisorLastName_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(AdvisorLastName_TB),"Producer Information Page is Not Loaded\n");
	}

}
