package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class HCCExpressAdd extends LoadableComponent<HCCExpressAdd>{
	
    @FindBy (id="mainform:add")
	private  WebElement HCC_RaiderTypeAdd_BT;
    
    @FindBy(id="mainform:hccRiderType")
    private  WebElement HCC_RaiderType_LB;
    
    @FindBy (id="mainform:HccAdd:0:hccAddPlanCode")
	private  WebElement HCC_RaiderPlan_LB;
    
    @FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
    
    @SuppressWarnings("unused")
   	private WebElement getWebElement(String fieldName) {
   		

   		if (fieldName.trim().equalsIgnoreCase("HCC_Select_RiderType")) {
   			return this.HCC_RaiderType_LB;
   		}
   		
   		if (fieldName.trim().equalsIgnoreCase("HCC_Select_RiderPlan")) {
   			return this.HCC_RaiderPlan_LB;
   		}
   		
   		if (fieldName.trim().equalsIgnoreCase("HCC_ClickOn_Add")) {
   			return this.HCC_RaiderTypeAdd_BT;
   		}
   		
   		
   		
   		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
   				+ fieldName + "'",
   				"No WebElement mapped for this field\nPage: <b>"
   						+ this.getClass().getName() + "</b>", false);

   		return null;
   	}
    
    
    public void SelectRidertype(String ridertype) {
    	if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null)
    	{
    		System.out.println("Rider Type is not selected Since its null in Test data and parameter");
    	}
    	
    	else if( System.getProperty("RiderType")!=null || Stock.GetParameterValue("RiderType")!=null)
		{
    		if(System.getProperty("RiderType")!=null && (System.getProperty("RiderType").trim().length()>0)) {
    			System.out.println("Data is picekd from paramter for rider type");
    			Web.waitForElement(HCC_RaiderType_LB);
        		Web.selectDropDownOption(HCC_RaiderType_LB,System.getProperty("RiderType"));
    		}else if(Stock.GetParameterValue("RiderType") != null && Stock.GetParameterValue("RiderType").length()>0) {
    			System.out.println("Data is picekd from Test data for rider type");
    			Web.waitForElement(HCC_RaiderType_LB);
        		Web.selectDropDownOption(HCC_RaiderType_LB,ridertype);
    		}
    		
		}else {
			 System.out.println("Rider Type is not selected for this test case");
		}
    	
    }
    
    public void SelectRiderPlan() {
    	if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null)
    	{
    		System.out.println("Rider Plan Since its null in Test data and parameter");
    	}
    	
    	else if( System.getProperty("RiderType")!=null || Stock.GetParameterValue("RiderType")!=null)
		{
    		if(System.getProperty("RiderType")!=null && (System.getProperty("RiderType").trim().length()>0)) {
    			System.out.println("Data is picekd from paramter for rider plan");
    			Web.waitForElement(HCC_RaiderPlan_LB);
        		Web.selectDropDownOption(HCC_RaiderPlan_LB,System.getProperty("RiderPlan"));
    		}else if(Stock.GetParameterValue("RiderType") != null && Stock.GetParameterValue("RiderType").length()>0){
    			System.out.println("Data is picekd from Test data for rider plan");
    			Web.waitForElement(HCC_RaiderPlan_LB);
        		Web.selectDropDownOption(HCC_RaiderPlan_LB,Stock.GetParameterValue("RiderPlan"));
    		}
    		
		}else {
			 System.out.println("Rider plan is not selected for this test case");
		}
    	
    }

		public HCCExpressAdd(LoadableComponent<?> parent) {
			this.parent = new LandingPage();
			PageFactory.initElements(lib.Web.getDriver(), this);
		}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(HCC_RaiderTypeAdd_BT);
		Assert.assertTrue(Web.isWebElementDisplayed(HCC_RaiderTypeAdd_BT),"HCC Express Add Page is Not Loaded\n");
	
	}

}
