package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import lib.Reporter;
import lib.Web;

public class ContractInfo extends LoadableComponent<ContractInfo>{
	
	@FindBy(id="mainform:contractEntryRetirementAge")
	private  WebElement AnnuityRetAge;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryManagementCode")
	private WebElement Managementcode_LB;
	
	@FindBy(id="mainform:contractEntryAdministrationCode")	
	private WebElement Admincode_LB;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("ContractInfo_Retriementage")) {
			return this.AnnuityRetAge;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	public void AnnuityRetAge(String retage) throws InterruptedException {
		Web.waitForElement(AnnuityRetAge);
		 Web.setTextToTextBox(AnnuityRetAge, retage);
		 Assert.assertTrue(AnnuityRetAge.getAttribute("value").contains(retage), "Annuity retriment age set with value [ :"+retage+"]");
		 Reporter.logEvent(Status.PASS, "In Contract Info page enter the Annuity Retriement age", "the Annuity Retriement age is["+ retage+"] entered successfully", false);
		
	}
	
	public void SelectManagementcode(String mgt) {
		Web.waitForElement(Managementcode_LB);
		Web.selectDropDownOption(Managementcode_LB, mgt);
	}
	
	public void SelectAdmincode(String adm) {
		Web.waitForElement(Admincode_LB);
		Web.selectDropDownOption(Admincode_LB, adm);
	}

	public ContractInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(AnnuityRetAge);
		Assert.assertTrue(Web.isWebElementDisplayed(AnnuityRetAge),"Contract Info Page is Not Loaded\n");
		
	}

}
