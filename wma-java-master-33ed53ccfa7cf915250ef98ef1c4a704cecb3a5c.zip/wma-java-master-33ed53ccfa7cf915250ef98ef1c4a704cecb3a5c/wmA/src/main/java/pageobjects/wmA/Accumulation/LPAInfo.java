package pageobjects.wmA.Accumulation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class LPAInfo extends LoadableComponent<LPAInfo>{
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataFirstName")
	private  WebElement LPA_FirstName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataLastName")
	private  WebElement LPA_LastName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataTaxIdNumber")
	private  WebElement LPA_SSN_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataBirthdate_input")
	private  WebElement LPA_Dob_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataSexCode")
	private  WebElement LPA_Gender_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataStartDate_input")
	private  WebElement LPA_Startdate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataEndDate_input")
	private  WebElement LPA_enddate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataAddressLine1")
	private  WebElement LPA_Addres1_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataCity")
	private  WebElement LPA_City_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataState")
	private  WebElement LPA_State_LB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataZipPostalCode")
	private  WebElement LPA_Zip_TB;
	
	@FindBy(id="mainform:contractEntryContractEntryLimitedPowerOfAttorneyDataZipPostalCode4")
	private  WebElement LPA_remaingZIP_TB;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("LPAInfo_Gender")) {
			return this.LPA_Gender_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("LPAInfo_State")) {
			return this.LPA_State_LB;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	
	public void EnterLPAzipcode(String zip) {
		
		String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(LPA_Zip_TB, zip1);
		if(LPA_Zip_TB.getAttribute("value").equalsIgnoreCase(zip1)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", true);
		}
	}
	
	public void SelectLPAstate (String state) {
	Web.selectDropDownOption(LPA_State_LB, state);
	
	}
	
	public void EnterLPAcity(String city) {
		Web.setTextToTextBox(LPA_City_TB, city);
		if(LPA_City_TB.getAttribute("value").equalsIgnoreCase(city)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the City", "the City is["+ city+"] is Entered successfully", false);
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the City", "the City is["+ city+"] is Entered successfully", true);
		}
	}
	
	public void EnterLPAaddressline1 (String addrss) {
		String Address = Common.AddressGenerator();
		Web.setTextToTextBox(LPA_Addres1_TB, Address);
		if(LPA_Addres1_TB.getAttribute("value").equalsIgnoreCase(Address)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", true);
		}
	}
	
	public void EnterLPAenddate(String enddate) {
		Web.setTextToTextBox(LPA_enddate_TB, enddate);
		if(LPA_enddate_TB.getAttribute("value").equalsIgnoreCase(enddate)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", true);
		}
		}
	
	public void EnterLPAStartdate(String sdate) {
		Web.setTextToTextBox(LPA_Startdate_TB, sdate);
		if(LPA_Startdate_TB.getAttribute("value").equalsIgnoreCase(sdate)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", true);
		}
	}
	
	public void SelectLPAgender(String Gender) {
		Web.selectDropDownOption(LPA_Gender_LB, Gender);
	}
	
	public void EnterLPADOB(String dob) {
		Web.setTextToTextBox(LPA_Dob_TB, dob);
		if(LPA_Dob_TB.getAttribute("value").equalsIgnoreCase(dob)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", true);
		}
	}
	
	public void EnterLPAssn(String ssn) {
		String SSN = Common.generateSSN();
		Web.setTextToTextBox(LPA_SSN_TB, SSN);
		if(LPA_SSN_TB.getAttribute("value").equalsIgnoreCase(SSN)) {
			lib.Reporter.logEvent(Status.PASS, "In the LPA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", false);			
		}
		else {
			lib.Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", true);
		}
	}
	
	public void EnterLPALastNAme(String Lname) {
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(LPA_LastName_TB, Lnames);
		if(LPA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", true);
		}
	}
	
	public void EnterLPAFirstName (String Fname) throws InterruptedException {
		
		Web.waitForElement(LPA_FirstName_TB);
		String FirName = Common.randomvaildFirstname();
		Web.setTextToTextBox(LPA_FirstName_TB, FirName);
		if(LPA_FirstName_TB.getAttribute("value").equalsIgnoreCase(FirName)) {
			Reporter.logEvent(Status.PASS, "In the LPA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the LPA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", true);
		}
	}
	
	
	
	public void LPADetails(String Gentype,String DOB,String city,String state ,String Startdate) throws ParseException {
		Web.waitForElement(LPA_FirstName_TB);	
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(LPA_FirstName_TB, Fnames);
		if(LPA_FirstName_TB.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In LPA page Enter the payer First name", "The LPA First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In LPA page Enter the payer First name", "The LPA First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(LPA_LastName_TB);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(LPA_LastName_TB, Lnames);
		if(LPA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In LPA page Enter the payer Last name", "The LPA Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In LPA page Enter the LPA Last name", "The LPA  Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(LPA_Gender_LB);
		Web.selectDropDownOption(LPA_Gender_LB, Gentype);
		Web.waitForElement(LPA_SSN_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(LPA_SSN_TB, ssn);
		Web.waitForElement(LPA_Dob_TB);		
		Web.setTextToTextBox(LPA_Dob_TB, DOB);
		
		if(LPA_Dob_TB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In LPA Info page Enter the DOB", "The LPA DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In LPAInfo page Enter the  DOB", "The LPA DOB is ["+ DOB+"] entered Successfully", true);
		}
		
		
		
		if(System.getProperty("EffectiveDate")==null)
		{
			Web.waitForElement(LPA_Startdate_TB);
			 Web.setTextToTextBox(LPA_Startdate_TB, Startdate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(LPA_Startdate_TB);
			Web.setTextToTextBox(LPA_Startdate_TB, System.getProperty("EffectiveDate").trim());	
								
		}else {
			Web.waitForElement(LPA_Startdate_TB);
			 Web.setTextToTextBox(LPA_Startdate_TB, Startdate);
		}

		
				
		int z=1;
		String enddate;
		if(System.getProperty("EffectiveDate")==null)
		{
			
			enddate = Startdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(LPA_enddate_TB);
			 Web.setTextToTextBox(LPA_enddate_TB, enddate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0) {
			
		enddate = System.getProperty("EffectiveDate");
		enddate = enddate.replace("/", "");
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(enddate));
		c.add(Calendar.YEAR, z); // number of days to add
		enddate = sdf.format(c.getTime());
		
			Web.waitForElement(LPA_enddate_TB);
			Web.setTextToTextBox(LPA_enddate_TB, enddate);	
								
		}else {
			enddate = Startdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(LPA_enddate_TB);
			 Web.setTextToTextBox(LPA_enddate_TB, enddate);
		}
		
		Web.waitForElement(LPA_Addres1_TB);	
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(LPA_Addres1_TB, address);
		if(LPA_Addres1_TB.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In LPA page Enter the address", "The LPA address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In LPA page Enter the address", "The LPA address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(LPA_City_TB);
				 Web.setTextToTextBox(LPA_City_TB, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(LPA_City_TB);
				Web.setTextToTextBox(LPA_City_TB, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(LPA_City_TB);
				 Web.setTextToTextBox(LPA_City_TB, city);
			}
			Web.waitForElement(LPA_Zip_TB);	
			String Zip = Common.AutoZipcode();
			Web.setTextToTextBox(LPA_Zip_TB, Zip);			
			if(LPA_Zip_TB.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In LPAInfo page Enter the Zipcode", "The LPA Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In LPAInfo page Enter the Zipcode", "The LPA Zipcode is ["+ Zip+"] entered Successfully", true);
			}
			
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(LPA_State_LB);
				 Web.selectDropDownOption(LPA_State_LB, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(LPA_State_LB);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(LPA_State_LB, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(LPA_State_LB);
				 Web.selectDropDownOption(LPA_State_LB, state);
			}
	}
	

	
	public LPAInfo (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(LPA_FirstName_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(LPA_FirstName_TB),"Login Page is Not Loaded\n");
	
	}

}
