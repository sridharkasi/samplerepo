package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class Co_Owner extends LoadableComponent<Co_Owner>{
	
   @FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataFirstName']")
	private  WebElement Co_Owner_Firstname;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataLastName']")
	private  WebElement Co_Owner_Lastname;
	
	@FindBy(xpath="//input[@id='mainform:coOwnsearch']")
	private  WebElement Co_Owner_PartySearch;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoOwnerDataSexCode']")
	private  WebElement Co_Owner_Gender;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataBirthdate_input']")
	private  WebElement Co_Owner_DOB;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataAddressLine1']")
	private  WebElement Co_Owner_Residentaddress;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataCity']")
	private  WebElement Co_Owner_City;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoOwnerDataState']")
	private  WebElement Co_Owner_state;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoOwnerDataCountryCode']")
	private  WebElement Co_Owner_Country;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoOwnerDataZipPostalCode']")
	private  WebElement Co_Owner_Zipcode;
	
	@FindBy(id="mainform:contractEntryContractEntryCoOwnerDataTaxIdNumber")
	private static WebElement taxid_TB;
	
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	

	
	public void EnterCo_OwnerInfoFirstname(String Fnames) {
		Web.waitForElement(Co_Owner_Firstname);		
		Web.setTextToTextBox(Co_Owner_Firstname, Fnames);
		if(Co_Owner_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_Owner Info page Enter the payer First name", "Co_Owner First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_Owner Info page Enter the payer First name", "The Co_Owner First name is ["+ Fnames+"] entered Successfully", true);
		}
	}

	
	public void EnterCo_OwnerInfoLastname(String Lnames) {
		Web.waitForElement(Co_Owner_Lastname);		
		Web.setTextToTextBox(Co_Owner_Lastname, Lnames);
		if(Co_Owner_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_OwnerInfo page Enter the payer Last name", "The Co_Owner Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_OwnerInfo page Enter the owner Last name", "The Co_Owner  Last name is ["+ Lnames+"] entered Successfully", true);
		}
	}
	
	public void SelectCo_OwnerInfoGender(String Gentype)
	
	{
		Web.waitForElement(Co_Owner_Gender);
		Web.selectDropDownOption(Co_Owner_Gender, Gentype);
	}
	
	public void EnterCo_OwnerInfoDOB(String DOB) {
		Web.waitForElement(Co_Owner_DOB);		
		Web.setTextToTextBox(Co_Owner_DOB, DOB);
		if(Co_Owner_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Co_OwnerInfo page Enter the DOB", "The Co_Owner DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_OwnerInfo page Enter the  DOB", "The Co_Owner DOB is ["+ DOB+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_OwnerInfoaddress(String address) {
		Web.waitForElement(Co_Owner_Residentaddress);		
		Web.setTextToTextBox(Co_Owner_Residentaddress, address);
		if(Co_Owner_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Co_OwnerInfo page Enter the address", "The Co_Owner address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_OwnerInfo page Enter the address", "The Co_Owner address is ["+ address+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_OwnerInfocity(String city) {
		Web.waitForElement(Co_Owner_City);		
		Web.setTextToTextBox(Co_Owner_City, city);
		if(Co_Owner_City.getAttribute("value").equalsIgnoreCase(city)) {
			 Reporter.logEvent(Status.PASS, " In Co_OwnerInfo page Enter the city", "The  Co_Owner city is ["+ city+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_OwnerInfo page Enter the city", "The Co_Owner city is ["+ city+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_OwnerInfozip(String Zip) {
		Web.waitForElement(Co_Owner_Zipcode);		
		Web.setTextToTextBox(Co_Owner_Zipcode, Zip);
		if(Co_Owner_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Co_OwnerInfo page Enter the Zipcode", "The Co_Owner Zipcode is ["+ Zip+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_OwnerInfo page Enter the Zipcode", "The Co_Owner Zipcode is ["+ Zip+"] entered Successfully", true);
		}
	}
	
public void SelectCo_OwnerInfoState(String state)
	
	{
		Web.waitForElement(Co_Owner_state);
		Web.selectDropDownOption(Co_Owner_state, state);
	}

public void SelectCo_OwnerInfoCountry(String country)

{
	Web.waitForElement(Co_Owner_Country);
	Web.selectDropDownOption(Co_Owner_Country, country	);
}


public void Co_OwnerInfoDeatils(String Gentype,String DOB,String city,String state) {
	Web.waitForElement(Co_Owner_Firstname);	
	String Fnames = Common.randomvaildFirstname();
	Web.setTextToTextBox(Co_Owner_Firstname, Fnames);
	if(Co_Owner_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
		 Reporter.logEvent(Status.PASS, " In Co_Owner Info page Enter the payer First name", "TheCo_Owner First name is ["+ Fnames+"] entered Successfully", false);	
	}
	else {
		 Reporter.logEvent(Status.FAIL, " In Co_Owner Info page Enter the payer First name", "The Co_Owner First name is ["+ Fnames+"] entered Successfully", true);
	}
	Web.waitForElement(Co_Owner_Lastname);	
	String Lnames = Common.randomvaildLastname();
	Web.setTextToTextBox(Co_Owner_Lastname, Lnames);
	if(Co_Owner_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
		 Reporter.logEvent(Status.PASS, " In Co_Owner page Enter the payer Last name", "The Co_Owner Lastname is ["+ Lnames+"] entered Successfully", false);	
	}
	else {
		 Reporter.logEvent(Status.FAIL, " In Co_Owner page Enter the owner Last name", "The Co_Owner  Last name is ["+ Lnames+"] entered Successfully", true);
	}
	Web.waitForElement(Co_Owner_Gender);
	Web.selectDropDownOption(Co_Owner_Gender, Gentype);
	Web.waitForElement(taxid_TB);
	String ssn = Common.generateSSN();
	Web.setTextToTextBox(taxid_TB, ssn);
	Web.waitForElement(Co_Owner_DOB);		
	Web.setTextToTextBox(Co_Owner_DOB, DOB);
	if(Co_Owner_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
		 Reporter.logEvent(Status.PASS, " In Co_Owner page Enter the DOB", "The Co_Owner DOB is ["+ DOB+"] entered Successfully", false);	
	}
	else {
		 Reporter.logEvent(Status.FAIL, " In Co_Owner page Enter the  DOB", "The Co_Owner DOB is ["+ DOB+"] entered Successfully", true);
	}
	Web.waitForElement(Co_Owner_Residentaddress);	
	String address = Common.AddressGenerator();
	Web.setTextToTextBox(Co_Owner_Residentaddress, address);
	if(Co_Owner_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
		 Reporter.logEvent(Status.PASS, " In Co_Owner page Enter the address", "The Co_Owner address is ["+ address+"] entered Successfully", false);	
	}
	else {
		 Reporter.logEvent(Status.FAIL, " In Co_Owner page Enter the address", "The Co_Owner address is ["+ address+"] entered Successfully", true);
	}
	 if(System.getProperty("City")==null)
		{
			Web.waitForElement(Co_Owner_City);
			 Web.setTextToTextBox(Co_Owner_City, city);
		}
		else if( System.getProperty("City").trim().length() > 0)
		{
			Web.waitForElement(Co_Owner_City);
			Web.setTextToTextBox(Co_Owner_City, System.getProperty("City").trim());	
								
		}else {
			Web.waitForElement(Co_Owner_City);
			 Web.setTextToTextBox(Co_Owner_City, city);
		}
		Web.waitForElement(Co_Owner_Zipcode);	
		String Zip = Common.AutoZipcode();
		Web.setTextToTextBox(Co_Owner_Zipcode, Zip);			
		if(Co_Owner_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Co_Owner page Enter the Zipcode", "The Co_Owner Zipcode is ["+ Zip+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_Owner page Enter the Zipcode", "The Co_Owner Zipcode is ["+ Zip+"] entered Successfully", true);
		}
		
		if(System.getProperty("IssueState")==null)
		{
			Web.waitForElement(Co_Owner_state);
			 Web.selectDropDownOption(Co_Owner_state, state);
		}
		else if( System.getProperty("IssueState").trim().length() > 0)
		{
			Web.waitForElement(Co_Owner_state);
			//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
			Common.selectbyvalues(Co_Owner_state, System.getProperty("IssueState").trim());										
		}else {
			Web.waitForElement(Co_Owner_state);
			 Web.selectDropDownOption(Co_Owner_state, state);
		}
}

	
	public Co_Owner(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Co_Owner_Firstname);
		Assert.assertTrue(Web.isWebElementDisplayed(Co_Owner_Firstname),"Co_OwnerInfo Page is Not Loaded\n");
	
	}

}

	
	





