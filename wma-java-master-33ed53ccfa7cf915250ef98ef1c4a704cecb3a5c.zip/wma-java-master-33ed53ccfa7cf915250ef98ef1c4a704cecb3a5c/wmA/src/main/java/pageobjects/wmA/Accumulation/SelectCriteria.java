package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class SelectCriteria extends LoadableComponent<SelectCriteria>{
	
	@FindBy(id="mainform:contractEntryPolicyEffectiveDate_input")
	private WebElement Effectivedate;
	
	@FindBy(id="mainform:contractEntryIssueState")
	private WebElement Issuestate;
	
	@FindBy(id="mainform:contractEntryProductType")
	private WebElement prd;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryApplicationDate_input")
	private static WebElement ApplicationSigned_TB;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("Effective_date")) {
			return this.Effectivedate;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Issue_state")) {
			return this.Issuestate;
		}

	
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	public void EnterSelectCriteriaInfo(String Effdate, String state) {
		try {
			 
			if(System.getProperty("EffectiveDate")==null)
			{
				Web.waitForElement(Effectivedate);
				 Web.setTextToTextBox(Effectivedate, Effdate);
			}
			else if( System.getProperty("EffectiveDate").trim().length() > 0)
			{
				Web.waitForElement(Effectivedate);
				Web.setTextToTextBox(Effectivedate, System.getProperty("EffectiveDate").trim());	
									
			}else {
				Web.waitForElement(Effectivedate);
				 Web.setTextToTextBox(Effectivedate, Effdate);
			}
			
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(Issuestate);
				 Web.selectDropDownOption(Issuestate, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(Issuestate);
				//Web.selectDropDownOption(Issuestate, System.getProperty("IssueState").trim());	
				Common.selectbyvalues(Issuestate, System.getProperty("IssueState").trim());					
			}else {
				Web.waitForElement(Issuestate);
				 Web.selectDropDownOption(Issuestate, state);
			}
		/* Web.waitForElement(Effectivedate);
		 Web.setTextToTextBox(Effectivedate, Effdate);
		 Assert.assertTrue(Effectivedate.getAttribute("value").contains(Effdate), "Profile set with value [ :"+Effdate+"]");
		 Reporter.logEvent(Status.PASS, "In the Select Criteria Page enter the Effective Date", "the Effective Date is["+ Effdate+"]  is Entered successfully", false);		
		 Web.selectDropDownOption(Issuestate, state);*/	
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	
	}
	
	public void EnterApplicationsignedDate(String signdate) {
		Web.waitForElement(ApplicationSigned_TB);
		Web.setTextToTextBox(ApplicationSigned_TB, signdate);
	}
	
	public void selectproducttype(String pdt) {
		try {
		Web.waitForElement(prd);
		Web.setTextToTextBox(prd, pdt);
		 Reporter.logEvent(Status.PASS, "In the Select Criteria Page enter the Product Type", "the Product Type is ["+ pdt+"] is entered successfully", false);
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
		
	
	}

	
	public void selectIssuestate(String state) throws InterruptedException {
		try {
		 Web.waitForElement(Issuestate);	
		 Web.selectDropDownOption(Issuestate, state);
		 Reporter.logEvent(Status.PASS, "In the Select Criteria Page Select the Issue state", "the Issue state["+ state+"]  is Selected successfully", false);
		
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	
	public SelectCriteria(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());

	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Effectivedate);
		Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate),"Login Page is Not Loaded\n");
	
		
	}

}
