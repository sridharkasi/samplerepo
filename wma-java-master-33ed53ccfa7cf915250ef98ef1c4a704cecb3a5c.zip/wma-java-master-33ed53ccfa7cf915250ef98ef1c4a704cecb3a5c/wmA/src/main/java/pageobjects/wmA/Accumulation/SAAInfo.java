package pageobjects.wmA.Accumulation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class SAAInfo extends LoadableComponent<SAAInfo>{
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataFirstName")
	private  WebElement SAA_FirstName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataLastName")
	private  WebElement SAA_LastName_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataTaxIdNumber")
	private  WebElement SAA_SSN_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataBirthdate_input")
	private  WebElement SAA_Dob_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataSexCode")
	private  WebElement SAA_Gender_LB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataStartDate_input")
	private  WebElement SAA_Startdate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataEndDate_input")
	private  WebElement SAA_enddate_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataAddressLine1")
	private  WebElement SAA_Addres1_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataCity")
	private  WebElement SAA_City_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataState")
	private  WebElement SAA_State_LB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataZipPostalCode")
	private  WebElement SAA_Zip_TB;
	
	@FindBy(id="mainform:contractEntryContractEntrySalesAssistantDataZipPostalCode4")
	private  WebElement SAA_remaingZIP_TB;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("SAAInfo_Gender")) {
			return this.SAA_Gender_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("SAAInfo_State")) {
			return this.SAA_State_LB;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	
	public void EnterSAAzipcode(String zip) {
		
		String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(SAA_Zip_TB, zip1);
		if(SAA_Zip_TB.getAttribute("value").equalsIgnoreCase(zip1)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the Zip code", "the Zip code ["+ zip1+"] is entered successfully", true);
		}
	}
	
	public void SelectSAAstate (String state) {
	Web.selectDropDownOption(SAA_State_LB, state);
	
	}
	
	public void EnterSAAcity(String city) {
		Web.setTextToTextBox(SAA_City_TB, city);
		if(SAA_City_TB.getAttribute("value").equalsIgnoreCase(city)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the City", "the City is["+ city+"] is Entered successfully", false);
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the City", "the City is["+ city+"] is Entered successfully", true);
		}
	}
	
	public void EnterSAAaddressline1 (String addrss) {
		String Address = Common.AddressGenerator();
		Web.setTextToTextBox(SAA_Addres1_TB, Address);
		if(SAA_Addres1_TB.getAttribute("value").equalsIgnoreCase(Address)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the 1st line Address ", "the 1st line Address is["+ Address+"] is entered successfully", true);
		}
	}
	
	public void EnterSAAenddate(String enddate) {
		Web.setTextToTextBox(SAA_enddate_TB, enddate);
		if(SAA_enddate_TB.getAttribute("value").equalsIgnoreCase(enddate)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the End date", "the End date ["+ enddate+"] is selected successfully", true);
		}
		}
	
	public void EnterSAAStartdate(String sdate) {
		Web.setTextToTextBox(SAA_Startdate_TB, sdate);
		if(SAA_Startdate_TB.getAttribute("value").equalsIgnoreCase(sdate)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the Start date", "the Start date ["+ sdate+"] is entered successfully", true);
		}
	}
	
	public void SelectSAAgender(String Gender) {
		Web.selectDropDownOption(SAA_Gender_LB, Gender);
	}
	
	public void EnterSAADOB(String dob) {
		Web.setTextToTextBox(SAA_Dob_TB, dob);
		if(SAA_Dob_TB.getAttribute("value").equalsIgnoreCase(dob)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the Date of birth", "the Date of birth ["+ dob+"] is entered successfully", true);
		}
	}
	
	public void EnterSAAssn(String ssn) {
		String SSN = Common.generateSSN();
		Web.setTextToTextBox(SAA_SSN_TB, SSN);
		if(SAA_SSN_TB.getAttribute("value").equalsIgnoreCase(SSN)) {
			lib.Reporter.logEvent(Status.PASS, "In the SAA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", false);			
		}
		else {
			lib.Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the SSN","the SSN Name is["+ SSN+"] is entered successfully", true);
		}
	}
	
	public void EnterSAALastNAme(String Lname) {
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(SAA_LastName_TB, Lnames);
		if(SAA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", false);	
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the Last Name", "the Last Name is["+ Lname+"] is entered successfully", true);
		}
	}
	
	public void EnterSAAFirstName (String Fname) throws InterruptedException {
		
		Web.waitForElement(SAA_FirstName_TB);
		String FirName = Common.randomvaildFirstname();
		Web.setTextToTextBox(SAA_FirstName_TB, FirName);
		if(SAA_FirstName_TB.getAttribute("value").equalsIgnoreCase(FirName)) {
			Reporter.logEvent(Status.PASS, "In the SAA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In the SAA Info page enter the First Name", "the First Name is["+ FirName+"] is entered successfully", true);
		}
	}
	
	
	
	public void SAADetails(String Gentype,String DOB,String city,String state ,String Startdate) throws ParseException {
		Web.waitForElement(SAA_FirstName_TB);	
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(SAA_FirstName_TB, Fnames);
		if(SAA_FirstName_TB.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In SAA page Enter the payer First name", "The SAA First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In SAA page Enter the payer First name", "The SAA First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(SAA_LastName_TB);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(SAA_LastName_TB, Lnames);
		if(SAA_LastName_TB.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In SAA page Enter the payer Last name", "The SAA Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In SAA page Enter the SAA Last name", "The SAA  Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(SAA_Gender_LB);
		Web.selectDropDownOption(SAA_Gender_LB, Gentype);
		Web.waitForElement(SAA_SSN_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(SAA_SSN_TB, ssn);
		Web.waitForElement(SAA_Dob_TB);		
		Web.setTextToTextBox(SAA_Dob_TB, DOB);
		
		if(SAA_Dob_TB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In SAA Info page Enter the DOB", "The SAA DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In SAAInfo page Enter the  DOB", "The SAA DOB is ["+ DOB+"] entered Successfully", true);
		}
		
				
		if(System.getProperty("EffectiveDate")==null)
		{
			Web.waitForElement(SAA_Startdate_TB);
			 Web.setTextToTextBox(SAA_Startdate_TB, Startdate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(SAA_Startdate_TB);
			Web.setTextToTextBox(SAA_Startdate_TB, System.getProperty("EffectiveDate").trim());	
								
		}else {
			Web.waitForElement(SAA_Startdate_TB);
			 Web.setTextToTextBox(SAA_Startdate_TB, Startdate);
		}
						
		int z=1;
		String enddate;
		if(System.getProperty("EffectiveDate")==null)
		{
			
			enddate = Startdate;
			enddate = enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(SAA_enddate_TB);
			 Web.setTextToTextBox(SAA_enddate_TB, enddate);
		}
		else if( System.getProperty("EffectiveDate").trim().length() > 0) {
			
		enddate = System.getProperty("EffectiveDate");
		enddate = enddate.replace("/", "");
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(enddate));
		c.add(Calendar.YEAR, z); // number of days to add
		enddate = sdf.format(c.getTime());
		
			Web.waitForElement(SAA_enddate_TB);
			Web.setTextToTextBox(SAA_enddate_TB, enddate);	
								
		}else {
			enddate = Startdate;
			enddate =	enddate.replace("/", "");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Calendar c = Calendar.getInstance();
			c.setTime(sdf.parse(enddate));
			c.add(Calendar.YEAR, z); // number of days to add
			enddate = sdf.format(c.getTime());
			Web.waitForElement(SAA_enddate_TB);
			 Web.setTextToTextBox(SAA_enddate_TB, enddate);
		}
		
		Web.waitForElement(SAA_Addres1_TB);	
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(SAA_Addres1_TB, address);
		if(SAA_Addres1_TB.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In SAA page Enter the address", "The SAA address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In SAA page Enter the address", "The SAA address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(SAA_City_TB);
				 Web.setTextToTextBox(SAA_City_TB, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(SAA_City_TB);
				Web.setTextToTextBox(SAA_City_TB, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(SAA_City_TB);
				 Web.setTextToTextBox(SAA_City_TB, city);
			}
			Web.waitForElement(SAA_Zip_TB);	
			String Zip = Common.AutoZipcode();
			Web.setTextToTextBox(SAA_Zip_TB, Zip);			
			if(SAA_Zip_TB.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In SAAInfo page Enter the Zipcode", "The SAA Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In SAAInfo page Enter the Zipcode", "The SAA Zipcode is ["+ Zip+"] entered Successfully", true);
			}
			
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(SAA_State_LB);
				 Web.selectDropDownOption(SAA_State_LB, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(SAA_State_LB);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(SAA_State_LB, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(SAA_State_LB);
				 Web.selectDropDownOption(SAA_State_LB, state);
			}
	}
	

	
	public SAAInfo (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(SAA_FirstName_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(SAA_FirstName_TB),"Login Page is Not Loaded\n");
	
	}

}
