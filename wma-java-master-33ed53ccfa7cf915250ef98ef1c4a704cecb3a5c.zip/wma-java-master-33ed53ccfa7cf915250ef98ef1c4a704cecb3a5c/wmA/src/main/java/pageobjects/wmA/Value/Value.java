package pageobjects.wmA.Value;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;



public class Value extends LoadableComponent<Value>{
	
	@FindBy(id="mainform:update")
	private  WebElement updatebtn;
	
	@FindBy(xpath="//li[@id='accum_Values']/a")
	private WebElement waitVaule;
	
	@FindBy(id="mainform:inquiryRequestValaEffDate_input")
	private static WebElement Value_Effectivedate;
	
	@FindBy(id="mainform:ValuesPortfolioValuesA:0:valuesPortfolioValuesAPortfolioBenefitBase")
	private static WebElement Value_Benefitbase;
	
	@FindBy(xpath="//div[@id='accum_Values_menu']/a[1]")
	private  WebElement SubmenuValue;
	
	@FindBy(id="mainform:ValuesFundVals:0:valuesValuesFundValsFundValue")
	private  WebElement verifyfund1;
	
	@FindBy(id="mainform:ValuesFundVals:2:valuesValuesFundValsFundValue")
	private static WebElement Verifyfund2;
	
	@FindBy(xpath=".//*[@id='ValuesFundVals_0']/td[7]")
	private WebElement waittablevalue;
	
	//@FindBy(xpath="//table[@id='fundsGlwb']/tbody/tr[1]/td[4]/span") //  //table[@id='mainform:ValuesPortfolioValuesA']/tbody/tr/td[4]/span
	
	@FindBy(id="mainform:valuesBenefitBase")
	private WebElement Benefitbasevalue;
	
	@FindBy(id="mainform:ValuesPortfolioValuesA:0:valuesPortfolioValuesAPortfolioBenefitBase")
	private static WebElement EWBenefitbaseAmount;
	
	@FindBy(id="mainform:ValuesPortfolioValuesA:0:valuesPortfolioValuesAPortfolioValue")
	public static WebElement EWCoveredfundvalue;
	

	@FindBy (id="mainform:valuesTotalCoveredFundValue")
	public static WebElement BenefitCoveredFundValue;
	
	@FindBy(id="mainform:valuesBenefitBase")
	private static WebElement BenefitbaseAmount;
	
	@FindBy(id="mainform:valuesAccumCashValue")
	public static WebElement AccumulatedCashValue;
	
	@FindBy (id="mainform:valuesFreeWithdrawalAmount")
    private  WebElement FreeOutAmount;

	@FindBy(id="mainform:valuesFavCode")
	private static WebElement FavCode;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {

		
		if (fieldName.trim().equalsIgnoreCase("Value_updateButton")) {
			return this.updatebtn;
		}
		
		if (fieldName.trim().equalsIgnoreCase("ClickSubmenuValue")) {
			return this.SubmenuValue;
		}
		
		if (fieldName.trim().equalsIgnoreCase("WaitforValuetable")) {
			return this.waittablevalue;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void VerifyFavCodeChange() {
		Web.waitForElement(FavCode);
		if(FavCode.getText().equalsIgnoreCase(Stock.GetParameterValue("FavCodeChange"))) {
			Reporter.logEvent(Status.PASS, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is displayed sucessfully", false);
		}else {
			Reporter.logEvent(Status.FAIL, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is Not displayed sucessfully", false);
		}
	}
	
	public void VerifyFavCodeChangeExisting() {
        Web.waitForElement(FavCode);
        
        if(System.getProperty("Favcdechange")==null)
        {
               if(FavCode.getText().equalsIgnoreCase(Stock.GetParameterValue("FavCodeChange"))) {
                     Reporter.logEvent(Status.PASS, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is displayed sucessfully", false);
               }else {
                     Reporter.logEvent(Status.FAIL, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is Not displayed sucessfully", false);
               } 
        }
        else if( System.getProperty("Favcdechange").trim().length() > 0)
        {
               if(FavCode.getText().equalsIgnoreCase(System.getProperty("Favcdechange"))) {
                     Reporter.logEvent(Status.PASS, "In Value page the Expected Fav Code is ["+System.getProperty("Favcdechange"), "The Actual Fav code  ["+FavCode.getText()+"] is displayed sucessfully", false);
               }else {
                     Reporter.logEvent(Status.FAIL, "In Value page the Expected Fav Code is ["+System.getProperty("Favcdechange"), "The Actual Fav code  ["+FavCode.getText()+"] is Not displayed sucessfully", false);
               } 
                                          
        }else {
               if(FavCode.getText().equalsIgnoreCase(Stock.GetParameterValue("FavCodeChange"))) {
                     Reporter.logEvent(Status.PASS, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is displayed sucessfully", false);
               }else {
                     Reporter.logEvent(Status.FAIL, "In Value page the Expected Fav Code is ["+Stock.GetParameterValue("FavCodeChange")+"]", "The Actual Fav code  ["+FavCode.getText()+"] is Not displayed sucessfully", false);
               } 
        }
 }

	
	public void getFreeOutAmount() {
        //Policynumber.getText();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        try {
        lib.Reporter
        .logEvent(
                     Status.PASS,
                     "Free Out Amount: ",
                     FreeOutAmount.getText(),
                     true);
 }
        catch (Exception e) {
               e.printStackTrace();
        }      
        String FreeOutAmountvalue=Common.trimspecialcharacter(FreeOutAmount.getText());
        Common.FreeoutAmountValue.put("Freeamountval", FreeOutAmountvalue);
        
 }

	
	public void EnterEffectivedatevalue(String effectdate) {
		
		Web.waitForElement(Value_Effectivedate);
		Web.setTextToTextBox(Value_Effectivedate,effectdate);
	}
	
	public void EnterEffectivedatevalueGAW(String effectdate) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,effectdate);
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,System.getProperty("TrxEffectiveDate"));
								
		}else {
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,effectdate);
		}
		
		
	}
	public void EnterEffectivedatevalueAssetrebalance(String effectdate) {
		if(System.getProperty("NextPayoutDate")==null)
		{
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,effectdate);
		}
		else if( System.getProperty("NextPayoutDate").trim().length() > 0)
		{
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,System.getProperty("NextPayoutDate"));
								
		}else {
			Web.waitForElement(Value_Effectivedate);
			Web.setTextToTextBox(Value_Effectivedate,effectdate);
		}
		
		
	}
	
	public void VerifyFundtransferCFBasebenefit(String expectedtext) {
		try {
			Web.waitForElement(verifyfund1);
			Web.waitForElement(waittablevalue);
			String Expected = Stock.GetParameterValue("PaymentAmount");
			System.out.println(Expected);
			String Actual = Benefitbasevalue.getText();		
			Web.waitForElement(Benefitbasevalue);
			Assert.assertTrue(Benefitbasevalue.getText().contains(Expected), "Fund transfer To value1 verification");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		catch (Exception e) {
			e.printStackTrace(); 
		}		
	}
	
	public void VerifyFundtransferNonCFBasebenefit(String expectedtext) {
		try {
			Web.waitForElement(verifyfund1);
			Web.waitForElement(waittablevalue);
			String Expected = Stock.GetParameterValue("PaymentAmount");
			System.out.println(Expected);
			String Actual = Benefitbasevalue.getText();		
			Web.waitForElement(Benefitbasevalue);
			Assert.assertNotEquals(Benefitbasevalue.getText().contains(Expected), "Fund transfer To value1 verification");
			
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		catch (Exception e) {
			e.printStackTrace(); 
		}		
	}
	
	public void VerifyFundTransfer1(String expectedtext) {
		try {
			Web.waitForElement(verifyfund1);
			Web.waitForElement(waittablevalue);
			String Expected = Stock.GetParameterValue("FTtransferTO1");
			String Actual = verifyfund1.getText();
			Assert.assertTrue(verifyfund1.getText().contains(Expected), "Fund transfer To value1 verification");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void ExcpectedEWGaw() {
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		Web.waitForElement(EWBenefitbaseAmount);
		String BCF = Common.trimspecialcharacter(EWCoveredfundvalue.getText());
		String BBA = Common.trimspecialcharacter(EWBenefitbaseAmount.getText());
		Common.EWrider=BCF;
		String ageper = Stock.GetParameterValue("GAWPercent");
		Double percetvalue = Double.parseDouble(ageper);
		
		
		Double ValueBCF = Double.parseDouble(BCF);	
		Double ValueBBA = Double.parseDouble(BBA);	
		
		if( ValueBCF>ValueBBA) {
			Double Value = ValueBCF * percetvalue;
			Common.MaximumBenefitvalue = ValueBCF.toString();
			Double MaxGawAmount = Value/100;
			MaxGawAmount = Math.round(MaxGawAmount * 100.0) / 100.0;
			Common.Disbursementtable.put("MaxGaw", Double.toString(MaxGawAmount));
			Reporter.logEvent(Status.PASS,"Expected Gaw Value","Present in the Actual text [ " + MaxGawAmount + " ]", false);
		}else if(ValueBBA>ValueBCF) {
			Double Value = ValueBBA* percetvalue;
			Common.MaximumBenefitvalue = ValueBBA.toString();
			Double MaxGawAmount = Value/100;
			MaxGawAmount = Math.round(MaxGawAmount * 100.0) / 100.0;
			Common.Disbursementtable.put("MaxGaw", Double.toString(MaxGawAmount));
			Reporter.logEvent(Status.PASS,"Expected Gaw Value","Present in the Actual text [ " + MaxGawAmount + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL," Gaw Value","Could not evaluvate please check benefit value displayed", false);
		}
	}
	
	
	public void excpectedLWMAXGaw() {
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		Web.waitForElement(BenefitCoveredFundValue);
		String BCF = Common.trimspecialcharacter(BenefitCoveredFundValue.getText());
		String BBA = Common.trimspecialcharacter(BenefitbaseAmount.getText());
		Common.lWrider = BCF;
		String ageper = Stock.GetParameterValue("GAWPercent");
		Double percetvalue = Double.parseDouble(ageper);
		
		
		Double ValueBCF = Double.parseDouble(BCF);	
		Double ValueBBA = Double.parseDouble(BBA);	
		
		if( ValueBCF>ValueBBA) {
			Double Value = ValueBCF * percetvalue;
			Common.MaximumBenefitvalue = ValueBCF.toString();
			Double MaxGawAmount = Value/100;
			MaxGawAmount = Math.round(MaxGawAmount * 100.0) / 100.0;
			Common.Disbursementtable.put("MaxGaw", Double.toString(MaxGawAmount));
			Reporter.logEvent(Status.PASS,"Expected Gaw Value","Present in the Actual text [ " + MaxGawAmount + " ]", false);
		//	Double perGawamout = MaxGawAmount/12;
			
		}else if(ValueBBA>ValueBCF) {
			Double Value = ValueBBA* percetvalue;
			Common.MaximumBenefitvalue = ValueBBA.toString();
			Double MaxGawAmount = Value/100;
			MaxGawAmount = Math.round(MaxGawAmount * 100.0) / 100.0;
			Common.Disbursementtable.put("MaxGaw", Double.toString(MaxGawAmount));
			Reporter.logEvent(Status.PASS,"Expected Gaw Value","Present in the Actual text [ " + MaxGawAmount + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL," Gaw Value","Could not evaluvate please check benefit value displayed", false);
		}
	}
	
	public void verifyMaximumBenefitvalue() {
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		if(Common.MaximumBenefitvalue.equalsIgnoreCase(Common.trimspecialcharacter(BenefitbaseAmount.getText())) ) {
			Reporter.logEvent(Status.PASS,"Maximum Benefit Base ["+Common.MaximumBenefitvalue+"]","Present in the Actual BenefitBase [ " + Common.trimspecialcharacter(BenefitbaseAmount.getText()) + " ]", false);
		}
		else {
			Reporter.logEvent(Status.FAIL,"Maximum Benefit Base ["+Common.MaximumBenefitvalue+"]","Not Present in the Actual BenefitBase [ " + Common.trimspecialcharacter(BenefitbaseAmount.getText()) + " ]", false);
		}
	}
	
	public Value(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	public void calculatebasevaluepercentage_CovFund()
	{
		String benefitval;
		Double userval;
		benefitval = Benefitbasevalue.getText();
		
		benefitval = Common.trimspecialcharacter(benefitval);
		
		//String userdata = Stock.GetParameterValue("PaymentAmount");
		
		Double Appval = Double.parseDouble(benefitval);
		
		if(System.getProperty("PaymentAmount")==null)
		{
			 userval = Double.parseDouble(Stock.GetParameterValue("PaymentAmount"));
		}
		else if( System.getProperty("PaymentAmount").trim().length() > 0)
		{
			 userval = Double.parseDouble(System.getProperty("PaymentAmount"));					
		}else {
			 userval = Double.parseDouble(Stock.GetParameterValue("PaymentAmount"));
		
		}
		
		
		//userval.intvalue;
		
		
		if(userval.equals(Appval))
		{
		
		/*if (benefitval.equalsIgnoreCase(Stock.GetParameterValue("PaymentAmount")))
		{*/
			Reporter.logEvent(Status.PASS,"Expected benefit value  ["+userval.toString()+" ]","Present in the Actual text [ " + benefitval + " ]", false);
		}
		else
		{
			Reporter.logEvent(Status.FAIL,"Expected benefit value  ["+userval.toString()+" ]","Not present in the Actual text [ " + benefitval + " ]", false);
		}
				
		
	}
	
	public void calculatebasevaluepercentage_NonCovFund()
	{
		String benefitval;
		String paymtAmount;
		benefitval = Benefitbasevalue.getText();
		
		if(System.getProperty("PaymentAmount")==null)
		{
			 paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));
		}
		else if( System.getProperty("PaymentAmount").trim().length() > 0)
		{
			
			  paymtAmount = Common.trimspecialcharacter(System.getProperty("PaymentAmount"));
		}else {
			 paymtAmount = Common.trimspecialcharacter(Stock.GetParameterValue("PaymentAmount"));
		
		}

		
		String Fttransferamt = Common.trimspecialcharacter(Stock.GetParameterValue("Ftfromtransfer"));
		benefitval = Common.trimspecialcharacter(benefitval);
		Double benfbal = null;
		if(Integer.parseInt(Stock.GetParameterValue("CFfundTransfer")) >= 1)
		{
			benfbal = Double.parseDouble(paymtAmount) - Common.frmFundtotal;
		}
		else
		{
			 benfbal = Double.parseDouble(Fttransferamt)/100 * Double.parseDouble(paymtAmount);
		}		
		
		//if (benefitval.equalsIgnoreCase(benfbal.toString()))
			if (Double.parseDouble(benefitval)==benfbal)
		{
			Reporter.logEvent(Status.PASS,"Expected benefit value  ["+benfbal.toString()+" ]","Present in the Actual text [ " + benefitval + " ]", false);
		}
		else
		{
			Reporter.logEvent(Status.FAIL,"Expected benefit value  ["+benfbal.toString()+" ]","not present in the Actual text [ " + benefitval + " ]", false);
		}
		
				
		
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		
		Web.waitForElement(waitVaule);
		Assert.assertTrue(Web.isWebElementDisplayed(waitVaule),"Value Page is Not Loaded\n");
	}

}
