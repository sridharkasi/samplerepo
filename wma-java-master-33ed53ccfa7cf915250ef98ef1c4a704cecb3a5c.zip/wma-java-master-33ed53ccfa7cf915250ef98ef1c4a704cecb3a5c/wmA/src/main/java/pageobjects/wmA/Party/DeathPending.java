package pageobjects.wmA.Party;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class DeathPending extends LoadableComponent<DeathPending>{
	
	@FindBy(id= "mainform:partyDeathEffectiveDate_input")
	private static WebElement DeathPendingEffectivedate_TB;
	
	@FindBy(id="mainform:partyDeathLifeStatus")
	private  WebElement LifeStatus;
	
	@FindBy(id="mainform:partyDeathDateOfDeath_input")
	private static WebElement DateofDeath_TB;
	
	@FindBy(id="mainform:PartyDeathPolicyPresentation:0:partyDeathPolicyPresentationDeathPendingInd")
	private WebElement Deathindicator_BT;
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
		 
		 if (fieldName.trim().equalsIgnoreCase("Life_Status")) {
				return this.LifeStatus;
			}
		 
		 if (fieldName.trim().equalsIgnoreCase("DeathPending_CheckBox")) {
				return this.Deathindicator_BT;
			}
		 
		 Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	 
	 public void SelectLifeStatus(String status) {
		 String lifestat=null;
		 Web.waitForElement(LifeStatus);
		 if(System.getProperty("LifeStatus")==null){
			 Web.waitForElement(LifeStatus);
			 Web.selectDropDownOption(LifeStatus, status);
			}
			else if( System.getProperty("LifeStatus").trim().length() > 0){
				if(System.getProperty("LifeStatus").toLowerCase().contains("dece")) {
					lifestat = "D";
				}
				else if (System.getProperty("DateOfDeath").toLowerCase().contains("liv")) {
					lifestat = "L";
				}
				else
				{
					 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the correct ", "cause of death "+lifestat, true);
					 return;
				}
				 Web.waitForElement(LifeStatus);
				Common.selectbyvalues(LifeStatus,lifestat);
			}
			else {
				 Web.waitForElement(LifeStatus);
				 Web.selectDropDownOption(LifeStatus, status);
				 }
		 
	 }
	 
	 public void EnterDateOfDeath(String DoD) {
		 if(System.getProperty("DateOfDeath")==null)
			{
			 Web.waitForElement(DateofDeath_TB);
			 Web.setTextToTextBox(DateofDeath_TB, DoD);
			 if(DateofDeath_TB.getAttribute("value").equalsIgnoreCase(DoD))
				 Reporter.logEvent(Status.PASS, "In Death Pending page enter the date of Death", "The date of Death is["+DoD+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the date of Death", "The date of Death is["+DoD+"] Not entered sucessfully", false);
			}
			else if( System.getProperty("DateOfDeath").trim().length() > 0)
			{
				 Web.waitForElement(DateofDeath_TB);
				 Web.setTextToTextBox(DateofDeath_TB, System.getProperty("DateOfDeath"));
				 if(DateofDeath_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("DateOfDeath")))
					 Reporter.logEvent(Status.PASS, "In Death Pending page enter the date of Death", "The date of Death is["+System.getProperty("DateOfDeath")+"] entered sucessfully", false);
				else
					 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the date of Death", "The date of Death is["+System.getProperty("DateOfDeath")+"] Not entered sucessfully", false);	
									
			}else {
				 Web.waitForElement(DateofDeath_TB);
				 Web.setTextToTextBox(DateofDeath_TB, DoD);
				 if(DateofDeath_TB.getAttribute("value").equalsIgnoreCase(DoD))
					 Reporter.logEvent(Status.PASS, "In Death Pending page enter the date of Death", "The date of Death is["+DoD+"] entered sucessfully", false);
				else
					 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the date of Death", "The date of Death is["+DoD+"] Not entered sucessfully", false);
			}
		
	 }
	
	public void EnterDeathPendingEffectiveDate(String effective) {
		if(System.getProperty("DeathPendingEffectiveDate")==null)
		{
			Web.waitForElement(DeathPendingEffectivedate_TB);
			Web.setTextToTextBox(DeathPendingEffectivedate_TB, effective);
			if(DeathPendingEffectivedate_TB.getAttribute("value").equalsIgnoreCase(effective))
				 Reporter.logEvent(Status.PASS, "In Death Pending page enter the Effective date", "The Effective date is["+effective+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the Effective date", "The Effective date is["+effective+"] Not entered sucessfully", false);
		}
		else if( System.getProperty("DeathPendingEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(DeathPendingEffectivedate_TB);
			Web.setTextToTextBox(DeathPendingEffectivedate_TB, System.getProperty("DeathPendingEffectiveDate"));
			if(DeathPendingEffectivedate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("DeathPendingEffectiveDate")))
				 Reporter.logEvent(Status.PASS, "In Death Pending page enter the Effective date", "The Effective date is["+System.getProperty("DeathPendingEffectiveDate")+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the Effective date", "The Effective date is["+System.getProperty("DeathPendingEffectiveDate")+"] Not entered sucessfully", false);	
								
		}else {
			Web.waitForElement(DeathPendingEffectivedate_TB);
			Web.setTextToTextBox(DeathPendingEffectivedate_TB, effective);
			if(DeathPendingEffectivedate_TB.getAttribute("value").equalsIgnoreCase(effective))
				 Reporter.logEvent(Status.PASS, "In Death Pending page enter the Effective date", "The Effective date is["+effective+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Death Pending page enter the Effective date", "The Effective date is["+effective+"] Not entered sucessfully", false);
		}
	
	}

	public DeathPending(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {		
		Web.waitForElement(DeathPendingEffectivedate_TB);		
		Assert.assertTrue(Web.isWebElementDisplayed(DeathPendingEffectivedate_TB),"Demographic Change Page is Not Loaded\n");
		
	}


}
