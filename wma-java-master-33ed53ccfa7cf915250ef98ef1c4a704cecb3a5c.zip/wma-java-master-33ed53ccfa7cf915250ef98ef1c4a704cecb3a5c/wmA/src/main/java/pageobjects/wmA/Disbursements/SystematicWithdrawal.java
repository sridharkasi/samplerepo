package pageobjects.wmA.Disbursements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class SystematicWithdrawal extends LoadableComponent<SystematicWithdrawal>{
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id ="mainform:searchButton")
	private static WebElement searchbutton;
	
	@FindBy(partialLinkText ="Disbursements")
	private static WebElement Disbursement;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[1]")
	private static WebElement syswithdrawal;
	
	@FindBy(id = "mainform:add")
	private static WebElement addbutton;
	
	@FindBy (id = "mainform:systematicWithdrawalAddEffectiveDate_input")
	private static WebElement syseffdate;
	
	@FindBy(id="mainform:systematicWithdrawalAddStartDate_input")
	private static WebElement startdate;
	
	@FindBy(id="mainform:systematicWithdrawalAddPayoutEndDate_input")
	private static WebElement Enddate;
	
	@FindBy(id="mainform:systematicWithdrawalAddTrxLevelIndicator")
	private static WebElement translevel;
	
	@FindBy(id="mainform:systematicWithdrawalAddPayoutMode")
	private static WebElement mode;
	
	@FindBy(id="mainform:systematicWithdrawalAddPayoutAmount")
	private static WebElement payoutamount;
	
	@FindBy(id="mainform:systematicWithdrawalAddSourceCode")
	private static WebElement systranscSorucecode;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	@FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr[1]/td[5]/input")
	private static WebElement FundallocationTB;
	
	@FindBy(id="mainform:systematicWithdrawalAddPayoutType")
	private static WebElement WithdrawalType_LB;
	
	@FindBy(id="mainform:systematicWithdrawalAddPayoutOptionInd")
	private static WebElement Option_LB;
	
	@FindBy(id="mainform:systematicWithdrawalAddDistributionInd")
	private static WebElement Disbursementcode_LB;
	
	@FindBy(id="mainform:systematicWithdrawalAddMemoCode")
	private static WebElement MemoCode_LB; 
	
	@FindBy(id="mainform:systematicWithdrawalAddGlwbAnnualOverideAmount")
	private static WebElement RMDAmount_TB;
	
	@FindBy(id="mainform:systematicWithdrawalAddCurrentMaxGawAmount")
	private static WebElement MaxGAWAmount;
	
	@FindBy(xpath="//select[@id='mainform:systematicWithdrawalAddPayoutType']/option[@value='G']")
	private static WebElement WaitGawOnly;
	
	@FindBy(id="mainform:Payouts:0:payoutsPayoutAmount")
	private static WebElement PayoutAmount;
	
	public boolean Waitelement;
	
	public void EnterRMDAmount(String rmd) {
		Web.waitForElement(RMDAmount_TB);
		Web.setTextToTextBox(RMDAmount_TB, rmd);
	}
	
	public void VerifyLWMaxGAWAmount() {
		Web.waitForElement(MaxGAWAmount);
		String GawAmount = Common.trimspecialcharacter(MaxGAWAmount.getText());
		Double Excped =  Double.parseDouble(GawAmount);	
		
		if(Double.parseDouble(Common.Disbursementtable.get("MaxGaw"))==Excped) {
			Reporter.logEvent(Status.PASS,"Maximum GAW Amount: Expected Value  [$"+Common.Disbursementtable.get("MaxGaw")+"]","Vs Actual value [$ " + Excped + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Maximum GAW Amount: Expected Value  [$"+Common.Disbursementtable.get("MaxGaw")+"]","Vs Actual value [$ " + Excped + " ]", false);
		}		
		}
	public void VerifyEWMaxGawAmount() {
		Web.waitForElement(MaxGAWAmount);
		String GawAmount = Common.trimspecialcharacter(MaxGAWAmount.getText());
		Double Excped =  Double.parseDouble(GawAmount);	
		
		if(Double.parseDouble(Common.Disbursementtable.get("MaxGaw"))==Excped) {
			Reporter.logEvent(Status.PASS,"Maximum GAW Amount: Expected Value  [$"+Common.Disbursementtable.get("MaxGaw")+"]","Vs Actual value [$ " + Excped + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Maximum GAW Amount: Expected Value  [$"+Common.Disbursementtable.get("MaxGaw")+"]","Vs Actual value [$ " + Excped + " ]", false);
		}
	}
	public void SelectMemoCode(String Memo) {
		Web.waitForElement(MemoCode_LB);
		Web.selectDropDownOption(MemoCode_LB, Memo);
	}
	
	public void SelectDisbursementCode(String Disburse) {
		Web.waitForElement(Disbursementcode_LB);
		Web.selectDropDownOption(Disbursementcode_LB, Disburse);
	}
	
	public void SelectOption(String opt) {
		/*try {
			Thread.sleep(7000);
		}
		catch(Exception e)
		{
			
		}*/
		
		Web.waitForElement(Option_LB);
		Web.selectDropDownOption(Option_LB, opt);
		Web.waitForElement(WithdrawalType_LB);
	}
	
	public void SelectWithdrawalType(String WithdrawalType) throws InterruptedException {
		Thread.sleep(15000);
		Web.waitForElement(WithdrawalType_LB);
		Select drp = new Select(WithdrawalType_LB);
		drp.selectByValue(WithdrawalType);
		/*try {
			System.out.println("*********"+WithdrawalType+"**********");
			long lStartTime = System.nanoTime();

            long lEndTime;

           // int a= 10;
            
            WebDriverWait wait = new WebDriverWait(Web.getDriver(), 90);
            
            boolean selectionstate = wait.until(ExpectedConditions.elementSelectionStateToBe(WithdrawalType_LB, true));//.presenceOfElementLocated(By.id("mainform:systematicWithdrawalAddPayoutType")));
            
            //boolean selectionstate = wait.until(ExpectedConditions.elementSelectionStateToBe(WithdrawalType_LB, true));//.presenceOfElementLocated(By.id("mainform:systematicWithdrawalAddPayoutType")));
            
            lEndTime = System.nanoTime();

          

                    System.out.println((lEndTime - lStartTime)/ 1000000000.0);
            if(element.)
            {
            	
            }
            while(WithdrawalType_LB.isEnabled()!= true)

            {

                    lEndTime = System.nanoTime();

                    if ( ((lEndTime - lStartTime)/ 1000000000.0) > 50)

                                    {

                            System.out.println((lEndTime - lStartTime)/ 1000000000.0);
                            Thread.sleep(2000);
                           // System.out.println(a);

                            break;

                                            }

                    

            }
                    Select drp = new Select(WithdrawalType_LB); 
                if(selectionstate)
                {
            
    		drp.selectByValue(WithdrawalType);
                }
                else {
                	//Thread.sleep(2000);
                }
                
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		*/
	
		
		
		/*try {
			Thread.sleep(7000);
		}
		catch(Exception e)
		{
			
		}*/
		
		/*
		WithdrawalType_LB  = (new WebDriverWait(Web.getDriver(), 40))
				  .until(ExpectedConditions.elementToBeClickable(WithdrawalType_LB));*/
		/*while(WithdrawalType_LB.isEnabled()!= true)
		{
			
		}*/
	
	/*	Web.clickOnElement(WithdrawalType_LB);
		Web.waitForElement(WaitGawOnly);
		Web.clickOnElement(WithdrawalType_LB);
		
		//***********************
		Select drp = new Select(WithdrawalType_LB);
		drp.selectByValue(WithdrawalType);*/
		
		//***********************
		
		//Web.selectDropDownOption(WithdrawalType_LB, WithdrawalType);
	//	System.out.println("withdrwal type selected");
		/*if (Waitelement)
		{
		Web.selectDropDownOption(WithdrawalType_LB, WithdrawalType);
		}
		
		else
		{
			Web.selectDropDownOption(WithdrawalType_LB, WithdrawalType);
		}*/
		/*if(WithdrawalType_LB.isEnabled()) {
		Web.waitForElement(WaitGawOnly);
		Web.selectDropDownOption(WithdrawalType_LB, WithdrawalType);
		}
		else {
			System.out.println("Fail");
		}*/
	//	Thread.sleep(10000);
		
		/*var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
		//wait.Until(driver => !driver.FindElement(By.("processing")).Displayed);*/
	/*	wait.Until(driver => !WithdrawalType_LB).di*/

	}
	
	public void clickhomebutton () {
		Web.waitForElement(homebutton);
		Web.clickOnElement(homebutton);
		if(homebutton.isDisplayed()){
			
			  Reporter.logEvent(Status.PASS, "In wmA Home screen Click on Home Button ", "the Home Button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In wmA Home screen Click on Home Button", "the Home Button is not clicked sucessfully", true);
			 }
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
		 if(contractsearch.getAttribute("value").equalsIgnoreCase(contractid)) {
			 Reporter.logEvent(Status.PASS, "In Home page enter the Contract Id", "the Contratct Id is["+contractid+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Home page enter the Contract Id", "the Contract Id is["+contractid+"] not entered sucessfully", true);
		 }
	}
	
	public void clicksearchbutton() {
		Web.waitForElement(searchbutton);
		Web.clickOnElement(searchbutton);
		if(searchbutton.isDisplayed()){
			
			  Reporter.logEvent(Status.PASS, "In Home page Click on Search Button ", "the Search Button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Home page Click on Search Button", "the Search Button is not clicked sucessfully", true);
			 }
		
	}
	
	public void clicksystematicwithdrawal () {
		//Web.waitForElement(syswithdrawal);
		Web.clickOnElement(syswithdrawal);
		//Common.ClickSubmenu(syswithdrawal);
		
	}
	
	public void clickaddbutton () {
		Web.waitForElement(addbutton);
		Web.clickOnElement(addbutton);
		if(addbutton.isDisplayed()){
			
			  Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page Click on Add button ", "the Add button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page Click on Add button", "the Add button is not clicked sucessfully", true);
			 }
	}
	
	public void setsyseffectivedate (String syseff) {
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		Web.waitForElement(syseffdate);
		Web.setTextToTextBox(syseffdate, syseff);
		 if(syseffdate.getAttribute("value").equalsIgnoreCase(syseff)) {
			 Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page enter the Effective date", "the Effective date is["+syseff+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page enter the Effective date", "the Effective date is["+syseff+"] not entered sucessfully", true);
		 }
		
	}
	
	public void setstartdate (String Startdate) {
		Web.waitForElement(startdate);
		Web.setTextToTextBox(startdate, Startdate);
		Web.waitForElement(FundallocationTB);
		Web.setTextToTextBox(startdate, Startdate);
		if(startdate.getAttribute("value").equalsIgnoreCase(Startdate)) {
			 Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page enter the Start date", "the Start date is["+Startdate+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page enter the Start date", "the Start date is["+Startdate+"] not entered sucessfully", true);
		 }
	}
	
	public void setenddate (String enddate) {
		Web.waitForElement(Enddate);
		Web.setTextToTextBox(Enddate, enddate);
		if(Enddate.getAttribute("value").equalsIgnoreCase(enddate)) {
			 Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page enter the End date", "the End date is["+enddate+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page enter the End date", "the End date is["+enddate+"] not entered sucessfully", true);
		 }
	}
	
	public void transactionlevel (String trasaclevel) {
		Web.waitForElement(translevel);
		Web.selectDropDownOption(translevel, trasaclevel);
		Web.waitForElement(FundallocationTB);
	}
	
	public void paymentmode (String paymode) {
		Web.waitForElement(mode);
		Web.selectDropDownOption(mode, paymode);
	}
	
	public void payoutamount (String payamount) {
		Web.waitForElement(payoutamount);
		Web.setTextToTextBox(payoutamount, payamount);
		if(payoutamount.getAttribute("value").equalsIgnoreCase(payamount)) {
			 Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page enter the Payout Amount ", "the Payout Amount is["+payamount+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page enter the Payout Amount", "the Payout Amount is["+payamount+"] not entered sucessfully", true);
		 }
	}
	
	@FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr[1]/td[4]")
	private static WebElement waitfundamout;
	
	public void EnterFundAmount(String Famount) {
		Web.waitForElement(waitfundamout);
		
		Web.setTextToTextBox(FundallocationTB, Famount);
		if(FundallocationTB.getAttribute("value").equalsIgnoreCase(Famount)) {
			 Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page enter the Fund Amount ", "the Fund Amount is["+Famount+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page enter the Fund Amount", "the Fund Amount is["+Famount+"] not entered sucessfully", true);
		 }
		
		String fundamnt = Common.trimspecialcharacter(waitfundamout.getText());
		
		Double value = Double.parseDouble(fundamnt)- Double.parseDouble(Famount);
		
		
		Common.Disbursementtable.put("FundValue", Double.toString(value));
		Reporter.logEvent(Status.INFO, "Expected Fund value ", value.toString(), false);
		
	}
	
	public void syssourcecode (String source) {
		Web.waitForElement(systranscSorucecode);
		Web.selectDropDownOption(systranscSorucecode, source);
	}
	
	public void RealtimeDrpDwn(String selectrealtime) {
		Web.waitForElement(RealtimeDrpDwn);
		 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
		 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
	}
   
	@FindBy(xpath="//table[@id='mainform:Payouts']/tbody/tr[1]/td[1]")
	private static WebElement Nextpayoutdate;
	
	public void VerifyNextpayoutDate() {
		Web.waitForElement(Nextpayoutdate);
		String Actual = Stock.GetParameterValue("NextPayoutDate");
		String Expected = Nextpayoutdate.getText();
		if(Nextpayoutdate.isDisplayed()){
			Assert.assertTrue(Nextpayoutdate.getText().contains(Expected), "verification Nextpayout date");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","NOT Present in the Actual text [ " + Actual + " ]", false);
		}
		
	}
	
	public void VerifyNextpayoutDate(String Actual) {
		Web.waitForElement(Nextpayoutdate);
	
		String Expected = Nextpayoutdate.getText();
		if(Nextpayoutdate.isDisplayed()){
			Assert.assertTrue(Nextpayoutdate.getText().contains(Expected), "verification Nextpayout date");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","NOT Present in the Actual text [ " + Actual + " ]", false);
		}
		
	}
	
	public void VerifyPayoutAmount() {
		Web.waitForElement(PayoutAmount);
		if(Common.trimspecialcharacter(PayoutAmount.getText()).contains(Common.GawFundNEW.get("RMDMonthlyvalue"))) {
			Reporter.logEvent(Status.PASS,"Expected Payount Amount is ["+PayoutAmount.getText()+" ]","Present in the Actual Payout amount is [ " + Common.GawFundNEW.get("RMDMonthlyvalue") + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Expected Payount Amount is ["+PayoutAmount.getText()+" ]","NOT Present in the Actual Payout amount is [ " + Common.GawFundNEW.get("RMDMonthlyvalue") + " ]", false);
		}
	}
	
   public void clicksumbmit() {
	 //  Web.waitForElement(submit);
   	Web.clickOnElement(submit);
   	if(submit.isDisplayed()){
		
		  Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page Click on Submit button ", "the Submit button is clicked sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page Click on Submit button", "the Submit button is not clicked sucessfully", true);
		 }
   }
   
  @FindBy(id="overridebox")
  private static WebElement overidebox;
  
  public void clickoverirde() {
	  
	 // Web.waitForElement(ErrorText);
	  try {
		Thread.sleep(10000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  Web.waitForElement(overidebox);
	  Web.clickOnElement(overidebox);
	  if(overidebox.isSelected()){
			
		  Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page Click on override button ", "the Override button is clicked sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page Click on override button", "the Override button is not clicked sucessfully", true);
		 }
  }
   
	public void VerifyErrorText(String expectedtext) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(ErrorText);	
		String Expected = expectedtext;
		String Actual = ErrorText.getText();
		if(ErrorText.getText().contains(Expected)){
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
	}
	
	@FindBy(xpath="//li[@id='history']/div/a[1]")
	private static WebElement Historysubmenu;
		
	public void clickhistorysubmenu() {
		//Web.waitForElement(Historysubmenu);
		//Historysubmenu.click();
		Web.clickOnElement(Historysubmenu);
		//Common.ClickSubmenu(Historysubmenu);
		
	}

	public SystematicWithdrawal(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(addbutton);
		Assert.assertTrue(Web.isWebElementDisplayed(addbutton),"Systematic Withdrawal Page is Not Loaded\n");
	}

}
