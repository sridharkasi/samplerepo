package pageobjects.wmA.Disbursements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.General.General;

public class RMDQuote extends LoadableComponent<RMDQuote>{
	
	@FindBy(id="mainform:update")
	private static WebElement Updatequote_BT;
	
	@FindBy(id="mainform:mrdQuoteEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	@FindBy(id="mainform:mrdQuoteEndOfYearAcvLs")
	private static WebElement Prioryearvalue;
	
	@FindBy(id="mainform:mrdQuoteLifeExpectMultLs")
	private static WebElement LMEfactor;
	
	@FindBy(id="mainform:mrdQuoteGrossMrdAmtLs")
	private static WebElement RMDamount;
	
	public void verifyRMDgrossamount() {
		Web.waitForElement(RMDamount);
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String prioryearvalue = Prioryearvalue.getText().trim();
		 prioryearvalue = Common.trimspecialcharacter(prioryearvalue);
		Double prioryearAmount = Double.parseDouble(prioryearvalue);
		
		String LEM = Common.trimspecialcharacter(LMEfactor.getText());
		Double Lemfactor = Double.parseDouble(LEM);
		
		Double calculatedRMD = prioryearAmount/Lemfactor;
		calculatedRMD = Math.round(calculatedRMD * 100.0) / 100.0;
		String RMDExecpected = calculatedRMD.toString();
		
		String RMDvalue = Common.trimspecialcharacter(RMDamount.getText());
		Double RMDamount =  Double.parseDouble(RMDvalue);
		String RMDActualAmount = RMDamount.toString();
		Common.RMDGrossvalue = RMDamount.toString();
		
		if(RMDamount<0.1) {
			String GivenRMDvalue = Stock.GetParameterValue("RMDAmount");
			Common.RMDGrossvalue = GivenRMDvalue;
			 Reporter.logEvent(Status.PASS, "In RMD Quote page RMD is not available", "the RMD Amount is["+GivenRMDvalue+"] is going to enter in RMD Amount", false);
		}
		
		else if(RMDExecpected.equalsIgnoreCase(RMDActualAmount)) {
			 Reporter.logEvent(Status.PASS, "In RMD Quote page Excepected RMD ["+RMDExecpected+"]", "the RMD Amount is["+RMDActualAmount+"] Verifyied sucessfully", false);
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In RMD Quote page Excepected RMD ["+RMDExecpected+"]", "the RMD Amount is["+RMDActualAmount+"] Not Verifyied sucessfully", false);
		}
		
	}
	
	public void verifyTBRMDgrossamount() {
		Web.waitForElement(RMDamount);
		try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}
		String prioryearvalue = Prioryearvalue.getText().trim();
		 prioryearvalue = Common.trimspecialcharacter(prioryearvalue);
		Double prioryearAmount = Double.parseDouble(prioryearvalue);
		
		String LEM = Common.trimspecialcharacter(LMEfactor.getText());
		Double Lemfactor = Double.parseDouble(LEM);
		
		Double calculatedRMD = prioryearAmount/Lemfactor;
		calculatedRMD = Math.round(calculatedRMD * 100.0) / 100.0;
		String RMDExecpected = calculatedRMD.toString();
		
		String RMDvalue = Common.trimspecialcharacter(RMDamount.getText());
		Double RMDamount =  Double.parseDouble(RMDvalue);
		Double TBRMDamount = RMDamount-Double.parseDouble(Stock.GetParameterValue("SurrenderAmt"));
		String RMDActualAmount = RMDamount.toString();
		Common.RMDGrossvalue = TBRMDamount.toString();
		
		if(RMDamount<0.1) {
			String GivenRMDvalue = Stock.GetParameterValue("RMDAmount");
			Double TBGivenRMDamount = Double.parseDouble(GivenRMDvalue)-Double.parseDouble(Stock.GetParameterValue("SurrenderAmt"));
			Common.RMDGrossvalue = TBGivenRMDamount.toString();
			 Reporter.logEvent(Status.PASS, "In RMD Quote page RMD is not available", "the RMD Amount is["+GivenRMDvalue+"] is going to enter in RMD Amount", false);
		}
		
		else if(RMDExecpected.equalsIgnoreCase(RMDActualAmount)) {
			 Reporter.logEvent(Status.PASS, "In RMD Quote page Excepected RMD ["+RMDExecpected+"]", "the RMD Amount is["+RMDActualAmount+"] Verifyied sucessfully", false);
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In RMD Quote page Excepected RMD ["+RMDExecpected+"]", "the RMD Amount is["+RMDActualAmount+"] Not Verifyied sucessfully", false);
		}
		
	}
	
	public void enterEffectivedate (String Effectivedate) {
		Web.waitForElement(Effectivedate_TB);
		Web.setTextToTextBox(Effectivedate_TB, Effectivedate);
		if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(Effectivedate))
			 Reporter.logEvent(Status.PASS, "In RMD Quote page enter the Effective date", "the Effective date is["+Effectivedate+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In RMD Quote page enter the Effective date", "the Effective date is["+Effectivedate+"] Not entered sucessfully", false);
	}
	
	public void ClickOnUpdateButton() {
		Web.waitForElement(Updatequote_BT);
		Web.clickOnElement(Updatequote_BT);
	}
	
	
	public RMDQuote (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}


	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Updatequote_BT);
		// TODO Auto-generated method stub
		Assert.assertTrue(Web.isWebElementDisplayed(Updatequote_BT),"Rmd Quote Page is Not Loaded\n");
	}

}


