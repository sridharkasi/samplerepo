package pageobjects.wmA.General;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;


public class General extends LoadableComponent<General> {
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[1]")
	private static WebElement syswithdrawal;
	
	@FindBy(id = "mainform:cmdContractPrint")
	private static WebElement ContractPrint_BT;
	
	@FindBy(id="mainform:allocationModelLabel")
	private static WebElement Allocation_Lable;
	
	@FindBy(xpath="//li[@id='history']/div/a[1]")
	private static WebElement Historysubmenu;
	
	@FindBy(xpath="//li[@id='maintenance']/div/a[7]")
	private static WebElement Maintenancesubmenyrealtime;
	
	@FindBy(xpath="//li[@id='accum_Values']/div/a[1]")
	private static WebElement ValueSubmenu;
	
	@FindBy(xpath="//li[@id='disbursements']/div/a[9]")
	private static WebElement RMDQuote_Submenu;
	
	@FindBy(xpath = "//li[@id='accum_Fund_Processing']/div/a[1]")
	private static WebElement AllocationChange_Submenu;
	
	@FindBy(xpath = "//li[@id='premiums_Billing']/a")
	private static WebElement PremiumBillings_Submenu;
	
	@FindBy(xpath = "//li[@id='accum_Fund_Processing']/div/a[2]")
	private static WebElement AssetRebalance_Submenu;
	
	@FindBy(xpath = "//li[@id='accum_Fund_Processing']/div/a[3]")
	private static WebElement CostAverage_Submenu;
	
	@FindBy(xpath="//li[@id='accum_Values']/a")
	private WebElement waitVaule;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Partial Surrender')]")
	private static WebElement ps;
	
	@FindBy(id="AnnRolesSlider")
	private static WebElement Roleslider;
	
	@FindBy(xpath="//span[@id='mainform:Roles:0:rolesDirectoryId']")
	private static WebElement DirectorID_text;
	
	@FindBy(xpath="//div[@id='summaryBar']/table/tbody/tr[2]/td/table/tbody/tr/td[3]")
	private static WebElement Statuschek;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Death Claim')]")
	private static WebElement deathclaim;
	
	@FindBy(xpath = "//li[@id='accum_Fund_Processing']/div/a[4]")
	private static WebElement Fav_Submenu;
	
	@FindBy(id="AnnRolesSlider")
    private static WebElement Role;
	
	@FindBy(xpath="//div[@id='maintenance_menu']/a[1]")
	private static WebElement Producerinfo_Submenu;
	
	@FindBy(xpath="//div[@id='disbursements_menu']/a[8]")
	private static WebElement RMD_Submenu;
	
	 @FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Full Surrender')]")
		private static WebElement fs;
	 
	 @FindBy(xpath = "//table[@id='mainform:AllocationFund']")
	 private static WebElement FundTable;
	 
	 @FindBy(id="FundsSlider")
	 private static WebElement FundSilder;
	 
	 @FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr")
	 private  List<WebElement> CoveredFundrow;
	
	 public void clickFullsurrender() {
		  Web.waitForElement(fs);
	    	Common.ClickSubmenu(fs);
	    }
	
	public void ClickRMDSubmenu (){
		Common.ClickSubmenu(RMD_Submenu);
	}
	public void ClickOnProducerinforamtion() {
		Common.ClickSubmenu(Producerinfo_Submenu);
	}
	

	public void clickRoleTab(){
		Common.ClickSubmenu(Role);
	}


	
	public void VerifyDeathStatus() {
		Web.waitForElement(Statuschek);
		String sat = "E-Death Pending";
		if(Statuschek.getText().contains(sat)) {
			Reporter.logEvent(Status.PASS,"Expected Status ["+sat+"] ","Present in the Status as ["+Statuschek.getText()+"]", false);	
		}else {
			Reporter.logEvent(Status.FAIL,"Expected Status ["+sat+"] ","Not Present in the Status as ["+Statuschek.getText()+"]", false);
		}
	}
	
	public void ClickCostAveraging() {
		Web.waitForElement(CostAverage_Submenu);
		Common.ClickSubmenu(CostAverage_Submenu);
	}
	
	public void CLickonDeathClaimSubmenu() {
		Common.ClickSubmenu(deathclaim);
	}

	public void ClickonFavSubmenu() {
		Common.ClickSubmenu(Fav_Submenu);
	}
	
	public void GetDirectorID() {
		Web.getDriver().switchTo().frame("quickFrame");
		Web.waitForElement(DirectorID_text);		
		String dirid =	DirectorID_text.getText();
		Common.Contractinfo.put("DirectorID",dirid );
		Web.getDriver().switchTo().defaultContent();
	}
	
	public void ClickFundSilderBar() {
		Web.waitForElement(FundSilder);
		Web.clickOnElement(FundSilder);
	}
	
	public void getFundINFO() {
		Web.getDriver().switchTo().frame("quickFrame");
		Web.waitForElement(FundTable);
		int tempNC =0;
   		int temp =0;
		for (int i=1; i<=CoveredFundrow.size();i++)
   		{
   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
   			if(str1.equalsIgnoreCase("c")) 
   			{
   				temp = temp + 1;
   				Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
   				Common.CovFundinfo.put("CovFundPercent"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());					
				
   			}else if(!str1.equalsIgnoreCase("c")) {
   				tempNC = tempNC + 1;
   				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
   				Common.NonCFundinfo.put("NonNCPercent"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
   			}
   		}
		Web.getDriver().switchTo().defaultContent();
		
	}
	
	public void ClickRoleSilderBar() {
		Web.waitForElement(Roleslider);
		Web.clickOnElement(Roleslider);
	}
	 public void clickpartialsurrender() {	    
	    	Common.ClickSubmenu(ps);
	    }
	
	public void ClickAssetRebalanceSM() {
		Common.ClickSubmenu(AssetRebalance_Submenu);
	}
	
	public void ClickPremiumBillingSM() {
		Common.ClickSubmenu(PremiumBillings_Submenu);
	}
	
	public void ClickAllocationchangeSM() {
		Common.ClickSubmenu(AllocationChange_Submenu);
	}
	
	public void ClickRMDQuote() {
		Common.ClickSubmenu(RMDQuote_Submenu);
	}
	
	public void clicksystematicwithdrawal () {
		Web.waitForElement(syswithdrawal);
		Common.ClickSubmenu(syswithdrawal);
		
	}
	
	public void ClickonmaintenanceSubmenu() {
		//Web.waitForElement(Maintenancesubmenyrealtime);
		Common.ClickSubmenu(Maintenancesubmenyrealtime);
		
	}
	
	
	
	public void ClickonValueSubmenu() {
		/*try
		{
			Thread.sleep(10000);
		}
		catch(Exception e)
		{
			
		}*/
		//Web.waitForElement(ValueSubmenu);
		Common.ClickSubmenu(ValueSubmenu);
		/*try {
			if(Common.isAlerPresent()) {
				Common.switchto_newwindow();
				Web.getDriver().switchTo().alert().accept();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}
	
	
	public void clickhistorysubmenu() {
		//Web.waitForElement(Historysubmenu);
		Common.ClickSubmenu(Historysubmenu);
		
	}
	
	
	public General(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;

	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Allocation_Lable);
		Assert.assertTrue(Web.isWebElementDisplayed(Allocation_Lable),"General Page is Not Loaded\n");
		
	}
	
	
	

}
