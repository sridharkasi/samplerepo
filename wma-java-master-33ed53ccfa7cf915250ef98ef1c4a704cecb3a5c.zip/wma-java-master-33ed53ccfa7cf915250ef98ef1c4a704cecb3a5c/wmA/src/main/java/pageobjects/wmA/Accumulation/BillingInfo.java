package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import lib.Reporter;
import lib.Web;

public class BillingInfo extends LoadableComponent<BillingInfo>{
	
	@FindBy (id="mainform:contractEntryModalPremium")
	private  WebElement ModelPremium;
	
	@FindBy (id="mainform:contractEntryInitialDepositPremium")
	private  WebElement InitialPayment;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
	
		if (fieldName.trim().equalsIgnoreCase("BillingInfo_Modelpremium")) {
			return this.ModelPremium;
		}
		
		if (fieldName.trim().equalsIgnoreCase("BillingInfo_Initialpremium")) {
			return this.InitialPayment;
		}
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	

	public void ModelPremeium(String modalpaymnt) throws InterruptedException {

		Web.waitForElement(ModelPremium);
		 Web.setTextToTextBox(ModelPremium, modalpaymnt);
		 Assert.assertTrue(ModelPremium.getAttribute("value").contains(modalpaymnt), "Annuity retriment age set with value [ :"+modalpaymnt+"]");
		 Reporter.logEvent(Status.PASS, "In Billing Info page enter the Model Premium amount", "The Model premium value is ["+ modalpaymnt+"] entered Successfully", false);
		 
	}
	
	public void InitialPayment(String initpaymnt) {
		 Web.setTextToTextBox(InitialPayment, initpaymnt);	
		 Assert.assertTrue(InitialPayment.getAttribute("value").contains(initpaymnt), "Annuity retriment age set with value [ :"+initpaymnt+"]");
		 Reporter.logEvent(Status.PASS, "In Billing Info page enter the Initial Payment amount", "The Initial premium value is["+ initpaymnt+"] entered Successfully", false);
		
	}
	
	public BillingInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(ModelPremium);
		Assert.assertTrue(Web.isWebElementDisplayed(ModelPremium),"Billing Info Page is Not Loaded\n");
		
	
	
	}

}
