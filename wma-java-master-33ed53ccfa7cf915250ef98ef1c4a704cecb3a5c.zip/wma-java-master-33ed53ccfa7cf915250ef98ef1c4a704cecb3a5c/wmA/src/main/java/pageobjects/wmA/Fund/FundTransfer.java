package pageobjects.wmA.Fund;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class FundTransfer extends LoadableComponent<FundTransfer>{
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id ="mainform:searchButton")
	private static WebElement searchbutton;
	
	@FindBy(xpath="//div[@id='accum_Fund_Processing_menu']/a[7]")
	private static WebElement SUBmenuFundTransafer;
	
	@FindBy(id="mainform:fundTransferEffectiveDate_input")
	private static WebElement Effectivedate;
	
	@FindBy(id="mainform:fundTransferTransferType")
	private WebElement Transfertype;
	
	@FindBy(id="mainform:fundTransferSourceCode")
	private  WebElement SourceCode;
	
	@FindBy(id="mainform:TransferFund:0:transferFundFromAmount")
	private static WebElement Fromtransfer;
	
	@FindBy(id="mainform:TransferFund:1:transferFundToAmount")
	private static WebElement Totransfer1;
	
	@FindBy(id="mainform:TransferFund:2:transferFundToAmount")
	private static WebElement Totransfer2;
	
	@FindBy(id="mainform:fundTransferMemoCode")
	private static WebElement memocode;
	
	@FindBy(id="mainform:TransferFund:TransferFundfromAmountHeaderText")
	private static WebElement waittransfertypeDollar;
	
	@FindBy(id="mainform:TransferFund:TransferFundfromPercentHeaderText")
	private static WebElement waittransfertypePercent;
	
	@FindBy(xpath="//li[@id='accum_Fund_Processing']/a")
	private static WebElement waitFund;
	
	@FindBy(xpath="//li[@id='accum_Values']/a")
	private WebElement waitVaule;
	
	@FindBy(xpath=".//*[@id='waitDiv']")
	private WebElement WaitofrFundValue;
	
	@FindBy(xpath="//div[@id='accum_Values_menu']/a[1]")
	private  WebElement SubmenuValue;
	
	@FindBy(id="mainform:TransferFund:0:transferFundFromPercent")
	private WebElement FromTransferpercent;
	
	@FindBy(id="mainform:TransferFund:1:transferFundToPercent")
	private WebElement ToTransferPercent;
	
	@FindBy(xpath="//table[@id='mainform:TransferFund']/tbody/tr")
    private  List<WebElement> CoveredFundrow;
	
	@FindBy(id="mainform:TransferFund:1:transferFundToPercent")
	private static WebElement Tofund;
	
	@FindBy(id="mainform:fundTransferMvaOverrideInd")
	private static WebElement CoveredFund;
	
	@FindBy(xpath=".//*[@id='mainform']/div[1]/table/tbody/tr[6]/td/div")
	private  WebElement Producerinfo;
	
	@FindBy (id="realtimeselect")
	private  WebElement RealtimeDrpDwn;

	@FindBy(id="submitbutton")
	private WebElement SubmitButton;
	
	@FindBy(id="overridebox")
	private WebElement Overridebutton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		
		if (fieldName.trim().equalsIgnoreCase("Summary_Homebtn")) {
			return this.homebutton;
		}
		
		if (fieldName.trim().equalsIgnoreCase("FundTransfer_Overridebtn")) {
			return this.Overridebutton;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Transfer_Type")) {
			return this.Transfertype;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Summary_Submitbtn")) {
			return this.SubmitButton;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Summary_Realtime")) {
			return this.RealtimeDrpDwn;
		}
		
		if (fieldName.trim().equalsIgnoreCase("SourceCode")) {
			return this.SourceCode;
		}

		if (fieldName.trim().equalsIgnoreCase("WaitforValuepage")) {
			return this.waitVaule;
		}
		
		if (fieldName.trim().equalsIgnoreCase("ClickSubmenuValue")) {
			return this.SubmenuValue;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Summary_Realtimewait")) {
			return this.Producerinfo;
		}
		
		if (fieldName.trim().equalsIgnoreCase("FundTransfer_waitvalue")) {
			return this.WaitofrFundValue;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	public  void entercoveredfund(String inv) throws InterruptedException {
		Web.waitForElement(Tofund);
		
		for (int i=2; i<CoveredFundrow.size();i++) {
			
		
			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[4]")).getText();
			
					if(str.equalsIgnoreCase("c")) {
						System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[4]")).getText());
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]/input")).isEnabled();
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]/input")).clear();						
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:TransferFund']/tbody/tr["+i+"]/td[8]/input")).sendKeys(inv);
						Reporter.logEvent(Status.PASS, "In the Fund Transfer page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);
						break;
					}
		}
	}
	
	public void TC1FundtransferNonCFDollartype(String effdate,String fundtype,String Memocode) {
		
		Web.waitForElement(waitFund);
		Common.ClickSubmenu(SUBmenuFundTransafer);
		Web.waitForElement(Effectivedate);
		Web.setTextToTextBox(Effectivedate, effdate);
		if(Effectivedate.getAttribute("value").equalsIgnoreCase(effdate)) 
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
		
		else 
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"]not entered sucessfully", false);
		
		Web.selectDropDownOption(Transfertype, fundtype);
		Web.waitForElement(waittransfertypeDollar);
		Web.selectDropDownOption(memocode, Memocode);
		
		/*Web.setTextToTextBox(Fromtransfer, Fromtrans);
		if(Fromtransfer.getAttribute("value").equalsIgnoreCase(Fromtrans))
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"]not entered sucessfully", false);
		
		Web.setTextToTextBox(Totransfer1, Totrans);
		if(Totransfer1.getAttribute("value").equalsIgnoreCase(Totrans))
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the To fund transfer Amount1 is["+Totrans+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the To fund transfer Amount1 is["+Totrans+"]not entered sucessfully", false);
	
		Web.setTextToTextBox(Totransfer2, Totrans2);
		if(Totransfer2.getAttribute("value").equalsIgnoreCase(Totrans2))
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the To fund transfer Amount2 is["+Totrans2+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the To fund transfer Amount2 is["+Totrans2+"]not entered sucessfully", false);
	*/
	}
	
	
public void TC2FundTransferCFPercentTypeToCF(String effdate,String Fundtype2,String fundtype,String Memocode) {
		
		Web.waitForElement(waitFund);
		Common.ClickSubmenu(SUBmenuFundTransafer);
		Web.waitForElement(Effectivedate);
		Web.setTextToTextBox(Effectivedate, effdate);
		
		Web.getDriver().findElement(By.id("mainform:fundTransferEffectiveDate_input")).sendKeys(Keys.TAB);
		if(Effectivedate.getAttribute("value").equalsIgnoreCase(effdate)) 
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
		
		else 
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"]not entered sucessfully", false);
		
		
		Web.waitForElement(Effectivedate);
		Web.selectDropDownOption(Transfertype, Fundtype2);
		Web.waitForElement(waittransfertypeDollar);
		Web.selectDropDownOption(Transfertype, fundtype);
		Web.waitForElement(waittransfertypePercent);
		Web.selectDropDownOption(memocode, Memocode);
		
		//, String Fromtrans
		
	/*	Web.waitForElement(SourceCode);
		Web.waitForElement(CoveredFund);
		Web.waitForElement(WaitofrFundValue);*/
		/*Web.setTextToTextBox(FromTransferpercent, Fromtrans);
		if(FromTransferpercent.getAttribute("value").equalsIgnoreCase(Fromtrans))
			 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"]not entered sucessfully", false);
			*/	
	}

public void TC3FundTransferCFPercentTypeToNonCF(String effdate,String Fundtype2,String fundtype,String Memocode) throws InterruptedException {
	
	Web.waitForElement(waitFund);
	Common.ClickSubmenu(SUBmenuFundTransafer);
	Web.waitForElement(Effectivedate);
	Web.setTextToTextBox(Effectivedate, effdate);
	
	Web.getDriver().findElement(By.id("mainform:fundTransferEffectiveDate_input")).sendKeys(Keys.TAB);
	if(Effectivedate.getAttribute("value").equalsIgnoreCase(effdate)) 
		 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
	
	else 
		 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"]not entered sucessfully", false);
	
	
	Web.waitForElement(Effectivedate);
	Web.selectDropDownOption(Transfertype, Fundtype2);
	Web.waitForElement(waittransfertypeDollar);
	Web.selectDropDownOption(Transfertype, fundtype);
	Web.waitForElement(waittransfertypePercent);
	Web.selectDropDownOption(memocode, Memocode);
	
/*	Web.waitForElement(SourceCode);
	Web.waitForElement(CoveredFund);
	Web.waitForElement(WaitofrFundValue);*/
	/*Web.setTextToTextBox(FromTransferpercent, Fromtrans);
	if(FromTransferpercent.getAttribute("value").equalsIgnoreCase(Fromtrans))
		 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"] entered sucessfully", false);
	else
		 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"]not entered sucessfully", false);
	
	Web.setTextToTextBox(ToTransferPercent,	Totransfer);
	if(ToTransferPercent.getAttribute("value").equalsIgnoreCase(Totransfer))
		 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the To transfer Amount", "the To fund transfer Amount is["+Totransfer+"] entered sucessfully", false);
	else
		 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the To transfer Amount", "the To fund transfer Amount is["+Totransfer+"]not entered sucessfully", false);*/	
}


	
		public void enterfrompercentagefund(String Fromtrans) {
			Web.setTextToTextBox(FromTransferpercent, Fromtrans);
			if(FromTransferpercent.getAttribute("value").equalsIgnoreCase(Fromtrans))
				 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"]not entered sucessfully", false);
		}


		public void TC4FundtransferFromCFDollartypeToCF(String effdate,String fundtype,String Memocode) {
			
			Web.waitForElement(waitFund);
			Common.ClickSubmenu(SUBmenuFundTransafer);
			Web.waitForElement(Effectivedate);
			Web.setTextToTextBox(Effectivedate, effdate);
			if(Effectivedate.getAttribute("value").equalsIgnoreCase(effdate)) 
				 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
			
			else 
				 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the Effective date", "the Effective date is["+effdate+"]not entered sucessfully", false);
			
			Web.selectDropDownOption(Transfertype, fundtype);
			Web.waitForElement(waittransfertypeDollar);
			Web.selectDropDownOption(memocode, Memocode);
			
			/*Web.setTextToTextBox(Fromtransfer, Fromtrans);
			if(Fromtransfer.getAttribute("value").equalsIgnoreCase(Fromtrans))
				 Reporter.logEvent(Status.PASS, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Fund Transfer page enter the From transfer Amount", "the From fund transfer Amount is["+Fromtrans+"]not entered sucessfully", false);*/
			
			
		}
		
		
		
		@FindBy(id= "iconform:mainIcon")
		private  WebElement homebutton;
	
		
		public void clickhomebutton () {
			Web.waitForElement(homebutton);
			Web.clickOnElement(homebutton);
		}
		
		public void entercontractid (String contractid) {
			Web.waitForElement(contractsearch);
			Web.setTextToTextBox(contractsearch, contractid);
		}
		
		public void clicksearchbutton() {
			Web.waitForElement(searchbutton);
			Web.clickOnElement(searchbutton);
		}
		
		
		
		public void VerifyErrorText(String expectedtext) {
			try {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
			
		}
			catch (Exception e) {
				e.printStackTrace();
			}	
		}
	
	public FundTransfer(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		
	}

}
