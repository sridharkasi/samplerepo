package pageobjects.wmA.History;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

//import app.wmAweb.testcases.Disbursements.ExpText;
import appUtils.Common;
import lib.Log;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class Transaction extends LoadableComponent<Transaction>{

	@FindBy(id="mainform:update")
	private  WebElement HistoryupdateBT;
	
	@FindBy(xpath="//div[@id='history_menu']/a[1]")
	private static WebElement Historysubmenu;
	
	@FindBy(xpath="//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr[1]/td[2]")
	private static WebElement Verifytrans;
	
	@FindBy(xpath="//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr[1]/td[4]")
	private static WebElement Hisdate;
	
	@FindBy(xpath="//li[@id='maintenance']/div/a[7]")
	private static WebElement Maintenancesubmenyrealtime;
	
	@FindBy(xpath="//div[@id='summaryBar']/table/tbody/tr[2]/td/table/tbody/tr/td[3]")
	private static WebElement Statuschek;	


	@FindBy(xpath="//table[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr[1]/td[2]")
	private static WebElement VerifytransTB;
	
	@FindBy(xpath ="//*[@id='mainform:detail']/tbody/tr[3]/td/table/tbody/tr[27]/td[2]/span")
	private static WebElement AmtWithheldState; 
	
	@FindBy(xpath="//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/thead/tr[2]/th")
	private List<WebElement> newContractIDhead;
	
	@FindBy(xpath="//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr")
	private List<WebElement> newContractID;
	
	@FindBy(xpath ="//*[@id='mainform:detail']/tbody/tr[5]/td/table//tr[12]/td[4]/span")
    private static WebElement Surrenderpenality;
	
	@FindBy(xpath="//input[@id='mainform:inquiryRequestEndDate_input']")
    private static WebElement History_ToDate;

	@FindBy(xpath="//*[@id='ContractHistoryIndexReturnedHistoryData_0']/td[4]/span")
    private static WebElement NAED;
               
    @FindBy(xpath="//*[@id='summaryBar']//table/tbody/tr/td[4]")
    private static WebElement ContractED;

    @FindBy(xpath = "//table[@id='mainform:detail']/tbody/tr[5]/td/table/tbody/tr[20]/td[2]/span")
    private static WebElement TefraGainAmount;

    @FindBy(xpath="//table[@id='mainform:detail']/tbody/tr[5]/td/table/tbody/tr[16]/td[2]/span")
    private static WebElement FedralWithholdoingAmount;
    
    @FindBy(xpath="//table[@id='mainform:detail']/tbody/tr[5]/td/table/tbody/tr[16]/td[4]/span")
    private static WebElement StateWithholdingAmount;
    
    @FindBy(xpath = "//table[@id='mainform:detail']/tbody/tr[5]/td/table/tbody/tr[12]/td[2]/span")
    private static WebElement SurrenderAmount;
    
    @FindBy(xpath="//*[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr/td[2]")
    private List<WebElement> Trxcode;
    
    @FindBy(id="mainform:transferType")
    private static WebElement CAtrxindicator;
    
    public void verifyCostaverageOEStransaction(String trx) {
        Web.waitForElement(Verifytrans);
        String Expected = "OEI - Cost Average Fund Transfer";                                     
        Common.historytable("trxcode", Expected, trx); 
    }


    public void SelectCATransfertype(String trxtype) {
                    if(System.getProperty("TrxType")==null)
                    {
                                    Web.waitForElement(CAtrxindicator);
                                    Web.selectDropDownOption(CAtrxindicator, trxtype);
                    }
                    else if( System.getProperty("TrxType").trim().length() > 0)
                    {
                                    Web.waitForElement(CAtrxindicator);
                                    Web.selectDropDownOption(CAtrxindicator, System.getProperty("TrxType").trim());    
                                                                                                                    
                    }else {
                                    Web.waitForElement(CAtrxindicator);
                                    Web.selectDropDownOption(CAtrxindicator, trxtype);
                    }
                    
    
                    Web.waitForElement(CAtrxindicator);
    	}


    
    public void verifyTAtransaction(String trx) {
        Web.waitForElement(Verifytrans);
        String Expected = "TA - Full Surrender";                                                 
        Common.historytable("trxcode", Expected, trx); 
    }
    
   
    
    public void FedralWithhodlingCalc() {
    	Web.waitForElement(FedralWithholdoingAmount);
    	String SSNverify = "SSN is Verified";
    	String SSNnotverify = "SSN is not Verified";
    	String fedralamt = SurrenderAmount.getText();
    	
    	fedralamt = fedralamt.replaceAll(",", "");
    	Double fedtax;
    	
    	if(Common.Contractinfo.get("SSNVerifcation").equalsIgnoreCase(SSNverify)) {
    		fedtax = Double.parseDouble(fedralamt)*.1;
    		fedtax = Math.round(fedtax * 100.0) / 100.0;
    		if(fedtax == Double.parseDouble(FedralWithholdoingAmount.getText().replaceAll(",", ""))) {
    		Reporter.logEvent(Status.PASS, "In Transaction page the excepted fedral withholding amount is ["+fedtax.toString()+"]", "The Actual Fedral with holding amount  is["+FedralWithholdoingAmount.getText()+"] ", false);
    		}else {
    			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted fedral withholding amount is ["+fedtax.toString()+"]", "The Actual Fedral with holding amount  is Not Matching with["+FedralWithholdoingAmount.getText()+"] ", false);
    		}
    	}else if(Common.Contractinfo.get("SSNVerifcation").equalsIgnoreCase(SSNnotverify)) {
    		fedtax = Double.parseDouble(fedralamt)*.3;
    		fedtax = Math.round(fedtax * 100.0) / 100.0;
    		if(fedtax==Double.parseDouble(FedralWithholdoingAmount.getText().replaceAll(",", ""))) {
        		Reporter.logEvent(Status.PASS, "In Transaction page the excepted fedral withholding amount is ["+fedtax.toString()+"]", "The Actual Fedral with holding amount  is["+FedralWithholdoingAmount.getText()+"] ", false);
        		}else {
        			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted fedral withholding amount is ["+fedtax.toString()+"]", "The Actual Fedral with holding amount  is Not Matching with["+FedralWithholdoingAmount.getText()+"] ", false);
        		}
    	}
    }
    
    public void StateWithholdingCalc() {
    	Web.waitForElement(StateWithholdingAmount);
    	String fedamt = FedralWithholdoingAmount.getText();
    	fedamt = fedamt.replaceAll(",", "");
    	
    	if(System.getProperty("IssueState")==null)
		{
    		Double statetax;
        	if(Stock.GetParameterValue("TAXMethod").equalsIgnoreCase("F")) {    		
        		statetax = Double.parseDouble(fedamt)*Double.parseDouble(Stock.GetParameterValue("StateWithholdingPercent"));
        		statetax = Math.round(statetax * 100.0) / 100.0;
        		if(statetax== Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
        		Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
        		}else {
        			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
        		}
        	}else if(Stock.GetParameterValue("TAXMethod").equalsIgnoreCase("G")) {
        		statetax = Double.parseDouble(SurrenderAmount.getText().replaceAll(",", ""))*Double.parseDouble(Stock.GetParameterValue("StateWithholdingPercent"));
        		statetax = Math.round(statetax * 100.0) / 100.0;
        		if(statetax==Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
            		Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from gain amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
            		}else {
            			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from gain with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
            		}
		}
		}
		else if( System.getProperty("IssueState").trim().length() > 0)
		{
			Double statetax;
			String  StateMethod = Stock.getConfigParam(System.getProperty("IssueState").trim());
			String [] method = StateMethod.split("[+]");
			String taxmethod = method[0];
			String Withholdpercent = method[1];
			if(taxmethod.equalsIgnoreCase("F")) {
				statetax = Double.parseDouble(fedamt)*Double.parseDouble(Withholdpercent);
				statetax = statetax/100;
	    		statetax = Math.round(statetax * 100.0) / 100.0;
	    		if(statetax== Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
	    			Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
	    		}else {
	    			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
	    		}
	    		
			}else if(taxmethod.equalsIgnoreCase("G")) {
				statetax = Double.parseDouble(SurrenderAmount.getText().replaceAll(",", ""))*Double.parseDouble(Withholdpercent);
				statetax = statetax/100;
	    		statetax = Math.round(statetax * 100.0) / 100.0;
	    		if(statetax==Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
	        		Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from gain amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
	        		}else {
	        			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from gain with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
	        		}
			}
			
		}else {
			Double statetax;
	    	if(Stock.GetParameterValue("TAXMethod").equalsIgnoreCase("F")) {    		
	    		statetax = Double.parseDouble(fedamt)*Double.parseDouble(Stock.GetParameterValue("StateWithholdingPercent"));
	    		statetax = Math.round(statetax * 100.0) / 100.0;
	    		if(statetax== Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
	    		Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
	    		}else {
	    			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from Fedral state with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
	    		}
	    	}else if(Stock.GetParameterValue("TAXMethod").equalsIgnoreCase("G")) {
	    		statetax = Double.parseDouble(SurrenderAmount.getText().replaceAll(",", ""))*Double.parseDouble(Stock.GetParameterValue("StateWithholdingPercent"));
	    		statetax = Math.round(statetax * 100.0) / 100.0;
	    		if(statetax==Double.parseDouble(StateWithholdingAmount.getText().replaceAll(",", ""))) {
	        		Reporter.logEvent(Status.PASS, "In Transaction page the excepted State withholding amount is CAlculate from gain amount is ["+statetax.toString()+"]", "The Actual State with holding amount  is["+StateWithholdingAmount.getText()+"] ", false);
	        		}else {
	        			Reporter.logEvent(Status.FAIL, "In Transaction page the excepted State withholding amount is CAlculate from gain with holding amount is ["+statetax.toString()+"]", "The Actual State with holding amount is not matching["+StateWithholdingAmount.getText()+"] ", false);
	        		}
		}
    
    	
		}
		
    }
    
    public void verifyZMDI_RMDtransaction() {
        Web.waitForElement(Verifytrans);
        String Expected ="ZMDI - RMD Change";
        Common.historytable("trxcode", Expected,Stock.GetParameterValue("RMD_ED")) ;
    }

    public void verifyTKMtransaction() {
        Web.waitForElement(Verifytrans);
        String Expected ="TKM - Required Min Dist Payout";
        Common.historytable("trxcode", Expected,Stock.GetParameterValue("RMD_ED")) ;
	}

	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("Transaction_updateBT")) {
			return this.HistoryupdateBT;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void VerifyNA_Contract_SameED() {
        Web.waitForElement(NAED);
        String NAeffectiveddate=Web.getWebElementText(NAED);
        Web.waitForElement(ContractED);
        String Contracteffectiveddate=Web.getWebElementText(ContractED);
        if(Contracteffectiveddate.contains(NAeffectiveddate))
        {
         Reporter.logEvent(Status.PASS, "In History page ", "the NA Effective date is["+NAeffectiveddate+"] is same as contractEffectivedate ["+Contracteffectiveddate+"] Verified sucessfully", false);
        }

        else
        {
        Reporter.logEvent(Status.FAIL, "In History page ", "the NA Effective date is["+NAeffectiveddate+"] is not same as contractEffectivedate ["+Contracteffectiveddate+"] not Verified sucessfully", false);
        }
        

        
	}

	public void verifyNAForDifferentEDtransaction() {
        Web.waitForElement(Verifytrans);
        String Expected = "NA - Regular Remittance";
        //String Actual = Verifytrans.getText();
        Common.historytable("trxcode", Expected, Stock.GetParameterValue("NewED")); 
	}

	public void VerifyNA_Contract_DifferentED(String InitialED){

    Web.waitForElement(NAED);
    String NAeffectiveddate=Web.getWebElementText(NAED);
    Web.waitForElement(ContractED);
    String Contracteffectiveddate=Web.getWebElementText(ContractED);
    if(Contracteffectiveddate.contains(NAeffectiveddate)){
        Reporter.logEvent(Status.PASS, "In History page "," Entered effective date for contract is ["+InitialED+"]the NA Effective date is["+NAeffectiveddate+"] After Premium add  contractEffectivedate is ["+Contracteffectiveddate+"]  different Verified sucessfully", false);
    }
    else{
    	Reporter.logEvent(Status.FAIL, "In History page ", " Entered effective date for contract is  ["+InitialED+"]the NA Effective date is["+NAeffectiveddate+"] After Premium add  contractEffectivedate is ["+Contracteffectiveddate+"]  not different Verified sucessfully", false);
        }
    }

	public void verifyLBDAtransaction() {

        Web.waitForElement(Verifytrans);

        String Expected = "LBDA - Beneficiary Add";                                  

        Common.historytable("trxcode", Expected, Stock.GetParameterValue("Effectivedate")); 

    }


	
    public void VerifyGrossPenality(String Surrendramount ) 
    {
              
              String Freeamountval =  Common.FreeoutAmountValue.get("Freeamountval");
              if (Double.parseDouble(Surrendramount) > Double.parseDouble(Freeamountval)) 
              {
                     double Remainingamount;
                     Remainingamount = Double.parseDouble(Surrendramount) - Double.parseDouble(Freeamountval);
                     Web.waitForElement(Surrenderpenality);
                     String Actualamttext =  Common.trimspecialcharacter(Surrenderpenality.getText());
                     double Actualamt = Double.parseDouble(Actualamttext);
                     Actualamt=Math.round(Actualamt);
                     String orgactualamt=String.valueOf(Actualamt);
               
                     double Expectedamt =7*Remainingamount/100;
                     Expectedamt=Math.round(Expectedamt);
                     
                     String orgexpectedamt=String.valueOf(Expectedamt);
                     
              if(orgexpectedamt.equalsIgnoreCase(orgactualamt)) 
                     {
                           Reporter.logEvent(Status.PASS, "In History Transaction page the Expected State with surrender Penality is ["+orgexpectedamt+"]", "the Actual  surrender Penality  Amount is["+orgactualamt+"] Verified sucessfully", false);
                     }
                     
                     else 
                     {
                       Reporter.logEvent(Status.FAIL, "In History Transaction page the Expected State with surrender Penality is ["+orgexpectedamt+"]", "the Actual  surrender Penality is["+orgactualamt+"]Not Verified sucessfully", false);}
              
                  }
              else
              {
                     Reporter.logEvent(Status.FAIL, "In Partial surrend page", "Surrender amount is not greater then free amount", false);
              }
              
    }
    
    public void verifyNewNameRolesTable() {
        try {
                        Thread.sleep(5000);
        } catch (Exception e) {

        }
        try {
        	Web.getDriver().switchTo().frame("quickFrame");
        	int rolesTBsize = 0;
                        rolesTBsize = Web.getDriver().findElements(By.xpath("//table[@id='mainform:Roles']/tbody/tr")).size();
                        if (rolesTBsize < 1) {
                                        Reporter.logEvent(Status.FAIL, "Roles Table", " [Empty] ", false);
                                        return;
                        		}
                        
                            String temp1 = Common.NewRoleEnter.get("LastNm");
                                        String temp2=temp1.toUpperCase();
                                        
    for (int i = 1; i<rolesTBsize;i++)
    {
        String lname = Web.getDriver().findElement(By.xpath("//table[@id='mainform:Roles']/tbody/tr[" + i + "]/td[2]")).getText();
          if (lname.contains(temp2))
                       {
        	  System.out.println("New name enterd  is"+(Web.getDriver().findElement(By.xpath("//table[@id='mainform:Roles']/tbody/tr[" + i + "]/td[2]")).getText())+ "] matching with expected Firstname [" + temp1 + "]");
        	  Reporter.logEvent(Status.PASS, "In roles list First  Name of Beneficiery entered [" + temp1 + "]"," First Name of Beneficiery  Displayed correctly", false);
             break;
                       }
                                                                        
    	}  Web.getDriver().switchTo().defaultContent();
        } catch (Exception e) {
                        System.out.println(e);
        }
    }
    

    
    public void EnterTodate(String effectdate) {
        //Common.ClickSubmenu(SubmenuValue);
        Web.waitForElement(History_ToDate);
        if(History_ToDate.getAttribute("value").isEmpty()) {
        Web.setTextToTextBox(History_ToDate,effectdate);
        }else {
        	System.out.println("Date is present");
        }
    //    History_ToDate.sendKeys(Keys.TAB);
    }

    public void verifyEAtransaction(String trx) {
        Web.waitForElement(Verifytrans);
        String Expected = "EA - Policy Add";                                                        
        Common.historytable("trxcode", Expected, trx); 
    }   	

    
    public void verifyGCtransaction() {
        Web.waitForElement(Verifytrans);
        String Expected = "GC - Cost Average Alloc Add";                                  
        Common.historytable("trxcode", Expected, Stock.GetParameterValue("CAEffectivedate")); 
    }

    public void verifyCostaverageOEStransaction() {
        Web.waitForElement(Verifytrans);
        String Expected = "OEI - Cost Average Fund Transfer";                                     
        Common.historytable("trxcode", Expected, Stock.GetParameterValue("CAEffectivedate")); 
    }


    public void VerifyNetPenality(String Surrendramount ) 
    {
    		double Expectedamt = 0;
    		String orgexpectedamt = null;
    		String orgactualamt = null;
    		double calculation = 0;
              String Freeamountval =  Common.FreeoutAmountValue.get("Freeamountval");
              if (Double.parseDouble(Surrendramount) > Double.parseDouble(Freeamountval)) 
              {
                     double Remainingamount;
                  
                     Remainingamount = Double.parseDouble(Surrendramount) - Double.parseDouble(Freeamountval);
                     Web.waitForElement(Surrenderpenality);
                     String Actualamttext =  Common.trimspecialcharacter(Surrenderpenality.getText());
                     double Actualamt = Double.parseDouble(Actualamttext);
                     Actualamt=Math.round(Actualamt);
                      orgactualamt=String.valueOf(Actualamt);
               
                     Expectedamt =.07527*Remainingamount;
                     Expectedamt=Math.round(Expectedamt);
                     
                     orgexpectedamt=String.valueOf(Expectedamt);
                     
              if(orgexpectedamt.equalsIgnoreCase(orgactualamt)) 
                     {
                           Reporter.logEvent(Status.PASS, "In History Transaction page the Expected State with surrender Penality is ["+orgexpectedamt+"]", "the Actual  surrender Penality  Amount is["+orgactualamt+"] Verified sucessfully", false);
                     }
                     
              else 
              {
                Reporter.logEvent(Status.FAIL, "In History Transaction page the Expected State with surrender Penality is ["+orgexpectedamt+"]", "the Actual  surrender Penality is["+orgactualamt+"]Not Verified sucessfully", false);}
       
           }
       else
       {
              Reporter.logEvent(Status.FAIL, "In Partial surrend page", "Surrender amount is not greater then free amount", false);
       }
            
              
    }
	
	public void ClickonmaintenanceSubmenu() {
		//Web.waitForElement(Maintenancesubmenyrealtime);
		//Maintenancesubmenyrealtime.click();
		Web.clickOnElement(Maintenancesubmenyrealtime);
		//Common.ClickSubmenu(Maintenancesubmenyrealtime);
		
	}
	
	/***********
	 * Need to update this function
	 */
	public void verifyGKtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "GK - Systematic Withdrawal Add";
		String Actual = Verifytrans.getText();
	
		
		Common.historytable("trxcode", Expected, Stock.GetParameterValue("EffectiveDate_sys")); 
	}
	
	public void verifyRBtransaction() {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "RB - Asset Rebalancing Add";				
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("AREffectivedate")); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "RB - Asset Rebalancing Add";				
			Common.historytable("trxcode", Expected, System.getProperty("TrxEffectiveDate")); 
								
		}else {
			Web.waitForElement(Verifytrans);
			String Expected = "RB - Asset Rebalancing Add";				
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("AREffectivedate")); 
		}
		
	}
	
	public void verifyOEStransaction(String trx) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "OES - Rebalancing Fund Transfer";				
			Common.historytable("trxcode", Expected, trx); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "OES - Rebalancing Fund Transfer";				
			Common.historytable("trxcode", Expected, System.getProperty("TrxEffectiveDate")); 
								
		}else {
			Web.waitForElement(Verifytrans);
			String Expected = "OES - Rebalancing Fund Transfer";				
			Common.historytable("trxcode", Expected, trx); 
		}
		
		
	}
	
	public void verifyOEStransactionAssetrebalanceChange(String trx) {
		
			Web.waitForElement(Verifytrans);
			String Expected = "OES - Rebalancing Fund Transfer";				
			Common.historytable("trxcode", Expected, trx); 
		
		
		
	}
	
	public void verifyFavCodeChangeStransaction(String trx) {
		Web.waitForElement(Verifytrans);
		String Expected = "FAV - FAV Code Change";				
		Common.historytable("trxcode", Expected, trx); 
	}
	
	public void verifyNoOEStransaction(String trx) {
		Web.waitForElement(Verifytrans);
		String Expected = "OES - Rebalancing Fund Transfer";				
		Common.NOTinhistorytable("trxcode", Expected, trx); 
	}
	
	public void VerifyAmtWithheldStateTax() {
		
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(AmtWithheldState);
		String Actualamt =  Common.trimspecialcharacter(AmtWithheldState.getText());
		String Expectedamt = Common.trimspecialcharacter(Stock.GetParameterValue("StateOverideAmt"));
		if(Expectedamt.equalsIgnoreCase(Actualamt)) {
			Reporter.logEvent(Status.PASS, "In History Transaction page the Expected State with held tax amount is ["+Expectedamt+"]", "the Actual State with held tax Amount is["+Actualamt+"] Verified sucessfully", false);
		}else {
			Reporter.logEvent(Status.FAIL, "In History Transaction page the Expected State with held tax amount is ["+Expectedamt+"]", "the Actual State with held tax Amount is["+Actualamt+"]Not Verified sucessfully", false);
		}
	}
	
	public void verifyTBtransaction(String trx) {
		
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "TB - Partial Surrender";				
			Common.historytable("trxcode", Expected, trx); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "TB - Partial Surrender";				
			Common.historytable("trxcode", Expected,  System.getProperty("TrxEffectiveDate")); 
								
		}else {
			Web.waitForElement(Verifytrans);
			String Expected = "TB - Partial Surrender";				
			Common.historytable("trxcode", Expected, trx); 
		}
		
	
	
	}
	
	
	
	public void doubleclickTBTransaction()
	{
		try {
			Thread.sleep(4500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(VerifytransTB);
		Actions actions = new Actions(Web.getDriver());
		actions.doubleClick(VerifytransTB).perform();
		
	}
	
	public void VerifynewContractID(String disbursement) {
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String ContractId;
		int col =0;
		String spouse = "PayeeDisbursementInd";
		String spousetype = disbursement;
		
		for(int i=1;i<=newContractIDhead.size();i++) {
			String spou = Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/thead/tr[2]/th["+i+"]")).getText();
			if(spouse.equalsIgnoreCase(spou)) {
				col = i;
				break;
			}				
		}
		for(int i=1;i<=newContractID.size();i++) {
			String sptype = Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr["+i+"]/td["+col+"]")).getText();
			if(spousetype.equalsIgnoreCase(sptype)) {
				ContractId =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr["+i+"]/td[1]")).getText();
				Reporter.logEvent(Status.PASS, "New Contract ID for the payee selected as ["+spousetype+"]", "The New Contract Id is ["+ContractId+"]", false);
				break;
			}else {
				Reporter.logEvent(Status.FAIL, "New Contract ID for the payee selected as ["+spousetype+"]", ".", false);
			}
			
		}
	}
	
	public void VerifynewContractIDforExistingContract(String disbursement) {
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String ContractId;
		int col =0;
		String spouse = "PayeeSpousalType";
		String spousetype = disbursement;
		
		for(int i=1;i<=newContractIDhead.size();i++) {
			String spou = Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/thead/tr[2]/th["+i+"]")).getText();
			if(spouse.equalsIgnoreCase(spou)) {
				col = i;
				break;
			}				
		}
		for(int i=1;i<=newContractID.size();i++) {
			String sptype = Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr["+i+"]/td["+col+"]")).getText();
			if(spousetype.equalsIgnoreCase(sptype)) {
				ContractId =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:detail']/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr["+i+"]/td[1]")).getText();
				Reporter.logEvent(Status.PASS, "New Contract ID for the payee selected as ["+spousetype+"]", "The New Contract Id is ["+ContractId+"]", false);
				break;
			}else {
				Reporter.logEvent(Status.FAIL, "New Contract ID for the payee selected as ["+spousetype+"]", ".", false);
			}
			
		}
	}
	
	public void verifyLRBItransaction() {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "LRBI - Rebalancing Change";				
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ChangeAREffectivedate")); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Verifytrans);
			String Expected = "LRBI - Rebalancing Change";				
			Common.historytable("trxcode", Expected, System.getProperty("TrxEffectiveDate")); 
							
		}else {
			Web.waitForElement(Verifytrans);
			String Expected = "LRBI - Rebalancing Change";				
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ChangeAREffectivedate")); 
			
		}
		
	}
	
	public void verifyLRBItransaction(String inv) {
		Web.waitForElement(Verifytrans);
		String Expected = "LRBI - Rebalancing Change";				
		Common.historytable("trxcode", Expected, inv); 
	}
	
	public void verifyZEtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "ZE - Allocation Change";
		String Actual = Verifytrans.getText();
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Common.historytable("trxcode", Expected,  System.getProperty("TrxEffectiveDate")); 
							
		}else {
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
			
		}
		
	
	}
	
	public void verifyLPDCtransaction(String effectivedate ) {
		Web.waitForElement(Verifytrans);		
		String Expected = "LPDC - Producer Change";		
		Common.historytable("trxcode", Expected, effectivedate); 
	}
	
	public void verifyLBDCtransaction() {
        Web.waitForElement(Verifytrans);
        String Expected = "LBDC - Beneficiary Change";                                  
        Common.historytable("trxcode", Expected, Stock.GetParameterValue("Effectivedate")); 
    }
	
	

	
	public void verifyZEtransaction(String effectivedate) {
		Web.waitForElement(Verifytrans);
		String Expected = "ZE - Allocation Change";		
		Common.historytable("trxcode", Expected, effectivedate); 
	}
	
    public void verifyPA_DEAThCLAIMtransaction(String trx) {
        Web.waitForElement(Verifytrans);
        String Expected = "PA - Death Claim";                         
        Common.historytable("trxcode", Expected, trx); 
    }

    public void verifystatusD_Death() {
        Web.waitForElement(Statuschek);
        String Expected = "D-Death";        
		if(Statuschek.getText().contains(Expected)) {
			Reporter.logEvent(Status.PASS,"Expected Status ["+Expected+"] ","Present in the Status as ["+Statuschek.getText()+"]", false);	
		}else {
			Reporter.logEvent(Status.FAIL,"Expected Status ["+Expected+"] ","Not Present in the Status as ["+Statuschek.getText()+"]", false);
		}
    }

	
	public void verifyNAtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "NA - Regular Remittance";
		//String Actual = Verifytrans.getText();
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Common.historytable("trxcode", Expected, System.getProperty("TrxEffectiveDate")); 
							
		}else {
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
			
		}
		
		
	}
	
	public void verifyNAtransactionFAV() {
		Web.waitForElement(Verifytrans);
		String Expected = "NA - Regular Remittance";
		//String Actual = Verifytrans.getText();
		if(System.getProperty("FavPremiundepoDate")==null)
		{
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
		}
		else if( System.getProperty("FavPremiundepoDate").trim().length() > 0)
		{
			Common.historytable("trxcode", Expected, System.getProperty("FavPremiundepoDate")); 
							
		}else {
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("ACEffectivedate")); 
			
		}
		
		
	}
	
	public void verifyTKtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "TK - Individual Payout";
		//String Actual = Verifytrans.getText();
		
		Common.historytable("trxcode", Expected, Stock.GetParameterValue("EffectiveDate_sys")) ;
	//	String date = Stock.GetParameterValue("Startdate");
		//String webdate =Hisdate.getText();
		/*if(Hisdate.isDisplayed()){
			Assert.assertTrue(Verifytrans.getText().contains(Expected), "verification GK transaction");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","NOT Present in the Actual text [ " + Actual + " ]", false);
		}*/
	}
	
	public void verifyLPOItransaction() {
		Web.waitForElement(Verifytrans);
		String Expected ="LPOI - Systematic Withdrawal Information";
		Common.historytable("trxcode", Expected,Stock.GetParameterValue("UpdateEffectivedate")) ;
	}
	
	
	public void verifyIDIRenewaltransaction(String trx) {
        
        String ExpectedIDI = "IDI - Index Renewal Initiation";
        for(int i=1;i<=Trxcode.size();i++) {
                        String ActualIDI = Web.getDriver().findElement(By.xpath("//*[@id='mainform:ContractHistoryIndexReturnedHistoryData']/tbody/tr["+i+"]/td[2]")).getText();
                        if(ExpectedIDI.equalsIgnoreCase(ActualIDI)) {
                        Reporter.logEvent(Status.PASS, "In Transaction page Expected transacton name ["+ExpectedIDI+"]", "actual transaction  is ["+ActualIDI+"] same", false);
                                        break;
                        }
                        
                        
                        
        }Common.historytable("trxcode", ExpectedIDI, trx); 
	}

	
	public void verifyUpdatesTKsubseqtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected ="TK - Individual Payout";
		Common.historytable("trxcode", Expected,Stock.GetParameterValue("UpdateStartdate")) ;
	}
	
	public void verifyNextpayoutTKtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "TK - Individual Payout";
	
		Common.historytable("trxcode", Expected,Stock.GetParameterValue("NextPayoutDate")) ;
	}
	
	@FindBy(xpath="//li[@id='accum_Values']/div/a[1]")
	private static WebElement ValueSubmenu;
	
	public void ClickonValueSubmenu() {
	//	Web.waitForElement(ValueSubmenu);
	//	ValueSubmenu.click();
		Web.clickOnElement(ValueSubmenu);
		//Common.ClickSubmenu(ValueSubmenu);
	}
	
	public void clickhistorysubmenu() {
		Common.ClickSubmenu(Historysubmenu);
	}
	
	public void VerifyStatusS() {
		if(Statuschek.getText().contains("S-Surrendered")) {
			Reporter.logEvent(Status.PASS,"Expected Status S- Surrender ","Present in the Status as S - Surrender", false);	
		}else {
			Reporter.logEvent(Status.FAIL,"Expected Status S- Surrender ","Not Present in the Status as S - Surrender", false);
		}
	}


public void VerifyTAtransaction() {
		Web.waitForElement(Verifytrans);
		String Expected = "TA - Full Surrender";
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("EffectiveDate_full")) ;
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Common.historytable("trxcode", Expected, System.getProperty("TrxEffectiveDate")) ;
							
		}else {
			Common.historytable("trxcode", Expected, Stock.GetParameterValue("EffectiveDate_full")) ;
			
		}
		
	}

	public Transaction(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(HistoryupdateBT);
		Assert.assertTrue(Web.isWebElementDisplayed(HistoryupdateBT),"History Page is Not Loaded\n");
	}

}
