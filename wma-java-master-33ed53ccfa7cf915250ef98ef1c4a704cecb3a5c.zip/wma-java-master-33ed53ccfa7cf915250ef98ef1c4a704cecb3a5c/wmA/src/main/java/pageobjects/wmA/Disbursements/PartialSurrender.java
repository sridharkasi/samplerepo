package pageobjects.wmA.Disbursements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class PartialSurrender extends LoadableComponent<PartialSurrender> {
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id ="mainform:searchButton")
	private static WebElement searchbutton;
	
	@FindBy(partialLinkText ="Disbursements")
	private static WebElement Disbursement;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Partial Surrender')]")
	private static WebElement ps;
	
	@FindBy(id = "mainform:partialSurrenderEffectiveDate_input")
	private static WebElement ed;
	
	@FindBy(id ="mainform:partialSurrenderTrxAmount")
	private static WebElement surrenderamt;
	
	@FindBy(id = "mainform:partialSurrenderSourceCode")
	private static WebElement sourcecode;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr")
	private  List<WebElement> Fundtable;
		
    @FindBy(xpath= "//input[@id='mainform:partialSurrenderStateWithhOrInd']")
    private static WebElement withholdingOveride;    

    @FindBy(xpath= "//input[@id='mainform:partialSurrenderWithholdingAmtState']")
    private static WebElement stateOverideAmt;
    
    @FindBy(id="mainform:partialSurrenderNetGrossInd:1")
    private WebElement Net_RB;
   
    
    @FindBy(id="overridebox")
	  private static WebElement overidebox;
	  
	  public void clickoverirde() {		  
		
		  Web.waitForElement(overidebox);
		  Web.clickOnElement(overidebox);
		  
	  }
    
    public void clickwithholdingoverride()
    {
    	Web.clickOnElement(withholdingOveride);
    	Reporter.logEvent(Status.PASS, "In the Select Plan page click on Check box  ", " The Check box is successfully selected", false);
    }
    
	public void EnterStateoverideamt (String stateoverideAmt) {
		Web.waitForElement(stateOverideAmt);
		Web.setTextToTextBox(stateOverideAmt, stateoverideAmt);
		if(stateOverideAmt.getAttribute("value").equalsIgnoreCase(stateoverideAmt))
			 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the State Overide Amount", "the State Overide Amount is["+stateoverideAmt+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the State Overide Amount", "the State Overide Amount is["+stateoverideAmt+"] Not entered sucessfully", false);
		
	}
	
	public void ClickOnNetButton() {
		Web.waitForElement(Net_RB);
		Web.clickOnElement(Net_RB);
	}
	
	public void clickhomebutton () {
		Web.waitForElement(homebutton);
		Web.clickOnElement(homebutton);
	}
	
	//************************Transaction Level********************
	
	@FindBy(id="mainform:partialSurrenderTrxLevelIndicator")
	private static WebElement pstrxlevel;
	
	public void SelectTransactionLevel(String trxlevel) throws InterruptedException {
		Thread.sleep(5000);
		if(System.getProperty("TrxLevel")==null)
		{
			Web.waitForElement(pstrxlevel);
			Web.selectDropDownOption(pstrxlevel, trxlevel);
		}
		else if( System.getProperty("TrxLevel").trim().length() > 0)
		{
			Web.waitForElement(pstrxlevel);
			Web.selectDropDownOption(pstrxlevel, Stock.getConfigParam(System.getProperty("TrxLevel").trim()));	
								
		}else {
			Web.waitForElement(pstrxlevel);
			Web.selectDropDownOption(pstrxlevel, trxlevel);
		}
		
		
		Thread.sleep(3500);
	}
	
	//************************Transaction Type**********************
	
	@FindBy(id="mainform:partialSurrenderTrxTypeIndicator")
	private static WebElement pstrxindicator;
	
	public void SelectTransactionIndicator(String psindica) {
		if(System.getProperty("TrxType")==null)
		{
			Web.waitForElement(pstrxindicator);
			Web.selectDropDownOption(pstrxindicator, psindica);
		}
		else if( System.getProperty("TrxType").trim().length() > 0)
		{
			Web.waitForElement(pstrxindicator);
			Web.selectDropDownOption(pstrxindicator, System.getProperty("TrxType").trim());	
								
		}else {
			Web.waitForElement(pstrxindicator);
			Web.selectDropDownOption(pstrxindicator, psindica);
		}
		
	
		Web.waitForElement(pstrxindicator);
	}
	
	
	
	//************************Fund Amount***************************
	
	@FindBy(id="mainform:AllocationFund:0:allocationFundAmount")
	private static WebElement famount;
	
	public void EnterFundAmount (String FundAmt) {
		Web.waitForElement(famount);
		Web.setTextToTextBox(famount, FundAmt);
	}
	
	//*************************Fund Percentage**********************
	
	@FindBy(id="mainform:AllocationFund:0:allocationFundPercent")
	private static WebElement Fpercent;
	
	public void EnterFundPercentage (String FundPer) {
		Web.waitForElement(Fpercent);
		Web.setTextToTextBox(Fpercent, FundPer);
	}
	//*************************Fund Unit********************************
	
	@FindBy(id="mainform:AllocationFund:0:allocationFundUnit")
	private static WebElement Funit;
	
	public void EnterFundUnit(String Fundunit) {
		Web.waitForElement(Funit);
		Web.setTextToTextBox(Funit, Fundunit);
	}
	//************************PRO RATA Percentage basis******************
	
	@FindBy(id="mainform:partialSurrenderTrxPercent")
	private static WebElement Propercent;
	
	
	public void EnterProrataPercentage(String ProPer) {
		try {
			Thread.sleep(3500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(Propercent);
		Web.setTextToTextBox(Propercent, ProPer);
		if(Propercent.getAttribute("value").equalsIgnoreCase(ProPer))
			 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+ProPer+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+ProPer+"] Not entered sucessfully", false);
				   	
	}
	
	public void EnterFundForContractID() {
		
		if(System.getProperty("TrxType").equalsIgnoreCase("Amount"))
		{
			Web.waitForElement(surrenderamt);
			Web.setTextToTextBox(surrenderamt, System.getProperty("PSurrenderValue"));
			if(surrenderamt.getAttribute("value").equalsIgnoreCase(System.getProperty("PSurrenderValue")))
				 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+System.getProperty("PSurrenderValue")+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+System.getProperty("PSurrenderValue")+"] Not entered sucessfully", false);
		}
		else if(System.getProperty("TrxType").equalsIgnoreCase("Percent"))
		{
			Web.waitForElement(Propercent);
			Web.setTextToTextBox(Propercent, System.getProperty("PSurrenderValue"));
			if(Propercent.getAttribute("value").equalsIgnoreCase(System.getProperty("PSurrenderValue")))
				 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+System.getProperty("PSurrenderValue")+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Surrender Percent", "The Surrender Percent is["+System.getProperty("PSurrenderValue")+"] Not entered sucessfully", false);
		}
	}
	//*********************************End*******************************
	
	public void EnterPartialSurrenderFund() {
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		int cfundnumber = Integer.parseInt(Stock.GetParameterValue("PSCFFund"));
   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("PSNONCFFund"));
   		int tempNC =0;
   		int temp =0;
   		int cnt;
		int colmn = 0;
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th")).size();		
		String percent = "Withdrawal Percent";
		String Amt = "Surr Amt/Rem Amt";
		String Tabledata;
		String Fundvaule;
		String Percent;
		Double percentage;
		
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(percent) || fud.equalsIgnoreCase(Amt)) {
				colmn = i;
				break;
			}
		}
		
		if (Noncfundnumber >=1)	
	   	{
	   		for (int j=1; j<Fundtable.size();j++)
	   		{
	   			cnt = j;
	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
	   			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+colmn+"]")).getText();
	   			if(!str1.equalsIgnoreCase("c") && fud.equalsIgnoreCase(percent)) 
	   			{
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("PSurrender"+cnt));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("PSurrender"+cnt)+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText();
					Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
					Fundvaule =Common.trimspecialcharacter(Fundvaule);
					Percent =  Stock.GetParameterValue("PSurrender"+cnt);
					percentage = Double.parseDouble(Fundvaule) * Double.parseDouble(Percent);
					percentage = percentage/100;
					Double Newvalue = Double.parseDouble(Fundvaule) - percentage;
					Newvalue = Math.round(Newvalue * 100.0) / 100.0;
					Common.GawFundPRC.put(Tabledata, Newvalue.toString());
	   			}
	   			else if(!str1.equalsIgnoreCase("c") && fud.equalsIgnoreCase(Amt)){
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("PSurrender"+cnt));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("PSurrender"+cnt)+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText();
					Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
					Fundvaule =Common.trimspecialcharacter(Fundvaule);
					Percent =  Stock.GetParameterValue("PSurrender"+cnt);					
					Double Newvalue = Double.parseDouble(Fundvaule) - Double.parseDouble(Percent);
					Newvalue = Math.round(Newvalue * 100.0) / 100.0;
					Common.GawFundPRC.put(Tabledata, Newvalue.toString());
	   			}
	   			if(Noncfundnumber==tempNC)
				{
				break;
				}
	   		}
	   	}
	   	else if(Noncfundnumber==0)
	   	{
	   		
	   	}
	   	else
	   	{
	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
	   	}
	   		
		if (cfundnumber >=1)	
	   	{	
			for (int i=1; i<=Fundtable.size();i++) {
				cnt = i;
				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+colmn+"]")).getText();
						if(str.equalsIgnoreCase("c") && fud.equalsIgnoreCase(percent)) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("PSurrender"+cnt));
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("PSurrender"+cnt)+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
							Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText();
							Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
							Fundvaule =Common.trimspecialcharacter(Fundvaule);
							Percent =  Stock.GetParameterValue("PSurrender"+cnt);
							percentage = Double.parseDouble(Fundvaule) * Double.parseDouble(Percent);
							percentage = percentage/100;
							Double Newvalue = Double.parseDouble(Fundvaule) - percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Common.GawFundPRC.put(Tabledata, Newvalue.toString());
						}
						else if(str.equalsIgnoreCase("c") && fud.equalsIgnoreCase(Amt)) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
						//	Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("PSurrender"+cnt));
							
							///
							JavascriptExecutor js = (JavascriptExecutor) Web.getDriver();
							js.executeScript("arguments[0].value="+Stock.GetParameterValue("PSurrender"+cnt)+";", Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")));
							
							///
							
							
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("PSurrender"+cnt)+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
							Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText();
							Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
							Fundvaule =Common.trimspecialcharacter(Fundvaule);
							Percent =  Stock.GetParameterValue("PSurrender"+cnt);
							
							Double Newvalue = Double.parseDouble(Fundvaule) -  Double.parseDouble(Percent);
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Common.GawFundPRC.put(Tabledata, Newvalue.toString());
						}
						if(cfundnumber==temp)
						{
						break;
						}
			}
	   	}
		else if(cfundnumber==0)
	   	{
	   		
	   	}
		else
		{
			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
		}
	   	

		
	}
	
//**************************************************************************************************************************************************************************************************************************************************
public void EnterPartialSurrenderFundForExtingContract() {
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception e)
		{
			
		}
		
		int cfundnumber = 0 + Common.CovFund.size();
   		int Noncfundnumber = 0 + Common.NonCFund.size();
   		int tempNC =0;
   		int temp =0;
   		int cnt;
		int colmn = 0;
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th")).size();		
		String percent = "Withdrawal Percent";
		String Amt = "Surr Amt/Rem Amt";
		String Tabledata;
		String Fundvaule;
		String Percent;
		Double percentage;
		
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(percent) || fud.equalsIgnoreCase(Amt)) {
				colmn = i;
				break;
			}
		}
		
		if (Noncfundnumber >=1)	
	   	{
	   		for (int j=1; j<=Fundtable.size();j++)
	   		{
	   			cnt = j;
	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
	   			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+colmn+"]")).getText();
	   			if(!str1.equalsIgnoreCase("c") && fud.equalsIgnoreCase(percent)) 
	   			{
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(System.getProperty("PSurrenderValue"));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("PSurrenderValue")+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText();
					Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
					Fundvaule =Common.trimspecialcharacter(Fundvaule);
					Percent =  System.getProperty("PSurrenderValue");
					percentage = Double.parseDouble(Fundvaule) * Double.parseDouble(Percent);
					percentage = percentage/100;
					Double Newvalue = Double.parseDouble(Fundvaule) - percentage;
					Newvalue = Math.round(Newvalue * 100.0) / 100.0;
					Common.GawFundPRC.put(Tabledata, Newvalue.toString());
	   			}
	   			else if(!str1.equalsIgnoreCase("c") && fud.equalsIgnoreCase(Amt)){
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(System.getProperty("PSurrenderValue"));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("PSurrenderValue")+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText();
					Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
					Fundvaule =Common.trimspecialcharacter(Fundvaule);
					Percent =  System.getProperty("PSurrenderValue");					
					Double Newvalue = Double.parseDouble(Fundvaule) - Double.parseDouble(Percent);
					Newvalue = Math.round(Newvalue * 100.0) / 100.0;
					Common.GawFundPRC.put(Tabledata, Newvalue.toString());
	   			}
	   			if(Noncfundnumber==tempNC)
				{
				break;
				}
	   		}
	   	}
	   	else if(Noncfundnumber==0)
	   	{
	   		
	   	}
	   	else
	   	{
	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
	   	}
	   		
		if (cfundnumber >=1)	
	   	{	
			for (int i=1; i<=Fundtable.size();i++) {
				cnt = i;
				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr/th["+colmn+"]")).getText();
						if(str.equalsIgnoreCase("c") && fud.equalsIgnoreCase(percent)) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(System.getProperty("PSurrenderValue"));
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("PSurrenderValue")+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
							Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText();
							Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
							Fundvaule =Common.trimspecialcharacter(Fundvaule);
							Percent =  System.getProperty("PSurrenderValue");
							percentage = Double.parseDouble(Fundvaule) * Double.parseDouble(Percent);
							percentage = percentage/100;
							Double Newvalue = Double.parseDouble(Fundvaule) - percentage;
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Common.GawFundPRC.put(Tabledata, Newvalue.toString());
						}
						else if(str.equalsIgnoreCase("c") && fud.equalsIgnoreCase(Amt)) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
						//	Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("PSurrender"+cnt));
							
							///
							JavascriptExecutor js = (JavascriptExecutor) Web.getDriver();
							js.executeScript("arguments[0].value="+System.getProperty("PSurrenderValue")+";", Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")));
							
							///
							
							
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("PSurrender")+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
							Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText();
							Fundvaule = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
							Fundvaule =Common.trimspecialcharacter(Fundvaule);
							Percent =  System.getProperty("PSurrenderValue");
							
							Double Newvalue = Double.parseDouble(Fundvaule) -  Double.parseDouble(Percent);
							Newvalue = Math.round(Newvalue * 100.0) / 100.0;
							Common.GawFundPRC.put(Tabledata, Newvalue.toString());
						}
						if(cfundnumber==temp)
						{
						break;
						}
			}
	   	}
		else if(cfundnumber==0)
	   	{
	   		
	   	}
		else
		{
			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
		}
	   	

		
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
	}
	
	public void clicksearchbutton() {
		Web.waitForElement(searchbutton);
		Web.clickOnElement(searchbutton);
	}
	
    public void clickpartialsurrender() {
    	Web.waitForElement(ps);
    	Common.ClickSubmenu(ps);
    }
       
    public void seteffectivedate(String effdate) throws InterruptedException {
    	
    	if(System.getProperty("TrxEffectiveDate")==null)
		{
    		Web.waitForElement(ed);
        	Web.setTextToTextBox(ed, effdate);
        	if(ed.getAttribute("value").equalsIgnoreCase(effdate))
    			 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
    		else
    			 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(ed);
			Web.setTextToTextBox(ed, System.getProperty("TrxEffectiveDate").trim());
	    		    	
	    	if(ed.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate").trim()))
				 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] Not entered sucessfully", false);
								
		}else {
			Web.waitForElement(ed);
	    	Web.setTextToTextBox(ed, effdate);
	    	if(ed.getAttribute("value").equalsIgnoreCase(effdate))
				 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
			else
				 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
		}
    	

	}
    	
    	
    
    
    public void EnterSurrenderamount(String Samount) {
    	try {
			Thread.sleep(3500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Web.waitForElement(surrenderamt);
    	Web.setTextToTextBox(surrenderamt, Samount);
    	if(surrenderamt.getAttribute("value").equalsIgnoreCase(Samount))
			 Reporter.logEvent(Status.PASS, "In Partial Surrender page enter the Surrender Amount", "The Surrender Amount is["+Samount+"] entered sucessfully", false);
		else
			 Reporter.logEvent(Status.FAIL, "In Partial Surrender page enter the Surrender Amount", "The Surrender Amount is["+Samount+"] Not entered sucessfully", false);
    	
    }
    
    public void selectsourcecode(String source) {
    	Web.waitForElement(sourcecode);
    	Web.selectDropDownOption(sourcecode, source);
    }
    
	public void RealtimeDrpDwn(String selectrealtime) {
		Web.waitForElement(RealtimeDrpDwn);
		 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
		 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
	}
    
    public void clicksumbmit() {
    	Web.waitForElement(submit);
    	Web.clickOnElement(submit);
    }
    
	public void VerifyErrorText(String expectedtext) {
		Web.waitForElement(ErrorText);	
		String Expected = Stock.GetParameterValue("ErrorText");
		String Actual = ErrorText.getText();		
		Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
		Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
	}
		
	public PartialSurrender (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(ed);
		// TODO Auto-generated method stub
		Assert.assertTrue(Web.isWebElementDisplayed(ed),"Login Page is Not Loaded\n");
	}

}
