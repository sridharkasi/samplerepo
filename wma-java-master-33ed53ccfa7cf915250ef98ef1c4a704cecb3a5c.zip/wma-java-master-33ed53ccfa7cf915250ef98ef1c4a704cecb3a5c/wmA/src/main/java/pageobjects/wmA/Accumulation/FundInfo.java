package pageobjects.wmA.Accumulation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class FundInfo extends LoadableComponent<FundInfo>{
	
	@FindBy (id="mainform:AllocationFund:1:allocationFundPercent")
	private  WebElement GrowthINV;
	
    @FindBy(xpath="//span[contains(@id, 'allocationFundCoveredFundInd')]")
    private  List<WebElement> CoveredFund;
  
    
    @FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr")
    private  List<WebElement> CoveredFundrow;
    
    @FindBy(id="mainform:AllocationFund:96:allocationFundPercent")
    private  WebElement RIA_FUND_T;
    
    @FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
    
    @SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		// My Accounts
		if (fieldName.trim().equalsIgnoreCase("FundInfo_Fundpercent")) {
			return this.GrowthINV;
		}
		
		
		
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
    
    public void EnterRIAfund(String fund) {
    	Web.setTextToTextBox(RIA_FUND_T, fund);
    }
	
	public  void entercoveredfund(String inv) throws InterruptedException {
		Web.waitForElement(GrowthINV);
		int colmn = 0;
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[2]/th")).size();
		
		String allot = "Allocation Percent";
		
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[2]/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(allot)) {
				colmn = i;
				break;
			}
		}
		for (int i=1; i<CoveredFundrow.size();i++) {
			
		
			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
			
					if(str.equalsIgnoreCase("c")) {
						System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
						Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);
						break;
					}
		}
	}
	
	public  void enterfundMultiple(String inv) throws InterruptedException {
		Web.waitForElement(GrowthINV);
	
		if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null)
    	{
    		System.out.println("Covred Fund is not selected Since its null in Test data and parameter");
    		int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
       		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
       		int tempNC =0;
       		int temp =0;
       	if (Noncfundnumber >=1)	
       	{
       		for (int j=1; j<CoveredFundrow.size();j++)
       		{
       			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
       			if(!str1.equalsIgnoreCase("c")) 
       			{
       				tempNC = tempNC + 1;
       				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).clear();						
    				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).sendKeys(inv);
    				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
       			}
       			
       			if(Noncfundnumber==tempNC)
    			{
    			break;
    			}
       		}
       	}
       	else if(Noncfundnumber==0)
       	{
       		
       	}
       	else
       	{
       		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
       	}
       		
    	if (cfundnumber >=1)	
       	{	
    		for (int i=1; i<CoveredFundrow.size();i++) {
    			
    			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
    			
    					if(str.equalsIgnoreCase("c")) {
    						temp = temp + 1;
    						System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
    						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();						
    						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
    						Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    						Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
    					}
    					if(cfundnumber==temp)
    					{
    					break;
    					}
    		}
       	}
    	else if(cfundnumber==0)
       	{
       		
       	}
    	else
    	{
    		Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
    	}
    	}
		
    	else if( System.getProperty("RiderType")!=null || Stock.GetParameterValue("RiderType") != null)
		{
    		if(System.getProperty("RiderType")!=null && (System.getProperty("RiderType").trim().length()>0)) {
    			System.out.println("Covered Fund is selected from the parameter");
    			int cfundnumber = 1;
    	   		int Noncfundnumber = 0;
    	   		int tempNC =0;
    	   		int temp =0;
    	   		inv = "100";
    	   	if (Noncfundnumber >=1)	
    	   	{
    	   		for (int j=1; j<CoveredFundrow.size();j++)
    	   		{
    	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
    	   			if(!str1.equalsIgnoreCase("c")) 
    	   			{
    	   				tempNC = tempNC + 1;
    	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).clear();						
    					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).sendKeys(inv);
    					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
    	   			}
    	   			
    	   			if(Noncfundnumber==tempNC)
    				{
    				break;
    				}
    	   		}
    	   	}
    	   	else if(Noncfundnumber==0)
    	   	{
    	   		
    	   	}
    	   	else
    	   	{
    	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
    	   	}
    	   		
    		if (cfundnumber >=1)	
    	   	{	
    			for (int i=1; i<CoveredFundrow.size();i++) {
    				
    				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
    				
    						if(str.equalsIgnoreCase("c")) {
    							temp = temp + 1;
    							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
    							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();						
    							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
    							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
    						}
    						if(cfundnumber==temp)
    						{
    						break;
    						}
    			}
    	   	}
    		else if(cfundnumber==0)
    	   	{
    	   		
    	   	}
    		else
    		{
    			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
    		}
    		}
    		else if(Stock.GetParameterValue("RiderType") != null && Stock.GetParameterValue("RiderType").length()>0){
    			System.out.println("Covered fund is selected from the test data");
    			int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
    	   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
    	   		int tempNC =0;
    	   		int temp =0;
    	   	if (Noncfundnumber >=1)	
    	   	{
    	   		for (int j=1; j<CoveredFundrow.size();j++)
    	   		{
    	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
    	   			if(!str1.equalsIgnoreCase("c")) 
    	   			{
    	   				tempNC = tempNC + 1;
    	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).clear();						
    					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).sendKeys(inv);
    					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
    	   			}
    	   			
    	   			if(Noncfundnumber==tempNC)
    				{
    				break;
    				}
    	   		}
    	   	}
    	   	else if(Noncfundnumber==0)
    	   	{
    	   		
    	   	}
    	   	else
    	   	{
    	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
    	   	}
    	   		
    		if (cfundnumber >=1)	
    	   	{	
    			for (int i=1; i<CoveredFundrow.size();i++) {
    				
    				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
    				
    						if(str.equalsIgnoreCase("c")) {
    							temp = temp + 1;
    							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
    							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();						
    							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
    							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
    							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
    						}
    						if(cfundnumber==temp)
    						{
    						break;
    						}
    			}
    	   	}
    		else if(cfundnumber==0)
    	   	{
    	   		
    	   	}
    		else
    		{
    			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
    		}
    		}
    		else {
   			 System.out.println("Covered Fund is not selected for this test case Rider is NA in test data and Parameter");
   			 int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
   		   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
   		   		int tempNC =0;
   		   		int temp =0;
   		   	if (Noncfundnumber >=1)	
   		   	{
   		   		for (int j=1; j<CoveredFundrow.size();j++)
   		   		{
   		   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
   		   			if(!str1.equalsIgnoreCase("c")) 
   		   			{
   		   				tempNC = tempNC + 1;
   		   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).clear();						
   						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).sendKeys(inv);
   						Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
   						Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
   		   			}
   		   			
   		   			if(Noncfundnumber==tempNC)
   					{
   					break;
   					}
   		   		}
   		   	}
   		   	else if(Noncfundnumber==0)
   		   	{
   		   		
   		   	}
   		   	else
   		   	{
   		   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
   		   	}
   		   		
   			if (cfundnumber >=1)	
   		   	{	
   				for (int i=1; i<CoveredFundrow.size();i++) {
   					
   					String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
   					
   							if(str.equalsIgnoreCase("c")) {
   								temp = temp + 1;
   								System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
   								Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();						
   								Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
   								Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
   								Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
   							}
   							if(cfundnumber==temp)
   							{
   							break;
   							}
   				}
   		   	}
   			else if(cfundnumber==0)
   		   	{
   		   		
   		   	}
   			else
   			{
   				Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
   			}
   		}
    		
		}
		
		/*int cfundnumber = Integer.parseInt(Stock.GetParameterValue("CFfund"));
   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
   		int tempNC =0;
   		int temp =0;
   	if (Noncfundnumber >=1)	
   	{
   		for (int j=1; j<CoveredFundrow.size();j++)
   		{
   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[3]")).getText();
   			if(!str1.equalsIgnoreCase("c")) 
   			{
   				tempNC = tempNC + 1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]/input")).sendKeys(inv);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
   			}
   			
   			if(Noncfundnumber==tempNC)
			{
			break;
			}
   		}
   	}
   	else if(Noncfundnumber==0)
   	{
   		
   	}
   	else
   	{
   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
   	}
   		
	if (cfundnumber >=1)	
   	{	
		for (int i=1; i<CoveredFundrow.size();i++) {
			
			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
			
					if(str.equalsIgnoreCase("c")) {
						temp = temp + 1;
						System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();						
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
						Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
						Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
					}
					if(cfundnumber==temp)
					{
					break;
					}
		}
   	}
	else if(cfundnumber==0)
   	{
   		
   	}
	else
	{
		Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
	}*/
   	
	}
	
	public void Enterfundinfo()
	{
		boolean Passflag; 
		boolean skip = false;
		int temp =0;
		Web.waitForElement(GrowthINV);
		
		
		for (int j=1; j<=5; j++)
		{
			Passflag = false;
			if(skip)
			{
				break;
			}
		for (int i=1; i<CoveredFundrow.size();i++) {
			
			if(Stock.GetParameterValue("FundName_"+j)==null)
				
			{
				skip = true;
				Passflag = true;
				break;
			}
			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText();
			
					 
			if(str.equalsIgnoreCase(Stock.GetParameterValue("FundName_"+j))) 
			{
						temp = temp + 1;
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).click();
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).clear();			
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(Stock.GetParameterValue("Allocation"+j+""));
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(Keys.TAB);
						Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
						Passflag = true;
						Reporter.logEvent(Status.PASS, "In the Fund info page Fund Number ["+str+"]  "," The  Percentage value is ["+Stock.GetParameterValue("Allocation"+j+"")+"] Entered Successfully", false);
					
						break;
					}
					
					
		}
			if(!Passflag)
			{
				
				//Reporter.logEvent(Status.FAIL, "In the Fund info page Fund ["+System.getProperty("FundName"+j+"_Percentage")+"]", " Not found", false);
			Reporter.logEvent(Status.FAIL, "In the Fund info page Fund ["+Stock.GetParameterValue("FundName_"+j)+"]", " Not found", false);
			}
		}
	}
	
	
	public void GrowthINV(String inv) throws InterruptedException {

		Web.waitForElement(GrowthINV);
		 Web.setTextToTextBox(GrowthINV, inv);
		 Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);
	}
	
	
	public FundInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(GrowthINV);
		Assert.assertTrue(Web.isWebElementDisplayed(GrowthINV),"Fund Info Page is Not Loaded\n");
	
	}

}
