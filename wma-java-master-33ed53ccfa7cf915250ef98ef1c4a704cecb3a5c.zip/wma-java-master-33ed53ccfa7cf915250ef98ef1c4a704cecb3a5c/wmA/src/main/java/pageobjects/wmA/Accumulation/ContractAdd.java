package pageobjects.wmA.Accumulation;

import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.LoadableComponent;

import org.testng.Assert;

import com.aventstack.extentreports.Status;


import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;


	
	public class ContractAdd extends LoadableComponent<ContractAdd> {

		// Object Declarations
		@FindBy(linkText = "Accumulation")
		private WebElement ContractAddLink;
		//private WebElement menu;
		@FindBy(xpath = "//li[@id='accumulationMain']/div/a")
		private WebElement submenu;
		
		@FindBy(id="mainform:contractEntryPartnerName")
		private WebElement selectPartner;
		@FindBy(id="mainform:contractEntryPolicyEffectiveDate_input")
		private WebElement Effectivedate;
		@FindBy(id="mainform:contractEntryIssueState")
		private WebElement Issuestate;
		@FindBy(id="mainform:contractEntryPlanCode")
		private WebElement baseplan;
		
		@FindBy(id="mainform:contractEntryCashWithAppCode")
		private WebElement CashCeckbox;
		
		//how = How.ID, using = “userName”)
		@FindBy(how = How.ID, using ="mainform:contractEntryStatutoryCompanyCode")
		private WebElement StatutoryCompcode;
		
		@FindBy(id="mainform:contractEntryLineOfBusiness")
		private WebElement LineofBusiness;
		
		@FindBy(id="mainform:contractEntryResidentState")
		private WebElement residentstate;
		
		@FindBy(id="mainform:advisorLastName")
		private WebElement lastname;
		
		@FindBy(id="mainform:advisorSearch")
		private WebElement AdvisorSearch;
		
		@FindBy(xpath="//table/tbody/tr/td/input[@id='submitbutton']")
		private WebElement OKButton;
		
		@FindBy(id="nextbutton")
		private static WebElement NextButton;
		
		@FindBy(xpath ="//table[@id='mainform:Advisor']/tbody/tr")
		private static WebElement SelectRowPartySearch;
		
		//==
		@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoRoleTypeCode")
		private static WebElement RoleType;
	
		@FindBy (id="mainform:AdvisorAgentInfo:0:advisorAgentInfoAgentProfile")
		private static WebElement Profile;
		
		@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoFirstYearPercent")
		private static WebElement FirstYrPercentage;
		
		@FindBy(id="mainform:AdvisorAgentInfo:0:advisorAgentInfoRenewalPercent")
		private static WebElement RnwalPercentage;
		
		@FindBy (id="mainform:AdvisorAgentInfo:0:advisorAgentInfoCommissionAgencyCode")
		private static WebElement CommisionAgncy;
		
		//=====
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataFirstName")
		private static WebElement AnnuityFirstName;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataLastName")
		private static WebElement AnnuityLastName;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataBirthdate_input")
		private static WebElement AnnuityDOB;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataSexCode")
		private static WebElement AnnuityGender;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataAddressLine1")
		private static WebElement Address;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataCity")
		private static WebElement AnnuityCity;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataTaxIdNumber")
		private static WebElement AnnuitySSN;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataZipPostalCode")
		private static WebElement AnnuityZip;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataZipPostalCode4")
		private static WebElement AnnuityZipRemaining;
		
		@FindBy(id="mainform:contractEntryContractEntryAnnuitantDataState")
		private static WebElement AnnuityState;
		//===
		
		@FindBy(id="mainform:contractEntryRetirementAge")
		private static WebElement AnnuityRetAge;
		//======
		
		@FindBy (id="mainform:contractEntryModalPremium")
		private static WebElement ModelPremium;
		
		@FindBy (id="mainform:contractEntryInitialDepositPremium")
		private static WebElement InitialPayment;
		
		@FindBy (id="mainform:AllocationFund:1:allocationFundPercent")
		private static WebElement GrowthINV;
		
		@FindBy (id="mainform:premiumPaymentTrxCode:0")
		private static WebElement Paymenttype;
		
		@FindBy (id="mainform:premiumPaymentMemoCode")
		private static WebElement MemoCode;
		
		@FindBy (id="mainform:premiumPaymentPaymentAmount")
		private static WebElement PaymentAmount;
		
		@FindBy (id="mainform:premiumPaymentAllocationType")
		private static WebElement AllocationType;
		
		@FindBy (id="mainform:ForcedRateAllocationFund:1:forcedRateAllocationFundPercent")
		private static WebElement AllocationFormulaOveride;
		
		@FindBy (id="realtimeselect")
		private static WebElement RealtimeDrpDwn;
		
		@FindBy (id="finishbutton")
		private static WebElement FinishButton;
		
		@FindBy (id="errorMessages")
		private static WebElement ErrorText;
		
		@FindBy (id="mainform:summaryPolicyNumber")
		private static WebElement Policynumber;
		
        @FindBy(linkText="Navigate")
        private static WebElement nav;
        
        @FindBy(xpath="//span[contains(@id, 'allocationFundCoveredFundInd')]")
        private static List<WebElement> CoveredFund;
      
        
        @FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr")
        private static List<WebElement> CoveredFundrow;
        
        
        @FindBy (id="mainform:hccInd")
		private static WebElement AddRaiderCheckbox;
        
        @FindBy (id="mainform:hccRiderType")
		private static WebElement HCC_RaiderType_LB;
        
        @FindBy (id="mainform:add")
		private static WebElement HCC_RaiderTypeAdd_BT;
          
        @FindBy (id="mainform:HccAdd:0:hccAddPlanCode")
		private static WebElement HCC_RaiderPlan_LB;
        
        
        @FindBy(xpath = "//table[@id='mainform:AllocationFund']/tr[1]/td[1]")
        private static WebElement Testx;
        
        @FindBy(xpath = "//table[@id='mainform:AllocationFund']/tbody/tr")
        private static WebElement FundTablerow_TB;
      
      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        public void ClickOnNavigateprofile() {
               Web.clickOnElement(nav);
        }

		
		
		
		
		LoadableComponent<?> parent;
		@SuppressWarnings("unused")
		

		public ContractAdd() {
			// this.parent = parent;
			PageFactory.initElements(lib.Web.getDriver(), this);
		}
		
		


		@Override
		protected void load() {
			this.parent.get();
		 Stock.getConfigParam("AppURL" + "_"

	                                        + Stock.getConfigParam("TEST_ENV"));
			
		}
			
		/**
		 * Method to enter user credentials and click on Sign In button
		 * 
		 * @param userName
		 * @param password
		 */
		

		

	
		
		public void clickcontractADD() {
			Common.ClickSubmenu(submenu);
			
		
		}
		
		public void selectpartner(String partner) throws InterruptedException {
			 Web.selectDropDownOption(selectPartner, partner);
			 Thread.sleep(10000);
			
		}
	
		
		public void setEffectiveDate(String EffectiveDate) {
			 Web.setTextToTextBox(Effectivedate, EffectiveDate);
			
		}
		
		public void selectIssuestate(String state) {
			 Web.selectDropDownOption(Issuestate, state);
			
		}
		
		public void selectbaseplan(String baseplantext) {
			 Web.selectDropDownOption(baseplan, baseplantext);
		}
		
		
		
		public void StatutoryCompany(String StatutoryCompanyentry) throws InterruptedException
		{
			
			Thread.sleep(10000);
	        Web.selectDropDownOption(StatutoryCompcode, StatutoryCompanyentry);
			
		}
		
		
		public void LineofBusiness(String lineofbusinesstext) {
			
			 Web.selectDropDownOption(LineofBusiness, lineofbusinesstext);
			 
		}
		
		public void cashcheckbox() {
			CashCeckbox.click();

			//web.w
			//.Web.clickOnElement(arg0)
			Reporter.logEvent(Status.INFO,"cashcheckbox: ","Clicked",false);
		}
		
		public void addraidercheckbox() {
			Web.clickOnElement(AddRaiderCheckbox);
		}
		
		public void addraiderbutton() {
			Web.clickOnElement(HCC_RaiderTypeAdd_BT);
		}
		
		public void HCC_Raiderplanselect(String drpvalue) {
			Web.selectDropDownOption(HCC_RaiderPlan_LB, drpvalue);
		}
		
		
		
		
		
		
		
		
		
		public void Residentstate(String Residentstatestring) {
			 Web.selectDropDownOption(residentstate, Residentstatestring);
			 
		}
		
		public void setLastname(String Lname) {
			 Web.setTextToTextBox(lastname, Lname);
			 lib.Reporter.logEvent(Status.PASS, "set Lastname",Lname,false);
			
		}
		
		public void AdvisorSearch() {
			 Web.clickOnElement(AdvisorSearch);
			 lib.Reporter.logEvent(Status.PASS, "AdvisorSearch", "Search",false);
			
		}
		
		public void ClickNext() {
			 Web.clickOnElement(NextButton);
			//NextButton.click();
		}
		
		public void switchtowindow(String Casestring) {
			//SelectRowPartySearch
			Common.switchwindow(Casestring, SelectRowPartySearch);
			Common.switchwindow(Casestring, OKButton);
			lib.Reporter.logEvent(Status.PASS, "switch to new window", "new window opened",false);
			
			
		}
		
		public void selectpartysearch() {
			Web.clickOnElement(SelectRowPartySearch);
		}
		public void selectpartyOKButton() {
			Web.clickOnElement(OKButton);
		}
		
	//=========================================================================================
		
		public void selectRoleType(String roletype) {
			 Web.selectDropDownOption(RoleType, roletype);
		}
			
		public void setProfile(String profile) {
			 Web.setTextToTextBox(Profile, profile);
			 lib.Reporter.logEvent(Status.PASS, "set profile", profile,false);
		}
		
		public void FirstYrPercentage(String Firstyrpercent) {
			 Web.setTextToTextBox(FirstYrPercentage, Firstyrpercent);	
			 lib.Reporter.logEvent(Status.PASS, "set FirstYrPercentage", Firstyrpercent,false);
		}
		
		public void AnnuityFirstName(String anuityfname) {
			 Web.setTextToTextBox(AnnuityFirstName, anuityfname);		
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityFirstName", anuityfname,false);
		}
		
		public void AnnuityLastName(String anuitylname) {
			 Web.setTextToTextBox(AnnuityLastName, anuitylname);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityLastName", anuitylname,false);
		}
		
		public void AnnuityDOB(String AnnuityDOBtx) {
			 Web.setTextToTextBox(AnnuityDOB, AnnuityDOBtx);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityDOB", AnnuityDOBtx,false);
		}
		
		public void AnnuityGender(String Anuitygendr) {
			 Web.selectDropDownOption(AnnuityGender, Anuitygendr);
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityGender", Anuitygendr,false);
		}
		
		public void AnuityAddress(String anuityaddres) {
			 Web.setTextToTextBox(Address, anuityaddres);	
			 lib.Reporter.logEvent(Status.PASS, "set anuityaddres", anuityaddres,false);
		}
		
		public void AnnuityCity(String anuitCity) {
			 Web.setTextToTextBox(AnnuityCity, anuitCity);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityCity", anuitCity,false);
		}
		
		
		public void AnnuitySSN(String SSN) {
			String SSNnum = Common.generateSSN();
			
			Web.setTextToTextBox(AnnuitySSN, SSNnum);		
			 lib.Reporter.logEvent(Status.PASS, "set AnnuitySSN", SSNnum,false);
		
		}
		
		
		public void AnnuityZip(String zip) {
			 Web.setTextToTextBox(AnnuityZip, zip);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityZip", zip,false);
		}
		public void AnnuityZipRemaining(String ziprem) {
			 Web.setTextToTextBox(AnnuityZipRemaining, ziprem);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityZipRemaining", ziprem,false);
		}
		
		public void AnnuityState(String state) {
			 Web.selectDropDownOption(AnnuityState, state);
			
		}
		
	
		public void RnwalPercentage(String RnwalPercent) {
			 Web.setTextToTextBox(RnwalPercentage, RnwalPercent);
			 lib.Reporter.logEvent(Status.PASS, "set RnwalPercentage", RnwalPercent,false);
		}
		
		public void CommisionAgncy(String commision) {
			 Web.setTextToTextBox(CommisionAgncy, commision);
			 lib.Reporter.logEvent(Status.PASS, "set CommisionAgncy", commision,false);
		}
		
		public void AnnuityRetAge(String retage) {
			 Web.setTextToTextBox(AnnuityRetAge, retage);	
			 lib.Reporter.logEvent(Status.PASS, "set AnnuityRetAge", retage,false);
		}
		
		public void ModelPremeium(String initpaymnt) {
			 Web.setTextToTextBox(ModelPremium, initpaymnt);
			 lib.Reporter.logEvent(Status.PASS, "set ModelPremium", initpaymnt,false);
		}
		
		public void InitialPayment(String initpaymnt) {
			 Web.setTextToTextBox(InitialPayment, initpaymnt);	
			 lib.Reporter.logEvent(Status.PASS, "set InitialPayment", initpaymnt,false);
		}
		
		public void GrowthINV(String inv) {
			 Web.setTextToTextBox(GrowthINV, inv);	
			 lib.Reporter.logEvent(Status.PASS, "set GrowthINV", inv,false);
		}
		
		
		//covered fund
		public static void entercoveredfund(String inv) {
	
			
			for (int i=1; i<CoveredFundrow.size();i++) {
				
			
				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[3]")).getText();
				
						if(str.equalsIgnoreCase("c")) {
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).click();
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]/input")).sendKeys(inv);
							
							break;
						}
			}
			
	
		}
		
		public void Paymenttype() {
			 Web.clickOnElement(Paymenttype);
			
		}
		
		
		public void MemoCode(String memo) {
			 Web.selectDropDownOption(MemoCode, memo);
		}
		
		
		public void PaymentAmount(String payamount) {
			 Web.setTextToTextBox(PaymentAmount, payamount);
			 lib.Reporter.logEvent(Status.PASS, "set PaymentAmount", payamount,false);
		}
		
		public void AllocationType(String alloctype) {
			 Web.selectDropDownOption(AllocationType, alloctype);
		}
		
		public void AllocationFormulaOveride(String allocoveride) {
			 Web.selectDropDownOption(AllocationFormulaOveride, allocoveride);
		}
		
		public void RealtimeDrpDwn(String selectrealtime) {
			 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
			 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
		}
		
		public void FinishButton() {
			 Web.clickOnElement(FinishButton);
			 lib.Reporter.logEvent(Status.PASS, "Click on FinishButton", "FinishButton Clicked",false);
			
		}
		
		public void VerifyErrorText(String expectedtext) {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		
		public void getpolicynumber() {
			if (!(Policynumber.getText().equalsIgnoreCase(""))) {
				
			
			lib.Reporter
			.logEvent(
					Status.PASS,
					"Contract Add Policy Number: ",
					Policynumber.getText(),
					true);
			}
			else
			{
				lib.Reporter
				.logEvent(
						Status.FAIL,
						"No Contract Add Policy Number Displayed: ",
						Policynumber.getText(),
						true);
			}
			
		}
		
		
		
		
			

		
		
		
		
		
		
		
		
		
	
		
	//=========================================================================================
		
		@Override
		protected void isLoaded() throws Error {
			// TODO Auto-generated method stub
			Assert.assertTrue(Web.isWebElementDisplayed(ContractAddLink),"Login Page is Not Loaded\n");
			
			
		}

}
