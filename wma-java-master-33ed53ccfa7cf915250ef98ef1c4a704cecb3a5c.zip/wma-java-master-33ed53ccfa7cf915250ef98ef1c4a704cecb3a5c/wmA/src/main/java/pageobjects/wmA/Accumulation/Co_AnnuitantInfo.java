package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class Co_AnnuitantInfo extends LoadableComponent<Co_AnnuitantInfo>{
	
   @FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataFirstName']")
	private  WebElement Co_AnnuitantInfo_Firstname;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataLastName']")
	private  WebElement Co_AnnuitantInfo_Lastname;
	
	@FindBy(xpath="//input[@id='mainform:coAnnsearch']")
	private  WebElement Co_AnnuitantInfo_PartySearch;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoAnnDataSexCode']")
	private  WebElement Co_AnnuitantInfo_Gender;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataBirthdate_input']")
	private  WebElement Co_AnnuitantInfo_DOB;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataAddressLine1']")
	private  WebElement Co_AnnuitantInfo_Residentaddress;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataCity']")
	private  WebElement Co_AnnuitantInfo_City;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoAnnDataState']")
	private  WebElement Co_AnnuitantInfo_state;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryCoAnnDataCountryCode']")
	private  WebElement Co_AnnuitantInfo_Country;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryCoAnnDataZipPostalCode']")
	private  WebElement Co_AnnuitantInfo_Zipcode;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryContractEntryCoAnnDataTaxIdNumber")
	private static WebElement taxid_TB;
	
	
	public void CoAnnuitantInfoDeatils(String Gentype,String DOB,String city,String state) {
		Web.waitForElement(Co_AnnuitantInfo_Firstname);	
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(Co_AnnuitantInfo_Firstname, Fnames);
		if(Co_AnnuitantInfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_Annuitant Info page Enter the payer First name", "TheCo_Annuitant First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_Annuitant Info page Enter the payer First name", "The Co_Annuitant First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(Co_AnnuitantInfo_Lastname);	
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(Co_AnnuitantInfo_Lastname, Lnames);
		if(Co_AnnuitantInfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the payer Last name", "The Co_Annuitant Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the owner Last name", "The Co_Annuitant  Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(Co_AnnuitantInfo_Gender);
		Web.selectDropDownOption(Co_AnnuitantInfo_Gender, Gentype);
		Web.waitForElement(taxid_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(taxid_TB, ssn);
		Web.waitForElement(Co_AnnuitantInfo_DOB);		
		Web.setTextToTextBox(Co_AnnuitantInfo_DOB, DOB);
		if(Co_AnnuitantInfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the DOB", "The Co_Annuitant DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the  DOB", "The Co_Annuitant DOB is ["+ DOB+"] entered Successfully", true);
		}
		Web.waitForElement(Co_AnnuitantInfo_Residentaddress);	
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(Co_AnnuitantInfo_Residentaddress, address);
		if(Co_AnnuitantInfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the address", "The Co_Annuitant address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the address", "The Co_Annuitant address is ["+ address+"] entered Successfully", true);
		}
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(Co_AnnuitantInfo_City);
				 Web.setTextToTextBox(Co_AnnuitantInfo_City, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(Co_AnnuitantInfo_City);
				Web.setTextToTextBox(Co_AnnuitantInfo_City, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(Co_AnnuitantInfo_City);
				 Web.setTextToTextBox(Co_AnnuitantInfo_City, city);
			}
			Web.waitForElement(Co_AnnuitantInfo_Zipcode);	
			String Zip = Common.AutoZipcode();
			Web.setTextToTextBox(Co_AnnuitantInfo_Zipcode, Zip);			
			if(Co_AnnuitantInfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the Zipcode", "The Co_Annuitant Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the Zipcode", "The Co_Annuitant Zipcode is ["+ Zip+"] entered Successfully", true);
			}
			
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(Co_AnnuitantInfo_state);
				 Web.selectDropDownOption(Co_AnnuitantInfo_state, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(Co_AnnuitantInfo_state);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(Co_AnnuitantInfo_state, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(Co_AnnuitantInfo_state);
				 Web.selectDropDownOption(Co_AnnuitantInfo_state, state);
			}
	}
	
	public void EnterCo_AnnuitantInfoFirstname(String Fnames) {
		Web.waitForElement(Co_AnnuitantInfo_Firstname);		
		Web.setTextToTextBox(Co_AnnuitantInfo_Firstname, Fnames);
		if(Co_AnnuitantInfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_Annuitant Info page Enter the payer First name", "TheCo_Annuitant First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_Annuitant Info page Enter the payer First name", "The Co_Annuitant First name is ["+ Fnames+"] entered Successfully", true);
		}
	}

	
	public void EnterCo_AnnuitantInfoLastname(String Lnames) {
		Web.waitForElement(Co_AnnuitantInfo_Lastname);		
		Web.setTextToTextBox(Co_AnnuitantInfo_Lastname, Lnames);
		if(Co_AnnuitantInfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the payer Last name", "The Co_Annuitant Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the owner Last name", "The Co_Annuitant  Last name is ["+ Lnames+"] entered Successfully", true);
		}
	}
	
	public void SelectCo_AnnuitantInfoGender(String Gentype)
	
	{
		Web.waitForElement(Co_AnnuitantInfo_Gender);
		Web.selectDropDownOption(Co_AnnuitantInfo_Gender, Gentype);
	}
	
	public void EnterCo_AnnuitantInfoDOB(String DOB) {
		Web.waitForElement(Co_AnnuitantInfo_DOB);		
		Web.setTextToTextBox(Co_AnnuitantInfo_DOB, DOB);
		if(Co_AnnuitantInfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the DOB", "The Co_Annuitant DOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the  DOB", "The Co_Annuitant DOB is ["+ DOB+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_AnnuitantInfoaddress(String address) {
		Web.waitForElement(Co_AnnuitantInfo_Residentaddress);		
		Web.setTextToTextBox(Co_AnnuitantInfo_Residentaddress, address);
		if(Co_AnnuitantInfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the address", "The Co_Annuitant address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the address", "The Co_Annuitant address is ["+ address+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_AnnuitantInfocity(String city) {
		Web.waitForElement(Co_AnnuitantInfo_City);		
		Web.setTextToTextBox(Co_AnnuitantInfo_City, city);
		if(Co_AnnuitantInfo_City.getAttribute("value").equalsIgnoreCase(city)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the city", "The  Co_Annuitant city is ["+ city+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the city", "The Co_Annuitant city is ["+ city+"] entered Successfully", true);
		}
	}
	
	
	public void EnterCo_AnnuitantInfozip(String Zip) {
		Web.waitForElement(Co_AnnuitantInfo_Zipcode);		
		Web.setTextToTextBox(Co_AnnuitantInfo_Zipcode, Zip);
		if(Co_AnnuitantInfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Co_AnnuitantInfo page Enter the Zipcode", "The Co_Annuitant Zipcode is ["+ Zip+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Co_AnnuitantInfo page Enter the Zipcode", "The Co_Annuitant Zipcode is ["+ Zip+"] entered Successfully", true);
		}
	}
	
public void SelectCo_AnnuitantInfoState(String state)
	
	{
		Web.waitForElement(Co_AnnuitantInfo_state);
		Web.selectDropDownOption(Co_AnnuitantInfo_state, state);
	}

public void SelectCo_AnnuitantInfoCountry(String country)

{
	Web.waitForElement(Co_AnnuitantInfo_Country);
	Web.selectDropDownOption(Co_AnnuitantInfo_Country, country	);
}
	
	public Co_AnnuitantInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Co_AnnuitantInfo_Firstname);
		Assert.assertTrue(Web.isWebElementDisplayed(Co_AnnuitantInfo_Firstname),"Co_AnnuitantInfo Page is Not Loaded\n");
	
	}

}

	
	





