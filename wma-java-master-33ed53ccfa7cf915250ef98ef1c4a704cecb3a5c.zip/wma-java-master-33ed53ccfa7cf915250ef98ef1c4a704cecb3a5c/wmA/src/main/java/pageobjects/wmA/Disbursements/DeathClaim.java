package pageobjects.wmA.Disbursements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class DeathClaim extends LoadableComponent<DeathClaim>{
	
	@FindBy(partialLinkText ="Disbursements")
	private static WebElement Disbursement;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Death Claim')]")
	private static WebElement deathclaim;
	
	@FindBy(id ="mainform:deathClaimEffectiveDate_input")
	private static WebElement Deffecdate;
	
	@FindBy(id = "mainform:deathClaimDateOfDeath_input")
	private static WebElement deathdate;
	
	@FindBy(id ="mainform:deathClaimCauseCode")
	private static WebElement deathcause;
	
	@FindBy(id="mainform:deathClaimSourceCode")
	private static WebElement Dsource;
	
	@FindBy(id = "mainform:add")
	private static WebElement payeeadd;
	
	@FindBy(id = "mainform:deathClaimPayeeAreaPercentOfBenefit")
	private static WebElement Payeeper;
	
	@FindBy(id="mainform:deathClaimPayeeAreaPayeeResidentState")
	private static WebElement Payeestate;
	
	@FindBy(id ="mainform:payeeadd")
	private static WebElement Partyadd;
	
	@FindBy(id="mainform:clientAddEffectiveDate_input")
	private static WebElement pereffecdate;
	
	@FindBy(id="mainform:clientAddFirstName")
	private static WebElement firstname;
	
	@FindBy(id="mainform:clientAddLastName")
	private static WebElement lastename;
	
	@FindBy(id="mainform:clientAddAddress1")
	private static WebElement adress;
	
	@FindBy(id="mainform:clientAddCity")
	private static WebElement City;
	
	@FindBy(id="mainform:clientAddState")
	private static WebElement pstate;
	
	@FindBy(id="mainform:clientAddZipPostalCode")
	private static WebElement pzip;
	
	@FindBy(id="mainform:clientAddZipPostalCode4")
	private static WebElement przip;
	
	@FindBy(id="submitbutton")
	private static WebElement sub;
	
	@FindBy(id="mainform:update")
	private static WebElement updatebtn;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id="mainform:searchButton")
	private static WebElement searhbtn;
	
	@FindBy(id="mainform:payeesearch")
	private static WebElement partysearc;
	
	@FindBy(id="cancelbutton")
	private static WebElement cancel;
	
	@FindBy(id="mainform:deathClaimPayeeAreaPayeeSpousalType")
	private WebElement SpousalType_LB;
	
	@FindBy(id="mainform:deathClaimPayeeAreaPayeeContractInd")
	private WebElement Creatpolicy_LB;
	
	@FindBy(id="mainform:deathClaimPayeeAreaPayeePaymentInd")
	private WebElement Creatpayment_LB;
	
	@FindBy(id="mainform:deathClaimPayeeAreaPayeeDisbursementInd")
	private WebElement Disbursement_LB;
	
	@FindBy(id="mainform:clientAddClientBirthDate_input")
	private static WebElement PartyaddDOB_TB;
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
		 
		 if (fieldName.trim().equalsIgnoreCase("Create_Policy")) {
				return this.Creatpolicy_LB;
			}
		 
		 if (fieldName.trim().equalsIgnoreCase("Create_Payment")) {
				return this.Creatpayment_LB;
			}
		 
		 if (fieldName.trim().equalsIgnoreCase("Spousal_Type")) {
				return this.SpousalType_LB;
			}
		 
		 if (fieldName.trim().equalsIgnoreCase("Disbursement")) {
				return this.Disbursement_LB;
			}
		 
		 Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	public void SelectDisbursement (String Disbursement) {
		String Disburse=null;
		if(System.getProperty("Disbursement")==null)
		{
			Web.waitForElement(Disbursement_LB);
			Web.selectDropDownOption(Disbursement_LB, Disbursement);
		}
		else if(System.getProperty("Disbursement").trim().length() > 0)
		{
			if (System.getProperty("Disbursement").toLowerCase().trim().contains("bene"))
			{
				Disburse="B";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("cash"))
			{
				Disburse="C";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("issue"))
			{
				Disburse="D";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("eft"))
			{
				Disburse="E";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("life"))
			{
				Disburse="P";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("sus"))
			{
				Disburse="S";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("spo"))
			{
				Disburse="T";
			}
			else if (System.getProperty("Disbursement").toLowerCase().trim().contains("unde"))
			{
				Disburse="U";
			}
			else
			{
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the correct ", "causeof death "+Disburse, true);
				 return;
			}
			Web.waitForElement(Disbursement_LB);
			Common.selectbyvalues(Disbursement_LB, Disburse);
							
		}else {
			Web.waitForElement(Disbursement_LB);
			Web.selectDropDownOption(Disbursement_LB, Disbursement);
		}
	}
	 
	 
	public void CreatePolicy(String policy) {
		String Policycreation=null;
		if(System.getProperty("CreatePolicy_Payment")==null)
		{
			Web.waitForElement(Creatpolicy_LB);
			Web.selectDropDownOption(Creatpolicy_LB, policy);
		}
		else if(System.getProperty("CreatePolicy_Payment").trim().length() > 0)
		{
			if (System.getProperty("CreatePolicy_Payment").toLowerCase().trim().contains("yes"))
			{
				Policycreation="Y";
			}
			else if (System.getProperty("CreatePolicy_Payment").toLowerCase().trim().contains("no"))
			{
				Policycreation="N";
			}	
			else
			{
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the correct ", "Policy Creation selection "+Policycreation, true);
				 return;
			}
			Web.waitForElement(Creatpolicy_LB);
			Common.selectbyvalues(Creatpolicy_LB, Policycreation);
							
		}else {
			Web.waitForElement(Creatpolicy_LB);
			Web.selectDropDownOption(Creatpolicy_LB, policy);
		}
	
	}
	
	public void CreatePayemnt(String policy) {
		String Policycreation=null;
		if(System.getProperty("CreatePolicy_Payment")==null)
		{
			Web.waitForElement(Creatpayment_LB);
			Web.selectDropDownOption(Creatpayment_LB, policy);
		}
		else if(System.getProperty("CreatePolicy_Payment").trim().length() > 0)
		{
			if (System.getProperty("CreatePolicy_Payment").toLowerCase().trim().contains("yes"))
			{
				Policycreation="Y";
			}
			else if (System.getProperty("CreatePolicy_Payment").toLowerCase().trim().contains("no"))
			{
				Policycreation="N";
			}	
			else
			{
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the correct ", "Policy Creation selection "+Policycreation, true);
				 return;
			}
			Web.waitForElement(Creatpayment_LB);
			Common.selectbyvalues(Creatpayment_LB, Policycreation);
							
		}else {
			Web.waitForElement(Creatpayment_LB);
			Web.selectDropDownOption(Creatpayment_LB, policy);
		}
	
	}
	
	public void ClickOnCancelButton() {
		Web.waitForElement(cancel);
		Web.clickOnElement(cancel);
	}
	
	public void ClickOnPartySearch() {
		Web.waitForElement(partysearc);
		Web.clickOnElement(partysearc);
	}
	
	public void ClickOnSearchButton() {
		Web.clickOnElement(searhbtn);
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
	}
	
	public void clickhomebutton () {
		Web.clickOnElement(homebutton);
	}
	
	public void RealtimeDrpDwn(String selectrealtime) {
		Web.waitForElement(RealtimeDrpDwn);
		Web.waitForElement(RealtimeDrpDwn);
		 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
		 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
	}
	
   public void clicksumbmit() {
	   Web.waitForElement(submit);
   	Web.clickOnElement(submit);
   }
   
	public void VerifyErrorText(String expectedtext) {
		Web.waitForElement(ErrorText);	
		String Expected = Stock.GetParameterValue("ErrorText");
		String Actual = ErrorText.getText();		
		Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
		Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
	}
		
	
	public void ClickUpdatePayee() {
		Web.waitForElement(updatebtn);
		Web.clickOnElement(updatebtn);
	}
	public void ClickOkbutton (String CaseString) {
		Web.waitForElement(sub);
		Web.clickOnElement(sub);
	
	}
	
	public void Enterpayeeremmaingzip(String rzip) {
		Web.waitForElement(przip);
		Web.setTextToTextBox(przip, rzip);
	}
	
	public void Enterpayeezipcode() {
		Web.waitForElement(pzip);
		 String zip1 = Common.AutoZipcode();
		Web.setTextToTextBox(pzip, zip1);
		if(pzip.getAttribute("value").equalsIgnoreCase(zip1)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Zip Code", "the Zip Code is["+zip1+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Zip Code", "the Zip Code is["+zip1+"] not entered sucessfully", true);
		 }
	}
	
	public void SelectPayeeState(String state) {
		Web.waitForElement(pstate);
		Web.selectDropDownOption(pstate, state);
	}
	
	public void EnterPayeeCity(String pcity) {
		Web.waitForElement(City);
		Web.setTextToTextBox(City, pcity);
	}
	
	public void EnterPayeeAddressline1() {
		Web.waitForElement(adress);
		String Adress= Common.AddressGenerator();
		Web.setTextToTextBox(adress, Adress);
		if(adress.getAttribute("value").equalsIgnoreCase(Adress)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Address", "the Address is["+Adress+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Address", "the Address is["+Adress+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterPayeeLastName() {
		Web.waitForElement(lastename);		
		String lastname =  Common.randomvaildLastname();
		Web.setTextToTextBox(lastename, lastname);
		if(lastename.getAttribute("value").equalsIgnoreCase(lastname)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Last Name", "the Last Name is["+lastname+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Last Name", "the Last Name is["+lastname+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterPayeeFirstName()  {
		Web.waitForElement(firstname);
		String firstname1 = Common.randomvaildFirstname();
		Web.setTextToTextBox(firstname, firstname1);
		 if(firstname.getAttribute("value").equalsIgnoreCase(firstname1)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Payee First Name", "the Payee First Name is["+firstname1+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Payee First Name", "the Payee First Name is["+firstname1+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterPersonalDOB(String dob) {
		Web.waitForElement(PartyaddDOB_TB);
		Web.setTextToTextBox(PartyaddDOB_TB, dob);		
		 if(PartyaddDOB_TB.getAttribute("value").equalsIgnoreCase(dob)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the date of birth", "the date of birth is["+dob+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the date of birth", "the date of birth is["+dob+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterbeneficiaryDetails(String Effdate,String dob,String pcity,String state) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(pereffecdate);
			Web.setTextToTextBox(pereffecdate, Effdate);		
			 if(pereffecdate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(pereffecdate);
			Web.setTextToTextBox(pereffecdate, System.getProperty("TrxEffectiveDate").trim());		
			 if(pereffecdate.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate").trim())) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] not entered sucessfully", true);
			 }
							
		}else {
			Web.waitForElement(pereffecdate);
			Web.setTextToTextBox(pereffecdate, Effdate);		
			 if(pereffecdate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
		
		 if(System.getProperty("Dateofbirth")==null)
			{
				Web.waitForElement(PartyaddDOB_TB);
				Web.setTextToTextBox(PartyaddDOB_TB, dob);	
			}
			else if( System.getProperty("Dateofbirth").trim().length() > 0)
			{
				Web.waitForElement(PartyaddDOB_TB);
				Web.setTextToTextBox(PartyaddDOB_TB, System.getProperty("Dateofbirth").trim());			
									
			}else {
				Web.waitForElement(PartyaddDOB_TB);
				Web.setTextToTextBox(PartyaddDOB_TB, dob);	
			}
		 Web.waitForElement(firstname);
			String firstname1 = Common.randomvaildFirstname();
			Web.setTextToTextBox(firstname, firstname1);
			 if(firstname.getAttribute("value").equalsIgnoreCase(firstname1)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Payee First Name", "the Payee First Name is["+firstname1+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Payee First Name", "the Payee First Name is["+firstname1+"] not entered sucessfully", true);
			 }
			 
			 Web.waitForElement(lastename);		
				String lastname =  Common.randomvaildLastname();
				Web.setTextToTextBox(lastename, lastname);
				if(lastename.getAttribute("value").equalsIgnoreCase(lastname)) {
					 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Last Name", "the Last Name is["+lastname+"] entered sucessfully", false); 
				 }
				 else {
					 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Last Name", "the Last Name is["+lastname+"] not entered sucessfully", true);
				 }
				
				Web.waitForElement(adress);
				String Adress= Common.AddressGenerator();
				Web.setTextToTextBox(adress, Adress);
				if(adress.getAttribute("value").equalsIgnoreCase(Adress)) {
					 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Address", "the Address is["+Adress+"] entered sucessfully", false); 
				 }
				 else {
					 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Address", "the Address is["+Adress+"] not entered sucessfully", true);
				 }
			
				 if(System.getProperty("City")==null)
					{
					 Web.waitForElement(City);
						Web.setTextToTextBox(City, pcity);
					}
					else if( System.getProperty("City").trim().length() > 0)
					{
						Web.waitForElement(City);
						Web.setTextToTextBox(City, System.getProperty("City").trim());				
											
					}else {
						Web.waitForElement(City);
						Web.setTextToTextBox(City, pcity);
					}
				 
					if(System.getProperty("IssueState")==null)
					{
						Web.waitForElement(pstate);
						Web.selectDropDownOption(pstate, state);
					}
					else if( System.getProperty("IssueState").trim().length() > 0)
					{
						Web.waitForElement(pstate);
						Common.selectbyvalues(pstate, System.getProperty("IssueState").trim());															
					}else {
						Web.waitForElement(pstate);
						Web.selectDropDownOption(pstate, state);
					}
					
					Web.waitForElement(pzip);
					 String zip1 = Common.AutoZipcode();
					Web.setTextToTextBox(pzip, zip1);
					if(pzip.getAttribute("value").equalsIgnoreCase(zip1)) {
						 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Zip Code", "the Zip Code is["+zip1+"] entered sucessfully", false); 
					 }
					 else {
						 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Zip Code", "the Zip Code is["+zip1+"] not entered sucessfully", true);
					 }
					
					Web.waitForElement(sub);
					Web.clickOnElement(sub);
				
	}
	
	public void EnterPersonalEffectiveDate (String Effdate) {
		Web.waitForElement(pereffecdate);
		Web.setTextToTextBox(pereffecdate, Effdate);		
		 if(pereffecdate.getAttribute("value").equalsIgnoreCase(Effdate)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
		 }
	}
	
	public void ClickonPayeePartyadd() {
		Web.waitForElement(Partyadd);
		Web.clickOnElement(Partyadd);
	}
	
	public void SelectPayeeResState(String state) {
		if(System.getProperty("IssueState")==null)
		{
			Web.waitForElement(Payeestate);
			Web.selectDropDownOption(Payeestate, state);
		}
		else if( System.getProperty("IssueState").trim().length() > 0)
		{
			Web.waitForElement(Payeestate);
			Common.selectbyvalues(Payeestate, System.getProperty("IssueState").trim());															
		}else {
			Web.waitForElement(Payeestate);
			Web.selectDropDownOption(Payeestate, state);
		}
		
	}
	
	
	
	public void EnterPayeePercentage(String Payeeamount) {
		
		
		
		Web.waitForElement(Payeeper);
		Web.setTextToTextBox(Payeeper, Payeeamount);
		if(Payeeper.getAttribute("value").equalsIgnoreCase(Payeeamount)) {
			 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Payee Percentage", "the Payee Percentage is["+Payeeamount+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Payee Percentage", "the Payee Percentage is["+Payeeamount+"] not entered sucessfully", true);
		 }
	}
	
	public void ClickOnAddbutton() {
		Web.waitForElement(payeeadd);
		Web.clickOnElement(payeeadd);
	}
	
	public void SelectDSourceCode(String Desource) {
		Web.waitForElement(Dsource);
		Web.selectDropDownOption(Dsource, Desource);
	}
	
	
	public void SelectDeathCause(String DCause) {
		String deathcausevar=null;
		if(System.getProperty("DeathCause")==null)
		{
			Web.waitForElement(deathcause);
			Web.selectDropDownOption(deathcause, DCause);
		}
		else if( System.getProperty("DeathCause").trim().length() > 0)
		{
			Web.waitForElement(deathcause);
			if (System.getProperty("DeathCause").toLowerCase().trim().contains("cancer"))
			{
				deathcausevar="CA";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("homicide"))
			{
				deathcausevar="HO";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("illness"))
			{
				deathcausevar="IL";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("natural"))
			{
				deathcausevar="NT";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("suicide"))
			{
				deathcausevar="SU";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("accident"))
			{
				deathcausevar="AC";
			}
			else if (System.getProperty("DeathCause").toLowerCase().trim().contains("unknown"))
			{
				deathcausevar="AI";
			}
			else
			{
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the correct ", "causeof death "+deathcausevar, true);
				 return;
			}
			
			Common.selectbyvalues(deathcause, deathcausevar);															
		}else {
			Web.waitForElement(deathcause);
			Web.selectDropDownOption(deathcause, DCause);
		}
		
	}
	
	public void EnterDeathDate(String Ddate) {
		Web.waitForElement(deathdate);
		if(System.getProperty("DateOfDeath")==null)
		{
			Web.waitForElement(deathdate);
			Web.setTextToTextBox(deathdate, Ddate);
			if(deathdate.getAttribute("value").equalsIgnoreCase(Ddate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Date of death", "the Date of death is["+Ddate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Date of death", "the Date of death is["+Ddate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("DateOfDeath").trim().length() > 0)
		{
			Web.waitForElement(deathdate);
			Web.setTextToTextBox(deathdate, System.getProperty("DateOfDeath"));
			if(deathdate.getAttribute("value").equalsIgnoreCase(System.getProperty("DateOfDeath"))) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Date of death", "the Date of death is["+System.getProperty("DateOfDeath")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Date of death", "the Date of death is["+System.getProperty("DateOfDeath")+"] not entered sucessfully", true);
			 }	
								
		}else {
			Web.waitForElement(deathdate);
			Web.setTextToTextBox(deathdate, Ddate);
			if(deathdate.getAttribute("value").equalsIgnoreCase(Ddate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Date of death", "the Date of death is["+Ddate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Date of death", "the Date of death is["+Ddate+"] not entered sucessfully", true);
			 }
		}
	
	}
	
	public void EnterEffectiveDate(String Effdate) {
		
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(pereffecdate);
			Web.setTextToTextBox(pereffecdate, Effdate);		
			 if(pereffecdate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Deffecdate);
			Web.setTextToTextBox(Deffecdate, System.getProperty("TrxEffectiveDate").trim());		
			 if(Deffecdate.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate").trim())) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate").trim()+"] not entered sucessfully", true);
			 }
							
		}else {
			Web.waitForElement(Deffecdate);
			Web.setTextToTextBox(Deffecdate, Effdate);		
			 if(Deffecdate.getAttribute("value").equalsIgnoreCase(Effdate)) {
				 Reporter.logEvent(Status.PASS, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Death Claim page enter the Effective date", "the Effective date is["+Effdate+"] not entered sucessfully", true);
			 }
		}
	
	}
	
	public void clickondeathclaim () {
		Web.waitForElement(deathclaim);
		Common.ClickSubmenu(deathclaim);
	}
	
	public DeathClaim (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Deffecdate);
		Assert.assertTrue(Web.isWebElementDisplayed(Deffecdate),"Login Page is Not Loaded\n");
	}

}
