package pageobjects.wmA.Disbursements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class UpdateSystematicWithdrawal extends LoadableComponent<UpdateSystematicWithdrawal>{
	
	@FindBy(partialLinkText ="Disbursements")
	private static WebElement Disbursement;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	@FindBy(id ="mainform:clientRequestMasterId")
	private static WebElement contractsearch;
	
	@FindBy(id ="mainform:searchButton")
	private static WebElement searchbutton;
	
	@FindBy (id = "mainform:update")
	private static WebElement Update;
	
	@FindBy(id = "Payouts_0")
	private static WebElement rowselect;
	
	@FindBy(id="mainform:systematicWithdrawalInquiryChangeEffectiveDate_input")
	private static WebElement updateeffdate;
	
	@FindBy(id = "mainform:systematicWithdrawalInquiryChangeSystematicWithdrawalInquiryChangeTrxSegmentCurrentNextPayoutDate_input")
	private static WebElement updatestartdate;
	
	@FindBy(id = "mainform:systematicWithdrawalInquiryChangeSystematicWithdrawalInquiryChangeTrxSegmentCurrentPayoutMode")
	private static WebElement updatemode;
	
	@FindBy (id="realtimeselect")
	private static WebElement RealtimeDrpDwn;
	
	@FindBy (id = "submitbutton")
	private static WebElement submit;
	
	@FindBy (id="errorMessages")
	private static WebElement ErrorText;
	
	@FindBy(id="contract")
	private static WebElement general;
	
	//@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Systematic Withdrawal')]")
	//private static WebElement syswithdrawal;
	
	@FindBy(xpath = ".//*[@id='disbursements']/a")
	private static WebElement syswithdrawal;
	
	@FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr[1]/td[4]/span")
	private static WebElement FundallocationTB;
	
	
	public void clickhomebutton () {
		Web.waitForElement(homebutton);
		Web.clickOnElement(homebutton);
	}
	
	public void entercontractid (String contractid) {
		Web.waitForElement(contractsearch);
		Web.setTextToTextBox(contractsearch, contractid);
	}
	
	public void clicksearchbutton() {
		Web.waitForElement(searchbutton);
		Web.clickOnElement(searchbutton);
	}
	
	public void clicksystematicwithdrawal () {
		Web.waitForElement(syswithdrawal);
		Common.ClickSubmenu(syswithdrawal);
	}
	
	   public void clickupdatebutton() {
		   Web.waitForElement(Update);
		   Web.clickOnElement(Update);
	   }
	   
	   public void selectrow1() {
		   Web.waitForElement(rowselect);
		   Web.clickOnElement(rowselect);
	   }
	   
	   public void updateeffectivedate (String updaeffdate) {
		   Web.waitForElement(updateeffdate);
		   Web.setTextToTextBox(updateeffdate, updaeffdate);
		   if(updateeffdate.getAttribute("value").equalsIgnoreCase(updaeffdate)) {
				 Reporter.logEvent(Status.PASS, "In Update Systematic Withdrawal information page enter the Effective date", "the Effective date is["+updaeffdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Update Systematic Withdrawal information page enter the Effective date", "the Effective date is["+updaeffdate+"] not entered sucessfully", true);
			 }
	   }
	   
	   public void UpdateStartDate(String startdate) {
		//   Web.clickOnElement(updatestartdate);
		//   Web.waitForElement(updatestartdate);
		   Web.setTextToTextBox(updatestartdate, startdate);
		   try
		   {
			   Thread.sleep(15000);
		   }
		   catch(Exception e)
		   {
			   System.out.println("exception "+ e);
			   
		   }
		   Web.waitForElement(updatestartdate);
		   Web.setTextToTextBox(updatestartdate, startdate);
	//	   Web.waitForElement(FundallocationTB);
	//	   Web.setTextToTextBox(updatestartdate, startdate);
		   if(updatestartdate.getAttribute("value").equalsIgnoreCase(startdate)) {
				 Reporter.logEvent(Status.PASS, "In Update Systematic Withdrawal information page enter the Start date", "the Start date is["+startdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In udapte Systematic Withdrawal information page enter the Start date", "the Start date is["+startdate+"] not entered sucessfully", true);
			 }
	   }
	   
	   public void updatemodeoption (String modeup) {
		   Web.waitForElement(updatemode);
		   Web.selectDropDownOption(updatemode, modeup);
	   }
	   
		public void RealtimeDrpDwn(String selectrealtime) {
			Web.waitForElement(RealtimeDrpDwn);
			 Web.selectDropDownOption(RealtimeDrpDwn, selectrealtime);
			 lib.Reporter.logEvent(Status.PASS, "select RealtimeDrpDwn", selectrealtime,false);
		}
	   
	   public void clicksumbmit() {
		   Web.waitForElement(submit);
	   	Web.clickOnElement(submit);
	   }
	   
	  
	   
		public void VerifyErrorText(String expectedtext) {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}

		
	public UpdateSystematicWithdrawal (LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
		}
		
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Disbursement);
		Assert.assertTrue(Web.isWebElementDisplayed(Disbursement),"Login Page is Not Loaded\n");
	}

}
