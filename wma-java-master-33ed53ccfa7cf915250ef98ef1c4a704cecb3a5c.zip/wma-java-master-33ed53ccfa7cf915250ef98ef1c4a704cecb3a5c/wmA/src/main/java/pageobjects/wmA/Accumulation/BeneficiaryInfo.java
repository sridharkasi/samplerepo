package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Web;

public class BeneficiaryInfo extends LoadableComponent<BeneficiaryInfo> {
	
	@FindBy(id="mainform:beneficiaryAddLastName")
	private  WebElement BeneficiaryInfo_Lastname_TB;
	
	@FindBy(id="mainform:beneficiaryAddBenefType")
	private  WebElement Beneficiary_Type_LB;
	
	@FindBy(id="mainform:beneficiaryAddTaxIdNumber")
	private  WebElement Beneficiary_SSN_TB;
	
	@FindBy(id="mainform:beneficiaryAddBenefRelationship")
	private  WebElement Beneficiary_Relationship_LB;
	
	@FindBy(id="mainform:beneficiaryAddBenefPercent")
	private  WebElement Beneficiary_Percent_TB;
	
	@FindBy(id="mainform:beneficiaryAddFirstName")
	private  WebElement Beneficiary_Firstname_TB;
	
	@FindBy(id="mainform:beneficiaryAddSexCode")
	private  WebElement Beneficiary_Gender_LB;
	
	@FindBy(id="mainform:beneficiaryAddBirthdate_input")
	private  WebElement Beneficiary_DOB_TB;
	
	@FindBy(id="mainform:beneficiaryAddAddressLine1")
	private  WebElement Beneficiary_Address_TB;
	
	@FindBy(id="mainform:beneficiaryAddCity")
	private  WebElement Beneficiary_City_TB;
	
	@FindBy(id="mainform:beneficiaryAddState")
	private  WebElement Beneficiary_State_LB;
	
	@FindBy(id="mainform:beneficiaryAddZipPostalCode")
	private  WebElement Beneficiary_Zip_TB;
	
	@FindBy(id="mainform:beneficiaryAddZipPostalCode4")
	private  WebElement Beneficiary_RemaingZip_TB;
	
	@FindBy(id=".//*[@id='annEaBene1']/tbody/tr[1]/td")
	private  WebElement Beneficiary_benifiinfotab_labe;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		if (fieldName.trim().equalsIgnoreCase("BeneficiaryInfo_Gender")) {
			return this.Beneficiary_Gender_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("BeneficiaryInfo_Type")) {
			return this.Beneficiary_Type_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("BeneficiaryInfo_Relationship")) {
			return this.Beneficiary_Relationship_LB;
		}
		
		if (fieldName.trim().equalsIgnoreCase("BeneficiaryInfo_State")) {
			return this.Beneficiary_State_LB;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	
	
	public void EnterBeneficiaryZIPcode(String zip) {
		String Zip = Common.AutoZipcode();
		Web.setTextToTextBox(Beneficiary_Zip_TB, Zip);
		if(Beneficiary_Zip_TB.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Beneficiary Info page Enter the Zip code", "The Zip code is ["+ Zip+"] entered Successfully", false);
		}
		else {
			Reporter.logEvent(Status.FAIL, " In Beneficiary Info page Enter the Zip code", "The Zip code is ["+ Zip+"] entered Successfully", true);
		}
	}

	public void EnterBeneficiaryCity(String city) {
		Web.setTextToTextBox(Beneficiary_City_TB, city);
		if(Beneficiary_City_TB.getAttribute("value").equalsIgnoreCase(city)) {
			 Reporter.logEvent(Status.PASS, "In Beneficiary Info page Enter the City", "The city is["+ city+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Beneficiary Info page Enter the City", "The city is["+ city+"] entered Successfully", true);
		}
	}
	
	public void Enter1stAddress(String Address) {
		String Address1 = Common.AddressGenerator();
		Web.setTextToTextBox(Beneficiary_Address_TB, Address1);
		if(Beneficiary_Address_TB.getAttribute("value").equalsIgnoreCase(Address1)) {
			 Reporter.logEvent(Status.PASS, "In Beneficiary Info page Enter the Address", "The Address is["+ Address1+"] entered Successfully", false);			
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Beneficiary Info page Enter the Address", "The Address is["+ Address1+"] entered Successfully", true);
		}
	}
	
	public void EnterBeneficiaryDOB(String Dob) {
		Web.setTextToTextBox(Beneficiary_DOB_TB, Dob);
		if(Beneficiary_DOB_TB.getAttribute("value").equalsIgnoreCase(Dob)) {
			 Reporter.logEvent(Status.PASS, "In Beneficiary Info page Enter the Date of birth", "The date of birth is["+ Dob+"] entered Successfully]", false);			
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Beneficiary Info page Enter the Date of birth", "The date of birth is["+ Dob+"] entered Successfully]", true);
		}
	}

	
	public void EnterBeneficiaryFirstName(String first) throws InterruptedException {

	    Web.waitForElement(Beneficiary_Firstname_TB);
		String fname = Common.randomvaildFirstname();
		Web.setTextToTextBox(Beneficiary_Firstname_TB, fname);
		if(Beneficiary_Firstname_TB.getAttribute("value").equalsIgnoreCase(fname)) {
			 Reporter.logEvent(Status.PASS, "In Beneficiary Info page Enter the City", "The Firstname is ["+ fname+"] entered Successfully", false);			
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Beneficiary Info page Enter the City", "The Firstname is ["+ fname+"] entered Successfully", true);
		}
	}
	
	public void EnterBeneficiaryPercentage(String percent) {
	   Web.setTextToTextBox(Beneficiary_Percent_TB, percent);
	   if(Beneficiary_Percent_TB.getAttribute("value").equalsIgnoreCase(percent)) {
		   Reporter.logEvent(Status.PASS, "In Beneficiary Info page enter the Percentage", "the Percentage is ["+ percent+" entered Successfully", false);		   
	   }
	   else {
		   Reporter.logEvent(Status.FAIL, "In Beneficiary Info page enter the Percentage", "the Percentage is ["+ percent+" entered Successfully", true);
	   }
	}
	
	public void EnterBeneficiarySSN(String SSN) {
		String SSNnum = Common.generateSSN();
		Web.setTextToTextBox(Beneficiary_SSN_TB, SSNnum);
		if(Beneficiary_SSN_TB.getAttribute("value").equalsIgnoreCase(SSNnum)) {
			 Reporter.logEvent(Status.PASS, "In Beneficiary Info page Enter the SSN", "The SSN is["+ SSNnum+"] entered Successfully", false);			
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Beneficiary Info page Enter the SSN", "The SSN is["+ SSNnum+"] entered Successfully", true);
		}
	}
	

	public void Enterlastname (String Lname) {
		String LAstname = Common.randomvaildLastname();
		Web.setTextToTextBox(BeneficiaryInfo_Lastname_TB, LAstname);
		if(BeneficiaryInfo_Lastname_TB.getAttribute("value").equalsIgnoreCase(LAstname)) {
			Reporter.logEvent(Status.PASS, "In Beneficiary Info page enter the Last Name ", "The Beneficiary ["+LAstname+"] is entered Successfully", false);			
		}
		else {
			Reporter.logEvent(Status.FAIL, "In Beneficiary Info page enter the Last Name ", "The Beneficiary ["+LAstname+"] is entered Successfully", true);
		}
	}
	
	public BeneficiaryInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
		
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(BeneficiaryInfo_Lastname_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(BeneficiaryInfo_Lastname_TB),"Beneficiary Info Page is Not Loaded\n");
	
	}

}
