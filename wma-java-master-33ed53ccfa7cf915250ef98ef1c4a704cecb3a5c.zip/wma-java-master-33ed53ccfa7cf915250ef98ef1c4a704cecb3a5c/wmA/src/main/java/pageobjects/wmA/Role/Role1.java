package pageobjects.wmA.Role;



import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

//import app.wmAweb.testcases.Role.Int;
import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.General.General;

public class Role1 extends LoadableComponent<Role1> {

	@FindBy(name = "mainform:cmdAdd")
	private static WebElement Costaveraging_addbutton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;

	@FindBy(xpath = "//input[@id='mainform:beneficiaryAddEffectiveDate_input']")
	private static WebElement Effectivedate_Benificery;

	@FindBy(id = "mainform:dcaAddGcBeginDate_input")
	private static WebElement Begindate;

	@FindBy(id = "mainform:dcaAddNumberOfTransfers")
	private static WebElement NumberTransfer;

	@FindBy(xpath = "//select[@id='mainform:beneficiaryAddBenefRelationship']")
	private static WebElement BeneficieryRelation;
	
	@FindBy(xpath = "//select[@id='mainform:beneficiaryAddBenefType']")
	private static WebElement BeneficieryType;
	
	
	@FindBy(xpath = "//input[@id='mainform:beneficiaryAddBenefPercent']")
	private static WebElement BeneficieryPercent;
	
	@FindBy(xpath ="//*[@id='mainform:Roles:3:rolesRoleNameFormatted']")
    private static WebElement Rolename;

	@FindBy(id ="mainform:updateRole")
    private static WebElement Rolechange;	
	
	@FindBy(xpath = "//input[@id='mainform:addRoleCode:2']")
	private static WebElement clickonBeneficiary;
	
	
	@FindBy(id = "mainform:continueAdd")
	private static WebElement clickContinuebutton;
	
	@FindBy(xpath ="//input[@id='mainform:addRole']")
	private static WebElement AddRole;
	
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddFirstName']")
	private  WebElement Bene_FirstName;
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddLastName']")
	private  WebElement Bene_LastName;
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddBirthdate_input']")
	private  WebElement Bene_DOB;
	
	@FindBy(xpath="//select[@id='mainform:beneficiaryAddSexCode']")
	private  WebElement Bene_Gender;
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddAddressLine1']")
	private  WebElement Address;
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddCity']")
	private  WebElement BeneCity;
	
	@FindBy(xpath="//input[@id='mainform:beneficiaryAddTaxIdNumber']")
	private  WebElement Bene_SSN;
	
	@FindBy(id="mainform:beneficiaryAddZipPostalCode")
	private  WebElement BeneZip;
	
	@FindBy(id="mainform:beneficiaryAddZipPostalCode4")
	private  WebElement BeneZipRemaining;
	
	@FindBy(id="mainform:beneficiaryAddState")
	private  WebElement BeneState;
	
	@FindBy(xpath = "//input[@id='mainform:beneficiaryUpdateEffectiveDate_input']")
    private static WebElement Effectivedate_Update_Benificery;
    
    @FindBy(xpath = "//select[@id='mainform:beneficiaryUpdateBenefRelationship']")
    private static WebElement BeneficieryUpdateRelation;
    
    @FindBy(id = "mainform:roleIndexQuickViewPresentationBenefRelationship")
    private static WebElement BeneficieryactualRelation;
    
    @FindBy(id ="mainform:updateParty")
    private static WebElement RoleUpdate;
    
    @FindBy(xpath = "//input[@id='mainform:directoryTransactionEffectiveDate_input']")
    private static WebElement Effectivedate_AddUpdate_Benificery;

    @FindBy(xpath = "//select[@id='mainform:directoryTransactionDirectoryTransactionTrxSegmentCurrentCountryCode']")
    private static WebElement BeneficieryCountry;
    

    @FindBy(id = "mainform:roleIndexQuickViewPresentationCountryCode")
    private static WebElement BeneficieryactualCountryCode;
    
    public void verifyBeneficieryCountrychange(String expectedcountry)
    {   
       Web.getDriver().switchTo().frame("quickFrame");
                    String actualrcountry=BeneficieryactualCountryCode.getText();
                    if(actualrcountry.equalsIgnoreCase(expectedcountry))
                    {
                                    Reporter.logEvent(Status.PASS,"Expected string ["+expectedcountry+" ]","Present in the Actual text [ " + actualrcountry + " ]", false);
                    }
    
                     else {
                                    Reporter.logEvent(Status.FAIL,"Expected string ["+expectedcountry+" ]","Present in the Actual text [ " + actualrcountry + " ]", true);
                    }
                    Web.getDriver().switchTo().defaultContent();
    }
     



    public void UpdateBeneficeryCountry(String country) {
                    Web.waitForElement(BeneficieryCountry);
                    Web.selectDropDownOption(BeneficieryCountry, country);
                    
                    
    }

    public void EnterEffectivedateAddUpdateBenificery(String effectivedate) {
                    Web.waitForElement(Effectivedate_AddUpdate_Benificery);
                    Web.setTextToTextBox(Effectivedate_AddUpdate_Benificery, effectivedate);
                    if (Effectivedate_AddUpdate_Benificery.getAttribute("value").equalsIgnoreCase(effectivedate)) {
                                    Reporter.logEvent(Status.PASS, "In Demographic page enter the Effective date",
                                                                    "the Effective date is[" + effectivedate + "] entered sucessfully", false);
                    } else {
                                    Reporter.logEvent(Status.FAIL, "In Demographic page enter the Effective date",
                                                                    "the Effective date is[" + effectivedate + "] not entered sucessfully", true);
                    }
    	}


    public void clickRoleUpdateButton() {
      
        Web.getDriver().switchTo().frame("quickFrame");
                    Web.waitForElement(RoleUpdate);
                    Web.clickOnElement(RoleUpdate);
                    Web.getDriver().switchTo().defaultContent();
    }

    
    public void verifyBeneficieryStatuschange(String expectedrelation)
    {   
      Web.getDriver().switchTo().frame("quickFrame");
                    String actualrelation=BeneficieryactualRelation.getText();
                    if(actualrelation.equalsIgnoreCase(expectedrelation))
                    {
                                    Reporter.logEvent(Status.PASS,"Expected string ["+expectedrelation+" ]","Present in the Actual text [ " + actualrelation + " ]", false);
                    }
    
                    else {
                                    Reporter.logEvent(Status.FAIL,"Expected string ["+expectedrelation+" ]","Present in the Actual text [ " + actualrelation + " ]", true);
                    }
                    Web.getDriver().switchTo().defaultContent();
    }

    public void UpdateBeneficeryRelation(String relation) {
        Web.waitForElement(BeneficieryUpdateRelation);
        Web.selectDropDownOption(BeneficieryUpdateRelation, relation);  
        
    }

	public void EnterEffectivedateUpdateBenificery(String effectivedate) {
        Web.waitForElement(Effectivedate_Update_Benificery);
        Web.setTextToTextBox(Effectivedate_Update_Benificery, effectivedate);
        if (Effectivedate_Update_Benificery.getAttribute("value").equalsIgnoreCase(effectivedate)) {
                        Reporter.logEvent(Status.PASS, "In Role page enter the Effective date",
                                                        "the Effective date is[" + effectivedate + "] entered sucessfully", false);
        } else {
                        Reporter.logEvent(Status.FAIL, "In Role page enter the Effective date",
                                                        "the Effective date is[" + effectivedate + "] not entered sucessfully", true);
        }
	}

	
	public void clickRolename() {
        
        Web.getDriver().switchTo().frame("quickFrame");
                    Web.waitForElement(Rolename);
                    Web.clickOnElement(Rolename);
                    Web.getDriver().switchTo().defaultContent();
    }

	  public void clickRoleChangeButton() {
          
          Web.getDriver().switchTo().frame("quickFrame");
                      Web.waitForElement(Rolechange);
                      Web.clickOnElement(Rolechange);
                      Web.getDriver().switchTo().defaultContent();
      }

	
  public void clickRoleaddbutton() {
	  
	   Web.getDriver().switchTo().frame("quickFrame");
		Web.waitForElement(AddRole);
		Web.clickOnElement(AddRole);
		Web.getDriver().switchTo().defaultContent();
	}
 
  public void selectbeneficery()
  {
	  Web.waitForElement(clickonBeneficiary);
	  Web.clickOnElement(clickonBeneficiary);
  }
 
  public void clickcontinuebutton()
  {
	  Web.waitForElement(clickContinuebutton);
	  Web.clickOnElement(clickContinuebutton);
  }

	
public void EnterEffectivedate(String effectivedate) {
		Web.waitForElement(Effectivedate_Benificery);
		Web.setTextToTextBox(Effectivedate_Benificery, effectivedate);
		if (Effectivedate_Benificery.getAttribute("value").equalsIgnoreCase(effectivedate)) {
			Reporter.logEvent(Status.PASS, "In Role page enter the Effective date",
					"the Effective date is[" + effectivedate + "] entered sucessfully", false);
		} else {
			Reporter.logEvent(Status.FAIL, "In Role page enter the Effective date",
					"the Effective date is[" + effectivedate + "] not entered sucessfully", true);
		}
	}

	
	

	

	public void SelectBeneficeryDetail(String relation,String type,String percent) {
		
		Web.waitForElement(BeneficieryRelation);
		Web.selectDropDownOption(BeneficieryRelation, relation);
		Web.waitForElement(BeneficieryType);
		Web.selectDropDownOption(BeneficieryType, type);
		Web.waitForElement(BeneficieryPercent);
		Web.setTextToTextBox(BeneficieryPercent, percent);
		
	}

	
	public void BeneficieryInformation(String RoleDOBtx, String Rolegendr,  String RoleCity,  String  state) {
        
        Web.waitForElement(Bene_FirstName);
        String firstname1 = Common.randomvaildFirstname();
        Web.setTextToTextBox(Bene_FirstName, firstname1);
        
         Assert.assertTrue(Bene_FirstName.getAttribute("value").contains(firstname1), "first name set with value [ :"+firstname1+"]");
        Reporter.logEvent(Status.PASS, "In Role page enter the Beneficiery FirstName", "the Beneficiery FirstName is["+firstname1+"] entered sucessfully", false);                          
        String LAstname = Common.randomvaildLastname();
        Web.setTextToTextBox(Bene_LastName, LAstname);   
        Common.NewRoleEnter.put("LastNm",firstname1);
        
        
        if(Bene_LastName.getAttribute("value").equalsIgnoreCase(LAstname)) {
                        Reporter.logEvent(Status.PASS, "In Role page enter the Beneficiery LastName", "the Beneficiery LastName is["+LAstname+"] entered sucessfully", false); 
         }
        else {
                        Reporter.logEvent(Status.FAIL, "In  Role page enter the Beneficiery LastName", "the Beneficiery LastName is["+LAstname+"] not entered sucessfully", true);
        }
        
         Web.setTextToTextBox(Bene_DOB, RoleDOBtx);
        Assert.assertTrue(Bene_DOB.getAttribute("value").contains(RoleDOBtx), "Date of birth set with value [ :"+RoleDOBtx+"]");
        Reporter.logEvent(Status.PASS, "In  Role page enter the Beneficiery Date of birth", "The Date of birth is["+ RoleDOBtx+"] entered sucessfully", false);                                          
         Web.selectDropDownOption(Bene_Gender, Rolegendr);
        String SSNnum = Common.generateSSN();                                         
        Web.setTextToTextBox(Bene_SSN, SSNnum);  
        Assert.assertTrue(Bene_SSN.getAttribute("value").contains(SSNnum), "SSN set with value [ :"+SSNnum+"]");
        Reporter.logEvent(Status.PASS, "In  Role page enter the Beneficiery SSN ", "SSN is["+SSNnum+"] entered sucessfully",false);
        String roleaddres1 = Common.AddressGenerator();
        Web.setTextToTextBox(Address, roleaddres1);                                                
        Assert.assertTrue(Address.getAttribute("value").contains(roleaddres1), "Gender with value [ :"+roleaddres1+"]");
        Reporter.logEvent(Status.PASS, "In  Role page enter the Beneficiery Address", "The Annuity Address is["+roleaddres1+"] entered sucessfully", false);
        Web.setTextToTextBox(BeneCity, RoleCity);      
        Assert.assertTrue(BeneCity.getAttribute("value").contains(RoleCity), "City set with value [ :"+RoleCity+"]");
        Reporter.logEvent(Status.PASS, "In  Role page enter the Beneficiery City", "The city is ["+RoleCity+"] entered sucessfully", true);
        String zip1 = Common.AutoZipcode();
        Web.setTextToTextBox(BeneZip, zip1);                
        Assert.assertTrue(BeneZip.getAttribute("value").contains(zip1), "Zip set with value [ :"+zip1+"]");
        Reporter.logEvent(Status.PASS, "In  Role page enter the Zip code", "Zip code is["+zip1+"] entered", false);                                                
        Web.selectDropDownOption(BeneState, state);
	}

	

	public void VerifyErrorText(String expectedtext) {
		try {
		Web.waitForElement(ErrorText);	
		String Expected = Stock.GetParameterValue("ErrorText");
		String Actual = ErrorText.getText();		
		Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
		Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		
	}
		catch (Exception e) {
			Reporter.logEvent(Status.FAIL,"Display Expected error text messaage","took Longer than normal", true);
			e.printStackTrace();
		}	
	}

	
public Role1(LoadableComponent<?> parent) {
	this.parent = new LandingPage();
	PageFactory.initElements(lib.Web.getDriver(), this);
}


LoadableComponent<?> parent;


	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(AddRole);
		Assert.assertTrue(Web.isWebElementDisplayed(AddRole), "Add Role  is Not Loaded\n");
	}

}
