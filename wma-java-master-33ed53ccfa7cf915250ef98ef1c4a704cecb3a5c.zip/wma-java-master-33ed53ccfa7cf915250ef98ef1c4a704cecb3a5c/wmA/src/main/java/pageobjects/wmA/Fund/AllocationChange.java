package pageobjects.wmA.Fund;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class AllocationChange extends LoadableComponent<AllocationChange>{
	
	@FindBy(id="mainform:allocationInquiryChangeEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	@FindBy(id="mainform:allocateBy")
	private static WebElement Allocateby_LB;
	
	@FindBy (id="realtimeselect")
	private  WebElement RealtimeDrpDwn;
	
	@FindBy (id="submitbutton")
	private  WebElement FinishButton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;
	
	@FindBy(id="overridebox")
	private static WebElement overidebox;
	 
	@FindBy (id="mainform:AllocationFund:1:allocationFundPercent")
	private  WebElement GrowthINV;
	
	@FindBy(xpath="//table[@id='mainform:AllocationFund']/tbody/tr")
    private  List<WebElement> CoveredFundrow;
	
	@FindBy(xpath=".//*[@id='mainform']/div[1]/table/tbody/tr[6]/td/div")
	private  WebElement Producerinfo;
	 
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
			

			// My Accounts
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtime")) {
				return this.RealtimeDrpDwn;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Finishbtn")) {
				return this.FinishButton;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtimewait")) {
				return this.Producerinfo;
			}
					

			Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	  
	  public void clickoverirde() {		  	
		  Web.waitForElement(overidebox);
		  Web.clickOnElement(overidebox);		 
	  }
	  
	  public void VerifyErrorText(String expectedtext) {
			try {
			Web.waitForElement(ErrorText);	
			String Expected = Stock.GetParameterValue("ErrorText");
			String Actual = ErrorText.getText();		
			Assert.assertTrue(ErrorText.getText().contains(Expected), "Error text verification");	
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
			
		}
			catch (Exception e) {
				Reporter.logEvent(Status.FAIL,"Display Expected error text messaage","took Longer than normal", true);
				e.printStackTrace();
			}	
		}
	
	public  void  entereffectivedate (String effectivedate) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Allocation Change page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Allocation Change page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, System.getProperty("TrxEffectiveDate"));
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("TrxEffectiveDate"))) {
				 Reporter.logEvent(Status.PASS, "In Allocation Change page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Allocation Change page enter the Effective date", "the Effective date is["+System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Allocation Change page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Allocation Change page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		
	}
	
	public void EnterRandomFundAllocation() {
		Web.waitForElement(GrowthINV);
		int tempNC =0;
		int temp =0;
		int colmn = 0;
		String allot = "Allocation Percent";
		String allotamt = "Allocation Amount";
		String Allotpercent = "25";
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th")).size();
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(allot)|| fud.equalsIgnoreCase(allotamt)) {
				colmn = i;
				break;
			}
		}
		
		for (int j=1; j<CoveredFundrow.size();j++) {
			if(!Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();
			}else if(Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
				break;
			}
		}
		for (int j=1; j<=4;j++) {
			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
			if(!str1.equalsIgnoreCase("c")) 
   			{
   				tempNC = tempNC + 1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Allotpercent);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Allotpercent+"] entered Successfully", false);					
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
   			}else if(str1.equalsIgnoreCase("c")) {
				temp = temp + 1;
				System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[5]")).getText());
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Allotpercent);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Allotpercent+"] entered Successfully", false);					
				Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
			}
		}
		
	}
	
	public  void enterfundMultiple() throws InterruptedException {
		Web.waitForElement(GrowthINV);
		
		int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ACCFfund"));
   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("ACNonCFfund"));
   		int tempNC =0;
   		int temp =0;
   		int cnt;
   		int colmn = 0;
   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th")).size();
   		String allot = "Allocation Percent";
		String allotamt = "Allocation Amount";
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(allot)|| fud.equalsIgnoreCase(allotamt)) {
				colmn = i;
				break;
			}
		}
   	if (Noncfundnumber >=1)	
   	{
   		for (int j=1; j<CoveredFundrow.size();j++)
   		{
   			cnt = j;
   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
   			if(!str1.equalsIgnoreCase("c")) 
   			{
   				tempNC = tempNC + 1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
   			}
   			
   			if(Noncfundnumber==tempNC)
			{
			break;
			}
   		}
   	}
   	else if(Noncfundnumber==0)
   	{
   		
   	}
   	else
   	{
   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
   	}
   		
	if (cfundnumber >=1)	
   	{	
		for (int i=1; i<CoveredFundrow.size();i++) {
			cnt = i;
			String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
			
					if(str.equalsIgnoreCase("c")) {
						temp = temp + 1;
						System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
						Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
						Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
						Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
					}
					if(cfundnumber==temp)
					{
					break;
					}
		}
   	}
	else if(cfundnumber==0)
   	{
   		
   	}
	else
	{
		Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
	}
   	
	}
	
	public  void enterfundMultipleExistingContract() throws InterruptedException {
		Web.waitForElement(GrowthINV);
	
		
		if(System.getProperty("FundNumber1")==null)
		{
			//********************************
			System.out.println("Fund NUmber is not given in the parameter");
			int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ACCFfund"));
	   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("ACNonCFfund"));
	   		int tempNC =0;
	   		int temp =0;
	   		int cnt;
	   		int colmn = 0;
	   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th")).size();
	   		String allot = "Allocation Percent";
			String allotamt = "Allocation Amount";
			for(int i=1;i<=num;i++) {
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th["+i+"]")).getText();
				if(fud.equalsIgnoreCase(allot)|| fud.equalsIgnoreCase(allotamt)) {
					colmn = i;
					break;
				}
			}
	   	if (Noncfundnumber >=1)	
	   	{
	   		for (int j=1; j<CoveredFundrow.size();j++)
	   		{
	   			cnt = j;
	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
	   			if(!str1.equalsIgnoreCase("c")) 
	   			{
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
	   			}
	   			
	   			if(Noncfundnumber==tempNC)
				{
				break;
				}
	   		}
	   	}
	   	else if(Noncfundnumber==0)
	   	{
	   		
	   	}
	   	else
	   	{
	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
	   	}
	   		
		if (cfundnumber >=1)	
	   	{	
			for (int i=1; i<CoveredFundrow.size();i++) {
				cnt = i;
				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
				
						if(str.equalsIgnoreCase("c")) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
						}
						if(cfundnumber==temp)
						{
						break;
						}
			}
	   	}
		else if(cfundnumber==0)
	   	{
	   		
	   	}
		else
		{
			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
		}
			
		}
		else if( System.getProperty("FundNumber1").trim().length() > 0)
		{
		//create a code for fund number
		
			
	   		int tempNC =0;
	   		int temp =0;
	   		int cnt;
	   		int colmn = 0;
	   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th")).size();
	   		String allot = "Allocation Percent";
			String allotamt = "Allocation Amount";
			for(int i=1;i<=num;i++) {
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th["+i+"]")).getText();
				if(fud.equalsIgnoreCase(allot)|| fud.equalsIgnoreCase(allotamt)) {
					colmn = i;
					break;
				}
			}
			for (int j=1; j<CoveredFundrow.size();j++) {
				if(!Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();
				}else if(Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
					break;
				}
			}
			
			boolean Passflag; 
			boolean skip = false;
			for (int k=1; k<=5; k++)
			{
				Passflag = false;
				if(skip)
				{
					break;
				}
			
			
	   	
			for (int j=1; j<CoveredFundrow.size();j++)
	   		{
				
	   			cnt = j;
	   			if(System.getProperty("FundNumber"+k)==null)
					
				{
					skip = true;
					Passflag = true;
					break;
				}else {
					
				}
	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
	   			String FundNumber = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText();
	   			if(!str1.equalsIgnoreCase("c") && FundNumber.equalsIgnoreCase(System.getProperty("FundNumber"+k))) 
	   			{
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(System.getProperty("FundAllocation"+k));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("FundAllocation"+k)+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					break;
	   			} else if(str1.equalsIgnoreCase("c") && FundNumber.equalsIgnoreCase(System.getProperty("FundNumber["+k+"]"))) {
					temp = temp + 1;
					System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[5]")).getText());
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(System.getProperty("FundAllocation"+k));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ System.getProperty("FundAllocation"+k)+"] entered Successfully", false);					
					Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
					break;
				}
	   			
	   			
	   		}
		
			
		
	   	
			}
			
			
			
			}						
		else {
			//********************************
			System.out.println("Fund NUmber is not given in the parameter & Not availble in aruguments");
			int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ACCFfund"));
	   		int Noncfundnumber = Integer.parseInt(Stock.GetParameterValue("ACNonCFfund"));
	   		int tempNC =0;
	   		int temp =0;
	   		int cnt;
	   		int colmn = 0;
	   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th")).size();
	   		String allot = "Allocation Percent";
			String allotamt = "Allocation Amount";
			for(int i=1;i<=num;i++) {
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/thead/tr[1]/th["+i+"]")).getText();
				if(fud.equalsIgnoreCase(allot)|| fud.equalsIgnoreCase(allotamt)) {
					colmn = i;
					break;
				}
			}
	   	if (Noncfundnumber >=1)	
	   	{
	   		for (int j=1; j<CoveredFundrow.size();j++)
	   		{
	   			cnt = j;
	   			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[4]")).getText();
	   			if(!str1.equalsIgnoreCase("c")) 
	   			{
	   				tempNC = tempNC + 1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+j+"]/td[1]")).getText());
	   			}
	   			
	   			if(Noncfundnumber==tempNC)
				{
				break;
				}
	   		}
	   	}
	   	else if(Noncfundnumber==0)
	   	{
	   		
	   	}
	   	else
	   	{
	   		Reporter.logEvent(Status.FAIL, "Test Data for NonCoveredFund is ","Less than 1", false);
	   	}
	   		
		if (cfundnumber >=1)	
	   	{	
			for (int i=1; i<CoveredFundrow.size();i++) {
				cnt = i;
				String str = Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[4]")).getText();
				
						if(str.equalsIgnoreCase("c")) {
							temp = temp + 1;
							System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[5]")).getText());
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
							Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(Stock.GetParameterValue("Allocation"+cnt));
							Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Stock.GetParameterValue("Allocation"+cnt)+"] entered Successfully", false);					
							Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:AllocationFund']/tbody/tr["+i+"]/td[1]")).getText());
						}
						if(cfundnumber==temp)
						{
						break;
						}
			}
	   	}
		else if(cfundnumber==0)
	   	{
	   		
	   	}
		else
		{
			Reporter.logEvent(Status.FAIL, "Test Data for CoveredFund is ","Less than 1", false);
		}
			
		}
		
		
		
   	
	}

	
	public AllocationChange(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Effectivedate_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate_TB),"Allocation Change Page is Not Loaded\n");
	}

}
