package pageobjects.wmA.Accumulation;





import lib.Reporter;
import lib.Stock;
import lib.Web;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import appUtils.Common;
import com.aventstack.extentreports.Status;
public class LoginPagewmA extends LoadableComponent<LoginPagewmA> {

	// Object Declarations
	@FindBy(id = "mainform:userId")
	private WebElement userId;
	@FindBy(id = "mainform:userPassword")
	private WebElement Password;
	@FindBy(id = "mainform:loginAction")
	private WebElement btnLogin;
	
	@FindBy(linkText = "Accumulation")
	
	private WebElement ContractAdd;
	
	@FindBy(id="mainform:environment")
	private WebElement envi;
	
	public void selectenvironment(String env) {
		Web.selectDropDownOption(envi, env);
	}


	
	LoadableComponent<?> parent;
	@SuppressWarnings("unused")
	private String username;
	@SuppressWarnings("unused")
	private String password;
	private String url = null;

	public LoginPagewmA() {
		// this.parent = parent;
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	public LoginPagewmA(String username, String password) {
		this.username = username;
		this.password = password;
		PageFactory.initElements(lib.Web.getDriver(), this);
	}


	@Override
	protected void load() {
		
		url = Stock.getConfigParam("AppURL" + "_"

                                        + Stock.getConfigParam("TEST_ENV"));
		
			  Web.getDriver().get(url);
			
	}
		
	/**
	 * Method to enter user credentials and click on Sign In button
	 * 
	 * @param userName
	 * @param password
	 */
	

	public void submitLoginCredentials(String userName, String password, String env) {
		try {
		Web.waitForElement(userId);
			Web.setTextToTextBox(this.userId, userName);
		Reporter.logEvent(Status.PASS, userName,
				"Entered", false);
		Web.setTextToTextBox(this.Password, password);
		Reporter.logEvent(Status.PASS, password,
				"Entered", false);			
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		this.btnLogin.click();
		Common.waitForProgressBar();
		Web.waitForPageToLoad(Web.getDriver());

		try {
			Thread.sleep(4000);
			Reporter.logEvent(Status.PASS, "Login Button",
					"Clicked", false);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Assert.assertTrue(Web.isWebElementDisplayed(Password),"Login Page is Not Loaded\n");	
		
	}


}


