package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import lib.Reporter;
import lib.Web;

public class PaymentAdd extends LoadableComponent<PaymentAdd>{
	
	@FindBy (id="mainform:premiumPaymentMemoCode")
	private static WebElement MemoCode;
	
	@FindBy (id="mainform:premiumPaymentPaymentAmount")
	private static WebElement PaymentAmount;
	
	@FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
	
	public PaymentAdd(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	public void PaymentAmount(String payamount) {
		
		if(System.getProperty("PaymentAmount")==null)
		{
			Web.waitForElement(PaymentAmount);
			 Web.setTextToTextBox(PaymentAmount, payamount);
		}
		else if( System.getProperty("PaymentAmount").trim().length() > 0)
		{
			Web.waitForElement(PaymentAmount);
			Web.setTextToTextBox(PaymentAmount, System.getProperty("PaymentAmount").trim());	
								
		}else {
			Web.waitForElement(PaymentAmount);
			 Web.setTextToTextBox(PaymentAmount, payamount);
		}
	//	 Web.setTextToTextBox(PaymentAmount, payamount);	
		 Reporter.logEvent(Status.PASS, "In the Payment Add page enter the Payment Amount"," the Payment Amount is ["+ payamount+"] entered successfully", false);
	}	
	public void MemoCode(String memo) {
		 Web.selectDropDownOption(MemoCode, memo);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(PaymentAmount);
		Assert.assertTrue(Web.isWebElementDisplayed(PaymentAmount),"Login Page is Not Loaded\n");
	
	}

}
