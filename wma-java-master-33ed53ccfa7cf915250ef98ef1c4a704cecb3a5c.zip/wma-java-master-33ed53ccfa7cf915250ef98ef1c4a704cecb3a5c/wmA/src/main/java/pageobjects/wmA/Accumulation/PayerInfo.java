
package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class PayerInfo extends LoadableComponent<PayerInfo>{
	
	
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryOwnerDataCompanyIndivCode']")
	private  WebElement Ownerinfo_IndivCode;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryOwnerDataPrefix']")
	private  WebElement Ownerinfo_Prefix;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataFirstName']")
	private  WebElement Payerinfo_Firstname;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataLastName']")
	private  WebElement Payerinfo_Lastname;
	
	@FindBy(xpath="//input[@id='mainform:partyorsearch']")
	private  WebElement Payerinfo_PartySearch;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataName']")
	private  WebElement Payerinfo_Corporation;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryPayorDataSexCode']")
	private  WebElement Payerinfo_Gender;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataBirthdate_input']")
	private  WebElement Payerinfo_DOB;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataAddressLine1']")
	private  WebElement Payerinfo_Residentaddress;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataCity']")
	private  WebElement Payerinfo_City;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryPayorDataState']")
	private  WebElement Payerinfo_state;
	
	@FindBy(xpath="//select[@id='mainform:contractEntryContractEntryPayorDataCountryCode']")
	private  WebElement Payerinfo_Country;
	
	@FindBy(xpath="//input[@id='mainform:contractEntryContractEntryPayorDataZipPostalCode']")
	private  WebElement Payerinfo_Zipcode;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(id="mainform:contractEntryContractEntryPayorDataTaxIdNumber")
	private static WebElement taxid_TB;
	
	public void payerinfodetails(String Gentype,String DOB,String city,String state) {
		Web.waitForElement(Payerinfo_Firstname);
		String Fnames = Common.randomvaildFirstname();
		Web.setTextToTextBox(Payerinfo_Firstname, Fnames);
		if(Payerinfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Payer Info page Enter the payer First name", "The payer First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payer Info page Enter the payer First name", "The payer First name is ["+ Fnames+"] entered Successfully", true);
		}
		Web.waitForElement(Payerinfo_Lastname);
		String Lnames = Common.randomvaildLastname();
		Web.setTextToTextBox(Payerinfo_Lastname, Lnames);
		if(Payerinfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the payer Last name", "The payer Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the owner Last name", "The payer Last name is ["+ Lnames+"] entered Successfully", true);
		}
		Web.waitForElement(Payerinfo_Gender);
		Web.selectDropDownOption(Payerinfo_Gender, Gentype);
		Web.waitForElement(taxid_TB);
		String ssn = Common.generateSSN();
		Web.setTextToTextBox(taxid_TB, ssn);
		Web.waitForElement(Payerinfo_DOB);		
		Web.setTextToTextBox(Payerinfo_DOB, DOB);
		if(Payerinfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the DOB", "The payerDOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the  DOB", "The payer DOB is ["+ DOB+"] entered Successfully", true);
		}
		Web.waitForElement(Payerinfo_Residentaddress);	
		String address = Common.AddressGenerator();
		Web.setTextToTextBox(Payerinfo_Residentaddress, address);
		if(Payerinfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the address", "The payer address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfopage Enter the address", "The payer address is ["+ address+"] entered Successfully", true);
		}
		
		 if(System.getProperty("City")==null)
			{
				Web.waitForElement(Payerinfo_City);
				 Web.setTextToTextBox(Payerinfo_City, city);
			}
			else if( System.getProperty("City").trim().length() > 0)
			{
				Web.waitForElement(Payerinfo_City);
				Web.setTextToTextBox(Payerinfo_City, System.getProperty("City").trim());	
									
			}else {
				Web.waitForElement(Payerinfo_City);
				 Web.setTextToTextBox(Payerinfo_City, city);
			}
		 
		 Web.waitForElement(Payerinfo_Zipcode);	
		 String Zip = Common.AutoZipcode();
		 Web.setTextToTextBox(Payerinfo_Zipcode, Zip);
			
			if(Payerinfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
				 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the Zipcode", "The payer Zipcode is ["+ Zip+"] entered Successfully", false);	
			}
			else {
				 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the Zipcode", "The payer Zipcode is ["+ Zip+"] entered Successfully", true);
			}
		
			if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(Payerinfo_state);
				 Web.selectDropDownOption(Payerinfo_state, state);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(Payerinfo_state);
				//Web.selectDropDownOption(AnnuityState, System.getProperty("IssueState").trim());
				Common.selectbyvalues(Payerinfo_state, System.getProperty("IssueState").trim());										
			}else {
				Web.waitForElement(Payerinfo_state);
				 Web.selectDropDownOption(Payerinfo_state, state);
			}
		
	}
	
	public void EnterPayerinfoFirstname(String Fnames) {
		Web.waitForElement(Payerinfo_Firstname);		
		Web.setTextToTextBox(Payerinfo_Firstname, Fnames);
		if(Payerinfo_Firstname.getAttribute("value").equalsIgnoreCase(Fnames)) {
			 Reporter.logEvent(Status.PASS, " In Payer Info page Enter the payer First name", "The payer First name is ["+ Fnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payer Info page Enter the payer First name", "The payer First name is ["+ Fnames+"] entered Successfully", true);
		}
	}

	
	public void EnterPayerinfoLastname(String Lnames) {
		Web.waitForElement(Payerinfo_Lastname);		
		Web.setTextToTextBox(Payerinfo_Lastname, Lnames);
		if(Payerinfo_Lastname.getAttribute("value").equalsIgnoreCase(Lnames)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the payer Last name", "The payer Lastname is ["+ Lnames+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the owner Last name", "The payer Last name is ["+ Lnames+"] entered Successfully", true);
		}
	}
	
	public void SelectPayerinfoGender(String Gentype)
	
	{
		Web.waitForElement(Payerinfo_Gender);
		Web.selectDropDownOption(Payerinfo_Gender, Gentype);
	}
	
	public void EnterPayerinfoDOB(String DOB) {
		Web.waitForElement(Payerinfo_DOB);		
		Web.setTextToTextBox(Payerinfo_DOB, DOB);
		if(Payerinfo_DOB.getAttribute("value").equalsIgnoreCase(DOB)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the DOB", "The payerDOB is ["+ DOB+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the  DOB", "The payer DOB is ["+ DOB+"] entered Successfully", true);
		}
	}
	
	
	public void EnterPayerinfoaddress(String address) {
		Web.waitForElement(Payerinfo_Residentaddress);		
		Web.setTextToTextBox(Payerinfo_Residentaddress, address);
		if(Payerinfo_Residentaddress.getAttribute("value").equalsIgnoreCase(address)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the address", "The payer address is ["+ address+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfopage Enter the address", "The payer address is ["+ address+"] entered Successfully", true);
		}
	}
	
	
	public void EnterPayerinfocity(String city) {
		Web.waitForElement(Payerinfo_City);		
		Web.setTextToTextBox(Payerinfo_City, city);
		if(Payerinfo_City.getAttribute("value").equalsIgnoreCase(city)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the city", "The payer city is ["+ city+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the city", "The payer city is ["+ city+"] entered Successfully", true);
		}
	}
	
	
	public void EnterPayerinfozip(String Zip) {
		Web.waitForElement(Payerinfo_Zipcode);		
		Web.setTextToTextBox(Payerinfo_Zipcode, Zip);
		if(Payerinfo_Zipcode.getAttribute("value").equalsIgnoreCase(Zip)) {
			 Reporter.logEvent(Status.PASS, " In Payerinfo page Enter the Zipcode", "The payer Zipcode is ["+ Zip+"] entered Successfully", false);	
		}
		else {
			 Reporter.logEvent(Status.FAIL, " In Payerinfo page Enter the Zipcode", "The payer Zipcode is ["+ Zip+"] entered Successfully", true);
		}
	}
	
public void SelectPayerinfoState(String state)
	
	{
		Web.waitForElement(Payerinfo_state);
		Web.selectDropDownOption(Payerinfo_state, state);
	}

public void SelectOwnerInfoCountry(String country)

{
	Web.waitForElement(Payerinfo_Country);
	Web.selectDropDownOption(Payerinfo_Country, country	);
}
	
	public PayerInfo(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		Web.waitForElement(Payerinfo_Firstname);
		Assert.assertTrue(Web.isWebElementDisplayed(Payerinfo_Firstname),"Payerinfo Page is Not Loaded\n");
	
	}

}
