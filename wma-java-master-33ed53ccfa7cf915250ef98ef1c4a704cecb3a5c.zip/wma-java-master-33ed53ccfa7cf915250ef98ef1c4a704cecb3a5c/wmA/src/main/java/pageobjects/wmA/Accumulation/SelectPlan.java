package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class SelectPlan extends LoadableComponent<SelectPlan> {
	
	@FindBy(id="mainform:contractEntryPlanCode")
	private WebElement baseplan;
	
	@FindBy(id="mainform:contractEntryCashWithAppCode")
	private WebElement CashCheckbox;
	
	
	@FindBy(id="mainform:contractEntryStatutoryCompanyCode")
	private WebElement StatutoryCompcode;
	
	@FindBy(id="mainform:contractEntryPartnerCompensationOptionDe")	
	private  WebElement lineofbusinesswait;
	
	@FindBy(id="mainform:contractEntryLineOfBusiness")
	private WebElement LineofBusiness;
	
	@FindBy(id="mainform:contractEntryResidentState")
	private WebElement residentstate;
	
    @FindBy(id="mainform:contractEntryPartnerCompensationOption")
    private WebElement compes;
    
    @FindBy(xpath="//select[@id=\"mainform:contractEntryStatutoryCompanyCode\"]/option[2]")   
    private  WebElement waitforstatutoryco;
    
    @FindBy (id="mainform:hccInd")
    private  WebElement AddRaiderCheckbox;
    
    @FindBy(id= "iconform:mainIcon")
	private static WebElement homebutton;
    
    @SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		
		if (fieldName.trim().equalsIgnoreCase("Base_plan")) {
			return this.baseplan;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Statutory_Company")) {
			return this.StatutoryCompcode;
		}
		
		if (fieldName.trim().equalsIgnoreCase("waitobj")) {
			return this.waitforstatutoryco;
		}
		
		if (fieldName.trim().equalsIgnoreCase("waitobj_lineofbusiness")) {
			return this.lineofbusinesswait;
		}

		if (fieldName.trim().equalsIgnoreCase("Line_biz")) {
			return this.LineofBusiness;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Resi_state")) {
			return this.residentstate;
		}
		
		if (fieldName.trim().equalsIgnoreCase("ClickOnriderbox")) {
			return this.AddRaiderCheckbox;
		}
		
		if (fieldName.trim().equalsIgnoreCase("ClickOnCashCheckbox")) {
			return this.CashCheckbox;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void selectcompensationoption(String opt) {
		Web.selectDropDownOption(compes,opt);
		Reporter.logEvent(Status.PASS, "In the Select Plan page select the Compensation option  ",  "the Compensation option is["+ opt+"] selected successfully", false);
	}
	
	public void addraidercheckbox() throws InterruptedException {
	
		Web.clickOnElement(AddRaiderCheckbox);
		Reporter.logEvent(Status.PASS, "In the Select Plan page click on Check box  ", " The Check box is successfully selected", false);
	}
		
	
	public void EnterSelectPlanEntries(String baseplancode, String Company, String lineofBusiness, String ResidentState)
	{
		
		try {
			
		if(System.getProperty("PlanCode")==null)
		{
			Web.waitForElement(baseplan);
			 Web.selectDropDownOption(baseplan, baseplancode);
			
		}
		else if( System.getProperty("PlanCode").trim().length() > 0)
		{
			Web.waitForElement(baseplan);
			Web.selectDropDownOption(baseplan, System.getProperty("PlanCode").trim());
		
			
			
								
		}else {
			Web.waitForElement(baseplan);
			 Web.selectDropDownOption(baseplan, baseplancode);
		}
		
		if(System.getProperty("StatutoryCompany")==null)
		{
			Web.waitForElement(waitforstatutoryco);
			 Web.selectDropDownOption(StatutoryCompcode, Company);
		}
		else if( System.getProperty("StatutoryCompany").trim().length() > 0)
		{
			Web.waitForElement(waitforstatutoryco);		
			Web.selectDropDownOption(StatutoryCompcode, System.getProperty("StatutoryCompany").trim());	
								
		}else {
			Web.waitForElement(waitforstatutoryco);
			 Web.selectDropDownOption(StatutoryCompcode, Company);
		}
		
		if(System.getProperty("LineofBusiness")==null)
		{
			Web.waitForElement(LineofBusiness);
			 Web.selectDropDownOption(LineofBusiness, lineofBusiness);
		}
		else if( System.getProperty("LineofBusiness").trim().length() > 0)
		{
			Web.waitForElement(LineofBusiness);				
			Common.selectbyvalues(LineofBusiness, System.getProperty("LineofBusiness").trim());					
		}else {
			Web.waitForElement(LineofBusiness);
			 Web.selectDropDownOption(LineofBusiness, lineofBusiness);
		}
		
		 /*Web.waitForElement(baseplan);
		 Web.selectDropDownOption(baseplan, baseplancode);	
		 Web.waitForElement(waitforstatutoryco);
		 Web.selectDropDownOption(StatutoryCompcode, Company);	
		 Web.waitForElement(LineofBusiness);
		 Web.selectDropDownOption(LineofBusiness, lineofBusiness);*/
		 Web.waitForElement(lineofbusinesswait);
		 
		 if(System.getProperty("IssueState")==null)
			{
				Web.waitForElement(residentstate);
				 Web.selectDropDownOption(residentstate, ResidentState);
			}
			else if( System.getProperty("IssueState").trim().length() > 0)
			{
				Web.waitForElement(residentstate);
			//	Web.selectDropDownOption(residentstate, System.getProperty("IssueState").trim());	
				Common.selectbyvalues(residentstate, System.getProperty("IssueState").trim());					
			}else {
				Web.waitForElement(residentstate);
				 Web.selectDropDownOption(residentstate, ResidentState);
			}
		 
		/* Web.waitForElement(residentstate);
		 Web.selectDropDownOption(residentstate, ResidentState);*/
		 Web.waitForElement(residentstate);	
		 
			 
			 if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null)
				{
					/*Web.waitForElement(residentstate);
					 Web.selectDropDownOption(residentstate, ResidentState);*/
				 System.out.println("Rider Check box not Clicked for this test case");
				}
			/* else if(Stock.GetParameterValue("RiderType") == null) {
				 System.out.println("Rider Check box not Clicked for this test case");
			 }*/
				else if( System.getProperty("RiderType") !=null || Stock.GetParameterValue("RiderType") != null)
				{
					if( System.getProperty("RiderType") !=null &&System.getProperty("RiderType").trim().length()>0 ) {
						Web.waitForElement(AddRaiderCheckbox);
						Web.clickOnElement(AddRaiderCheckbox);
						 System.out.println("rider is available for this test case runing through parameter");
					}else if(Stock.GetParameterValue("RiderType") != null && Stock.GetParameterValue("RiderType").length()>0){
						Web.waitForElement(AddRaiderCheckbox);
						Web.clickOnElement(AddRaiderCheckbox);
						 System.out.println("rider is available for this test case runing through test data");
					}
				/*	Web.waitForElement(AddRaiderCheckbox);
					Web.clickOnElement(AddRaiderCheckbox);
					 System.out.println("rider is available for this test case");*/
				}else {
					 System.out.println("Rider Check box not Clicked for this test case");
				}
			 
		 } 
		 catch(Exception e)
		 {
			 Reporter.logEvent(Status.FAIL, "Ecxception ", e.toString(), true); 
		 }
		/* if(System.getProperty("RiderType")==null && Stock.GetParameterValue("RiderType") == null)
			{
				Web.waitForElement(residentstate);
				 Web.selectDropDownOption(residentstate, ResidentState);
			 System.out.println("Rider Check box not Clicked for this test case");
			}
			else if( System.getProperty("RiderType").trim().length() > 0 || Stock.GetParameterValue("RiderType").endsWith("W"))
			{
				Web.waitForElement(residentstate);
			//	Web.selectDropDownOption(residentstate, System.getProperty("IssueState").trim());	
				Common.selectbyvalues(residentstate, System.getProperty("IssueState").trim());
				Web.waitForElement(AddRaiderCheckbox);
				Web.clickOnElement(AddRaiderCheckbox);
				 System.out.println("rider is available for this test case");
			}else {
				 System.out.println("Rider Check box not Clicked for this test case");
			}*/
		 
	}
	
	public void cashcheckbox() {
		Web.waitForElement(CashCheckbox);
		Web.clickOnElement(CashCheckbox);
	
	}
	

	public SelectPlan(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {

		Web.waitForElement(baseplan);
		Assert.assertTrue(Web.isWebElementDisplayed(baseplan),"Login Page is Not Loaded\n");
	
	}

	
}

