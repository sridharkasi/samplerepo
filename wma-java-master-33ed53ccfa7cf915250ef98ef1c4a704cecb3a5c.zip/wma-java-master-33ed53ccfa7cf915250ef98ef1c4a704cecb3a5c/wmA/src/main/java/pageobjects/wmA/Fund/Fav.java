package pageobjects.wmA.Fund;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import lib.Reporter;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class Fav extends LoadableComponent<Fav>{
	
	@FindBy(id="mainform:favUpdateEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	@FindBy(id="mainform:favUpdateToFavCode")
	private static WebElement FavCode_LB;
	
	public void SelectFAVCode(String fa) {
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(FavCode_LB);
		Web.selectDropDownOption(FavCode_LB, fa	);
	}
	
	public void EnterEffectivedate(String eff) {
		Web.waitForElement(Effectivedate_TB);
		Web.setTextToTextBox(Effectivedate_TB, eff);
		if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(eff)) {
			 Reporter.logEvent(Status.PASS, "In Fav page enter the Effective date", "the Effective date is["+eff+"] entered sucessfully", false);
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Fav page enter the Effective date", "the Effective date is["+eff+"]Not entered sucessfully", false);
		}
		Effectivedate_TB.sendKeys(Keys.TAB);
	}
	
	public void seteffectivedateFavcode(String effdate) throws InterruptedException {
	       
	       if(System.getProperty("FavEffectDate")==null)
	              {
	              Web.waitForElement(Effectivedate_TB);
	              Web.setTextToTextBox(Effectivedate_TB, effdate);
	              if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effdate))
	                      Reporter.logEvent(Status.PASS, "In Fav Code page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
	              else
	                      Reporter.logEvent(Status.FAIL, "In  Fav Code page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
	              }
	              else if( System.getProperty("FavEffectDate").trim().length() > 0)
	              {
	                     Web.waitForElement(Effectivedate_TB);
	                     Web.setTextToTextBox(Effectivedate_TB, System.getProperty("FavEffectDate").trim());
	                            
	                  if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("FavEffectDate").trim()))
	                           Reporter.logEvent(Status.PASS, "In  Fav Code page enter the Effective date", "the Effective date is["+System.getProperty("FavEffectDate").trim()+"] entered sucessfully", false);
	                     else
	                           Reporter.logEvent(Status.FAIL, "In  Fav Code page enter the Effective date", "the Effective date is["+System.getProperty("FavEffectDate").trim()+"] Not entered sucessfully", false);
	                                                       
	              }else {
	                     Web.waitForElement(Effectivedate_TB);
	              Web.setTextToTextBox(Effectivedate_TB, effdate);
	              if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effdate))
	                           Reporter.logEvent(Status.PASS, "In  Fav Code page enter the Effective date", "the Effective date is["+effdate+"] entered sucessfully", false);
	                     else
	                           Reporter.logEvent(Status.FAIL, "In  Fav Code page enter the Effective date", "the Effective date is["+effdate+"] Not entered sucessfully", false);
	              }
	       

	       }


	public Fav(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());		
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(Effectivedate_TB);
		Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate_TB),"Allocation Change Page is Not Loaded\n");
	}

}
