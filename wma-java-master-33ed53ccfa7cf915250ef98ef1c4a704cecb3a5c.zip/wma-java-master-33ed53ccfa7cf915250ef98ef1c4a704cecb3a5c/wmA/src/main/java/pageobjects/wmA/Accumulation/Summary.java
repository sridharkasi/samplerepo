package pageobjects.wmA.Accumulation;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;
import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;

public class Summary extends LoadableComponent<Summary>{
	
	@FindBy (id="realtimeselect")
	private  WebElement RealtimeDrpDwn;
	
	@FindBy (id="finishbutton")
	private  WebElement FinishButton;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;
	
	@FindBy (id="mainform:summaryPolicyNumber")
	private  WebElement Policynumber;
	
	@FindBy(id= "iconform:mainIcon")
	private  WebElement homebutton;
	
	@FindBy(xpath=".//*[@id='mainform']/div[1]/table/tbody/tr[6]/td/div")
	private  WebElement Producerinfo;
	
	@FindBy(xpath=".//*[@id='mainform']/div[1]/table/tbody/tr/td/a")
	private WebElement Navigatebutton;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[1]")
	private static WebElement syswithdrawal;
	
	@FindBy(id="submitbutton")
	private WebElement SubmitButton;
	
	@FindBy(xpath = "//li[@id='disbursements']/div/a[contains(text(),'Full Surrender')]")

    private static WebElement Full_Surrender_LK;



	
	@FindBy(id="accum_Fund_Processing")private WebElement fund;
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
			

			// My Accounts
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtime")) {
				return this.RealtimeDrpDwn;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_NavigateButton")) {
				return this.Navigatebutton;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Fund")) {
				return this.fund;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtimewait")) {
				return this.Producerinfo;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Finishbtn")) {
				return this.FinishButton;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Submitbtn")) {
				return this.SubmitButton;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Homebtn")) {
				return this.homebutton;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Overide_Button")) {
				return this.overidebox;
			}
			
			Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	 @FindBy(id="overridebox")
	  private  WebElement overidebox;
	  
	  public void clickoverirde() {
		  
		 // Web.waitForElement(ErrorText);
		  try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  Web.waitForElement(overidebox);
		  Web.clickOnElement(overidebox);
		  if(overidebox.isSelected()){
				
			  Reporter.logEvent(Status.PASS, "In Systematic Withdrawal information page Click on override button ", "the Override button is clicked sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Systematic Withdrawal information page Click on override button", "the Override button is not clicked sucessfully", true);
			 }
	  }
	 
	  public void VerifyErrorText(String expectedtext) {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Web.waitForElement(ErrorText);	
			String Expected = expectedtext;
			String Actual = ErrorText.getText();
			if(ErrorText.getText().contains(Expected)){
				Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
			}else {
				Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
			}
		}
	
	public void clicksystematicwithdrawal () {
		Web.waitForElement(syswithdrawal);
		Web.clickOnElement(syswithdrawal);
	//	syswithdrawal.click();
		//Web.clickOnElement(syswithdrawal);
		
		
	}
	

	public void clickfullsurrender() {

        Web.waitForElement(Full_Surrender_LK);

      Common.ClickSubmenu(Full_Surrender_LK);

  }
	
	public void getpolicynumber() {
		//Policynumber.getText();
		try {
		lib.Reporter
		.logEvent(
				Status.PASS,
				"Contract Add Policy Number: ",
				Policynumber.getText(),
				true);
	}
		catch (Exception e) {
			e.printStackTrace();
		}	
		Common.Contractinfo.put("Contractid", Policynumber.getText());
	}
	
	public Summary(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}


	@Override
	protected void isLoaded() throws Error {
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(FinishButton);
		//Web.waitForElement(Summary_Finishbtn);
		Assert.assertTrue(Web.isWebElementDisplayed(FinishButton),"Summary Page is Not Loaded\n");
		
	}

}
