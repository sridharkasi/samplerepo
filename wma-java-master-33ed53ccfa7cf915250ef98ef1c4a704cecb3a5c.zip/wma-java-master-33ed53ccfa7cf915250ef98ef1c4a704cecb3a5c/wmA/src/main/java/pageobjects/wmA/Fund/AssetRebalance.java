package pageobjects.wmA.Fund;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class AssetRebalance extends LoadableComponent<AssetRebalance>{
	
	@FindBy(id="mainform:rebalanceAddEffectiveDate_input")
	private static WebElement Effectivedate_TB;
	
	@FindBy(id="mainform:rebalanceAddRebalancingFrequency")
	private static WebElement TransferFrequency_LB;
	
	@FindBy(id="mainform:rebalanceAddRebalanceStartDate_input")
	private static WebElement RebalanceStartdate_TB;
	
	@FindBy(id="mainform:rebalanceAddFinalRebalanceDate_input")
	private static WebElement FinalRebalanceDate_TB;
	
	@FindBy (id="errorMessages")
	private  WebElement ErrorText;
	
	@FindBy (id="realtimeselect")
	private  WebElement RealtimeDrpDwn;
	
	@FindBy (id="submitbutton")
	private  WebElement FinishButton;
	
	@FindBy(xpath="//table[@id='mainform:UnscheduledFunds']/tbody/tr") 
	private  List<WebElement> OneTimeAssetrebalanceFundRow;
	
	@FindBy(xpath="//table[@id='mainform:ScheduledFunds']/tbody/tr") 
	private  List<WebElement> AssetrebalanceFundRow;
	
	@FindBy(id="overridebox")
	private static WebElement overidebox;
	
	@FindBy(id="mainform:rebalanceUpdateEffectiveDate_input")
	private static WebElement ChangeEffectivedate_TB;
	
	@FindBy(id="mainform:rebalanceUpdateNextRebalanceDate_input")
	private static WebElement Nextpayoutdate_TB;
	
	@FindBy(id="mainform:rebalanceUpdateActionCode")
	private static WebElement SelectAction_LB;
	
	@FindBy(id="mainform:rebalanceUpdateRebalancingStatus")
	private static WebElement RebalanceStatus;
	
	@FindBy(id="mainform:rebalanceAddUnsRebalanceDate_input")
	private static WebElement UnscheduledDate_TB;
	
	@FindBy(id="mainform:rebalanceUpdateUnsRebalanceDate_input")
	private static WebElement UpdateUnscheduledDate_TB;
	
	@FindBy(id="mainform:rebalanceAddCreateAllocChgUnschedInd")
	private static WebElement AllocationChangeUnschedule_CB;
	
	@FindBy(id="mainform:refresh_Table")
	private static WebElement RefreshButton;
	
	
	
	public void ClickOnRefreshButton(){
		Web.waitForElement(RefreshButton);
		Web.clickOnElement(RefreshButton);
		Web.getDriver().manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	public void ClickOnAllocationChangeButton() {
		Web.waitForElement(AllocationChangeUnschedule_CB);
		Web.clickOnElement(AllocationChangeUnschedule_CB);
	}
	
	public void GetNextRebalanceDate() {
		String Ndate = Nextpayoutdate_TB.getAttribute("value");
		Common.Contractinfo.put("NextPayoutDate", Ndate);
	}
	
	public void verifyRebalanceStatus() {
		Web.waitForElement(RebalanceStatus);
		String status = "t";
		if(RebalanceStatus.getText().equalsIgnoreCase(status)) {
			 Reporter.logEvent(Status.PASS, "In Asset rebalance page Execpected the Status is ["+status+"]", "the Actual status is["+RebalanceStatus.getText()+"] presented in Asset rebalance page", false);
		}
		else {
			 Reporter.logEvent(Status.FAIL, "In Asset rebalance page Execpected the Status is ["+status+"]", "the Actual status is["+RebalanceStatus.getText()+"] Not presented in Asset rebalance page", false);
		}
	}
	  
	  public void clickoverirde() {
		  
		 
		  Web.waitForElement(overidebox);
		  Web.clickOnElement(overidebox);
		  
	  }
	 
	
	 @SuppressWarnings("unused")
		private WebElement getWebElement(String fieldName) {
			

			// My Accounts
			if (fieldName.trim().equalsIgnoreCase("Summary_Realtime")) {
				return this.RealtimeDrpDwn;
			}
			
			if (fieldName.trim().equalsIgnoreCase("Summary_Finishbtn")) {
				return this.FinishButton;
			}
			
			Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
					+ fieldName + "'",
					"No WebElement mapped for this field\nPage: <b>"
							+ this.getClass().getName() + "</b>", false);

			return null;
		}
	
	public void SelectAction(String act) {
		String Action=null;
		
		if(System.getProperty("SelectAction")==null)
		{
			Web.waitForElement(SelectAction_LB);
			Web.selectDropDownOption(SelectAction_LB,act);
		}
		else if( System.getProperty("SelectAction").trim().length() > 0)
		{
			if(System.getProperty("SelectAction").toLowerCase().contains("add")) {
				Action = "A";
			}
			else if (System.getProperty("SelectAction").toLowerCase().contains("term")) {
				Action = "T";
			}
			else if (System.getProperty("SelectAction").toLowerCase().contains("change")) {
				Action = "C";
			}else
			{
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the correct ", "Select Action "+Action, true);
				 return;
			}
			Web.waitForElement(SelectAction_LB);
			Common.selectbyvalues(SelectAction_LB,Action);
								
		}else {
			Web.waitForElement(SelectAction_LB);
			Web.selectDropDownOption(SelectAction_LB,act);
		}
		
		
	}
	
	public void EnterEffectivedate(String effectivedate) {
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB,  System.getProperty("TrxEffectiveDate"));
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase( System.getProperty("TrxEffectiveDate"))) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(Effectivedate_TB);
			Web.setTextToTextBox(Effectivedate_TB, effectivedate);
			 if(Effectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		
		
	}
	
	public void EnterOneTimeEffectivedate(String effectivedate) {
		Web.waitForElement(UnscheduledDate_TB);
		Web.setTextToTextBox(UnscheduledDate_TB, effectivedate);
		 if(UnscheduledDate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
			 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterUpdateOneTimeEffectivedate(String effectivedate) {
		Web.waitForElement(UpdateUnscheduledDate_TB);
		Web.setTextToTextBox(UpdateUnscheduledDate_TB, effectivedate);
		 if(UpdateUnscheduledDate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
			 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
		 }
		 else {
			 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
		 }
	}
	
	public void EnterChangeEffectivedate(String effectivedate) {
		
		if(System.getProperty("TrxEffectiveDate")==null)
		{
			Web.waitForElement(ChangeEffectivedate_TB);
			Web.setTextToTextBox(ChangeEffectivedate_TB, effectivedate);
			 if(ChangeEffectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("TrxEffectiveDate").trim().length() > 0)
		{
			Web.waitForElement(ChangeEffectivedate_TB);
			Web.setTextToTextBox(ChangeEffectivedate_TB,  System.getProperty("TrxEffectiveDate"));
			 if(ChangeEffectivedate_TB.getAttribute("value").equalsIgnoreCase( System.getProperty("TrxEffectiveDate"))) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+ System.getProperty("TrxEffectiveDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(ChangeEffectivedate_TB);
			Web.setTextToTextBox(ChangeEffectivedate_TB, effectivedate);
			 if(ChangeEffectivedate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Effective date", "the Effective date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		
		
	
	}
	
	public void EnterNextpayoutdate(String effectivedate) {
		if(System.getProperty("NextPayoutDate")==null)
		{
			Web.waitForElement(Nextpayoutdate_TB);
			Web.setTextToTextBox(Nextpayoutdate_TB, effectivedate);
			 if(Nextpayoutdate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("NextPayoutDate").trim().length() > 0)
		{
			Web.waitForElement(Nextpayoutdate_TB);
			Web.setTextToTextBox(Nextpayoutdate_TB, System.getProperty("NextPayoutDate"));
			 if(Nextpayoutdate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("NextPayoutDate"))) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+System.getProperty("NextPayoutDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+System.getProperty("NextPayoutDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(Nextpayoutdate_TB);
			Web.setTextToTextBox(Nextpayoutdate_TB, effectivedate);
			 if(Nextpayoutdate_TB.getAttribute("value").equalsIgnoreCase(effectivedate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+effectivedate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Next payout date", "the Next payout date is["+effectivedate+"] not entered sucessfully", true);
			 }
		}
	
	}
	
	public void SelectTransferFrequency(String Transfer) {
		
		String Transferfrq = null;
		
		if(System.getProperty("TransferFrequency")==null)
		{
			Web.waitForElement(TransferFrequency_LB);
			Web.selectDropDownOption(TransferFrequency_LB, Transfer);
		}
		else if( System.getProperty("TransferFrequency").trim().length() > 0)
		{
			if(System.getProperty("TransferFrequency").toLowerCase().contains("anniversarydateannual")) {
				Transferfrq = "AP";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("anniversarydatemonthly")) {
				Transferfrq = "MP";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("anniversarydatequarterly")) {
				Transferfrq = "QP";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("AnniversarydateSemiAnnual")) {
				Transferfrq = "SP";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("annually")) {
				Transferfrq = "01";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("calendaryearannual")) {
				Transferfrq = "AC";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("calendaryearmonthly")) {
				Transferfrq = "MC";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("calendaryearquarterly")) {
				Transferfrq = "QC";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("calendaryearsemiannual")) {
				Transferfrq = "SC";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("monthly")) {
				Transferfrq = "12";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("Quarterly")) {
				Transferfrq = "04";
			}
			else if (System.getProperty("TransferFrequency").toLowerCase().contains("semiannually")) {
				Transferfrq = "02";
			}
			else
			{
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the correct ", "Transfer Frequency "+Transferfrq, true);
				 return;
			}
			Web.waitForElement(TransferFrequency_LB);
			Common.selectbyvalues(TransferFrequency_LB, Transferfrq);			
		}else {
			Web.waitForElement(TransferFrequency_LB);
			Web.selectDropDownOption(TransferFrequency_LB, Transfer);
		}
		
		
	}
	
	public void EnterRebalanceStartDate (String Startdate) {
		if(System.getProperty("RebalanceStartDate")==null)
		{
			Web.waitForElement(RebalanceStartdate_TB);
			Web.setTextToTextBox(RebalanceStartdate_TB, Startdate);
			 if(RebalanceStartdate_TB.getAttribute("value").equalsIgnoreCase(Startdate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Start date", "the Start date is["+Startdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Start date", "the Start date is["+Startdate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("RebalanceStartDate").trim().length() > 0)
		{
			Web.waitForElement(RebalanceStartdate_TB);
			Web.setTextToTextBox(RebalanceStartdate_TB, System.getProperty("RebalanceStartDate"));
			 if(RebalanceStartdate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("RebalanceStartDate"))) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Start date", "the Start date is["+System.getProperty("RebalanceStartDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Start date", "the Start date is["+System.getProperty("RebalanceStartDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(RebalanceStartdate_TB);
			Web.setTextToTextBox(RebalanceStartdate_TB, Startdate);
			 if(RebalanceStartdate_TB.getAttribute("value").equalsIgnoreCase(Startdate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Start date", "the Start date is["+Startdate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Start date", "the Start date is["+Startdate+"] not entered sucessfully", true);
			 }
		}
		
		
	}
	
	public void EnterFinalRebalanceDate(String Ldate) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(System.getProperty("RebalanceFinalDate")==null)
		{
			Web.waitForElement(FinalRebalanceDate_TB);
			Web.setTextToTextBox(FinalRebalanceDate_TB, Ldate);
			 if(FinalRebalanceDate_TB.getAttribute("value").equalsIgnoreCase(Ldate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Last date", "the Last date is["+Ldate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Last date", "the Last date is["+Ldate+"] not entered sucessfully", true);
			 }
		}
		else if( System.getProperty("RebalanceFinalDate").trim().length() > 0)
		{
			Web.waitForElement(FinalRebalanceDate_TB);
			Web.setTextToTextBox(FinalRebalanceDate_TB, System.getProperty("RebalanceFinalDate"));
			 if(FinalRebalanceDate_TB.getAttribute("value").equalsIgnoreCase(System.getProperty("RebalanceFinalDate"))) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Last date", "the Last date is["+System.getProperty("RebalanceFinalDate")+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Last date", "the Last date is["+System.getProperty("RebalanceFinalDate")+"] not entered sucessfully", true);
			 }
								
		}else {
			Web.waitForElement(FinalRebalanceDate_TB);
			Web.setTextToTextBox(FinalRebalanceDate_TB, Ldate);
			 if(FinalRebalanceDate_TB.getAttribute("value").equalsIgnoreCase(Ldate)) {
				 Reporter.logEvent(Status.PASS, "In Asset rebalance page enter the Last date", "the Last date is["+Ldate+"] entered sucessfully", false); 
			 }
			 else {
				 Reporter.logEvent(Status.FAIL, "In Asset rebalance page enter the Last date", "the Last date is["+Ldate+"] not entered sucessfully", true);
			 }
		}
		
	
	}
	
	public void VerifyErrorText(String expectedtext) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Web.waitForElement(ErrorText);	
		String Expected = expectedtext;
		String Actual = ErrorText.getText();
		if(ErrorText.getText().contains(Expected)){
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}else {
			Reporter.logEvent(Status.FAIL,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
	}
//***********************************************************************************************************************************************************************************************
	 /* Method : EnterAllocationrebalance(String inv)
		 * purpose : Used in Asset rebalance test cases Newrebalance,Change rebalance,Terminate test case **
		 * 
		 */ 
	 public void EnterOneTimeAllocationrebalance(String inv) {
			try
			{
				Thread.sleep(2000);
			}
			catch(Exception e)
			{
				
			}
		//	int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ARCFfund"));
	   		int Noncfundnumber = 
	   			Integer.parseInt(Stock.GetParameterValue("ARNonCFfund")) +
	   			Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
	   		String temp;
	   		String Currentrepercent = "0.0%";
	   		int tempNC=0;
	   		int colmn = 0;
	   		int sz =Common.NonCFund.size();
	   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:UnscheduledFunds']/thead/tr[2]/th")).size();
	   		String UNallot = "Uns Allocation Percent";
	   		String allot = "Allocation";
	   		
	   		
			for(int i=1;i<=num;i++) {
				String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/thead/tr[2]/th["+i+"]")).getText();
				if(fud.equalsIgnoreCase(allot) || fud.equalsIgnoreCase(UNallot)) {
					colmn = i;
					break;
				}
			}
	   		
	   		if (Noncfundnumber >=1)	
	   		
	   		for (int i=1; i<OneTimeAssetrebalanceFundRow.size();i++) {
	   			String fudn = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/thead/tr[2]/th["+colmn+"]")).getText();
	   			String Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[1]")).getText();
	   			String CurrentrebalancePercentage = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[4]")).getText();
	   			CurrentrebalancePercentage = CurrentrebalancePercentage.replace("%", "").trim();
	   			Currentrepercent = Currentrepercent.replace("%", "").trim();
	   			
				if((CurrentrebalancePercentage == null) || CurrentrebalancePercentage.contains(Stock.GetParameterValue("Assetrebalance_percent")) && (fudn.equalsIgnoreCase(UNallot))){
					 
	   				tempNC = tempNC + 1;
	   				sz=sz+1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
					//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
					temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
	   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
	   				
					}
	   			
	   			else	if ( Common.NonCFund.get("NonNCFund"+i)==null || !Common.NonCFund.get("NonNCFund"+i).equals(Tabledata)) {
	   				tempNC = tempNC + 1;
	   				sz=sz+1;
	   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
					Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
					Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
					//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
					Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
					temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
	   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
	   			}
	   			else if ( Common.NonCFund.get("NonNCFund"+i).trim().equalsIgnoreCase(Tabledata))
	   			{
	   				tempNC = tempNC + 1;
	   				temp = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value");
	   				temp =temp.replace("%", "");
	   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
	   				//RBFundPRC
	   			}
	   			

	   			if(Noncfundnumber==(tempNC))
				{
				break;
				}
	   		}
	   		
		}
//******************************************************************************************************************************
	 /* Method : EnterAllocationrebalance(String inv)
		 * purpose : Used in Asset rebalance test cases Newrebalance,Change rebalance,Terminate test case **
		 * 
		 */ 
	public void EnterAllocationrebalance(String inv) {
		try
		{
			Thread.sleep(4000);
		}
		catch(Exception e)
		{
			
		}
	//	int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ARCFfund"));
   		int Noncfundnumber = 
   			Integer.parseInt(Stock.GetParameterValue("ARNonCFfund")) +
   			Integer.parseInt(Stock.GetParameterValue("NonCFfund"));
   		String temp;
   		String Currentrepercent = "0.0%";
   		int tempNC=0;
   		int colmn = 0;
   		int sz =Common.NonCFund.size(); 
   		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th")).size();
   		String allot = "Allocation";
		
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(allot)) {
				colmn = i;
				break;
			}
		}
   		
   		if (Noncfundnumber >=1)	
   			
   		
   		for (int i=1; i<AssetrebalanceFundRow.size();i++) {
   			String Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText();
   			String CurrentrebalancePercentage = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[5]")).getText();
   			if(CurrentrebalancePercentage.equals(Currentrepercent)) {
   				tempNC = tempNC + 1;
   				sz=sz+1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
				//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
				temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
   			}
   			else	if ( Common.NonCFund.get("NonNCFund"+i)==null || !Common.NonCFund.get("NonNCFund"+i).equals(Tabledata)) {
   				tempNC = tempNC + 1;
   				sz=sz+1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
				//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
				temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
   			}
   			else if ( Common.NonCFund.get("NonNCFund"+i).trim().equalsIgnoreCase(Tabledata))
   			{
   				tempNC = tempNC + 1;
   				temp = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value");
   				temp =temp.replace("%", "");
   				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
   				//RBFundPRC
   			}
   			

   			if(Noncfundnumber==(tempNC))
			{
			break;
			}
   		}
   		
	}
//***************************************************************************************************************************************************************
	 /* Method : EnterAllocationrebalance(String inv)
	 * purpose : Used in Asset rebalance test cases Newrebalance,Change rebalance,Terminate test case **
	 * 
	 */ 
public void EnterRandomonetimerebalance_Econtract() {
	try
	{
		Thread.sleep(4000);
	}
	catch(Exception e)
	{
		
	}
//	int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ARCFfund"));
		int Noncfundnumber = 2;
		String temp;
		String Currentrepercent = "0.0%";
		int tempNC=0;
		int colmn = 0;
		String inv = "50";
		int sz =Common.NonCFund.size(); 
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:UnscheduledFunds']/thead/tr[2]/th")).size();
		String allot = "Allocation";
	
	for(int i=1;i<=num;i++) {
		String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/thead/tr[2]/th["+i+"]")).getText();
		if(fud.equalsIgnoreCase(allot)) {
			colmn = i;
			break;
		}
	}
		
		if (Noncfundnumber >=1)	
			
		
		for (int i=1; i<AssetrebalanceFundRow.size();i++) {
			String Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[1]")).getText();
			String CurrentrebalancePercentage = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[5]")).getText();
			if(CurrentrebalancePercentage.equals(Currentrepercent)) {
				tempNC = tempNC + 1;
				sz=sz+1;
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
			Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
			//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
			}
			else	if ( Common.NonCFund.get("NonNCFund"+i)==null ||! Common.NonCFund.get("NonNCFund"+i).equals(Tabledata)) {
				tempNC = tempNC + 1;
				sz=sz+1;
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
			Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
			//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
			}
			else if ( Common.NonCFund.get("NonNCFund"+i).trim().equalsIgnoreCase(Tabledata))
			{
				tempNC = tempNC + 1;
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
				temp = Web.getDriver().findElement(By.xpath("//table[@id='mainform:UnscheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value");
				temp =temp.replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
				//RBFundPRC
			}
			

			if(Noncfundnumber==(tempNC))
		{
		break;
		}
		}
		
}
//**********************************************************************************************************************************************************************************
	/* Method : EnterAllocationrebalance(String inv)
	 * purpose : Used in Asset rebalance test cases Newrebalance,Change rebalance,Terminate test case **
	 * 
	 */ 
public void EnterRandomAllocationrebalance_Econtract() {
	try
	{
		Thread.sleep(4000);
	}
	catch(Exception e)
	{
		
	}
//	int cfundnumber = Integer.parseInt(Stock.GetParameterValue("ARCFfund"));
		int Noncfundnumber = 2;
		String temp;
		String Currentrepercent = "0.0%";
		int tempNC=0;
		int colmn = 0;
		String inv = "50";
		int sz =Common.NonCFund.size(); 
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th")).size();
		String allot = "Allocation";
	
	for(int i=1;i<=num;i++) {
		String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th["+i+"]")).getText();
		if(fud.equalsIgnoreCase(allot)) {
			colmn = i;
			break;
		}
	}
		
		if (Noncfundnumber >=1)	
			
		
		for (int i=1; i<AssetrebalanceFundRow.size();i++) {
			String Tabledata = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText();
			String CurrentrebalancePercentage = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[5]")).getText();
			if(CurrentrebalancePercentage.equals(Currentrepercent)) {
				tempNC = tempNC + 1;
				sz=sz+1;
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
			Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
			//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
			}
			else	if ( Common.NonCFund.get("NonNCFund"+i)==null ||! Common.NonCFund.get("NonNCFund"+i).equals(Tabledata)) {
				tempNC = tempNC + 1;
				sz=sz+1;
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
			Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
			Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ inv+"] entered Successfully", false);					
			//Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td[1]")).getText());
			temp =  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
			}
			else if ( Common.NonCFund.get("NonNCFund"+i).trim().equalsIgnoreCase(Tabledata))
			{
				tempNC = tempNC + 1;
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).sendKeys(inv);
				temp = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+i+"]/td["+colmn+"]/input")).getAttribute("value");
				temp =temp.replace("%", "");
				Common.RBFundPRC.put("NonNCFund"+tempNC, temp);
				//RBFundPRC
			}
			

			if(Noncfundnumber==(tempNC))
		{
		break;
		}
		}
		
}
//**********************************************************************************************************************************************************************************
	public void EnterRandomFundAllocation() {
		try
		{
			Thread.sleep(4000);
		}
		catch(Exception e)
		{
			
		}
		int tempNC =0;
		int temp =0;
		int colmn = 0;
		String allot = "Allocation";
	
		String Allotpercent = "25";
		int num = Web.getDriver().findElements(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th")).size();
		for(int i=1;i<=num;i++) {
			String fud = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/thead/tr[2]/th["+i+"]")).getText();
			if(fud.equalsIgnoreCase(allot)) {
				colmn = i;
				break;
			}
		}
		
	/*	for (int j=1; j<AssetrebalanceFundRow.size();j++) {
			if(!Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();
			}else if(Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").isEmpty()) {
				break;
			}
		}*/
		
		for (int j=1; j<=4;j++) {
			String str1 = Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td[4]")).getText();
			if(!str1.equalsIgnoreCase("c")) 
   			{
   				tempNC = tempNC + 1;
   				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Allotpercent);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Allotpercent+"] entered Successfully", false);					
				Common.NonCFund.put("NonNCFund"+tempNC, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td[1]")).getText());
				Common.NonCFundinfo.put("NonCovPercet"+tempNC,  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", ""));
   			}else if(str1.equalsIgnoreCase("c")) {
				temp = temp + 1;
				System.out.println(" table C "+Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td[5]")).getText());
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).clear();						
				Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).sendKeys(Allotpercent);
				Reporter.logEvent(Status.PASS, "In the Fund info page enter the fund Percentage","the fund Percentage is["+ Allotpercent+"] entered Successfully", false);					
				Common.CovFund.put("CovFundNumb"+temp, Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td[1]")).getText());
				Common.CovFundinfo.put("CovPercet"+tempNC,  Web.getDriver().findElement(By.xpath("//table[@id='mainform:ScheduledFunds']/tbody/tr["+j+"]/td["+colmn+"]/input")).getAttribute("value").replace("%", ""));
			}
		}
		
	}
	
	/* Method : ClearHashmapvalues()
	 * purpose : Used in Asset rebalance test cases to clear all the hash map values **
	 * 
	 */ 
	public void ClearHashmapvalues() {
		Common.NonCFund.clear();
		Common.RBFundPRC.clear();
		Common.GawFundPRC.clear();
		Common.CovFund.clear();
	}
	 
	public AssetRebalance(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}

	LoadableComponent<?> parent;
	@Override
	protected void load() {
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());	
	}

	@Override
	protected void isLoaded() throws Error {		
				Web.waitForElement(Effectivedate_TB);
				Assert.assertTrue(Web.isWebElementDisplayed(Effectivedate_TB),"Allocation Change Page is Not Loaded\n");
	}

}
