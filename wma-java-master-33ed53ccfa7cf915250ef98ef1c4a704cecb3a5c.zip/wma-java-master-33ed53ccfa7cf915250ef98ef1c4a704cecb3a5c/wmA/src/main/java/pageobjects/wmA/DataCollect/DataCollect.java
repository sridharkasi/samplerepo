package pageobjects.wmA.DataCollect;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import org.openqa.selenium.support.FindBy;

import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;

public class DataCollect extends LoadableComponent<DataCollect>{
	
	@FindBy(id="iconform:dataCollectIcon")
	private WebElement datacollect;
	
	@FindBy(id="mainform:searchButton")
	private static WebElement searchbtn;
	
	@FindBy(id="mainform:Index:0:indexTrxTypeDisplay")
	private WebElement OEdisplay;
	
	@SuppressWarnings("unused")
	private WebElement getWebElement(String fieldName) {
		

		
		if (fieldName.trim().equalsIgnoreCase("DataCollectIcon")) {
			return this.datacollect;
		}
		
		if (fieldName.trim().equalsIgnoreCase("Fundtransfertext")) {
			return this.OEdisplay;
		}
		
		Reporter.logEvent(Status.WARNING, "Get WebElement for field '"
				+ fieldName + "'",
				"No WebElement mapped for this field\nPage: <b>"
						+ this.getClass().getName() + "</b>", false);

		return null;
	}
	
	public void VerifyFundtransfer(String exptext) {
		try {
			Web.waitForElement(OEdisplay);
			String Expected = Stock.GetParameterValue("Verifytransaction");
			String Actual = OEdisplay.getText();
			Assert.assertTrue(OEdisplay.getText().contains(Expected), "Fund transfer verification");
			Reporter.logEvent(Status.PASS,"Expected string ["+Expected+" ]","Present in the Actual text [ " + Actual + " ]", false);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public DataCollect(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}
	
	LoadableComponent<?> parent;
	@Override
	protected void load() {
		// TODO Auto-generated method stub
		this.parent.get();
		Web.waitForPageToLoad(Web.getDriver());
	}

	@Override
	protected void isLoaded() throws Error {
		// TODO Auto-generated method stub
		Web.waitForElement(datacollect);
		Assert.assertTrue(Web.isWebElementDisplayed(datacollect),"Data Collect Page is Not Loaded\n");
	}

}
