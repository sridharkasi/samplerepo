package pageobjects.wmA.Role;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.Random;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import appUtils.Common;
import lib.Reporter;
import lib.Stock;
import lib.Web;
import pageobjects.wmA.Accumulation.LandingPage;
import pageobjects.wmA.General.General;

public class Party extends LoadableComponent<Party> {
	
	@FindBy(xpath = "//li[@id='PartyHistory_ID']/a")
	private static WebElement PartyHistory;
	
	
	public void clickPartyhistorysubmenu() {
		Web.waitForElement(PartyHistory);
		Common.ClickSubmenu(PartyHistory);

		
	}
	
	public Party(LoadableComponent<?> parent) {
		this.parent = new LandingPage();
		PageFactory.initElements(lib.Web.getDriver(), this);
	}


	LoadableComponent<?> parent;


		@Override
		protected void load() {
			this.parent.get();
			Web.waitForPageToLoad(Web.getDriver());
		}

		@Override
		protected void isLoaded() throws Error {
			Web.waitForElement(PartyHistory);
			Assert.assertTrue(Web.isWebElementDisplayed(PartyHistory), "PartyHistory  is Not Loaded\n");
		}

}
