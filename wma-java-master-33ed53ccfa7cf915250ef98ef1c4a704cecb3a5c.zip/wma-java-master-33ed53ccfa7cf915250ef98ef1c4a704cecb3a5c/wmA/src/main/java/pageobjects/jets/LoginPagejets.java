package pageobjects.jets;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.LoadableComponent;
import org.testng.Assert;

import appUtils.Common;
import lib.Stock;
import lib.Web;

public class LoginPagejets extends LoadableComponent<LoginPagejets>{
		
		@FindBy(id = "loginUserName")
		private WebElement userId;
		
		@FindBy(id = "loginPassword")
		private WebElement userpass;
		
		@FindBy(id = "login")
		private WebElement loginbtn;
		
		@FindBy(linkText = "Source Sytem Data")
		private WebElement sourceLink;

		@FindBy(xpath = ".//*[@id='jets2menu2_jets2menu1_jets2menu0']/span")
		private WebElement submenu;
		
		@FindBy(id = "contractIndexInquiryRequestSearchCriteriaContractNumber_input")
		private WebElement contrnum;
		
		@FindBy(id = "search")
		private WebElement searchbtn;
		
		@FindBy(id="contractIndexInquiryResponseContracts:0:contractNumber")
		private WebElement contrtablenum;
		
		LoadableComponent<?> parent;
		@SuppressWarnings("unused")
		private String username;
		@SuppressWarnings("unused")
		private String password;
		private String url = null;
		
		public LoginPagejets() {
			// this.parent = parent;
			PageFactory.initElements(lib.Web.getDriver(), this);
		}
		
		public LoginPagejets(String username, String password) {
			this.username = username;
			this.password = password;
			PageFactory.initElements(lib.Web.getDriver(), this);
		}

		
		@Override
		protected void load() {
			// TODO Auto-generated method stub
				
			url = Stock.getConfigParam("JetsURL" + "_"

	                                        + Stock.getConfigParam("TEST_ENV"));
			System.out.println(url);
			  Web.getDriver().get(url);
		
		}
		
		public void clickcontratinquiry() {
			Common.ClickSubmenu(submenu);
			
			
		
		}
		
		public void ContractNumber(String contractnum) {
			 Web.setTextToTextBox(contrnum, contractnum);		
		}
		
		public void cilcksearch() throws InterruptedException {
			searchbtn.click();
			Thread.sleep(1000);
		}
		
		public void contracttable() {
			String table=contrtablenum.getText();
			System.out.println(table);
					
		}
		
		public void submitLoginCredentials(String userName, String password) {
			try {
			Web.setTextToTextBox(this.userId, userName);
			Thread.sleep(2000);
			Web.setTextToTextBox(this.userpass, password);
				
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			this.loginbtn.click();
			Common.waitForProgressBar();
			Web.waitForPageToLoad(Web.getDriver());

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
		@Override
		protected void isLoaded() throws Error {
			// TODO Auto-generated method stub
			Assert.assertTrue(Web.isWebElementDisplayed(userpass),"Login Page is Not Loaded\n");
			
		}

}

